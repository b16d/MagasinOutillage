package com.sfeir.photo_gallery_api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PhotoGalleryApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
