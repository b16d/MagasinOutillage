# Lab 11: Prompt Engineering Workshop

**Duration**: 30 minutes
**Module**: 1 - Introduction to AI for Developers

## Objective

Compare three different prompting approaches on the same algorithm task to understand how prompt quality affects AI output.

## The Task

You will ask an AI to generate code for a **data transformation function** that:

- Takes a list of objects with `name` and `score` properties
- Filters objects where score >= 70
- Sorts remaining objects by score (descending)
- Returns only the names as a list

**Example**:

```javascript
Input: [
  { name: 'Alice', score: 85 },
  { name: 'Bob', score: 65 },
  { name: 'Charlie', score: 92 },
  { name: 'Diana', score: 70 },
];

Output: ['Charlie', 'Alice', 'Diana'];
```

## Choose Your Language

The task is deliberately language-agnostic. **Pick the language you work in every day** — you will judge the AI's output far better on familiar ground, and that judgement is the point of this lab.

Throughout the exercises, replace `JavaScript` in the example prompts with your language. The reference solution covers three:

| Language      | Reference solution                                                  |
| ------------- | ------------------------------------------------------------------- |
| JavaScript/TS | `labs/lab-11-prompt-engineering-solution/README.md`                 |
| **Python**    | `labs/lab-11-prompt-engineering-solution/resources/prompts/python/` |
| **Java**      | `labs/lab-11-prompt-engineering-solution/resources/prompts/java/`   |

The input shape adapts to the language: dictionaries in Python, records in Java, object literals in JavaScript. The three prompts and the three observations stay identical.

## Prerequisites Checklist

Before starting, ensure you have:

- [ ] **AI Tool Access**: Account and active session on at least one AI coding tool:
  - [ChatGPT (chat.openai.com)](https://chat.openai.com) - Free tier works
  - [Claude (claude.ai)](https://claude.ai) - Free tier works
  - [Gemini (gemini.google.com)](https://gemini.google.com) - Free tier works
  - [GitHub Copilot Chat (github.com/copilot)](https://github.com/copilot) - Requires subscription
  - Cursor IDE - Free tier works
- [ ] **Internet Connection**: Stable connection for AI API calls
- [ ] **Code Editor**: Any editor to test generated code (VS Code, WebStorm, IntelliJ IDEA, PyCharm)
- [ ] **A way to run the generated code**, matching your chosen language:
  - **JavaScript/TypeScript**: browser developer console, or Node.js 22+
  - **Python**: Python 3.12+ (`pytest` optional, for the Exercise 3 test cases)
  - **Java**: JDK 17+ (`jshell` is enough for Exercises 1-2; JUnit 5 for Exercise 3)

**Offline Fallback**: If internet is unavailable, use the pre-generated examples in `labs/lab-11-prompt-engineering-solution/` to complete the reflection exercise.

---

## The 5 Prompting Techniques

This lab uses 5 progressive techniques for effective prompting:

| #   | Technique            | Description                                           |
| --- | -------------------- | ----------------------------------------------------- |
| 1   | **Role**             | Assign a persona (e.g., "You are a senior developer") |
| 2   | **Context**          | Provide background and requirements                   |
| 3   | **Format**           | Specify desired output structure                      |
| 4   | **Few-Shot**         | Show input/output examples                            |
| 5   | **Chain-of-Thought** | Request step-by-step reasoning                        |

Each exercise builds on the previous, adding more techniques.

> **Visual Reference**: See the techniques diagram in the module slides (from repo root: `docs/assets/images/10_module_1/prompting-techniques.svg`)

---

## Exercise 1: Basic Prompting (~8 minutes)

### Approach

Use a simple, direct prompt with minimal structure.

### Your Prompt

Write a prompt using **only techniques 1-2** (Role + Context):

```
[Your prompt here - keep it simple and direct]
```

**Example structure** (swap `JavaScript` for your own language — here and in every following exercise):

```
You are a JavaScript developer.
Write a function that filters and sorts a list of objects by score.
```

### Steps

1. Send your basic prompt to your AI tool
2. Copy the generated code
3. Test it with the example input (paste into your browser console, Node.js REPL, or a code editor terminal)
4. Document the result below

### Results

**Generated Code**:

```
[Paste the AI's code here]
```

**Observations**:

- Did it work correctly?
- What was missing or unclear in the output?
- How much follow-up was needed?

---

> 💡 Remember to **clear your current session** before starting the new exercise!
>
> Type "/clear" then <kbd>ENTER</kbd> from within your current AI session or simply start a new terminal from this lab folder

## Exercise 2: Structured Prompting (~8 minutes)

### Approach

Add output format specification to your prompt.

### Your Prompt

Write a prompt using **techniques 1-3** (Role + Context + Format):

```
[Your prompt here - add role, context, and format specification]
```

**Example structure**:

```
You are a senior JavaScript developer.

I need a function that processes student scores:
- Input: Array of objects with 'name' (string) and 'score' (number)
- Filter: Keep only scores >= 70
- Sort: By score, highest first
- Output: Array of names only

Please provide:
- The function code
- Brief inline comments
- Example usage
```

### Steps

1. Send your structured prompt to your AI tool
2. Copy the generated code
3. Test it with the example input
4. Compare to Exercise 1

### Results

**Generated Code**:

```
[Paste the AI's code here]
```

**Observations**:

- How did the output differ from Exercise 1?
- Was the code better documented?
- Did specifying format help?

---

> 💡 Remember to **clear your current session** before starting the new exercise!
>
> Type "/clear" then <kbd>ENTER</kbd> from within your current AI session or simply start a new terminal from this lab folder

## Exercise 3: Advanced Prompting (~9 minutes)

> 💡 Remember to **clear your current session** before starting the new exercise!
>
> Type "/clear" then <kbd>ENTER</kbd> from within your current AI session or simply start a new terminal from this lab folder

### Approach

Use all 5 techniques including examples and chain-of-thought.

### Your Prompt

Write a prompt using **all 5 techniques**:

```
[Your prompt here - include role, context, format, example, and reasoning request]
```

**Example structure**:

```
You are a senior JavaScript developer specializing in data transformations.

## Task
Create a function to process student assessment data.

## Requirements
- Filter students with passing scores (>= 70)
- Sort by score in descending order
- Return only student names

## Example
Input:
[{ name: "Alice", score: 85 }, { name: "Bob", score: 65 }]

Expected Output:
["Alice"]

## Instructions
1. First, think through the steps needed
2. Then implement the function
3. Include error handling for edge cases
4. Add static types if your language supports them
5. Provide test cases

## Output Format
- Function code with comments
- Brief explanation of approach
- 2-3 test cases
```

### Steps

1. Send your advanced prompt to your AI tool
2. Copy the generated code
3. Test it with the example input
4. Compare to Exercises 1 and 2

### Results

**Generated Code**:

```
[Paste the AI's code here]
```

**Observations**:

- How did the output differ from previous exercises?
- Did chain-of-thought improve the solution?
- Was error handling included?

---

## Reflection (~5 minutes)

### Compare Your Results

| Aspect           | Exercise 1 | Exercise 2 | Exercise 3 |
| ---------------- | ---------- | ---------- | ---------- |
| Code correctness |            |            |            |
| Documentation    |            |            |            |
| Error handling   |            |            |            |
| Test coverage    |            |            |            |
| Follow-up needed |            |            |            |

### Key Learnings

1. **Which technique made the biggest difference?**

   [Your answer]

2. **When would you use each approach?**
   - Basic prompting: [Your answer]
   - Structured prompting: [Your answer]
   - Advanced prompting: [Your answer]

3. **What will you do differently in your daily work?**

   [Your answer]

---

## Troubleshooting

| Issue                    | Solution                                                                                         |
| ------------------------ | ------------------------------------------------------------------------------------------------ |
| **API Rate Limit**       | Wait 1-2 minutes, or switch to a different AI tool                                               |
| **Authentication Error** | Re-login to your AI tool, clear cookies if needed                                                |
| **Model Unavailable**    | Try a different model or tier (e.g., Opus → Sonnet, GPT-5.3 → GPT-4.1)                           |
| **Slow Response**        | Simplify your prompt, reduce expected output length                                              |
| **Code Doesn't Run**     | Check syntax, try specifying the language **and its version** in your prompt                     |
| **Missing Type**         | Common in Java: the AI uses a class it never defined. Ask it to include every type it references |
| **Unexpected Output**    | Re-read your prompt for ambiguity, add more specific constraints                                 |

**Still stuck?** Ask your instructor or use the solution file as reference.

---

## Next Steps

- Review the solution at `labs/lab-11-prompt-engineering-solution/README.md` (Python and Java variants live under `resources/prompts/python/` and `resources/prompts/java/`)
- Try these techniques on your own code tasks
- Module 2 will explore different AI coding paradigms (vibe coding vs agentic coding)
