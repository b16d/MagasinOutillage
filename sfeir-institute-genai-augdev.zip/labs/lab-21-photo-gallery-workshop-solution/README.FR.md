# Lab 21 : Atelier Galerie Photo - Solution et Analyse

> **Public : stagiaires.** À lire après avoir tenté le lab. Ce document déroule le résultat
> attendu et le raisonnement qui y mène.

## 🎯 Prompt pour générer l'application

Copiez le prompt suivant dans votre assistant IA (Cursor, Claude, GitHub Copilot, etc.) :

---

**PROMPT :**

```
Create a photo gallery web application with the following files in a "photo-gallery-app" folder:

## Files to create:
- index.html (semantic HTML5 structure)
- style.css (responsive design)
- script.js (interaction logic)

## Essential features:

1. **Grid Gallery**:
   - Display 12 photos in responsive grid (CSS Grid: 4 columns desktop, 3 tablet, 1-2 mobile)
   - Use Picsum Photos: https://picsum.photos/id/{10,20,30...120}/800/600
   - Hover effect and loading spinner

2. **Modal/Lightbox**:
   - Click on photo → fullscreen modal with high resolution image
   - Close button (×), clickable backdrop
   - Counter "3 / 12"
   - Previous/Next buttons with icons

3. **Navigation**:
   - Previous/Next buttons (with wrap-around)
   - Keyboard: ESC (close), left/right arrows (navigate)
   - Touch: swipe left/right on mobile

4. **Accessibility**:
   - ARIA attributes (role="dialog", aria-modal, aria-label)
   - Focus trap in modal
   - All elements keyboard accessible

5. **Design**:
   - Modern and professional style
   - Smooth animations (transitions, hover effects)
   - Responsive (mobile-first)

Generate 3 complete and functional files.
```

---

## Résumé de la solution

Ce répertoire contient une application de galerie photo complète et fonctionnelle qui montre ce que l'IA peut générer lorsqu'elle est correctement guidée et relue. La solution comprend :

- **index.html** : structure HTML5 sémantique avec la mise en page de la galerie
- **style.css** : style professionnel avec design responsive et animations
- **script.js** : logique complète de la galerie avec modale, navigation clavier et support tactile
- **README.md** (dans photo-gallery-app/) : notes d'implémentation et décisions d'architecture

Pour voir l'application en action, lancez `npx --yes http-server --port=42212` depuis le répertoire `resources/photo-gallery-app/` et ouvrez `http://localhost:42212` dans votre navigateur. Si le port 42212 est déjà utilisé, fermez le serveur précédent ou choisissez un autre port (ex. `--port=<any-free-port>`).

## Approche d'implémentation

### Fichiers créés

```
resources/photo-gallery-app/
├── index.html      # Gallery UI structure with modal
├── style.css       # Visual styling, grid layout, and animations
├── script.js       # Gallery logic, modal handling, and event management
└── README.md       # Implementation documentation
```

### Points clés de l'implémentation

1. **Grille d'images** : mise en page CSS Grid responsive qui s'adapte à la taille de l'écran
2. **Modale/Lightbox** : ouvre l'image en taille réelle avec arrière-plan et contrôles
3. **Navigation** : boutons Précédent/Suivant et support des flèches du clavier
4. **Support clavier** : ESC pour fermer, flèches pour naviguer
5. **Gestes tactiles** : swipe gauche/droite sur mobile
6. **États de chargement** : affiche un spinner pendant le chargement des images
7. **Gestion des erreurs** : repli élégant en cas d'échec de chargement d'une image
8. **Accessibilité** : labels ARIA, gestion du focus, support des lecteurs d'écran

## Résultats des tests

| Cas de test          | Attendu                     | Réel | Statut  | Notes                         |
| -------------------- | --------------------------- | ---- | ------- | ----------------------------- |
| Chargement galerie   | Grille de photos            | ✅   | ✅ PASS | Grille responsive             |
| Mise en page adaptée | S'adapte à la fenêtre       | ✅   | ✅ PASS | Testé mobile et desktop       |
| Clic sur photo       | Ouvre la modale             | ✅   | ✅ PASS | Transition fluide             |
| Bouton Suivant       | Affiche la photo suivante   | ✅   | ✅ PASS | Reboucle sur la première      |
| Bouton Précédent     | Affiche la photo précédente | ✅   | ✅ PASS | Reboucle sur la dernière      |
| Bouton Fermer        | Quitte la modale            | ✅   | ✅ PASS | Retour à la grille            |
| Touche ESC           | Ferme la modale             | ✅   | ✅ PASS | Support clavier               |
| Flèches clavier      | Navigue entre les photos    | ✅   | ✅ PASS | Navigation gauche/droite      |
| État de chargement   | Affiche un retour visuel    | ✅   | ✅ PASS | Spinner pendant le chargement |
| Vue mobile           | Fonctionne sur petit écran  | ✅   | ✅ PASS | Contrôles adaptés au tactile  |

## Analyse des problèmes courants

À partir des implémentations de galeries photo typiquement générées par IA, voici les problèmes courants que vous avez pu rencontrer :

### Problème 1 : gestion de l'état de la modale

**Problème** : la modale ne se ferme pas correctement, ou plusieurs modales peuvent s'ouvrir en même temps

**Pourquoi ça arrive** : gestion insuffisante de l'état ouvert/fermé de la modale

**Impact du vibe coding** : sans relecture du code, vous ne détectez ni les race conditions ni les bugs d'état

**Piste de solution** : une source de vérité unique pour l'état de la modale, nettoyage correct des événements

### Problème 2 : cas limites de la navigation clavier

**Problème** : les flèches naviguent en dehors de la modale, la touche ESC entre en conflit avec d'autres fonctionnalités

**Pourquoi ça arrive** : propagation des événements mal gérée

**Impact du vibe coding** : sans relecture, les bugs de navigation clavier passent souvent inaperçus jusqu'à la production

**Piste de solution** : gestion correcte de event.preventDefault() et stopPropagation()

### Problème 3 : performance du chargement des images

**Problème** : toutes les images se chargent d'un coup, ce qui ralentit le chargement initial de la page, ou les images ne sont pas préchargées dans la modale

**Pourquoi ça arrive** : implémentation naïve sans stratégie de lazy loading ni de préchargement

**Impact du vibe coding** : les problèmes de performance ne se voient pas en développement avec une connexion rapide

**Piste de solution** : lazy loading pour la grille, préchargement des images adjacentes dans la modale

### Problème 4 : expérience tactile sur mobile

**Problème** : pas de support du swipe, boutons trop petits pour être touchés, conflits avec le pincer-zoomer

**Pourquoi ça arrive** : développement desktop-first sans prise en compte du mobile

**Impact du vibe coding** : les problèmes d'UX mobile ne sont découverts qu'en testant sur de vrais appareils

**Piste de solution** : écouteurs d'événements tactiles, zones de tap plus grandes, balise meta viewport correcte

### Problème 5 : lacunes d'accessibilité

**Problème** : labels ARIA manquants, pas de gestion du focus, le lecteur d'écran n'annonce pas les changements d'état

**Pourquoi ça arrive** : les exigences d'accessibilité demandent une attention explicite

**Impact du vibe coding** : les problèmes d'accessibilité sont invisibles aux tests visuels

**Piste de solution** : HTML sémantique, attributs ARIA, focus trap dans la modale, annonces

### Problème 6 : compatibilité navigateur

**Problème** : fonctionne dans Chrome mais casse dans Safari ou Firefox

**Pourquoi ça arrive** : fonctionnalités JavaScript/CSS modernes sans solution de repli

**Impact du vibe coding** : les problèmes cross-browser ne se trouvent qu'avec des tests exhaustifs

**Piste de solution** : détection de fonctionnalités, polyfills, préfixes navigateur

## Analyse de la réflexion

### Prompt 1 : qu'est-ce qui a bien fonctionné ?

**Réponse typique** : « la galerie a été générée sans problème, la modale fonctionnait, l'UI avait l'air professionnelle »

**Analyse** : les outils d'IA modernes excellent à générer des UI fonctionnelles pour des patterns courants comme les galeries photo. Le happy path de base fonctionne généralement bien.

**Observation à retenir** : réussir sur des scénarios simples ne garantit pas la gestion des cas limites. La galerie « marche » pour les interactions de base mais peut cacher des problèmes d'accessibilité, de performance ou d'UX mobile.

### Prompt 2 : problèmes rencontrés

**Réponses typiques** :

- « la navigation clavier ne fonctionnait pas sur la première/dernière image »
- « la modale ne se fermait pas au clic sur l'arrière-plan »
- « les images ne se chargeaient pas sur connexion lente »
- « les gestes de swipe manquaient sur mobile »
- « aucun problème trouvé » (mais les tests n'étaient sans doute pas exhaustifs)

**Analyse** : les problèmes découverts dépendent fortement de la rigueur des tests. Sans relecture de code, vous comptez entièrement sur les tests pour trouver les problèmes. Les tests manuels ratent souvent des cas limites évidents en relecture de code.

**Observation à retenir** : comparez les problèmes trouvés par les tests avec ce qu'une relecture de code révélerait. Combien de bugs potentiels restent non détectés ?

### Prompt 3 : niveau de confiance

**Répartition typique** :

- **1-2 (faible)** : « je ne sais pas si le code est sécurisé/accessible/performant » — montre une conscience des risques du vibe coding
- **3 (moyen)** : « ça marche pour les cas de base mais je doute des cas limites » — évaluation réaliste
- **4-5 (élevé)** : « les tests passent donc ça semble prêt pour la production » — excès de confiance, le piège du vibe coding

**Analyse** : une confiance élevée sans relecture de code est un signal d'alarme. Les tests seuls ne devraient pas donner une forte confiance pour un déploiement en production.

**Observation à retenir** : votre confiance devrait dépendre à la fois de la rigueur des tests ET de la relecture de code. Tests au vert ≠ prêt pour la production.

### Prompt 4 : scénarios appropriés

**Réponses typiques** :

- **Portfolio personnel** : oui, risque acceptable si vous êtes le seul utilisateur
- **Bibliothèque photo interne** : peut-être, selon les standards de l'entreprise
- **Vitrine client** : non, trop risqué sans relecture
- **Prototype rapide** : oui, démonstration jetable

**Analyse** : le contexte détermine la pertinence. Une galerie photo pour apprendre convient au vibe coding ; une galerie pour une activité professionnelle de photographie, non.

**Observation à retenir** : la tolérance au risque varie selon le cas d'usage. La même approche de génération, acceptable pour une démo, peut être catastrophique pour une application génératrice de revenus.

### Prompt 5 : impact du niveau d'expérience

**Enseignements typiques** :

- **Développeurs juniors** : peuvent ne pas repérer l'accessibilité manquante, les optimisations de performance ou les enjeux de sécurité
- **Développeurs seniors** : repèrent les problèmes plus vite en relecture, mais ne peuvent pas relire un code qu'ils ne lisent pas
- **Reconnaissance de patterns** : l'expérience aide à identifier les pièges courants, mais seulement pendant la relecture de code

**Analyse** : l'expérience compte surtout pendant la relecture de code. Le vibe coding court-circuite justement l'étape où l'expérience apporte le plus de valeur.

**Observation à retenir** : même les développeurs seniors sont exposés aux risques du vibe coding. L'expérience ne sert à rien si vous ne l'appliquez pas via la relecture.

### Prompt 6 : comparaison avec la production

**Observations typiques** :

- « états de chargement et gestion d'erreurs manquants »
- « aucune prise en compte de l'accessibilité »
- « performance non optimisée »
- « enjeux de sécurité non traités »
- « documentation et tests totalement absents »

**Analyse** : l'écart entre une application vibe-codée et une application prête pour la production est considérable. La production exige :

- Une gestion d'erreurs exhaustive
- La conformité en accessibilité
- L'optimisation des performances
- Le durcissement de la sécurité
- Une couverture de tests
- De la documentation
- Du monitoring et de l'analytics

**Observation à retenir** : le « dernier kilomètre » vers la qualité production demande un travail supplémentaire important, que le vibe coding saute entièrement.

## Cas d'usage appropriés et inappropriés

### ✅ Appropriés (d'après ce lab)

1. **Projet de portfolio personnel** : vous êtes le seul utilisateur, les pannes n'impactent pas le business
2. **Prototype d'UI rapide** : démontrer des concepts de design, pas construire du code de production
3. **Exercice d'apprentissage** : comprendre des concepts par l'expérimentation (comme ce lab !)
4. **Démo interne** : présentation limitée dans le temps, code non maintenu

**Pourquoi** : enjeux faibles, périmètre limité, aucune charge de maintenance, risque d'échec acceptable

### ❌ Inappropriés (d'après ce lab)

1. **Vitrine produit e-commerce** : application génératrice de revenus, avec la réputation de la marque en jeu
2. **Portfolio de photographe professionnel** : des clients payants dépendent de la qualité et de la fiabilité
3. **Site web d'entreprise** : application publique qui représente l'entreprise
4. **Imagerie médicale** : application critique pour la sécurité, où un bug peut causer des dommages
5. **Codebase d'équipe** : d'autres doivent maintenir et faire évoluer le code

**Pourquoi** : enjeux élevés, maintenance nécessaire, conséquences d'échec sévères, responsabilité envers les utilisateurs et les parties prenantes

## Lien avec les concepts du module

### Des slides → à l'expérience du lab

| Concept des slides                | Expérience du lab                                                  |
| --------------------------------- | ------------------------------------------------------------------ |
| « Acceptation passive »           | Vous avez cliqué « Accept All » sans lire le code                  |
| « Manque de visibilité »          | Vous ne comprenez pas les détails d'implémentation                 |
| « Difficulté de débogage »        | Si des bugs surgissaient, sauriez-vous les corriger sans le code ? |
| « Pannes en production »          | Les tests ont révélé des cas limites problématiques                |
| « Le niveau d'expérience compte » | Votre rigueur de test a varié selon votre expérience               |
| « Développeur augmenté »          | Relecture + affinage = qualité production                          |

### À retenir

Cette expérience pratique rend concrets des concepts abstraits. Les pannes en production évoquées dans les slides (effondrement des performances, failles de sécurité, crise de maintenabilité) ne sont pas hypothétiques — ce sont des risques réels, présents même dans une simple galerie photo. Les systèmes de production sont plusieurs ordres de grandeur plus complexes.

## Lien avec les modules suivants

Cette galerie photo sert de base aux labs du module 3 :

### Lab 31 : refactoring de legacy

- Vous découvrirez une galerie photo « legacy » avec sa dette technique
- Vous pratiquerez les phases **Specify** et **Plan** pour l'analyser et l'améliorer
- Vous comparerez les résultats du vibe coding (ce lab) avec une approche de refactoring systématique

### Lab 32 : développement from scratch

- Construire une galerie photo avec un workflow agentique complet
- Vivre le cycle **Specify → Plan → Tasks → Implement → Validate**
- Constater l'écart de qualité entre vibe coding et agentic coding

**Progression** : vibe coding (Lab 21) → refactoring de code legacy (Lab 31) → construction from scratch avec workflow agentique (Lab 32)

## Prochaines étapes recommandées

1. **Relisez le code réel** dans `resources/photo-gallery-app/` pour voir les détails d'implémentation
2. **Comparez vos résultats** avec vos collègues — tout le monde a-t-il obtenu des implémentations similaires ?
3. **Identifiez ce qu'une relecture de code aurait détecté** et que les tests ont raté
4. **Listez les exigences de production** qui manquent à votre version (accessibilité, tests, gestion d'erreurs)
5. **Revenez sur les objectifs pédagogiques du module** — en quoi la pratique renforce-t-elle la théorie ?

## Questions de discussion pour le débrief collectif

1. Combien de cas limites différents le groupe a-t-il découverts collectivement via les tests ?
2. Quelqu'un se sentait-il confiant pour déployer sa galerie non relue en production ? Pourquoi ?
3. Quelles exigences supplémentaires une galerie photo de production nécessiterait-elle ?
4. En quoi votre niveau d'expérience a-t-il influencé votre rigueur de test et votre confiance ?
5. Après avoir relu le code de la solution, quels problèmes avez-vous manqués alors qu'ils auraient dû sauter aux yeux en relecture de code ?

## Ressources

- **Article** : [Vibe Coding vs AI-Assisted Engineering](https://addyo.substack.com/p/vibe-coding-is-not-the-same-as-ai)
- **Documentation de l'IDE Cursor** : https://cursor.sh/docs
- **Slides du module 2** : revoir les concepts pour la comparaison vibe coding / agentic coding
- **Recommandations WCAG** : https://www.w3.org/WAI/WCAG21/quickref/ (pour les standards d'accessibilité)

---

**À retenir** : ce lab a délibérément utilisé le vibe coding pour en démontrer les limites. En développement réel, relisez et comprenez toujours le code généré par IA avant tout déploiement. L'application de galerie photo devient votre point de référence pour comparer les approches dans le module 3.
