# Lab 21: Photo Gallery Workshop - Solution and Analysis

> **Audience: trainees.** Read this after attempting the lab. It walks through the expected
> result and the reasoning behind it.

## 🎯 Prompt to Generate the Application

Copy the following prompt into your AI assistant (Cursor, Claude, GitHub Copilot, etc.):

---

**PROMPT:**

```
Create a photo gallery web application with the following files in a "photo-gallery-app" folder:

## Files to create:
- index.html (semantic HTML5 structure)
- style.css (responsive design)
- script.js (interaction logic)

## Essential features:

1. **Grid Gallery**:
   - Display 12 photos in responsive grid (CSS Grid: 4 columns desktop, 3 tablet, 1-2 mobile)
   - Use Picsum Photos: https://picsum.photos/id/{10,20,30...120}/800/600
   - Hover effect and loading spinner

2. **Modal/Lightbox**:
   - Click on photo → fullscreen modal with high resolution image
   - Close button (×), clickable backdrop
   - Counter "3 / 12"
   - Previous/Next buttons with icons

3. **Navigation**:
   - Previous/Next buttons (with wrap-around)
   - Keyboard: ESC (close), left/right arrows (navigate)
   - Touch: swipe left/right on mobile

4. **Accessibility**:
   - ARIA attributes (role="dialog", aria-modal, aria-label)
   - Focus trap in modal
   - All elements keyboard accessible

5. **Design**:
   - Modern and professional style
   - Smooth animations (transitions, hover effects)
   - Responsive (mobile-first)

Generate 3 complete and functional files.
```

---

## Solution Summary

This directory contains a complete, working photo gallery application that demonstrates what AI can generate when properly guided and reviewed. The solution includes:

- **index.html**: Semantic HTML5 structure with gallery layout
- **style.css**: Professional styling with responsive design and animations
- **script.js**: Complete gallery logic with modal, keyboard navigation, and touch support
- **README.md** (in photo-gallery-app/): Implementation notes and architectural decisions

To see the application in action, run `npx --yes http-server --port=42212` from the `resources/photo-gallery-app/` directory and open `http://localhost:42212` in your browser. If port 42212 is in use, either close previous server or choose another port (e.g., `--port=<any-free-port>`).

## Implementation Approach

### Files Created

```
resources/photo-gallery-app/
├── index.html      # Gallery UI structure with modal
├── style.css       # Visual styling, grid layout, and animations
├── script.js       # Gallery logic, modal handling, and event management
└── README.md       # Implementation documentation
```

### Key Implementation Details

1. **Image Grid**: Responsive CSS Grid layout that adapts to screen size
2. **Modal/Lightbox**: Opens full-size image with backdrop and controls
3. **Navigation**: Previous/Next buttons and keyboard arrow key support
4. **Keyboard Support**: ESC to close, arrow keys to navigate
5. **Touch Gestures**: Swipe left/right on mobile devices
6. **Loading States**: Displays spinner while images load
7. **Error Handling**: Graceful fallback for failed image loads
8. **Accessibility**: ARIA labels, focus management, screen reader support

## Test Results

| Test Case         | Expected              | Actual | Status  | Notes                     |
| ----------------- | --------------------- | ------ | ------- | ------------------------- |
| Gallery loads     | Grid of photos        | ✅     | ✅ PASS | Responsive grid layout    |
| Responsive layout | Adapts to window      | ✅     | ✅ PASS | Mobile and desktop tested |
| Click photo       | Opens modal           | ✅     | ✅ PASS | Smooth transition         |
| Next button       | Shows next photo      | ✅     | ✅ PASS | Wraps to first on last    |
| Previous button   | Shows previous photo  | ✅     | ✅ PASS | Wraps to last on first    |
| Close button      | Exits modal           | ✅     | ✅ PASS | Returns to grid view      |
| ESC key           | Closes modal          | ✅     | ✅ PASS | Keyboard support          |
| Arrow keys        | Navigate photos       | ✅     | ✅ PASS | Left/right navigation     |
| Loading state     | Shows feedback        | ✅     | ✅ PASS | Spinner during load       |
| Mobile view       | Works on small screen | ✅     | ✅ PASS | Touch-friendly controls   |

## Common Issues Analysis

Based on typical AI-generated photo gallery implementations, here are common issues you may have encountered:

### Issue 1: Modal State Management

**Problem**: Modal doesn't close properly, or multiple modals can open simultaneously

**Why It Happens**: Inadequate state management for modal open/closed state

**Vibe Coding Impact**: If you didn't review the code, you wouldn't catch race conditions or state bugs

**Solution Approach**: Single source of truth for modal state, proper event cleanup

### Issue 2: Keyboard Navigation Edge Cases

**Problem**: Arrow keys navigate outside modal, ESC key conflicts with other functionality

**Why It Happens**: Event propagation not properly handled

**Vibe Coding Impact**: Without review, keyboard navigation bugs often go unnoticed until production

**Solution Approach**: Proper event.preventDefault() and stopPropagation() handling

### Issue 3: Image Loading Performance

**Problem**: All images load at once causing slow initial page load, or images don't preload in modal

**Why It Happens**: Naive implementation without lazy loading or preloading strategy

**Vibe Coding Impact**: Performance issues aren't visible in development with fast connections

**Solution Approach**: Lazy loading for grid, preloading adjacent images in modal

### Issue 4: Mobile Touch Experience

**Problem**: No touch swipe support, small buttons hard to tap, pinch-zoom conflicts

**Why It Happens**: Desktop-first development without mobile consideration

**Vibe Coding Impact**: Mobile UX issues only discovered when testing on actual devices

**Solution Approach**: Touch event listeners, larger tap targets, proper viewport meta tag

### Issue 5: Accessibility Gaps

**Problem**: Missing ARIA labels, no focus management, screen reader can't announce state changes

**Why It Happens**: Accessibility requirements need explicit attention

**Vibe Coding Impact**: Accessibility issues are invisible to visual testing

**Solution Approach**: Semantic HTML, ARIA attributes, focus trap in modal, announcements

### Issue 6: Browser Compatibility

**Problem**: Works in Chrome but breaks in Safari or Firefox

**Why It Happens**: Modern JavaScript/CSS features without fallbacks

**Vibe Coding Impact**: Cross-browser issues only found through comprehensive testing

**Solution Approach**: Feature detection, polyfills, vendor prefixes

## Reflection Analysis

### Prompt 1: What Worked Well?

**Typical Response**: "The gallery generated successfully, modal worked, UI looked professional"

**Analysis**: Modern AI tools excel at generating functional UIs for common patterns like photo galleries. The basic happy-path functionality usually works well.

**Meaningful Observation**: Success in simple scenarios doesn't guarantee edge case handling. The gallery "works" for basic interactions but may have hidden issues with accessibility, performance, or mobile UX.

### Prompt 2: Issues Encountered

**Typical Responses**:

- "Keyboard navigation didn't work on first/last image"
- "Modal didn't close on backdrop click"
- "Images didn't load on slow connection"
- "Touch swipe gestures missing on mobile"
- "No issues found" (but likely didn't test comprehensively)

**Analysis**: Issues discovered depend heavily on testing thoroughness. Without code review, you rely entirely on testing to find problems. Manual testing often misses edge cases obvious in code review.

**Meaningful Observation**: Compare issues found through testing vs. what code review would reveal. How many potential bugs remain undetected?

### Prompt 3: Confidence Level

**Typical Distribution**:

- **1-2 (Low)**: "I don't know if code is secure/accessible/performant" - shows awareness of vibe coding risks
- **3 (Medium)**: "Works for basic cases but unsure about edge cases" - realistic assessment
- **4-5 (High)**: "Tests passed so seems production-ready" - overconfidence, vibe coding trap

**Analysis**: High confidence without code review is a red flag. Testing alone shouldn't give high confidence for production deployment.

**Meaningful Observation**: Your confidence should correlate with both testing thoroughness AND code review. Passing tests ≠ production-ready.

### Prompt 4: Appropriate Scenarios

**Typical Responses**:

- **Personal portfolio**: Yes, acceptable risk if you're the only user
- **Internal photo library**: Maybe, depends on company standards
- **Customer showcase**: No, too risky without review
- **Quick prototype**: Yes, throwaway demonstration

**Analysis**: Context determines appropriateness. A photo gallery for learning is fine with vibe coding; a gallery for a professional photography business is not.

**Meaningful Observation**: Risk tolerance varies by use case. The same generation approach acceptable for demos could be catastrophic for revenue-generating applications.

### Prompt 5: Experience Level Impact

**Typical Insights**:

- **Junior developers**: May not recognize missing accessibility, performance optimizations, or security concerns
- **Senior developers**: Would spot issues faster during review but can't review code they don't read
- **Pattern recognition**: Experience helps identify common pitfalls, but only during code review

**Analysis**: Experience matters most during code review. Vibe coding bypasses the review step where experience provides maximum value.

**Meaningful Observation**: Even senior developers are vulnerable to vibe coding risks. Experience doesn't help if you don't apply it through review.

### Prompt 6: Production Comparison

**Typical Observations**:

- "Missing loading states and error handling"
- "No accessibility considerations"
- "Performance not optimized"
- "Security concerns not addressed"
- "Documentation and tests completely absent"

**Analysis**: The gap between vibe-coded application and production-ready application is substantial. Production requires:

- Comprehensive error handling
- Accessibility compliance
- Performance optimization
- Security hardening
- Testing coverage
- Documentation
- Monitoring and analytics

**Meaningful Observation**: The "last mile" to production quality requires significant additional work that vibe coding skips entirely.

## Appropriate vs Inappropriate Use Cases

### ✅ Appropriate (Based on This Lab)

1. **Personal Portfolio Project**: You're the only user, failures don't impact business
2. **Quick UI Prototype**: Demonstrating design concepts, not building production code
3. **Learning Exercise**: Understanding concepts through experimentation (like this lab!)
4. **Internal Demo**: Time-limited presentation, code won't be maintained

**Why**: Low stakes, limited scope, no maintenance burden, acceptable failure risk

### ❌ Inappropriate (Based on This Lab)

1. **E-commerce Product Showcase**: Revenue-generating application with brand reputation at stake
2. **Professional Photography Portfolio**: Paying clients depend on quality and reliability
3. **Company Website**: Public-facing application representing business
4. **Medical Imaging**: Safety-critical application where bugs could cause harm
5. **Team Codebase**: Others need to maintain and extend the code

**Why**: High stakes, maintenance required, failure consequences severe, responsibility to users/stakeholders

## Connecting to Module Concepts

### From Slides → Lab Experience

| Slide Concept              | Lab Experience                                             |
| -------------------------- | ---------------------------------------------------------- |
| "Passive acceptance"       | You clicked "Accept All" without reading code              |
| "Lack of visibility"       | You don't understand implementation details                |
| "Difficulty debugging"     | If bugs appeared, could you fix them without reading code? |
| "Production failures"      | Testing revealed potential edge case issues                |
| "Experience level matters" | Your testing thoroughness varied by experience             |
| "Augmented developer"      | Review + refinement = production quality                   |

### Key Takeaway

This hands-on experience makes abstract concepts concrete. The production failures discussed in slides (performance collapse, security bugs, maintainability crisis) aren't hypothetical - they're real risks present even in a simple photo gallery. Production systems are orders of magnitude more complex.

## Connection to Later Modules

This photo gallery serves as the foundation for Module 3 labs:

### Lab 31: Legacy Refactoring

- You'll see a "legacy" photo gallery with technical debt
- Practice using **Specify** and **Plan** phases to analyze and improve it
- Compare vibe coding results (this lab) with systematic refactoring approach

### Lab 32: From-Scratch Development

- Build a photo gallery using full agentic workflow
- Experience proper **Specify → Plan → Tasks → Implement → Validate** cycle
- See quality difference between vibe coding and agentic coding

**Progression**: Vibe coding (Lab 21) → Refactoring legacy code (Lab 31) → Building from scratch with agentic workflow (Lab 32)

## Recommended Next Steps

1. **Review the actual code** in `resources/photo-gallery-app/` to see implementation details
2. **Compare your results** with teammates - did everyone get similar implementations?
3. **Identify what code review would have caught** that testing missed
4. **List production requirements** your version lacks (accessibility, testing, error handling)
5. **Reflect on module learning objectives** - how does hands-on experience reinforce theory?

## Discussion Questions for Group Debrief

1. How many different edge cases did the group collectively discover through testing?
2. Did anyone feel confident deploying their unreviewed gallery to production? Why or why not?
3. What additional requirements would a production photo gallery need?
4. How did your experience level affect your testing thoroughness and confidence?
5. After reviewing the solution code, what issues did you miss that should have been obvious in code review?

## Resources

- **Article**: [Vibe Coding vs AI-Assisted Engineering](https://addyo.substack.com/p/vibe-coding-is-not-the-same-as-ai)
- **Cursor IDE Documentation**: https://cursor.sh/docs
- **Module 2 Slides**: Review concepts for vibe vs agentic coding comparison
- **WCAG Guidelines**: https://www.w3.org/WAI/WCAG21/quickref/ (for accessibility standards)

---

**Remember**: This lab intentionally used vibe coding to demonstrate its limitations. In real development, always review and understand AI-generated code before deployment. The photo gallery application becomes your reference point for comparing approaches in Module 3.
