# Lab 11 : Atelier Prompt Engineering - Solutions

> **Public : stagiaires.** À lire après avoir tenté le lab. Ce document déroule le résultat
> attendu et le raisonnement qui y mène.

**Module** : 1 - Introduction à l'IA pour les développeurs

## Vue d'ensemble

Ce document fournit des exemples de prompts et de sorties pour chaque exercice, montrant comment la qualité du prompt influence la sortie de l'IA.

---

## Exercice 1 : Prompting basique - Solution

### Exemple de prompt

```
You are a JavaScript developer.
Write a function that filters a list by score >= 70, sorts by score descending, and returns names.
```

### Sortie typique

```javascript
function filterAndSort(items) {
  return items
    .filter((item) => item.score >= 70)
    .sort((a, b) => b.score - a.score)
    .map((item) => item.name);
}
```

### Analyse

**Avantages** :

- Le code fonctionne correctement
- Solution concise

**Inconvénients** :

- Aucun commentaire ni documentation
- Aucune gestion d'erreur
- Aucune information de typage
- Aucun exemple d'utilisation
- Peut nécessiter des questions de suivi pour clarifier les besoins

---

## Exercice 2 : Prompting structuré - Solution

### Exemple de prompt

```
You are a senior JavaScript developer.

I need a function that processes student scores:
- Input: Array of objects with 'name' (string) and 'score' (number)
- Filter: Keep only scores >= 70
- Sort: By score, highest first
- Output: Array of names only

Please provide:
- The function code with inline comments
- Example usage
```

### Sortie typique

```javascript
/**
 * Filters and sorts student scores, returning names of passing students.
 * @param {Array<{name: string, score: number}>} students - Array of student objects
 * @returns {string[]} Names of students with score >= 70, sorted by score descending
 */
function getPassingStudentNames(students) {
  // Filter students with passing scores (>= 70)
  const passing = students.filter((student) => student.score >= 70);

  // Sort by score in descending order
  const sorted = passing.sort((a, b) => b.score - a.score);

  // Extract and return just the names
  return sorted.map((student) => student.name);
}

// Example usage:
const students = [
  { name: 'Alice', score: 85 },
  { name: 'Bob', score: 65 },
  { name: 'Charlie', score: 92 },
  { name: 'Diana', score: 70 },
];

console.log(getPassingStudentNames(students));
// Output: ["Charlie", "Alice", "Diana"]
```

### Analyse

**Améliorations par rapport à l'exercice 1** :

- Commentaires JSDoc avec types
- Nom de fonction explicite
- Commentaires inline expliquant chaque étape
- Exemple d'utilisation inclus
- Meilleurs noms de variables

**Toujours manquant** :

- Gestion d'erreur
- Gestion des cas limites
- Types TypeScript (le cas échéant)

---

## Exercice 3 : Prompting avancé - Solution

### Exemple de prompt

```
You are a senior JavaScript/TypeScript developer specializing in data transformations.

## Task
Create a function to process student assessment data.

## Requirements
- Filter students with passing scores (>= 70)
- Sort by score in descending order
- Return only student names

## Example
Input:
[{ name: "Alice", score: 85 }, { name: "Bob", score: 65 }]

Expected Output:
["Alice"]

## Instructions
1. First, think through the algorithm steps
2. Implement with TypeScript types
3. Include error handling for edge cases (empty array, invalid input)
4. Add comprehensive comments

## Output Format
- TypeScript function with full type definitions
- Brief explanation of approach
- 3 test cases covering normal, edge, and error scenarios
```

### Sortie typique

```typescript
/**
 * Student interface defining the shape of input objects
 */
interface Student {
  name: string;
  score: number;
}

/**
 * Configuration options for filtering
 */
interface FilterOptions {
  minScore?: number;
  sortOrder?: 'asc' | 'desc';
}

/**
 * Filters and sorts students by score, returning names of qualifying students.
 *
 * Algorithm:
 * 1. Validate input is an array
 * 2. Filter students meeting minimum score threshold
 * 3. Sort remaining students by score
 * 4. Extract and return names
 *
 * @param students - Array of student objects with name and score
 * @param options - Optional configuration (default: minScore=70, sortOrder='desc')
 * @returns Array of student names meeting criteria
 * @throws Error if students is not a valid array
 */
function getQualifyingStudentNames(students: Student[], options: FilterOptions = {}): string[] {
  // Set defaults
  const { minScore = 70, sortOrder = 'desc' } = options;

  // Validate input
  if (!Array.isArray(students)) {
    throw new Error('Input must be an array of students');
  }

  // Handle empty array edge case
  if (students.length === 0) {
    return [];
  }

  // Filter students with qualifying scores
  const qualifying = students.filter((student) => typeof student.score === 'number' && student.score >= minScore);

  // Sort by score
  const sorted = [...qualifying].sort((a, b) => (sortOrder === 'desc' ? b.score - a.score : a.score - b.score));

  // Extract and return names
  return sorted.map((student) => student.name);
}

// ============ TEST CASES ============

// Test 1: Normal case
const normalInput: Student[] = [
  { name: 'Alice', score: 85 },
  { name: 'Bob', score: 65 },
  { name: 'Charlie', score: 92 },
  { name: 'Diana', score: 70 },
];
console.log(getQualifyingStudentNames(normalInput));
// Expected: ["Charlie", "Alice", "Diana"]

// Test 2: Edge case - empty array
console.log(getQualifyingStudentNames([]));
// Expected: []

// Test 3: Edge case - no qualifying students
const noPassers: Student[] = [
  { name: 'Eve', score: 50 },
  { name: 'Frank', score: 60 },
];
console.log(getQualifyingStudentNames(noPassers));
// Expected: []

// Test 4: Custom threshold
console.log(getQualifyingStudentNames(normalInput, { minScore: 80 }));
// Expected: ["Charlie", "Alice"]
```

### Analyse

**Améliorations majeures par rapport aux exercices 1-2** :

- Définitions de types TypeScript complètes
- Options configurables (seuil, ordre de tri)
- Validation des entrées et gestion d'erreur
- Gère les cas limites (tableau vide, aucun candidat retenu)
- Cas de test exhaustifs
- Documentation claire de l'algorithme
- Tri immuable (spread operator)

---

## Synthèse comparative

| Aspect                  | Basique | Structuré | Avancé             |
| ----------------------- | ------- | --------- | ------------------ |
| Lignes de code          | ~5      | ~15       | ~50                |
| Documentation           | Aucune  | Bonne     | Excellente         |
| Sûreté de typage        | Aucune  | JSDoc     | TypeScript complet |
| Gestion d'erreur        | Aucune  | Aucune    | Complète           |
| Configurabilité         | Aucune  | Aucune    | Oui                |
| Couverture de test      | Aucune  | 1 exemple | 4 cas de test      |
| Prêt pour la production | Non     | Peut-être | Oui                |

## Variantes par langage

Le déroulé ci-dessus utilise JavaScript/TypeScript. Les trois mêmes prompts, appliqués à Python et à Java, sont documentés intégralement dans `resources/prompts/` :

- **Python** — [`resources/prompts/python/`](resources/prompts/python/)
- **Java** — [`resources/prompts/java/`](resources/prompts/java/)

Tout le code de ces variantes a été exécuté : les exemples Python tournent, les exemples Java compilent et s'exécutent, et les cas de test de l'exercice 3 passent.

### Ce que produisent les trois exercices, côte à côte

| Niveau        | JavaScript/TypeScript                         | Python                                                     | Java                                                                    |
| ------------- | --------------------------------------------- | ---------------------------------------------------------- | ----------------------------------------------------------------------- |
| **Basique**   | `filter`/`sort`/`map` chaînés, aucun type     | une compréhension de liste sur `sorted()`, aucun type hint | pipeline de streams **référençant une classe `Student` jamais définie** |
| **Structuré** | JSDoc, fonction nommée, exemple d'usage       | docstring style Google, filtre puis tri, exemple d'usage   | `record` + Javadoc, `Comparator` sûr, `main` exécutable                 |
| **Avancé**    | `interface`, objet d'options, 4 tests console | `dataclass` figée, alias `Literal`, 5 cas pytest           | `record` + `enum` + `FilterOptions`, 5 cas JUnit 5                      |

### Le révélateur propre à chaque langage

Ce que l'on gagne à sortir de JavaScript, c'est que **chaque langage expose une défaillance différente du prompt basique** :

- **Java** — le prompt basique produit du code qui _ne compile pas_. L'IA écrit `List<Student>` sans jamais définir `Student`. Cette défaillance n'a pas d'équivalent en JavaScript, et elle marque durablement une salle de développeurs Java : le premier prompt produit quelque chose qui a l'air juste et qui ne s'exécute pas.
- **Python** — le prompt basique suppose silencieusement que l'entrée est un `dict` avec les clés `"name"` / `"score"`. Rien ne le dit, rien ne le valide, et le moindre enregistrement malformé lève un `KeyError` à distance. Le prompt avancé est aussi le seul à se prémunir du fait qu'une `Sequence` accepte une simple chaîne de caractères.
- **JavaScript** — le prompt basique fonctionne du premier coup. C'est précisément pour cela qu'il est le langage le plus faible pour démontrer le propos de ce lab, et que proposer les variantes a un intérêt.

À utiliser au débriefing : demandez à chaque stagiaire lequel des trois niveaux a produit pour la première fois du code _exécutable_ dans son langage. Les réponses diffèrent, et cette différence est la leçon.

## Points clés à retenir

1. **Le prompting basique** convient aux prototypes rapides mais produit une sortie minimale
2. **Le prompting structuré** ajoute documentation et exemples pour un faible effort
3. **Le prompting avancé** produit du code de qualité production mais demande plus de préparation
4. **Choisissez votre approche** selon la tâche :
   - Exploration rapide → Basique
   - Documentation nécessaire → Structuré
   - Code de production → Avancé

## Ressources complémentaires

Voir le dossier `resources/prompts/` pour :

- `exercise-1-basic.md` - Solution détaillée de l'exercice 1 (JavaScript)
- `exercise-2-structured.md` - Solution détaillée de l'exercice 2 (JavaScript)
- `exercise-3-advanced.md` - Solution détaillée de l'exercice 3 (TypeScript)
- `examples.md` - Prompts supplémentaires organisés par niveau de technique pour d'autres tâches
- `python/exercise-{1,2,3}-*.md` - Les trois mêmes exercices en Python
- `java/exercise-{1,2,3}-*.md` - Les trois mêmes exercices en Java
