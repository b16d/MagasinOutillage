# Exercise 2: Structured Prompting - Solution

## Techniques Used

- **Role**: Assign expertise (e.g., "senior JavaScript developer")
- **Context**: Detailed requirements
- **Format**: Specify output structure

## Example Prompt

```
You are a senior JavaScript developer.

I need a function that processes student scores:
- Input: Array of objects with 'name' (string) and 'score' (number)
- Filter: Keep only scores >= 70
- Sort: By score, highest first
- Output: Array of names only

Please provide:
- The function code with inline comments
- Example usage
```

## Typical Output

```javascript
/**
 * Filters and sorts student scores, returning names of passing students.
 * @param {Array<{name: string, score: number}>} students - Array of student objects
 * @returns {string[]} Names of students with score >= 70, sorted by score descending
 */
function getPassingStudentNames(students) {
  // Filter students with passing scores (>= 70)
  const passing = students.filter((student) => student.score >= 70);

  // Sort by score in descending order
  const sorted = passing.sort((a, b) => b.score - a.score);

  // Extract and return just the names
  return sorted.map((student) => student.name);
}

// Example usage:
const students = [
  { name: 'Alice', score: 85 },
  { name: 'Bob', score: 65 },
  { name: 'Charlie', score: 92 },
  { name: 'Diana', score: 70 },
];

console.log(getPassingStudentNames(students));
// Output: ["Charlie", "Alice", "Diana"]
```

## Analysis

**Improvements over Exercise 1**:

- JSDoc comments with types
- Meaningful function name
- Inline comments explaining each step
- Usage example included
- Better variable names

**Still missing**:

- Error handling
- Edge case handling
- TypeScript types (if applicable)

## What to Look For

When evaluating your structured prompt results:

- Did specifying format improve documentation?
- Is the function name more descriptive?
- Did you get the example usage you requested?
