# Exercise 3: Advanced Prompting - Solution (Python)

> Python variant of [`../exercise-3-advanced.md`](../exercise-3-advanced.md).

## Techniques Used

- **Role**: Specialized senior developer persona
- **Context**: Structured requirements with headings
- **Format**: Precise output contract
- **Few-Shot**: Concrete input/output example
- **Chain-of-Thought**: Explicit request to reason through the steps first

## Example Prompt

```
You are a senior Python developer specializing in data transformations.

## Task
Create a function to process student assessment data.

## Requirements
- Filter students with passing scores (>= 70)
- Sort by score in descending order
- Return only student names

## Example
Input:
[Student(name="Alice", score=85), Student(name="Bob", score=65)]

Expected Output:
["Alice"]

## Instructions
1. First, think through the algorithm steps
2. Implement with full type hints (Python 3.12+)
3. Include error handling for edge cases (empty list, invalid input)
4. Add comprehensive docstrings

## Output Format
- A dataclass for the input record
- The function with full type annotations
- Brief explanation of approach
- pytest test cases covering normal, edge, and error scenarios
```

## Typical Output

```python
"""Student assessment data transformations."""

from dataclasses import dataclass
from typing import Literal, Sequence

SortOrder = Literal["asc", "desc"]

PASSING_SCORE = 70


@dataclass(frozen=True)
class Student:
    """A single student assessment record."""

    name: str
    score: int


def get_qualifying_student_names(
    students: Sequence[Student],
    min_score: int = PASSING_SCORE,
    sort_order: SortOrder = "desc",
) -> list[str]:
    """Return the names of students meeting a minimum score.

    Algorithm:
        1. Validate the input is a sequence of Student records.
        2. Keep the students at or above ``min_score``.
        3. Sort the survivors by score.
        4. Project the names out.

    Args:
        students: assessment records to process.
        min_score: inclusive score threshold (default: 70).
        sort_order: ``"desc"`` (default) or ``"asc"``.

    Returns:
        The qualifying names, ordered by score.

    Raises:
        TypeError: if ``students`` is not a sequence of Student records.
        ValueError: if ``sort_order`` is not ``"asc"`` or ``"desc"``.
    """
    if isinstance(students, (str, bytes)) or not isinstance(students, Sequence):
        raise TypeError("students must be a sequence of Student records")

    if sort_order not in ("asc", "desc"):
        raise ValueError(f"sort_order must be 'asc' or 'desc', got {sort_order!r}")

    if not students:
        return []

    if not all(isinstance(student, Student) for student in students):
        raise TypeError("every item must be a Student record")

    qualifying = [student for student in students if student.score >= min_score]

    ordered = sorted(
        qualifying,
        key=lambda student: student.score,
        reverse=sort_order == "desc",
    )

    return [student.name for student in ordered]
```

```python
# ============ TEST CASES (pytest) ============

import pytest

ROSTER = [
    Student("Alice", 85),
    Student("Bob", 65),
    Student("Charlie", 92),
    Student("Diana", 70),
]


def test_returns_passing_names_best_first():
    assert get_qualifying_student_names(ROSTER) == ["Charlie", "Alice", "Diana"]


def test_empty_roster_returns_empty_list():
    assert get_qualifying_student_names([]) == []


def test_no_one_passes_returns_empty_list():
    failing = [Student("Eve", 50), Student("Frank", 60)]
    assert get_qualifying_student_names(failing) == []


def test_custom_threshold_and_ascending_order():
    assert get_qualifying_student_names(ROSTER, min_score=80, sort_order="asc") == [
        "Alice",
        "Charlie",
    ]


def test_invalid_input_raises():
    with pytest.raises(TypeError):
        get_qualifying_student_names("not a roster")
```

Run with `pytest`. All five pass.

## Analysis

**Major improvements over Exercises 1-2**:

- Full type hints, including a `Literal` alias for the sort direction
- A frozen `dataclass` instead of an untyped `dict` — typos become errors
- Configurable threshold and sort order
- Input validation with _distinct_ exception types (`TypeError` vs `ValueError`)
- Handles edge cases (empty list, nobody qualifying)
- `sorted()` instead of `.sort()` — no mutation of the caller's data
- Docstring documents the algorithm, the arguments, _and_ what it raises
- Five pytest cases covering normal, edge, and error paths

**The Python-specific tell**: the `isinstance(students, (str, bytes))` guard. A bare `isinstance(x, Sequence)` check accepts a string, and `"abc"` would silently iterate character by character. An advanced prompt that asks for edge-case handling tends to surface that trap; a basic prompt never does.

## What to Look For

When evaluating your advanced prompt results:

- Did chain-of-thought produce an algorithm explanation in the docstring?
- Did the AI reach for `dataclass`, `TypedDict`, `NamedTuple`, or Pydantic? All are defensible — ask it why
- Did it raise `TypeError` and `ValueError` appropriately, or just `Exception`?
- Did it use `sorted()` (pure) or `.sort()` (mutating)?
- Are the test cases meaningful and covering edge cases?
