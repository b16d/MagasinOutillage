# Exercise 1: Basic Prompting - Solution (Python)

> Python variant of [`../exercise-1-basic.md`](../exercise-1-basic.md). Same task, same three prompts — only the target language changes.

## Techniques Used

- **Role**: Basic persona assignment
- **Context**: Direct task description

## Example Prompt

```
You are a Python developer.
Write a function that filters a list by score >= 70, sorts by score descending, and returns names.
```

## Typical Output

```python
def filter_and_sort(items):
    return [
        item["name"]
        for item in sorted(items, key=lambda i: i["score"], reverse=True)
        if item["score"] >= 70
    ]
```

## Analysis

**Pros**:

- Code works correctly
- Idiomatic one-expression solution

**Cons**:

- No docstring or comments
- No type hints
- No error handling
- The input shape is assumed to be a `dict` with `"name"` / `"score"` keys — never stated, never validated
- Filtering _after_ sorting: harmless here, wasteful on a large roster
- A `KeyError` on any malformed record, with no guidance on it

## What to Look For

When evaluating your basic prompt results:

- Did the AI pick `dict` or invent a class? Both are plausible — the prompt never said
- Did it order the operations the way you would have?
- Would you need follow-up prompts to get usable code?
