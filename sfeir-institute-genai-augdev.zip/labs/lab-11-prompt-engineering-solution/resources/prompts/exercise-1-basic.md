# Exercise 1: Basic Prompting - Solution

## Techniques Used

- **Role**: Basic persona assignment
- **Context**: Direct task description

## Example Prompt

```
You are a JavaScript developer.
Write a function that filters a list by score >= 70, sorts by score descending, and returns names.
```

## Typical Output

```javascript
function filterAndSort(items) {
  return items
    .filter((item) => item.score >= 70)
    .sort((a, b) => b.score - a.score)
    .map((item) => item.name);
}
```

## Analysis

**Pros**:

- Code works correctly
- Concise solution

**Cons**:

- No comments or documentation
- No error handling
- No type information
- No usage examples
- May need follow-up questions to clarify requirements

## What to Look For

When evaluating your basic prompt results:

- Did the AI understand the core task?
- How much ambiguity was in the output?
- Would you need follow-up prompts to get usable code?
