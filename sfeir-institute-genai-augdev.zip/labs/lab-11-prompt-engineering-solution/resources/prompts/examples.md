# Prompt Engineering Examples

A collection of prompts organized by technique level for common coding tasks.

## Basic Prompts (Role + Context)

### API Endpoint
```
Write a REST API endpoint that returns a list of users.
```

### Database Query
```
Write a SQL query to find the top 10 customers by order value.
```

### Function
```
Write a function to validate email addresses.
```

---

## Structured Prompts (Role + Context + Format)

### API Endpoint
```
You are a Node.js/Express developer.

Create a REST API endpoint that:
- Returns a paginated list of users
- Supports filtering by status (active/inactive)
- Returns JSON format

Include:
- Route definition
- Controller function
- Response structure
```

### Database Query
```
You are a SQL expert.

Write a query to find top customers:
- Table: orders (id, customer_id, total_amount, created_at)
- Table: customers (id, name, email)
- Criteria: Top 10 by total order value in last 30 days

Provide:
- The optimized query
- Brief explanation of approach
```

### Function
```
You are a senior developer.

Create an email validation function:
- Input: string (email address)
- Output: boolean (valid/invalid)
- Requirements: RFC 5322 compliant

Include:
- Function code
- Regex explanation
- Edge case handling
```

---

## Advanced Prompts (All 5 Techniques)

### API Endpoint
```
You are a senior Node.js/Express developer with expertise in REST API design.

## Task
Create a production-ready user listing endpoint.

## Requirements
- GET /api/users with pagination
- Query params: page, limit, status, search
- Response includes total count and pagination metadata
- Error handling for invalid parameters

## Example Request
GET /api/users?page=1&limit=10&status=active

## Example Response
{
  "data": [{ "id": 1, "name": "Alice", "status": "active" }],
  "pagination": { "page": 1, "limit": 10, "total": 42, "pages": 5 }
}

## Instructions
1. Think through the validation requirements
2. Design the response structure
3. Implement with TypeScript types
4. Add input validation
5. Include error responses

## Output
- Complete route and controller code
- TypeScript interfaces
- Error handling middleware
- Example test cases
```

### Database Query
```
You are a senior database architect specializing in PostgreSQL optimization.

## Task
Query to find top customers by revenue.

## Schema
- orders: id, customer_id, total_amount, created_at, status
- customers: id, name, email, created_at

## Requirements
- Top 10 customers by total order value
- Only completed orders from last 30 days
- Include customer name and email
- Handle edge cases (no orders, null values)

## Example Output
| rank | name  | email         | total_revenue |
|------|-------|---------------|---------------|
| 1    | Alice | alice@ex.com  | 5000.00       |

## Instructions
1. First, think through the join strategy
2. Consider index usage
3. Write the optimized query
4. Explain any performance considerations

## Output
- Final query
- Explanation of approach
- Index recommendations
- Performance notes
```

---

## Quick Reference

| Technique | When to Use |
|-----------|-------------|
| Basic | Quick exploration, simple tasks |
| Structured | Need documentation, specific format |
| Advanced | Production code, complex requirements |

## Tips

1. **Start simple, iterate**: Begin with basic, add detail if needed
2. **Include examples**: AI learns from patterns you show
3. **Specify constraints**: Language version, libraries, style guide
4. **Request explanation**: "Explain your approach" improves reasoning
5. **Test the output**: Always verify generated code works
