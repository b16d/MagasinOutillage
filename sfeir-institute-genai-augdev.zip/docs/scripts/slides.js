import { SfeirThemeInitializer } from 'sfeir-school-theme';
import RevealMarkdownPreview from '../plugins/reveal-markdown-preview.js';
import RevealSpeakerEventForward from '../plugins/reveal-speaker-event-forward.js';

function schoolSlides() {
  return [
    '00_intro.md',
    '01_speaker-acl.md',
    '02_agenda.md',

    // Module 1: Introduction to AI for Developers
    '10_module_1_intro-ai/10_module1_intro.md',
    '10_module_1_intro-ai/11_ai_fundamentals.md',
    '10_module_1_intro-ai/12_context_tokens.md',
    '10_module_1_intro-ai/13_market_models.md',
    '10_module_1_intro-ai/14_tools_panorama.md',
    '10_module_1_intro-ai/15_prompting_art.md',
    '10_module_1_intro-ai/16_glossary.md',
    '10_module_1_intro-ai/19_assessment_and_recap.md',

    // Module 2: Vibe Coding vs Agentic Coding
    '20_module_2_vibe_vs_agentic/20_module2_intro.md',
    '20_module_2_vibe_vs_agentic/21_vibe_coding_fundamentals.md',
    '20_module_2_vibe_vs_agentic/22_agentic_coding_fundamentals.md',
    '20_module_2_vibe_vs_agentic/29_assessment_and_recap.md',

    // Module 3: Discovery and Practice of Agentic Coding
    '30_module_3_agentic_coding/30_module3_intro.md',
    '30_module_3_agentic_coding/31_agentic_coding_fundamentals.md',
    '30_module_3_agentic_coding/32_context_management.md',
    '30_module_3_agentic_coding/33_best_practices.md',
    '30_module_3_agentic_coding/39_assessment_and_recap.md',

    // Module 4: Agentic Tools Deep Dive
    '40_module_4_ai_agentic_tools_deepdive/40_module4_intro.md',
    '40_module_4_ai_agentic_tools_deepdive/43_claude_code_features.md',
    '40_module_4_ai_agentic_tools_deepdive/44_github_copilot_features.md',
    '40_module_4_ai_agentic_tools_deepdive/45_gemini_cli_features.md',
    '40_module_4_ai_agentic_tools_deepdive/46_codex_cli_features.md',
    '40_module_4_ai_agentic_tools_deepdive/47_opencode_features.md',
    '40_module_4_ai_agentic_tools_deepdive/48_mistral_vibe_features.md',
    '40_module_4_ai_agentic_tools_deepdive/49_assessment_and_recap.md',

    // Module 5: MCP Servers Usage
    '50_module_5_mcp_servers_usage/50_module5_intro.md',
    '50_module_5_mcp_servers_usage/51_mcp_fundamentals.md',
    '50_module_5_mcp_servers_usage/52_mcp_use_cases.md',
    '50_module_5_mcp_servers_usage/53_mcp_claude_code_installation.md',
    '50_module_5_mcp_servers_usage/54_mcp_github_copilot_installation.md',
    '50_module_5_mcp_servers_usage/55_mcp_gemini_cli_installation.md',
    '50_module_5_mcp_servers_usage/56_mcp_codex_cli_installation.md',
    '50_module_5_mcp_servers_usage/57_mcp_opencode_installation.md',
    '50_module_5_mcp_servers_usage/58_mcp_mistral_vibe_installation.md',
    '50_module_5_mcp_servers_usage/58_mcp_server_tools.md',
    '50_module_5_mcp_servers_usage/59_assessment_and_recap.md',

    // Module 6: Team-Augmented Development
    '60_module_6_team_augmented/60_module6_intro.md',
    '60_module_6_team_augmented/61_lab_overview.md',
    '60_module_6_team_augmented/69_assessment_recap.md',

    // Module 7: Risks, Governance and Future
    '70_module_7_risks/70_module7_intro.md',
    '70_module_7_risks/71_human_in_the_loop.md',
    '70_module_7_risks/72_dependency_skills.md',
    '70_module_7_risks/73_security_risks.md',
    '70_module_7_risks/74_future_perspectives.md',
    '70_module_7_risks/79_assessment_and_recap.md',

    // Module 8: Final Exam
    '80_module_8_final_exam/80_module8_intro.md',
    '80_module_8_final_exam/81_module8_claude_code_final_exam.md',
    '80_module_8_final_exam/82_module8_github_copilot_final_exam.md',
    '80_module_8_final_exam/83_module8_gemini_cli_final_exam.md',
    '80_module_8_final_exam/84_module8_codex_cli_final_exam.md',
    '80_module_8_final_exam/85_module8_opencode_final_exam.md',
    '80_module_8_final_exam/86_module8_mistral_vibe_final_exam.md',

    // Module 10: Multi-Agent Orchestration
    //'100_module_10_multi_agent_orchestration/100_module10_intro.md',
    //'100_module_10_multi_agent_orchestration/101_multi_agent_architecture.md',
    //'100_module_10_multi_agent_orchestration/102_task_delegation_patterns.md',
    //'100_module_10_multi_agent_orchestration/103_error_handling_quality.md',
    //'100_module_10_multi_agent_orchestration/104_claude_code_orchestration.md',
    //'100_module_10_multi_agent_orchestration/105_copilot_orchestration.md',
    //'100_module_10_multi_agent_orchestration/106_gemini_cli_orchestration.md',
    //'100_module_10_multi_agent_orchestration/107_codex_cli_orchestration.md',
    //'100_module_10_multi_agent_orchestration/108_opencode_orchestration.md',
    //'100_module_10_multi_agent_orchestration/109_mistral_vibe_orchestration.md',
    //'100_module_10_multi_agent_orchestration/110_assessment_and_recap.md',

    // Module 11: Spec-Driven Development with AI Tools
    //'110_module_11_spec_driven_dev/110_module11_intro.md',
    //'110_module_11_spec_driven_dev/111_spec_driven_principles.md',
    //'110_module_11_spec_driven_dev/112_speckit.md',
    //'110_module_11_spec_driven_dev/113_openspec.md',
    //'110_module_11_spec_driven_dev/114_bmad.md',
    //'110_module_11_spec_driven_dev/115_comparison.md',
    //'110_module_11_spec_driven_dev/119_assessment_and_recap.md',

    // Module 12: MCP Server Creation
    //'120_module_12_mcp_server/120_module12_intro.md',
    //'120_module_12_mcp_server/121_mcp_architecture.md',
    //'120_module_12_mcp_server/122_mcp_inspector.md',
    //'120_module_12_mcp_server/123_typescript_sdk.md',
    //'120_module_12_mcp_server/124_java_sdk.md',
    //'120_module_12_mcp_server/125_mcp_security.md',
    //'120_module_12_mcp_server/129_assessment_and_recap.md',
  ];
}

function formation() {
  return [...schoolSlides()].map((slidePath) => {
    return { path: slidePath };
  });
}

SfeirThemeInitializer.init({
  slidesFactory: formation,
  defaultLang: 'EN',
  extrasRenderAttr: 'data-hmr-src',
  plugins: [RevealMarkdownPreview, RevealSpeakerEventForward],
});

import '../plugins/hmr-markdown-client';
