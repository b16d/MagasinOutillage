import 'sfeir-school-theme/theme';
import './custom.css';
import './scripts/slides.js';
