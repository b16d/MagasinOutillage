<!-- .slide: class="speaker-slide" -->
<div class="speaker-slide">

# Hello ! @SFEIR

## Mattias **Basle**

### Senior Developer at SFEIR Luxembourg

### basle.m@sfeir.com

![](./assets/images/logo-sfeir-blanc.png 'company')

![](./assets/images/speaker-mba.jpg 'speaker')

</div>

Notes:
Mattias Basle is a Backend Engineer with 4+ years of experience working in distributed system from e-commerce to banking applications, alongside experience in teaching in both academic and corporate medium.
