<!-- .slide: class="speaker-slide" -->
<div class="speaker-slide">

# Bonjour ! @SFEIR

## Jean-François **Garreau**

### Directeur Ingénierie chez SFEIR Nantes

### garreau.jf@sfeir.com

### @jefbinomed

![](./assets/images/logo-sfeir-blanc.png 'company')

![](./assets/images/speaker-jga.jpg 'speaker')

</div>
