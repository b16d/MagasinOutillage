<!-- .slide: class="first-slide" sfeir-level="2" sfeir-techno="AI" -->
# **Welcome to SFEIR Institute**
## **GenAI Augmented Developer**

Notes:
Welcome to SFEIR Institute's comprehensive training on GenAI Augmented Development.