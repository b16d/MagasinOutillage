<!-- .slide: -->

# SFEIR AI-Augmented Developer

## Examen final (OpenCode)

<br>

![](https://forms.gle/WC5Y2PteiYuCND1d9 'tc-qrcode h-500 text-below') https://tinyurl.com/3x5wjdcx

<!-- .element: class="center" -->

Notes:

Si l'URL raccourcie ne fonctionne plus, utilisez ce lien d'origine :
https://forms.gle/WC5Y2PteiYuCND1d9
