<!-- .slide: -->

# SFEIR AI-Augmented Developer

## Final Exam (Github Copilot)

<br>

![](https://forms.gle/b6aGJiDmJuFJnAKd8 'tc-qrcode h-500 text-below') https://tinyurl.com/2jth6tav

<!-- .element: class="center" -->

Notes:

In case shortned URL does no longer work, use this originallink:
https://forms.gle/b6aGJiDmJuFJnAKd8
