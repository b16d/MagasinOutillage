<!-- .slide: -->

# SFEIR AI-Augmented Developer

## Final Exam (OpenCode)

<br>

![](https://forms.gle/WC5Y2PteiYuCND1d9 'tc-qrcode h-500 text-below') https://tinyurl.com/3x5wjdcx

<!-- .element: class="center" -->

Notes:

In case shortned URL does no longer work, use this originallink:
https://forms.gle/WC5Y2PteiYuCND1d9
