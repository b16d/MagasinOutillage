<!-- .slide: -->

# SFEIR AI-Augmented Developer

## Examen final (Mistral Vibe)

<br>

![](https://forms.gle/Zngkf4b3YuoFVeGW8 'tc-qrcode h-500 text-below') https://tinyurl.com/52wndtem

<!-- .element: class="center" -->

Notes:

Si l'URL raccourcie ne fonctionne plus, utilisez ce lien d'origine :
https://forms.gle/Zngkf4b3YuoFVeGW8
