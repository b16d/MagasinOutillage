<!-- .slide: -->

# SFEIR AI-Augmented Developer

## Final Exam (Gemini CLI)

<br>

![](https://forms.gle/hnFYsjLVcA7JoxiA7 'tc-qrcode h-500 text-below') https://tinyurl.com/kdz6xw2a

<!-- .element: class="center" -->

Notes:

**Note (as of July 2026):** Gemini CLI was retired (May 2026; consumer access ended June 18, 2026) and succeeded by **Antigravity CLI** (Go-based, async multi-agent orchestration). This exam track is kept for reference and for trainees who completed the Gemini CLI lab; the questions remain valid for the concepts covered.

In case shortned URL does no longer work, use this originallink:
https://forms.gle/hnFYsjLVcA7JoxiA7
