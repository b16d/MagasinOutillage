<!-- .slide: class="transition" -->

# Aperçu du module 8

## Examen final

##==##

<!-- .slide: -->

# SFEIR AI-Augmented Developer

## Examen des connaissances

<br>

C'est l'occasion de démontrer les connaissances et compétences acquises tout au long de la formation. L'examen **couvre tous les modules**, en mettant l'accent sur la mise en pratique et l'esprit critique.

En cas de réussite et après validation de vos résultats, vous recevrez un certificat ainsi qu'un **badge numérique** attestant de vos compétences de développeur augmenté par l'IA.

<br>

- **⏱️ Durée de l'examen** : 30 minutes
- **❓ Nombre de questions** : 20 questions à choix multiples (QCM)
- **📊 Score de réussite** : 80 % minimum
