<!-- .slide: -->

# SFEIR AI-Augmented Developer

## Final Exam (Codex CLI)

<br>

![](https://forms.gle/b4pXjgnPQZi8kaRz5 'tc-qrcode h-500 text-below') https://tinyurl.com/yntbcpvk

<!-- .element: class="center" -->

Notes:

In case shortned URL does no longer work, use this originallink:
https://forms.gle/b4pXjgnPQZi8kaRz5
