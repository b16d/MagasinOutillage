<!-- .slide: -->

# SFEIR AI-Augmented Developer

## Final Exam (Mistral Vibe)

<br>

![](https://forms.gle/Zngkf4b3YuoFVeGW8 'tc-qrcode h-500 text-below') https://tinyurl.com/52wndtem

<!-- .element: class="center" -->

Notes:

In case shortned URL does no longer work, use this originallink:
https://forms.gle/Zngkf4b3YuoFVeGW8
