<!-- .slide: -->

# SFEIR AI-Augmented Developer

## Examen final (Claude Code)

<br>

![](https://forms.gle/7oWDNzwvaVbM1xDH7 'tc-qrcode h-500 text-below') https://tinyurl.com/yc8jbems

<!-- .element: class="center" -->

Notes:

Si l'URL raccourcie ne fonctionne plus, utilisez ce lien d'origine :
https://forms.gle/7oWDNzwvaVbM1xDH7
