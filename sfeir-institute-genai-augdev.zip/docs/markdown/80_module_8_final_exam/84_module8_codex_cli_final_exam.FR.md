<!-- .slide: -->

# SFEIR AI-Augmented Developer

## Examen final (Codex CLI)

<br>

![](https://forms.gle/b4pXjgnPQZi8kaRz5 'tc-qrcode h-500 text-below') https://tinyurl.com/yntbcpvk

<!-- .element: class="center" -->

Notes:

Si l'URL raccourcie ne fonctionne plus, utilisez ce lien d'origine :
https://forms.gle/b4pXjgnPQZi8kaRz5
