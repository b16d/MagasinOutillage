<!-- .slide: class="transition" -->

# Module 8 Overview

## Final Exam

##==##

<!-- .slide: -->

# SFEIR AI-Augmented Developer

## Knowledge Assessment Exam

<br>

This is your opportunity to demonstrate the knowledge and skills you've gained throughout the course. The exam will **cover all modules**, with a focus on practical application and critical thinking.

Upon successful completion and after validation of your results, you will receive a certificate of achievement, and a **digital badge**, recognizing your proficiency as an AI-Augmented Developer.

<br>

- **⏱️ Duration of Exam**: 30 minutes
- **❓ Number of questions**: 20 multiple-choice questions (MCQs)
- **📊 Passing Score**: 80% or higher
