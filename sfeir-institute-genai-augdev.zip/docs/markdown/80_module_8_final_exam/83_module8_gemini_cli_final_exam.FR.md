<!-- .slide: -->

# SFEIR AI-Augmented Developer

## Examen final (Gemini CLI)

<br>

![](https://forms.gle/hnFYsjLVcA7JoxiA7 'tc-qrcode h-500 text-below') https://tinyurl.com/kdz6xw2a

<!-- .element: class="center" -->

Notes:

**Note (à jour en juillet 2026) :** Gemini CLI a été retiré (mai 2026 ; fin de l'accès grand public le 18 juin 2026) et remplacé par **Antigravity CLI** (écrit en Go, orchestration multi-agents asynchrone). Ce parcours d'examen est conservé à titre de référence et pour les personnes ayant suivi le lab Gemini CLI ; les questions restent valables pour les concepts abordés.

Si l'URL raccourcie ne fonctionne plus, utilisez ce lien d'origine :
https://forms.gle/hnFYsjLVcA7JoxiA7
