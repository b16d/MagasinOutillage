<!-- .slide: -->

# SFEIR AI-Augmented Developer

## Examen final (Github Copilot)

<br>

![](https://forms.gle/b6aGJiDmJuFJnAKd8 'tc-qrcode h-500 text-below') https://tinyurl.com/2jth6tav

<!-- .element: class="center" -->

Notes:

Si l'URL raccourcie ne fonctionne plus, utilisez ce lien d'origine :
https://forms.gle/b6aGJiDmJuFJnAKd8
