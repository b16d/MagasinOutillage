<!-- .slide: -->

# SFEIR AI-Augmented Developer

## Final Exam (Claude Code)

<br>

![](https://forms.gle/7oWDNzwvaVbM1xDH7 'tc-qrcode h-500 text-below') https://tinyurl.com/yc8jbems

<!-- .element: class="center" -->

Notes:

In case shortned URL does no longer work, use this originallink:
https://forms.gle/7oWDNzwvaVbM1xDH7
