<!-- .slide: class="transition" -->

# Module 6: Assessment and Recap

## Team-Augmented Development

Notes:
Time to review what we've covered and assess your understanding of team-augmented development practices across Claude Code, GitHub Copilot, and Gemini CLI (retired May 2026; succeeded by Antigravity CLI — the concepts still apply to whichever tool you use).

##==##

<!-- .slide: -->

# **Learning Objectives Review**

## **What You Learned**

<br>

### **Using AI Augmentation in Team Scenarios**

- **Invoke agents** for architecture validation and API contracts
- **Leverage skills** for change impact analysis and flow tracing
- **Execute commands** for code review and PR preparation
- **Recognize hooks** that enforce quality gates automatically
- **Navigate references** for architecture and domain knowledge
- **Apply conventions** to accelerate team collaboration

Notes:
You've learned when and how to use pre-configured AI augmentation tools in team scenarios. The hands-on exercises demonstrated invoking agents, leveraging skills, and recognizing when hooks enforce standards automatically.

##==##

<!-- .slide: -->

# **Knowledge Check**

## **Question 1: Agent Purpose**

<br>

### What is the primary benefit of using role-specific agents (e.g., Architecture Guardian, Test Strategist)?

**A)** They execute faster than general-purpose AI assistants

**B)** They work offline without API access

**C)** They automatically fix code without human review

**D)** They provide domain expertise and enforce team standards consistently

<br>

<details>
<summary>Answer</summary>
<strong>D) They provide domain expertise and enforce team standards consistently</strong> - Role-specific agents encode team knowledge (architecture decisions, testing patterns, coding standards) so every developer gets the same expert guidance. They act as always-available specialists who apply consistent standards across the team.
</details>

Notes:
Agents encode institutional knowledge—the expertise that would otherwise live only in senior developers' heads—making it accessible to the entire team.

##==##

<!-- .slide: -->

# **Knowledge Check**

## **Question 2: Hooks Purpose**

<br>

### When should you use hooks in team-augmented development?

**A)** To automate quality gates before commits or after file changes

**B)** Only during production deployments

**C)** To replace manual code reviews entirely

**D)** Only when working alone on a project

<br>

<details>
<summary>Answer</summary>
<strong>A) To automate quality gates before commits or after file changes</strong> - Hooks intercept developer actions (like committing code or saving files) to automatically run validations—checking coding standards, running tests, or verifying security patterns. They catch issues early without requiring manual checks.
</details>

Notes:
Hooks shift quality enforcement left—catching issues at commit time rather than during code review or production. They work alongside (not instead of) human review.

##==##

<!-- .slide: -->

# **Knowledge Check**

## **Question 3: Skills vs Commands**

<br>

### What distinguishes a skill from a command in AI-augmented development?

**A)** Skills are faster to execute than commands

**B)** Commands work across platforms; skills are platform-specific

**C)** Skills are model or user-invoked; commands are only user-invoked via slash syntax

**D)** Skills require admin privileges; commands don't

<br>

<details>
<summary>Answer</summary>
<strong>C) Skills are user or model-invoked; commands are user-invoked via slash syntax</strong> - Skills (like <code>topology-awareness</code>) are automatically activated by the AI model based on context. Commands (like <code>/code-reviewer</code>) are explicitly invoked by users with slash syntax.
</details>

Notes:
The distinction between skills and commands reflects different patterns of AI assistance: automatic contextual help (model decides when to use skills) vs. explicit task invocation (user triggers commands with /).

##==##

<!-- .slide: -->

# **Resources**

## **Further Learning**

<br>

### **Documentation**

- [Claude Code Docs](https://docs.anthropic.com/en/docs/claude-code) - Official Claude Code documentation
- [GitHub Copilot Customization](https://docs.github.com/en/copilot/customizing-copilot) - Copilot agents, prompts, instructions
- [Gemini CLI Documentation](https://geminicli.com/docs/) - Gemini CLI commands and configuration
- [Codex CLI Documentation](https://developers.openai.com/codex) - Codex CLI commands and configuration
- [OpenCode CLI Documentation](https://opencode.ai/docs) - OpenCode CLI commands and configuration

<br><br>

### **Lab Solutions**

- Review `labs/lab-61-team-augmented-dev/photo-gallery-fullstack/`
- Platform configs: `.claude/`, `.github/`, `.gemini/`, `.opencode/` directories
- Platform guides: `CLAUDE.md`, `GEMINI.md`, `AGENTS.md`

Notes:
Use the lab support project as a template for your own team configurations. The platform-specific directories contain complete examples of agents, commands, skills, hooks, and references.
