<!-- .slide: class="transition" -->

# Module 6 : Évaluation et synthèse

## Développement augmenté en équipe

Notes:
Il est temps de revoir ce que nous avons couvert et d'évaluer votre compréhension des pratiques de développement augmenté en équipe avec Claude Code, GitHub Copilot et Gemini CLI (retiré en mai 2026 ; remplacé par Antigravity CLI — les concepts restent valables quel que soit l'outil utilisé).

##==##

<!-- .slide: -->

# **Revue des objectifs pédagogiques**

## **Ce que vous avez appris**

<br>

### **Utiliser l'augmentation IA en contexte d'équipe**

- **Invoquer des agents** pour valider l'architecture et les contrats d'API
- **Exploiter les skills** pour analyser l'impact des changements et tracer les flux
- **Exécuter des commandes** pour la revue de code et la préparation des PR
- **Reconnaître les hooks** qui imposent automatiquement les quality gates
- **Naviguer dans les références** d'architecture et de connaissance métier
- **Appliquer les conventions** pour accélérer la collaboration d'équipe

Notes:
Vous avez appris quand et comment utiliser des outils d'augmentation IA préconfigurés en contexte d'équipe. Les exercices pratiques ont montré comment invoquer des agents, exploiter des skills et reconnaître quand les hooks imposent automatiquement les standards.

##==##

<!-- .slide: -->

# **Test de connaissances**

## **Question 1 : Rôle des agents**

<br>

### Quel est le principal bénéfice des agents spécialisés par rôle (ex. Architecture Guardian, Test Strategist) ?

**A)** Ils s'exécutent plus vite que les assistants IA généralistes

**B)** Ils fonctionnent hors ligne, sans accès API

**C)** Ils corrigent le code automatiquement, sans revue humaine

**D)** Ils apportent une expertise métier et imposent les standards d'équipe de façon cohérente

<br>

<details>
<summary>Réponse</summary>
<strong>D) Ils apportent une expertise métier et imposent les standards d'équipe de façon cohérente</strong> - Les agents spécialisés encodent le savoir de l'équipe (décisions d'architecture, patterns de test, standards de code) pour que chaque développeur reçoive les mêmes conseils d'expert. Ils agissent comme des spécialistes toujours disponibles, appliquant des standards cohérents dans toute l'équipe.
</details>

Notes:
Les agents encodent le savoir institutionnel — l'expertise qui, sinon, ne réside que dans la tête des développeurs seniors — et le rendent accessible à toute l'équipe.

##==##

<!-- .slide: -->

# **Test de connaissances**

## **Question 2 : Rôle des hooks**

<br>

### Quand faut-il utiliser des hooks en développement augmenté en équipe ?

**A)** Pour automatiser les quality gates avant un commit ou après une modification de fichier

**B)** Uniquement lors des déploiements en production

**C)** Pour remplacer entièrement les revues de code manuelles

**D)** Uniquement quand on travaille seul sur un projet

<br>

<details>
<summary>Réponse</summary>
<strong>A) Pour automatiser les quality gates avant un commit ou après une modification de fichier</strong> - Les hooks interceptent les actions du développeur (commit, sauvegarde de fichier) pour lancer automatiquement des validations : standards de code, tests, vérification des patterns de sécurité. Ils détectent les problèmes tôt, sans contrôle manuel.
</details>

Notes:
Les hooks déplacent le contrôle qualité vers l'amont : les problèmes sont détectés au commit plutôt qu'en revue de code ou en production. Ils complètent la revue humaine, ils ne la remplacent pas.

##==##

<!-- .slide: -->

# **Test de connaissances**

## **Question 3 : Skills vs commandes**

<br>

### Qu'est-ce qui distingue un skill d'une commande en développement augmenté par l'IA ?

**A)** Les skills s'exécutent plus vite que les commandes

**B)** Les commandes sont multiplateformes ; les skills sont spécifiques à une plateforme

**C)** Les skills sont invoqués par le modèle ou l'utilisateur ; les commandes uniquement par l'utilisateur via la syntaxe slash

**D)** Les skills exigent des privilèges admin ; pas les commandes

<br>

<details>
<summary>Réponse</summary>
<strong>C) Les skills sont invoqués par l'utilisateur ou le modèle ; les commandes sont invoquées par l'utilisateur via la syntaxe slash</strong> - Les skills (comme <code>topology-awareness</code>) sont activés automatiquement par le modèle IA selon le contexte. Les commandes (comme <code>/code-reviewer</code>) sont invoquées explicitement par l'utilisateur avec la syntaxe slash.
</details>

Notes:
La distinction entre skills et commandes reflète deux modes d'assistance IA : l'aide contextuelle automatique (le modèle décide quand utiliser un skill) et l'invocation explicite d'une tâche (l'utilisateur déclenche une commande avec /).

##==##

<!-- .slide: -->

# **Ressources**

## **Pour aller plus loin**

<br>

### **Documentation**

- [Claude Code Docs](https://docs.anthropic.com/en/docs/claude-code) - Documentation officielle de Claude Code
- [GitHub Copilot Customization](https://docs.github.com/en/copilot/customizing-copilot) - Agents, prompts et instructions Copilot
- [Gemini CLI Documentation](https://geminicli.com/docs/) - Commandes et configuration de Gemini CLI
- [Codex CLI Documentation](https://developers.openai.com/codex) - Commandes et configuration de Codex CLI
- [OpenCode CLI Documentation](https://opencode.ai/docs) - Commandes et configuration d'OpenCode CLI

<br><br>

### **Solutions des labs**

- Revoir `labs/lab-61-team-augmented-dev/photo-gallery-fullstack/`
- Configs par plateforme : répertoires `.claude/`, `.github/`, `.gemini/`, `.opencode/`
- Guides par plateforme : `CLAUDE.md`, `GEMINI.md`, `AGENTS.md`

Notes:
Utilisez le projet support du lab comme modèle pour vos propres configurations d'équipe. Les répertoires spécifiques à chaque plateforme contiennent des exemples complets d'agents, de commandes, de skills, de hooks et de références.
