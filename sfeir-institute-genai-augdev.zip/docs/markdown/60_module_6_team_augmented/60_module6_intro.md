<!-- .slide: class="transition" -->

# Module 6: Team-Augmented Development

## Scaling AI Practices Across Teams

Notes:
Welcome to Module 6! This module focuses on team-wide AI-augmented development practices across Claude Code, GitHub Copilot, and Gemini platforms. We'll explore agents, skills, commands, hooks, and shared knowledge references that enable consistent, scalable AI assistance for entire development teams. Duration: 2.5-3 hours (20 min slides + 130-160 min hands-on lab).

##==##

<!-- .slide: -->

# **Learning Objectives**

<br>

### **By the end of this module, you will be able to:**

- **Invoke** the right agents and commands for architecture validation, API contracts, and release safety
- **Leverage** reusable skills for change impact analysis, flow tracing, and safe refactoring
- **Navigate** shared knowledge references (architecture, domain glossary, on-call guides)
- **Recognize** when hooks automatically enforce quality gates and coding standards
- **Apply** platform-specific conventions to accelerate team workflows

Notes:
These learning objectives focus on effectively using pre-configured AI augmentation tools in team scenarios. The lab provides complete agent, skill, command, and hook configurations—your goal is to learn when and how to use them.

##==##

<!-- .slide: -->

# **Prerequisites**

<br>

### **Required Knowledge:**

- ✅ Completion of Modules 1-5 (AI fundamentals, agentic coding, tools comparison, MCP)
- ✅ Experience with your chosen platform (Claude Code, GitHub Copilot, or Gemini Code Assist)
- ✅ Familiarity with Git workflows and pull request processes
- ✅ Basic understanding of project structure and architecture patterns

### **Required Setup:**

<!-- .element: class="md-padding-top" -->

- ✅ Active AI platform subscription (Claude Code, Copilot, or Gemini)
- ✅ VS Code or compatible IDE with AI extensions installed
- ✅ Lab support project access (`photo-gallery-fullstack`)

Notes:
This module builds directly on concepts from Modules 1-5. Ensure you have your AI platform configured and ready. The lab provides a complete support project with pre-configured team augmentation artifacts for hands-on practice.
