<!-- .slide: class="exercice" -->

# Exercice 1 : Développement augmenté en équipe

## Lab 61

<br>

### 👉 Voir les **instructions** dans

### <code data-markdown-preview="/labs/lab-61-team-augmented-dev/README.md">labs/lab-61-team-augmented-dev/README.md</code>

Notes:

**Objectifs pédagogiques :**

- Appliquer l'assistance IA à l'échelle de l'équipe pour valider l'architecture et les contrats d'API
- Exploiter des skills réutilisables entre plusieurs développeurs et plateformes
- Mettre en œuvre les conventions propres à chaque plateforme (agents, prompts, hooks)
- Gérer la connaissance partagée via des références et des glossaires métier

Choisissez UNE section de plateforme (Claude Code, GitHub Copilot, Gemini CLI ou Codex CLI) et réalisez 10-11 exercices progressifs (130-160 minutes). Note (en juillet 2026) : la piste Gemini CLI fonctionne toujours pour le lab, mais Gemini CLI a été retiré (mai 2026) et remplacé par Antigravity CLI — préférez une autre piste si vous démarrez.

##==##

<!-- .slide: class="exercice" -->

# Exercice 1 : Développement augmenté en équipe

## Lab 61

<br>

### 💡 Voir la **solution** dans

### <code data-markdown-preview="/labs/lab-61-team-augmented-dev-solution/README.md">labs/lab-61-team-augmented-dev-solution/README.md</code>

Notes:

**Points clés :**

- Maîtrise des agents/commandes : invoquer le bon agent selon le scénario
- Connaissance des skills : savoir quand les capacités sont invoquées automatiquement
- Usage des références : naviguer efficacement dans la connaissance partagée
- Conventions de plateforme : repérer les différences de syntaxe entre plateformes
- Collaboration d'équipe : intégrer ses coéquipiers aux setups augmentés en équipe
