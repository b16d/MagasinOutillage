<!-- .slide: class="exercice" -->

# Exercise 1: Team-Augmented Development

## Lab 61

<br>

### 👉 Follow **instructions** in

### <code data-markdown-preview="/labs/lab-61-team-augmented-dev/README.md">labs/lab-61-team-augmented-dev/README.md</code>

Notes:

**Learning Objectives:**

- Apply team-wide AI assistance for architecture validation and API contracts
- Leverage reusable skills across multiple developers and platforms
- Implement platform-specific conventions (agents, prompts, hooks)
- Manage shared knowledge through references and domain glossaries

Choose ONE platform section (Claude Code, GitHub Copilot, Gemini CLI, or Codex CLI) and complete 10-11 progressive exercises (130-160 minutes). Note (as of July 2026): the Gemini CLI track still works for the lab, but Gemini CLI was retired (May 2026) and succeeded by Antigravity CLI — prefer another track if starting fresh.

##==##

<!-- .slide: class="exercice" -->

# Exercise 1: Team-Augmented Development

## Lab 61

<br>

### 💡 Read **solution** at

### <code data-markdown-preview="/labs/lab-61-team-augmented-dev-solution/README.md">labs/lab-61-team-augmented-dev-solution/README.md</code>

Notes:

**Key Takeaways:**

- Agent/Command Mastery: Invoke the right agent for each scenario
- Skill Awareness: Understand when capabilities are automatically invoked
- Reference Utilization: Navigate shared knowledge effectively
- Platform Conventions: Recognize platform-specific syntax differences
- Team Collaboration: Onboard teammates to team-augmented setups
