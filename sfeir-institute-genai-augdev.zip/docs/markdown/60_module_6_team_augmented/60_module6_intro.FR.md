<!-- .slide: class="transition" -->

# Module 6 : Développement augmenté en équipe

## Passer les pratiques IA à l'échelle des équipes

Notes:
Bienvenue dans le module 6 ! Ce module porte sur les pratiques de développement augmenté par l'IA à l'échelle de l'équipe, sur Claude Code, GitHub Copilot et Gemini. Nous explorerons les agents, skills, commandes, hooks et références de connaissances partagées qui permettent une assistance IA cohérente et scalable pour toute une équipe de développement. Durée : 2h30-3h (20 min de slides + 130-160 min de lab pratique).

##==##

<!-- .slide: -->

# **Objectifs pédagogiques**

<br>

### **À la fin de ce module, vous saurez :**

- **Invoquer** les bons agents et commandes pour la validation d'architecture, les contrats d'API et la sûreté des releases
- **Exploiter** des skills réutilisables pour l'analyse d'impact, le traçage de flux et le refactoring sûr
- **Naviguer** dans les références de connaissances partagées (architecture, glossaire métier, guides d'astreinte)
- **Reconnaître** quand les hooks appliquent automatiquement les quality gates et standards de code
- **Appliquer** les conventions propres à chaque plateforme pour accélérer les workflows d'équipe

Notes:
Ces objectifs visent l'usage efficace d'outils d'augmentation IA préconfigurés en contexte d'équipe. Le lab fournit des configurations complètes d'agents, skills, commandes et hooks — votre objectif est d'apprendre quand et comment les utiliser.

##==##

<!-- .slide: -->

# **Prérequis**

<br>

### **Connaissances requises :**

- ✅ Modules 1 à 5 terminés (fondamentaux IA, codage agentique, comparatif des outils, MCP)
- ✅ Expérience de votre plateforme (Claude Code, GitHub Copilot ou Gemini Code Assist)
- ✅ Maîtrise des workflows Git et du processus de pull request
- ✅ Bases de la structure projet et des patterns d'architecture

### **Configuration requise :**

<!-- .element: class="md-padding-top" -->

- ✅ Abonnement actif à une plateforme IA (Claude Code, Copilot ou Gemini)
- ✅ VS Code ou IDE compatible avec les extensions IA installées
- ✅ Accès au projet support du lab (`photo-gallery-fullstack`)

Notes:
Ce module s'appuie directement sur les concepts des modules 1 à 5. Vérifiez que votre plateforme IA est configurée et prête. Le lab fournit un projet support complet, avec des artefacts d'augmentation d'équipe préconfigurés pour la pratique.
