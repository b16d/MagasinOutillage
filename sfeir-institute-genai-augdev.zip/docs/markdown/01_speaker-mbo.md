<!-- .slide: class="speaker-slide" -->
<div class="speaker-slide">

# Hello ! @SFEIR

## Mohamed **BOUZIDI**

### AI Champion, Senior C# .NET Engineer

### bouzidi.m@sfeir.com

![](./assets/images/logo-sfeir-blanc.png 'company')

![](./assets/images/speaker-mbo.png 'speaker')

</div>

Notes:
Mohamed BOUZIDI is AI Champion and Senior C# .NET Consulting Engineer at SFEIR, with Angular expertise and a certified agile profile (PSM I™, PSM II™, PSPO I™, PSPO II™), specialized in AI-augmented development.
