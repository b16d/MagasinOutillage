<!-- .slide: class="speaker-slide" -->
<div class="speaker-slide">

# Bonjour ! @SFEIR

## Mohamed **BOUZIDI**

### AI Champion, Ingénieur C# .NET Senior

### bouzidi.m@sfeir.com

![](./assets/images/logo-sfeir-blanc.png 'company')

![](./assets/images/speaker-mbo.png 'speaker')

</div>

Notes:
Mohamed BOUZIDI est AI Champion et Ingénieur Conseil Senior C# .NET chez SFEIR, avec une expertise Angular et un profil agile certifié (PSM I™, PSM II™, PSPO I™, PSPO II™), spécialisé dans le développement augmenté par l'IA.
