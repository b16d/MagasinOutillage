<!-- .slide: class="speaker-slide" -->
<div class="speaker-slide">

# Hello ! @SFEIR

## Mattias **Basle**

### Senior Developer chez SFEIR Luxembourg

### basle.m@sfeir.com

![](./assets/images/logo-sfeir-blanc.png 'company')

![](./assets/images/speaker-mba.jpg 'speaker')

</div>

Notes:
Mattias Basle est ingénieur backend avec plus de 4 ans d'expérience sur des systèmes distribués, de l'e-commerce aux applications bancaires, ainsi qu'une expérience d'enseignement en milieu académique et en entreprise.
