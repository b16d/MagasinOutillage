<!-- .slide: class="speaker-slide" -->
<div class="speaker-slide">

# Hello ! @SFEIR

## Jean-François **Garreau**

### Engineer Director at SFEIR Nantes

### garreau.jf@sfeir.com

### @jefbinomed

![](./assets/images/logo-sfeir-blanc.png 'company')

![](./assets/images/speaker-jga.jpg 'speaker')

</div>
