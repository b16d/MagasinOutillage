<!-- .slide: class="speaker-slide" -->
<div class="speaker-slide">

# Bonjour ! @SFEIR

## Guillaume **Homberg**

### Engineering Director & AI Champion chez SFEIR Luxembourg

### homberg.g@sfeir.com

![](./assets/images/logo-sfeir-blanc.png 'company')

![](./assets/images/speaker-gho.jpg 'speaker')

</div>

Notes:
Guillaume Homberg est Engineering Director et AI Champion chez SFEIR Luxembourg, spécialisé dans le développement augmenté par l'IA et le leadership d'ingénierie.
