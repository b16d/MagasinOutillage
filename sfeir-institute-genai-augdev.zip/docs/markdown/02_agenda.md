<!-- .slide -->

# **Learning Journey**

<br>

## **What You'll Learn**

- **AI Fundamentals**: Core concepts and prompt engineering
- **Agentic Coding**: From vibe coding to structured AI-driven development
- **Team Augmentation**: Collaborative workflows, shared contexts, and team standards
- **Multi-Agent Orchestration**: Specialized agents, complex task delegation, and MCP server creation (**Day 3**)
- **MCP Server Creation**: Building your own Model Context Protocol server for custom AI interactions (**Day 3**)
- **Spec-Driven Development**: From specifications to automated implementation (**Day 3**)

##==##

<!-- .slide-->

# **Learning Journey**

<br>

## **Prerequisites**

- **Programming experience** of at least one language (TypeScript, Java, Python, C#, Go, etc.)
- **Git proficiency** and modern **IDE experience** (VS Code, IntelliJ, WebStorm, etc.)
- **Command line skills** and collaborative workflow experience
- **AI Assistant access**

Notes:
This comprehensive 3-day program (21 hours) transforms developers into AI-augmented professionals. Each day builds practical skills, culminating in SFEIR Certified AI-Augmented Developer certification.
