<!-- .slide: class="transition" -->

# Human-in-the-Loop

## Pourquoi votre supervision est essentielle

Notes:
Cette section explique pourquoi la revue humaine reste essentielle malgré les capacités de l'IA. Durée : ~4 minutes.

##==##

<!-- .slide: -->

## Rôle de l'IA

| Forces de l'IA            | Apport humain         |
| ------------------------- | --------------------- |
| Tri initial du code       | Contexte métier       |
| Détection de motifs       | Vision architecturale |
| Génération de boilerplate | Logique métier        |
| Documentation auto        | Revue de sécurité     |

<!-- .element: class="sm-padding-top" -->

Notes:
L'IA ignore que votre roadmap a changé après une réunion client. Le contexte métier est critique.

##==##

<!-- .slide: -->

<img src="assets/images/70_module_7/human-loop-workflow.svg" alt="Workflow HITL" style="width:100%; height:auto;">

Notes:
Le schéma illustre un workflow human-in-the-loop en 4 étapes :

- (1) **Génération IA** - l'IA produit le code/les suggestions initiales,
- (2) **Revue humaine** - le développeur évalue la sortie sur la justesse, la sécurité et l'adéquation métier,
- (3) **Itération** - boucle de feedback où l'humain guide les améliorations de l'IA,
- (4) **Validation finale** - l'humain valide avant merge/déploiement. Point clé : la boucle n'est pas linéaire — prévoir 2-3 itérations sur les tâches complexes. C'est à l'étape « revue » que se produisent 75 % du gain de qualité.
