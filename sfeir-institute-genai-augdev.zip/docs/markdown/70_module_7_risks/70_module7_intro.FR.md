<!-- .slide: class="transition" -->

# Aperçu du module 7

## Risques, gouvernance et avenir

Notes:
Module sur les enjeux critiques du développement augmenté par l'IA. Durée : 30 minutes.

##==##

<!-- .slide: -->

## Objectifs pédagogiques

<br>

À la fin de ce module, vous saurez :

- **Comprendre** pourquoi le human-in-the-loop reste essentiel
- **Identifier** les signes d'atrophie cognitive et les risques de dépendance à l'IA
- **Reconnaître** les 5 principaux risques de sécurité du codage assisté par IA
- **Appliquer** une checklist de sécurité au code généré par IA
- **Anticiper** l'évolution du rôle de développeur

Notes:
Ces objectifs correspondent aux 3 sections clés : supervision humaine (US1), dépendance & compétences (US2) et sécurité (US3) — plus les perspectives d'avenir (US5). Le contenu PI/éthique est disponible comme support de référence formateur.
