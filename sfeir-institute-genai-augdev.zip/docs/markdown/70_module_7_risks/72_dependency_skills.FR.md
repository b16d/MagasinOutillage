<!-- .slide: class="transition" -->

# Dépendance aux outils IA

## Garder ses compétences clés

Notes:
Cette section couvre l'atrophie cognitive, les risques de dépendance et les stratégies d'atténuation. Durée : ~6 minutes. Objectif : sensibiliser les développeurs aux risques sans créer de peur.

##==##

<!-- .slide: -->

## Les preuves de l'atrophie cognitive

**Atrophie cognitive** : le déclin progressif des compétences de résolution de problèmes, de débogage et de conception causé par une délégation excessive à l'IA — comparable à la fonte musculaire par inactivité.

| Étude                                                                                                                                                                                                                                     | Constat                                                                           |
| ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | --------------------------------------------------------------------------------- |
| [**Anthropic (janv. 2026)**](https://www.anthropic.com/research/AI-assistance-coding-skills)                                                                                                                                              | Devs utilisant l'IA : **-17 points** aux quiz de maîtrise vs codage manuel        |
| [**MIT Media Lab (2025)**](https://arxiv.org/abs/2506.08872)                                                                                                                                                                              | ~47 % d'effondrement de la connectivité cérébrale (EEG) en travail assisté par IA |
| [**Microsoft/CMU (2025)**](https://www.microsoft.com/en-us/research/publication/the-impact-of-generative-ai-on-critical-thinking-self-reported-reductions-in-cognitive-effort-and-confidence-effects-from-a-survey-of-knowledge-workers/) | **40 % des tâches** : zéro pensée critique déclarée par les travailleurs          |

<br>

**Le paradoxe de la supervision** : superviser efficacement l'IA exige l'expertise que la sur-dépendance fait justement atrophier.

> Quand produire un résultat est si facile, il devient plus dur de prendre le temps d'apprendre. — Ingénieur Anthropic

<!-- .element: class="bbquote"-->

Notes:
L'essai randomisé d'Anthropic (n=52 ingénieurs juniors) a montré que les développeurs déléguant entièrement la génération de code obtenaient moins de 40 % aux quiz de maîtrise ; ceux utilisant l'IA pour l'exploration conceptuelle dépassaient 65 %. L'écart le plus fort portait sur les compétences de débogage. Le MIT Media Lab (n=54 étudiants, 4 mois, EEG) a constaté que 83 % des utilisateurs d'IA ne pouvaient pas restituer les points clés des essais qu'ils avaient écrits. Microsoft/CMU (n=319 travailleurs, CHI 2025) a montré qu'une plus grande confiance dans la GenAI est corrélée à moins de pensée critique. L'essai randomisé de METR (juillet 2025, n=16, 246 tâches) montrait un écart de perception d'environ 39 points de pourcentage (19 % plus lent mesuré vs 20 % plus rapide perçu) ; METR qualifie désormais ce résultat d'« historique » et un suivi de février 2026 a montré certains signes d'accélération : présentez-le donc comme un résultat de 2025, pas comme l'état actuel. Limites : échantillons réduits, l'étude du MIT ne portait pas spécifiquement sur le code, les données Microsoft sont auto-déclarées.

##==##

<!-- .slide: -->

## Signaux d'alerte et antidotes

| Signal d'alerte               | Ce qui se passe                     | Antidote                                  |
| ----------------------------- | ----------------------------------- | ----------------------------------------- |
| **Blocage page blanche**      | Impossible de démarrer sans IA      | Sessions « sans IA » (1h/semaine)         |
| **Débogage IA d'abord**       | Recours à l'IA avant de comprendre  | Lire d'abord la stack trace               |
| **Brouillard d'architecture** | Perte du modèle mental du système   | Dessiner des schémas, expliquer aux pairs |
| **Anxiété de panne**          | Panique quand l'IA est indisponible | Katas, projets perso sans IA              |

<br>

> Comment garder des compétences affûtées quand l'IA fait 60 % de votre travail ? — [Microsoft New Future of Work 2025](https://www.microsoft.com/en-us/research/wp-content/uploads/2025/12/New-Future-Of-Work-Report-2025.pdf)

<!-- .element: class="bbquote"-->

Notes:
L'étude interne d'Anthropic (132 ingénieurs, 53 entretiens, 200 000 transcriptions Claude Code) a relevé que les ingénieurs s'inquiétaient explicitement de « compétences qui s'atrophient à mesure qu'ils délèguent davantage ». Le New Future of Work Report 2025 de Microsoft documente la perte de compétences dans le travail intellectuel et recommande des interventions de conception (explications contrastives, apprentissage progressif). Les 4 signaux d'alerte sont des amorces de discussion — demandez aux stagiaires : « Lesquels avez-vous vécus ? »

##==##

<img src="assets/images/70_module_7/experience-comparison.svg" alt="Risk matrix showing coding approach by experience level: junior plus vibe coding equals critical risk requiring supervision, senior plus vibe coding equals moderate risk requiring vigilance, junior plus agentic coding equals safer approach with learning opportunity, senior plus agentic coding equals best practice recommended approach" style="width:100%; height:auto; display:block;">

Notes:

**Junior + vibe coding (risque critique) :** ce n'est pas une critique des développeurs juniors — tout le monde commence quelque part. Le problème est que le vibe coding amplifie l'inexpérience. Si vous ne savez pas à quoi ressemble du bon code, comment évaluer les suggestions de l'IA ? Les juniors sont ceux qui profitent le plus de l'opportunité d'apprentissage que procure la relecture de code : poser des questions, comprendre pourquoi certaines approches valent mieux que d'autres. Le vibe coding les prive de cet apprentissage tout en créant un risque en production.

**Senior + vibe coding (risque modéré) :** les développeurs seniors ont un avantage net en relecture de code, mais ils ne sont pas immunisés contre les risques du vibe coding. Le piège du « ça a l'air correct » est réel : un développeur expérimenté peut survoler du code et croire l'avoir relu alors qu'il n'a fait que reconnaître des motifs de surface. Les outils d'IA génèrent un code de plus en plus sophistiqué, qui demande une attention soutenue pour être relu correctement. Même les seniors ont besoin de processus de revue formels, pas seulement de coups d'œil rapides.

**Agentic coding pour tous :** juniors (avec supervision/binôme) comme seniors bénéficient de l'agentic coding. Les juniors apprennent du processus de revue, les seniors détectent les problèmes subtils. Le vibe coding doit être un choix conscient basé sur une évaluation du risque (prototypage, hackathons), pas un mode par défaut.
