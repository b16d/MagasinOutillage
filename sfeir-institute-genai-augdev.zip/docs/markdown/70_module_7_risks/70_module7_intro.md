<!-- .slide: class="transition" -->

# Module 7 Overview

## Risks, Governance and Future

Notes:
Module on critical challenges of AI-augmented development. Duration: 30 minutes.

##==##

<!-- .slide: -->

## Learning Objectives

<br>

By the end of this module, you will be able to:

- **Understand** why human-in-the-loop remains essential
- **Identify** cognitive atrophy signs and AI dependency risks
- **Recognize** the top 5 security risks of AI-assisted coding
- **Apply** a security checklist for AI-generated code
- **Anticipate** how the developer role is evolving

Notes:
These objectives map to the 3 core sections: human oversight (US1), dependency & skills (US2), and security (US3) — plus future perspectives (US5). IP/ethics content is available as trainer reference material.
