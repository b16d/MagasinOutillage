<!-- .slide: class="transition" -->

# Sécurité du code généré par IA

## Vulnérabilités à surveiller

Notes:
Cette section couvre les risques de sécurité propres au code généré par IA. Durée : ~4 minutes.

##==##

<!-- .slide: -->

## Top 5 des risques de sécurité du codage assisté par IA

_Instantané de juillet 2026 — basé sur des incidents réels et des travaux de recherche (données jusqu'au T2 2026)_

| #   | Risque                                                                                                                                                      | Preuves concrètes                                               |
| --- | ----------------------------------------------------------------------------------------------------------------------------------------------------------- | --------------------------------------------------------------- |
| 1   | [**Fuite de secrets et d'identifiants**](https://www.knostic.ai/blog/claude-cursor-env-file-secret-leakage)                                                 | Agents chargent les `.env` → clés envoyées aux fournisseurs LLM |
| 2   | [**Code vulnérable à grande échelle**](https://www.infosecurity-magazine.com/news/ai-generated-code-vulnerabilities/)                                       | 35 CVE issues de code IA en mars 2026 _(Infosecurity)_          |
| 3   | [**Backdoor via fichier de règles**](https://www.pillar.security/blog/new-vulnerability-in-github-copilot-and-cursor-how-hackers-can-weaponize-code-agents) | Configs empoisonnées détournent l'agent silencieusement         |
| 4   | [**Injection de prompt via le contexte**](https://thehackernews.com/2025/12/researchers-uncover-30-flaws-in-ai.html)                                        | Instructions cachées dans PR/code → RCE _(CVSS 9.6)_            |
| 5   | [**Confiance aveugle / revue insuffisante**](https://www.darkreading.com/application-security/coders-adopt-ai-agents-security-pitfalls-lurk-2026)           | Code IA non relu livré → 2,74× plus de vulnérabilités           |

<br>

**Principe clé :** _Traiter le code IA comme non fiable_ — relire, scanner, isoler

Notes:
Voici les 5 principaux risques de sécurité auxquels font face les développeurs qui codent avec des agents IA (Claude Code, Copilot, Cursor, etc.) — les chiffres ci-dessous sont un instantané de juillet 2026 (données jusqu'au T2 2026), recalibré depuis l'instantané d'avril 2026. À rafraîchir chaque trimestre. À noter : les versions récentes de Claude Code (dernière v2.1.215, juillet 2026) poursuivent le durcissement pertinent pour plusieurs de ces risques : contrôles de permissions Bash/PowerShell renforcés (les règles de refus couvrent les wrappers `env`/`sudo`/`watch`/`ionice`/`setsid` et les redirections de descripteurs de fichiers), correction de l'usurpation d'UI via commentaires bash multi-lignes (où des commentaires cachés pouvaient tromper l'utilisateur), heuristiques `rm` dangereuses détectant plus de motifs pipe+redirection, et plafonds de session limitant les boucles WebSearch/sous-agents incontrôlées. Rien de tout cela ne supprime le besoin des mitigations de la slide suivante — cela relève le niveau plancher.

**(1) Fuite de secrets et d'identifiants :** les agents de codage IA chargent automatiquement les fichiers .env dans le contexte, envoyant clés d'API et mots de passe aux fournisseurs de LLM. State of Secrets Sprawl 2026 de GitGuardian : 28,65 M de nouveaux secrets fuités sur GitHub public en 2025 (+34 % en un an, le plus fort bond annuel jamais enregistré), et les fuites de secrets liés aux services IA ont grimpé de +81 % en un an (~1,28 M de secrets fuités liés à des services IA). Les commits co-signés par Claude Code fuitent des secrets à ~2× la moyenne GitHub.

**(2) Code vulnérable à grande échelle :** 1 échantillon de code généré par IA sur 4 contient une vulnérabilité confirmée (AppSec Santa 2026, 534 échantillons sur 6 LLM). 35 CVE divulguées en mars 2026 uniquement pour du code généré par IA — 27 pour Claude Code, 4 pour Copilot, 2 pour Devin. Le code IA contient 2,74× plus de vulnérabilités que son équivalent écrit par un humain. Snyk rapporte 2 à 10× plus de vulnérabilités par développeur utilisant des outils IA.

**(3) Backdoor via fichier de règles :** découvert par Pillar Security (mars 2025). Les attaquants injectent des instructions Unicode cachées dans les fichiers de configuration (.cursorrules, copilot-instructions.md, CLAUDE.md). Ces règles empoisonnées altèrent silencieusement tout le code généré par l'agent. La propagation passe par les templates partagés, les dépôts open source et les bases de connaissances d'entreprise. GitHub a ajouté des avertissements Unicode ; Cursor a répondu que ce n'était « pas une vulnérabilité de leur côté ».

**(4) Injection de prompt via le contexte :** une injection de prompt cachée dans une description de PR, un commentaire de code ou un fichier de projet peut détourner les agents IA. CVE-2025-53773 : RCE via injection dans une description de PR Copilot (CVSS 9.6). Plus de 30 failles trouvées dans les principaux outils de codage IA (IDEsaster), 24 ayant reçu un identifiant CVE.

**(5) Confiance aveugle / revue insuffisante :** la culture du « vibe coding » pousse les développeurs à livrer du code qu'ils n'ont pas relu en profondeur. L'escalade sur le S1 2026, de 6 CVE (janv. 2026) à 35 CVE (mars 2026) dans du code généré par IA — une tendance qui s'est poursuivie au T2 2026 — montre l'ampleur du code IA non relu qui atteint la production. Mitigation clé : traiter TOUT code généré par IA comme non fiable — SAST obligatoire, revue humaine et exécution en bac à sable.

##==##

<!-- .slide: -->

## Atténuer les risques du codage assisté par IA

| Risque                         | Atténuation                                                                                                            |
| ------------------------------ | ---------------------------------------------------------------------------------------------------------------------- |
| **Fuite de secrets**           | `.gitignore` sur vos `.env` · Gestionnaires de secrets · Hooks pre-commit [GitGuardian](https://www.gitguardian.com/)  |
| **Code vulnérable**            | SAST obligatoire sur chaque PR · Contraintes de sécurité dans les prompts · `-50%` de vulns avec un prompting sécurisé |
| **Backdoor fichier de règles** | Auditer `.cursorrules` / `CLAUDE.md` (Unicode caché) · Diff des configs dans les PR · Épingler des versions fiables    |
| **Injection de prompt**        | Isoler l'exécution de l'agent · Restreindre l'accès fichiers/réseau · Relire les descriptions de PR avant traitement   |
| **Confiance aveugle**          | Revue ligne par ligne du code IA · Pair programming sur les chemins critiques · Pas de « vibe coding » en production   |

<br>

**Une règle à retenir :** _Si vous ne l'avez pas relu, vous ne l'avez pas écrit — mais vous en êtes responsable._

Notes:
Cette slide associe chacun des 5 risques à des mitigations actionnables dès aujourd'hui. Elles suivent une approche de défense en profondeur : prévenir (gestionnaires de secrets, .gitignore), détecter (SAST, GitGuardian, audits Unicode), contenir (bac à sable, permissions restreintes) et vérifier (revue humaine, pair programming). Le message clé est la responsabilité personnelle — l'IA génère le code, mais c'est le développeur qui répond de ce qui est livré. Le prompting sécurisé réduit à lui seul les vulnérabilités de 50 % (Veracode 2025). Les hooks pre-commit GitGuardian attrapent les secrets avant qu'ils n'atteignent le dépôt. Pour la backdoor via fichier de règles, GitHub affiche désormais des avertissements Unicode, mais les équipes doivent aussi comparer soigneusement les diffs des fichiers de config dans les PR. Pour l'injection de prompt, le principe du moindre privilège s'applique : les agents ne doivent accéder qu'aux fichiers et ressources réseau strictement nécessaires.

##==##

<!-- .slide: class="exercice" -->

# Exercice : risques, gouvernance et supervision humaine

## Lab 71

<br>

### 👉 Suivez les **instructions** dans

### <code data-markdown-preview="/labs/lab-71-risk-governance/README.md">labs/lab-71-risk-governance/README.md</code>

Notes:

- Démontrer une porte dérobée dans un fichier de règles et une injection véhiculée par les données utilisateur
- Vérifier les suggestions de dépendances de l'IA contre le vrai registre de paquets
- Calibrer la profondeur de relecture sur quatre diffs générés par IA
- Produire un RISK_REGISTER.md avec des responsables, pas seulement des inquiétudes
- Durée estimée : 50-60 minutes

##==##

<!-- .slide: class="exercice" -->

# Exercice : risques, gouvernance et supervision humaine

## Lab 71

<br>

### 💡 Consultez la **solution** dans

### <code data-markdown-preview="/labs/lab-71-risk-governance-solution/README.md">labs/lab-71-risk-governance-solution/README.md</code>

Notes:
La solution s'adresse au formateur : elle dévoile toutes les charges utiles et le classement complet des diffs. La question clé du débriefing est la première — « laquelle des trois expériences votre processus actuel aurait-il attrapée ? ». La réponse habituelle est aucune, et ce silence, c'est le module qui atterrit. Trois des quatre diffs de l'exercice 3 portent un commentaire plaidant pour un niveau de risque inférieur à ce que le code mérite ; c'est la leçon transférable, car dans du code généré par IA, la justification est générée aussi.
