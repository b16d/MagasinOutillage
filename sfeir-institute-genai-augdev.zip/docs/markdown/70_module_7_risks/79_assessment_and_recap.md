<!-- .slide: class="transition" -->

# Assessment and Recap

## Test Your Knowledge

Notes:
This section validates module learning outcomes. Duration: ~4 minutes.

##==##

<!-- .slide: -->

# **Knowledge Check**

## **Question 1: Team Dynamics**

<br>

### What is the key risk when replacing human pair programming with AI assistants?

**A)** Reduced knowledge transfer and mentorship

**B)** Higher infrastructure costs

**C)** Slower code review cycles

**D)** Incompatible coding styles

<br>

<details>
<summary>Answer</summary>
<strong>A) Reduced knowledge transfer and mentorship</strong> — Junior developers miss crucial mentorship and tacit knowledge that comes from working alongside experienced team members. AI can assist but cannot replace the human dynamics of knowledge sharing.
</details>

Notes:
Tacit knowledge—unwritten conventions, debugging intuition, architectural reasoning—transfers through human interaction, not AI sessions.

##==##

<!-- .slide: -->

# **Knowledge Check**

## **Question 2: AI-Assisted Coding Security**

<br>

### Which of the following is NOT one of the top 5 security risks of AI-assisted coding?

**A)** Secret & credential leakage from `.env` files loaded into agent context

**B)** Rules file backdoor via poisoned AI config files

**C)** Blind trust — shipping unreviewed AI-generated code to production

**D)** Model hallucination causing incorrect variable names

<br>

<details>
<summary>Answer</summary>
<strong>D) Model hallucination causing incorrect variable names</strong> — While hallucination is a real LLM limitation, it's not a security risk. The top 5 security risks of AI-assisted coding are: 
- (1) Secret & credential leakage, 
- (2) Vulnerable code at scale, 
- (3) Rules file backdoor, 
- (4) Prompt injection via context, and 
- (5) Blind trust / insufficient review. The key principle: treat all AI-generated code as untrusted.
</details>

Notes:
This question tests recall of the 5 security risks covered in the dedicated slide. The distractor (C) is intentionally plausible — hallucination is a well-known AI problem, but it's a correctness issue, not a security risk. The real risks all have concrete attack vectors with documented CVEs and incidents. This reinforces the distinction between "AI makes mistakes" (quality) and "AI introduces exploitable vulnerabilities" (security).

##==##

<!-- .slide: -->

# **Knowledge Check**

## **Question 3: Human-in-the-Loop**

<br>

### Why does the human remain essential even when AI-generated code looks correct?

**A)** AI is always slower than manual coding

**B)** AI lacks business context, architectural understanding, and long-term implications awareness

**C)** Regulations require it for all software projects

**D)** AI cannot generate syntactically correct code

<br>

<details>
<summary>Answer</summary>
<strong>B) AI lacks business context, architectural understanding, and long-term implications awareness</strong> — AI excels at initial screening, boilerplate generation, and auto-documentation. But humans are essential for domain logic, security review, architectural decisions, and understanding how code fits into the broader system and product roadmap.
</details>

Notes:
The key insight is that AI and humans have complementary strengths. The "looks fine" trap affects even senior developers who pattern-match on surface features without deep review. The question tests whether learners understand the WHY behind human-in-the-loop, not just that it's required.

##==##

<!-- .slide: -->

# **Knowledge Check**

## **Question 4: Skills Maintenance**

<br>

### What is the most effective strategy to prevent skill atrophy when using AI coding tools daily?

**A)** Limit AI usage to 2 hours per day

**B)** Only use AI for languages you don't know

**C)** Regular AI-free coding sessions combined with deep code review

**D)** Always rewrite AI-generated code from scratch

<br>

<details>
<summary>Answer</summary>
<strong>C) Regular AI-free coding sessions combined with deep code review</strong> — The METR study showed developers estimated 20-24% productivity gains while actually being 19% slower. The key is maintaining fundamentals through deliberate practice without AI, and ensuring you truly understand code during review rather than just approving it. Task rotation (some with AI, some without) prevents the "ask AI → deliver → skip understanding → need AI" erosion loop.
</details>

Notes:
Anthropic's study found 27% of AI-assisted tasks wouldn't have existed without AI, suggesting AI also creates new work. The erosion loop (ask AI → deliver → skip understanding → need AI → fundamentals atrophy) is the core risk. Regular deliberate practice without AI and mandatory comprehension during review are the two strongest mitigations.

##==##

<!-- .slide: -->

# **Resources**

## **Further Learning**

<br>

### Security

- [OWASP GenAI](https://genai.owasp.org/) — LLM & AI security standards
- [Pillar Security — Rules File Backdoor](https://www.pillar.security/blog/new-vulnerability-in-github-copilot-and-cursor-how-hackers-can-weaponize-code-agents) — Config poisoning attack
- [Knostic — .env Secret Leakage](https://www.knostic.ai/blog/claude-cursor-env-file-secret-leakage) — AI agents & credentials
- [GitGuardian 2026](https://blog.gitguardian.com/yes-github-copilot-can-leak-secrets/) — Secret leak rates with Copilot

<br>

### Cognitive Atrophy & Skills

- [Anthropic — AI & Coding Skills (2026)](https://www.anthropic.com/research/AI-assistance-coding-skills) — Mastery quiz RCT
- [METR 2025](https://metr.org/blog/2025-07-10-early-2025-ai-experienced-os-dev-study/) — Productivity paradox (+19% slower)
- [MIT Media Lab (2025)](https://arxiv.org/abs/2506.08872) — Brain connectivity & AI reliance
- [Anthropic — How AI Transforms Work](https://www.anthropic.com/research/how-ai-is-transforming-work-at-anthropic) — 60% AI usage internally

Notes:
Resources grouped by the two main themes of the module: security risks of AI-assisted coding, and cognitive atrophy / skills maintenance. All sources are 2025-2026 and verified. These allow trainees to go deeper on any topic discussed.
