<!-- .slide: class="transition" -->

# Human-in-the-Loop

## Why Your Oversight Remains Essential

Notes:
This section explains why human review is essential despite AI capabilities. Duration: ~4 minutes.

##==##

<!-- .slide: -->

## AI Role

| AI excels at           | Humans bring         |
| ---------------------- | -------------------- |
| Initial code screening | Business context     |
| Pattern detection      | Architectural vision |
| Boilerplate generation | Domain logic         |
| Auto documentation     | Security review      |

<!-- .element: class="sm-padding-top" -->

Notes:
AI doesn't know your roadmap changed after a client meeting. Business context is critical.

##==##

<!-- .slide: -->

<img src="assets/images/70_module_7/human-loop-workflow.svg" alt="HITL Workflow" style="width:100%; height:auto;">

Notes:
The diagram illustrates a 4-stage human-in-the-loop workflow:

- (1) **AI Generation** - AI produces initial code/suggestions,
- (2) **Human Review** - developer evaluates output for correctness, security, and business fit,
- (3) **Iteration** - feedback loop where human guides AI refinements,
- (4) **Final Approval** - human validates before merge/deploy. Key insight: the loop isn't linear—expect 2-3 iterations on complex tasks. The "review" stage is where 75% quality improvement happens.
