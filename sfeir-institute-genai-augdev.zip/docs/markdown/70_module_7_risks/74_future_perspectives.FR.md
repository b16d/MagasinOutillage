<!-- .slide: class="transition" -->

# Perspectives d'avenir

## Le rôle du développeur en transition

Notes:
Cette section couvre l'évolution de carrière du développeur. Durée : ~3 minutes.

##==##

<!-- .slide: -->

<img src="assets/images/70_module_7/developer-evolution-timeline.svg" alt="Chronologie de l'évolution du développeur" style="width:100%; height:auto;">

Notes:
La chronologie montre l'évolution du rôle de développeur :

- **2020** - Focus sur le code traditionnel,
- **2023** - Émergence du code assisté par IA,
- **2025** - Compétences d'orchestration d'IA valorisées,
- **2027+** - Domination des profils hybrides IA+Dev. Point clé : le rôle ne disparaît pas, il se transforme. Les compétences les plus valorisées passent de « écrire du code » à « diriger l'IA pour écrire du code » et « valider la sortie de l'IA ». Les développeurs qui s'adaptent gagnent en productivité ; ceux qui résistent risquent l'obsolescence.
