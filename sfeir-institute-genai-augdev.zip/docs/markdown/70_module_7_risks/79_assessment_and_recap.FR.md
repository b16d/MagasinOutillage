<!-- .slide: class="transition" -->

# Évaluation et Synthèse

## Testez vos connaissances

Notes:
Cette section valide les acquis du module. Durée : ~4 minutes.

##==##

<!-- .slide: -->

# **Quiz de connaissances**

## **Question 1 : Dynamique d'équipe**

<br>

### Risque majeur du remplacement du pair programming humain par l'IA ?

**A)** Transfert de connaissances et mentorat réduits

**B)** Coûts d'infrastructure plus élevés

**C)** Cycles de revue de code ralentis

**D)** Styles de code incompatibles

<br>

<details>
<summary>Réponse</summary>
<strong>A) Transfert de connaissances et mentorat réduits</strong> — Les développeurs juniors perdent le mentorat et le savoir tacite acquis au contact de collègues expérimentés. L'IA peut assister mais ne remplace pas la dynamique humaine du partage de connaissances.
</details>

Notes:
Le savoir tacite — conventions non écrites, intuition de débogage, raisonnement architectural — se transmet par l'interaction humaine, pas par des sessions IA.

##==##

<!-- .slide: -->

# **Quiz de connaissances**

## **Question 2 : Sécurité du code assisté par IA**

<br>

### Lequel n'est PAS dans le top 5 des risques de sécurité du code assisté par IA ?

**A)** Fuite de secrets et d'identifiants depuis des fichiers `.env` chargés dans le contexte de l'agent

**B)** Rules file backdoor via des fichiers de config IA empoisonnés

**C)** Confiance aveugle — livrer en production du code IA non relu

**D)** Hallucination du modèle produisant des noms de variables erronés

<br>

<details>
<summary>Réponse</summary>
<strong>D) Hallucination du modèle produisant des noms de variables erronés</strong> — L'hallucination est une vraie limite des LLM, mais pas un risque de sécurité. Le top 5 des risques de sécurité du code assisté par IA : 
- (1) Fuite de secrets et d'identifiants, 
- (2) Code vulnérable à grande échelle, 
- (3) Rules file backdoor, 
- (4) Prompt injection via le contexte, et 
- (5) Confiance aveugle / revue insuffisante. Principe clé : traiter tout code généré par IA comme non fiable.
</details>

Notes:
Cette question teste la mémorisation des 5 risques de sécurité vus dans la slide dédiée. Le distracteur (C) est volontairement plausible : l'hallucination est un problème IA bien connu, mais c'est un enjeu de justesse, pas de sécurité. Les vrais risques ont tous des vecteurs d'attaque concrets, avec CVE et incidents documentés. Cela renforce la distinction entre « l'IA se trompe » (qualité) et « l'IA introduit des vulnérabilités exploitables » (sécurité).

##==##

<!-- .slide: -->

# **Quiz de connaissances**

## **Question 3 : Human-in-the-loop**

<br>

### Pourquoi l'humain reste-t-il essentiel même quand le code IA semble correct ?

**A)** L'IA est toujours plus lente que le codage manuel

**B)** L'IA n'a ni contexte métier, ni compréhension architecturale, ni vision des implications à long terme

**C)** La réglementation l'impose pour tout projet logiciel

**D)** L'IA ne sait pas générer du code syntaxiquement correct

<br>

<details>
<summary>Réponse</summary>
<strong>B) L'IA n'a ni contexte métier, ni compréhension architecturale, ni vision des implications à long terme</strong> — L'IA excelle au premier filtrage, au boilerplate et à l'auto-documentation. Mais l'humain est indispensable pour la logique métier, la revue de sécurité, les décisions d'architecture et la compréhension de la place du code dans le système et la roadmap produit.
</details>

Notes:
L'idée clé : IA et humains ont des forces complémentaires. Le piège du « ça a l'air bon » touche même les développeurs seniors, qui reconnaissent des motifs de surface sans revue approfondie. La question teste si les apprenants comprennent le POURQUOI du human-in-the-loop, pas seulement son caractère obligatoire.

##==##

<!-- .slide: -->

# **Quiz de connaissances**

## **Question 4 : Maintien des compétences**

<br>

### Quelle est la stratégie la plus efficace contre l'atrophie des compétences avec un usage quotidien de l'IA ?

**A)** Limiter l'usage de l'IA à 2 heures par jour

**B)** N'utiliser l'IA que pour les langages que vous ne connaissez pas

**C)** Des sessions régulières de code sans IA, couplées à une revue de code approfondie

**D)** Toujours réécrire de zéro le code généré par IA

<br>

<details>
<summary>Réponse</summary>
<strong>C) Des sessions régulières de code sans IA, couplées à une revue de code approfondie</strong> — L'étude METR montre que les développeurs estimaient un gain de productivité de 20-24 % alors qu'ils étaient 19 % plus lents. La clé : entretenir les fondamentaux par une pratique délibérée sans IA, et vraiment comprendre le code en revue au lieu de simplement l'approuver. La rotation des tâches (certaines avec IA, d'autres sans) évite la boucle d'érosion « demander à l'IA → livrer → sauter la compréhension → besoin de l'IA ».
</details>

Notes:
L'étude d'Anthropic montre que 27 % des tâches assistées par IA n'auraient pas existé sans IA : l'IA crée aussi du travail nouveau. La boucle d'érosion (demander à l'IA → livrer → sauter la compréhension → besoin de l'IA → atrophie des fondamentaux) est le risque central. Pratique délibérée régulière sans IA et compréhension obligatoire en revue sont les deux meilleures parades.

##==##

<!-- .slide: -->

# **Ressources**

## **Pour aller plus loin**

<br>

### Sécurité

- [OWASP GenAI](https://genai.owasp.org/) — Standards de sécurité LLM & IA
- [Pillar Security — Rules File Backdoor](https://www.pillar.security/blog/new-vulnerability-in-github-copilot-and-cursor-how-hackers-can-weaponize-code-agents) — Attaque par config empoisonnée
- [Knostic — .env Secret Leakage](https://www.knostic.ai/blog/claude-cursor-env-file-secret-leakage) — Agents IA & identifiants
- [GitGuardian 2026](https://blog.gitguardian.com/yes-github-copilot-can-leak-secrets/) — Taux de fuite de secrets avec Copilot

<br>

### Atrophie cognitive & compétences

- [Anthropic — AI & Coding Skills (2026)](https://www.anthropic.com/research/AI-assistance-coding-skills) — RCT quiz de maîtrise
- [METR 2025](https://metr.org/blog/2025-07-10-early-2025-ai-experienced-os-dev-study/) — Paradoxe de productivité (+19 % plus lent)
- [MIT Media Lab (2025)](https://arxiv.org/abs/2506.08872) — Connectivité cérébrale & dépendance à l'IA
- [Anthropic — How AI Transforms Work](https://www.anthropic.com/research/how-ai-is-transforming-work-at-anthropic) — 60 % d'usage IA en interne

Notes:
Ressources regroupées selon les deux thèmes du module : risques de sécurité du code assisté par IA, et atrophie cognitive / maintien des compétences. Toutes les sources sont 2025-2026 et vérifiées. Elles permettent aux stagiaires d'approfondir chaque sujet abordé.
