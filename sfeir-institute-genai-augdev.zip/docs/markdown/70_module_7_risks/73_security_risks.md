<!-- .slide: class="transition" -->

# AI-Generated Code Security

## Vulnerabilities to Watch For

Notes:
This section covers security risks specific to AI-generated code. Duration: ~4 minutes.

##==##

<!-- .slide: -->

## Top 5 Security Risks of AI-Assisted Coding

_Snapshot as of July 2026 — based on real-world incidents and research (data through Q2 2026)_

| #   | Risk                                                                                                                                             | Real-world evidence                                        |
| --- | ------------------------------------------------------------------------------------------------------------------------------------------------ | ---------------------------------------------------------- |
| 1   | [**Secret & Credential Leakage**](https://www.knostic.ai/blog/claude-cursor-env-file-secret-leakage)                                             | Agents auto-load `.env` files → keys sent to LLM providers |
| 2   | [**Vulnerable Code at Scale**](https://www.infosecurity-magazine.com/news/ai-generated-code-vulnerabilities/)                                    | 35 CVEs from AI code in March 2026 alone _(Infosecurity)_  |
| 3   | [**Rules File Backdoor**](https://www.pillar.security/blog/new-vulnerability-in-github-copilot-and-cursor-how-hackers-can-weaponize-code-agents) | Poisoned config files hijack agent behavior silently       |
| 4   | [**Prompt Injection via Context**](https://thehackernews.com/2025/12/researchers-uncover-30-flaws-in-ai.html)                                    | Hidden instructions in PRs/code achieve RCE _(CVSS 9.6)_   |
| 5   | [**Blind Trust / Insufficient Review**](https://www.darkreading.com/application-security/coders-adopt-ai-agents-security-pitfalls-lurk-2026)     | Devs ship unreviewed AI code → 2.74× more vulnerabilities  |

<br>

**Key principle:** _Treat AI code as untrusted_ — review, scan, sandbox

Notes:
These are the top 5 security risks developers face when coding with AI agents (Claude Code, Copilot, Cursor, etc.) — the figures below are a snapshot as of July 2026 (data through Q2 2026), re-baselined from the earlier April 2026 snapshot. Refresh quarterly. Notably, recent Claude Code releases (latest v2.1.215, July 2026) continue the hardening relevant to several of these risks: tighter Bash/PowerShell permission checks (deny rules match `env`/`sudo`/`watch`/`ionice`/`setsid` wrappers and file-descriptor redirects), multi-line bash comment UI-spoofing (where hidden comments could trick the user) is fixed, dangerous `rm` heuristics catch more pipe+redirect patterns, and session-wide caps now limit runaway WebSearch/subagent loops. None of these eliminate the need for the mitigations on the next slide — they raise the floor.

**(1) Secret & Credential Leakage:** AI coding agents auto-load .env files into context, sending API keys and passwords to LLM providers. GitGuardian's State of Secrets Sprawl 2026: 28.65M new secrets leaked on public GitHub in 2025 (+34% YoY, the largest single-year jump recorded), and AI-service secret leaks surged +81% YoY (~1.28M leaked secrets tied to AI services). Claude Code co-authored commits leak secrets at ~2× the GitHub-wide baseline.

**(2) Vulnerable Code at Scale:** 1 in 4 AI-generated code samples contains a confirmed vulnerability (AppSec Santa 2026, 534 samples across 6 LLMs). 35 CVEs disclosed in March 2026 alone from AI-generated code — 27 from Claude Code, 4 from Copilot, 2 from Devin. AI code contains 2.74× more vulnerabilities than human-written equivalents. Snyk reports 2-10× more vulnerabilities per developer using AI tools.

**(3) Rules File Backdoor:** Discovered by Pillar Security (March 2025). Attackers inject hidden Unicode instructions into config files (.cursorrules, copilot-instructions.md, CLAUDE.md). These poisoned rules silently alter all code the agent generates. Propagates through shared templates, open-source repos, and corporate knowledge bases. GitHub added Unicode warnings; Cursor said "not a vulnerability on their side."

**(4) Prompt Injection via Context:** Hidden prompt injection in PR descriptions, code comments, or project files can hijack AI agents. CVE-2025-53773: RCE via Copilot PR description injection (CVSS 9.6). 30+ flaws found across major AI coding tools (IDEsaster), 24 assigned CVE identifiers.

**(5) Blind Trust / Insufficient Review:** "Vibe coding" culture means developers ship code they haven't deeply reviewed. The H1-2026 escalation from 6 CVEs (Jan 2026) to 35 CVEs (March 2026) in AI-generated code — a trend that has continued into Q2 2026 — shows the scale of unreviewed AI code reaching production. Key mitigation: treat ALL AI-generated code as untrusted — mandatory SAST, human review, and sandboxed execution.

##==##

<!-- .slide: -->

## Mitigating AI-Assisted Coding Risks

| Risk                    | Mitigation                                                                                                           |
| ----------------------- | -------------------------------------------------------------------------------------------------------------------- |
| **Secret Leakage**      | `.gitignore` your `.env` · Use secret managers · Enable [GitGuardian](https://www.gitguardian.com/) pre-commit hooks |
| **Vulnerable Code**     | Mandatory SAST on every PR · Include security constraints in prompts · `-50%` vulns with secure prompting            |
| **Rules File Backdoor** | Audit `.cursorrules` / `CLAUDE.md` for hidden Unicode · Diff config files in PRs · Pin trusted rule versions         |
| **Prompt Injection**    | Sandbox agent execution · Restrict file/network access · Review PR descriptions before agent processing              |
| **Blind Trust**         | Line-by-line review of AI code · Pair programming on critical paths · No "vibe coding" in production                 |

<br>

**One rule to remember:** _If you didn't review it, you didn't write it — but you own it._

Notes:
This slide maps each of the 5 risks to actionable mitigations developers can adopt today. The mitigations follow a defense-in-depth approach: prevent (secret managers, .gitignore), detect (SAST, GitGuardian, Unicode audits), contain (sandboxing, restricted permissions), and verify (human review, pair programming). The key message is personal accountability — AI generates the code, but the developer is responsible for what ships. Secure prompting alone reduces vulnerabilities by 50% (Veracode 2025). GitGuardian pre-commit hooks catch secrets before they reach the repo. For Rules File Backdoor, GitHub now shows Unicode warnings, but teams should also diff config files carefully in PRs. For prompt injection, the principle of least privilege applies: agents should only have access to the files and network resources they strictly need.

##==##

<!-- .slide: class="exercice" -->

# Exercise: Risks, Governance and Human Oversight

## Lab 71

<br>

### 👉 Follow **instructions** in

### <code data-markdown-preview="/labs/lab-71-risk-governance/README.md">labs/lab-71-risk-governance/README.md</code>

Notes:

- Demonstrate a rules-file backdoor and an injection carried in user data
- Verify AI dependency suggestions against the real package registry
- Calibrate review depth on four AI-generated diffs
- Produce a RISK_REGISTER.md with owners, not just worries
- Expected time: 50-60 minutes

##==##

<!-- .slide: class="exercice" -->

# Exercise: Risks, Governance and Human Oversight

## Lab 71

<br>

### 💡 Read **solution** at

### <code data-markdown-preview="/labs/lab-71-risk-governance-solution/README.md">labs/lab-71-risk-governance-solution/README.md</code>

Notes:
The solution is trainer-facing: it gives away every payload and the full diff classification. The key debrief question is the first one — "which of the three experiments would your current process have caught?" The usual answer is none, and that silence is the module landing. Three of the four diffs in Exercise 3 carry a comment arguing for a lower risk level than the code deserves; that is the transferable lesson, because in AI-generated code the rationale is generated too.
