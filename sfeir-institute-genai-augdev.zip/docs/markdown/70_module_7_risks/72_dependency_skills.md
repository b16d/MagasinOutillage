<!-- .slide: class="transition" -->

# AI Tool Dependency

## Preserving Your Core Skills

Notes:
This section covers cognitive atrophy, dependency risks, and mitigation strategies. Duration: ~6 minutes. Goal: make developers aware of the risks without creating fear.

##==##

<!-- .slide: -->

## The Cognitive Atrophy Evidence

**Cognitive atrophy**: the gradual decline of problem-solving, debugging and design skills caused by over-delegating to AI — similar to muscle loss from disuse.

| Study                                                                                                                                                                                                                                     | Finding                                                               |
| ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | --------------------------------------------------------------------- |
| [**Anthropic (Jan 2026)**](https://www.anthropic.com/research/AI-assistance-coding-skills)                                                                                                                                                | Devs using AI scored **-17 points** on mastery quizzes vs hand-coders |
| [**MIT Media Lab (2025)**](https://arxiv.org/abs/2506.08872)                                                                                                                                                                              | ~47% collapse in brain connectivity (EEG) during AI-assisted work     |
| [**Microsoft/CMU (2025)**](https://www.microsoft.com/en-us/research/publication/the-impact-of-generative-ai-on-critical-thinking-self-reported-reductions-in-cognitive-effort-and-confidence-effects-from-a-survey-of-knowledge-workers/) | **40% of tasks**: workers reported using **zero critical thinking**   |

<br>

**The paradox of supervision**: Effective AI oversight requires the expertise that may atrophy from overreliance.

> When producing output is so easy, it gets harder to actually take the time to learn something. — Anthropic engineer

<!-- .element: class="bbquote"-->

Notes:
Anthropic's RCT (n=52 junior engineers) found that developers who fully delegated code generation scored below 40% on mastery; those who used AI for conceptual inquiry scored 65%+. The largest gap was in debugging skills. MIT Media Lab (n=54 students, 4 months, EEG) found 83% of AI users couldn't recall key points of essays they wrote. Microsoft/CMU (n=319 workers, CHI 2025) found higher confidence in GenAI correlates with less critical thinking. METR's July-2025 RCT (n=16, 246 tasks) showed a ~39-percentage-point perception gap (19% slower measured vs 20% faster perceived); METR now labels this result "historical" and a February-2026 follow-up showed some evidence of speedup, so present it as a 2025 finding, not current state. Caveats: small samples, MIT study wasn't coding-specific, Microsoft data is self-reported.

##==##

<!-- .slide: -->

## Warning Signs & Antidotes

| Warning Sign           | What Happens                      | Antidote                        |
| ---------------------- | --------------------------------- | ------------------------------- |
| **Blank page block**   | Can't start without AI            | "No AI" sessions (1h/week)      |
| **AI-first debugging** | Reach for AI before understanding | Read the stack trace first      |
| **Architecture fog**   | Losing system mental model        | Draw diagrams, explain to peers |
| **Outage anxiety**     | Panic when AI is down             | Katas, pet projects without AI  |

<br>

> How do you maintain sharp skills when AI does 60% of your work? — [Microsoft New Future of Work 2025](https://www.microsoft.com/en-us/research/wp-content/uploads/2025/12/New-Future-Of-Work-Report-2025.pdf)

<!-- .element: class="bbquote"-->

Notes:
Anthropic's internal study (132 engineers, 53 interviews, 200K Claude Code transcripts) found engineers explicitly worried about "skills atrophying as they delegate more." Microsoft's New Future of Work Report 2025 documents deskilling across knowledge work and recommends design interventions (contrastive explanations, progressive learning). The 4 warning signs are discussion triggers — ask trainees: "Which have you experienced?"

##==##

<img src="assets/images/70_module_7/experience-comparison.svg" alt="Risk matrix showing coding approach by experience level: junior plus vibe coding equals critical risk requiring supervision, senior plus vibe coding equals moderate risk requiring vigilance, junior plus agentic coding equals safer approach with learning opportunity, senior plus agentic coding equals best practice recommended approach" style="width:100%; height:auto; display:block;">

Notes:

**Junior + Vibe Coding (Critical Risk):** This isn't a criticism of junior developers - everyone starts somewhere. The issue is that vibe coding amplifies inexperience. If you don't know what good code looks like, how can you evaluate AI suggestions? Junior developers benefit most from the learning opportunity that comes with reviewing code, asking questions, and understanding why certain approaches are better than others. Vibe coding robs them of that learning opportunity while creating production risk.

**Senior + Vibe Coding (Moderate Risk):** Senior developers have a significant advantage in code review, but they're not immune to vibe coding risks. The "looks fine" trap is real - experienced developers can glance at code and think they've reviewed it when they've actually just pattern-matched on surface features. AI tools can generate increasingly sophisticated code that takes careful attention to review properly. Even seniors need formal review processes, not just quick glances.

**Agentic Coding for All:** Both juniors (with supervision/pairing) and seniors benefit from agentic coding. Juniors learn from the review process, seniors catch subtle issues. Vibe coding should be a conscious choice based on risk assessment (prototyping, hackathons), not a default mode.
