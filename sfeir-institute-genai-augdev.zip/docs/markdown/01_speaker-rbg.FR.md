<!-- .slide: class="speaker-slide" -->
<div class="speaker-slide">

# Bonjour ! @SFEIR

## Ronald **Baby González**

### Technical Leader, Développeur Senior chez SFEIR Luxembourg

### baby-gonzalez.r@sfeir.com

![](./assets/images/logo-sfeir-blanc.png 'company')

![](./assets/images/speaker-rbg.jpg 'speaker')

</div>

Notes:
Ronald Baby González est Tech Lead Backend avec plus de 15 ans d'expérience en Java et Spring Boot, spécialisé dans la conception et le pilotage de backends résilients et cloud-ready sur des environnements Oracle, dans des contextes fortement régulés
