<!-- .slide: class="speaker-slide" -->
<div class="speaker-slide">

# Hello ! @SFEIR

## Ronald **Baby González**

### Technical Leader, Senior Developer at SFEIR Luxembourg

### baby-gonzalez.r@sfeir.com

![](./assets/images/logo-sfeir-blanc.png 'company')

![](./assets/images/speaker-rbg.jpg 'speaker')

</div>

Notes:
Ronald Baby González is a Backend Tech Lead with 15+ years of experience in Java and Spring Boot, specialized in designing and leading resilient, cloud-ready backends on Oracle-based environments in highly regulated contexts
