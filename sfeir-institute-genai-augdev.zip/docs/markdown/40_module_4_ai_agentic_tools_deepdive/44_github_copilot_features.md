<!-- .slide: class="transition" -->

# GitHub Copilot Deep Dive

## CLI Features Instructions, Prompts, Agents, Skills, Hooks, Plugins & Configuration

##==##

<!-- .slide: -->

# **GitHub Copilot: CLI Overview**

| Feature          | How         | Example                          |
| ---------------- | ----------- | -------------------------------- |
| Include files    | `@` symbol  | `@ src/api.ts review this`       |
| Slash commands   | `/` prefix  | `/help`, `/compact`, `/init`     |
| Execute shell    | `!` prefix  | `! npm test`                     |
| Permission modes | `Shift+Tab` | Standard → Plan → Autopilot      |
| Reasoning effort | `--effort`  | `low`, `medium`, `high`, `xhigh` |

<br>

**📚 Documentation**: https://docs.github.com/en/copilot/reference/copilot-cli-reference/cli-command-reference

Notes:
These are the foundational features. Master @ / ! before diving into customization. Permission modes control Copilot's autonomy: Standard (asks permission), Plan (read-only planning), Autopilot (full autonomy, also via --yolo or --allow-all). The --effort flag controls reasoning depth similar to Claude's extended thinking. The Copilot CLI reached GA on February 25, 2026 and is multi-provider — you can pick models across Anthropic, OpenAI, and Google per task/session (e.g. Claude Sonnet 5 became GA for Copilot on June 30, 2026); choose in `/model`.

##==##

<!-- .slide: -->

# **GitHub Copilot: CLI Overview**

| Feature            | How                     | Example                        |
| ------------------ | ----------------------- | ------------------------------ |
| Session resume     | `--resume` \| `/resume` | Resume a previous conversation |
| Context management | `/compact`              | Compress at context capacity   |
| Clear context      | `/clear`                | Wipes all context, fresh start |
| Delegate           | `/delegate`             | Async task → new branch + PR   |
| Fleet mode         | `/fleet`                | Parallel subagent execution    |

<br>

**📚 Documentation**: https://docs.github.com/en/copilot/reference/copilot-cli-reference/cli-command-reference

Notes:
The /delegate command is unique to Copilot - sends work to a background coding agent that commits to a branch and opens a PR. /fleet enables parallel subagent execution for faster task completion. Use --continue to resume the most recent session or --resume to pick from a list. Also supports /diff to review changes, /session for workspace info, and /share for exporting sessions.

##==##

<!-- .slide: class="with-code" -->

# GitHub Copilot: copilot-instructions.md (Context File)

**Definition**: Repository-wide instructions automatically loaded into every Copilot interaction. Provides project conventions, architecture guidelines, and coding standards.

| Level             | File                                     | Scope                    |
| ----------------- | ---------------------------------------- | ------------------------ |
| **Repository**    | `.github/copilot-instructions.md`        | All requests             |
| **Personal**      | `~/.copilot/copilot-instructions.md`     | All your projects        |
| **Path-specific** | `.github/instructions/*.instructions.md` | Files matching `applyTo` |

**Create/Update**: `/init` scaffolds from project analysis or create manually

**Auto-detection**: Copilot automatically combines instructions from all levels based on context

**Cross-compatible**: Copilot also reads `CLAUDE.md`, `GEMINI.md`, and `AGENTS.md` files

**📚 Documentation**: https://docs.github.com/en/copilot/how-tos/copilot-cli/customize-copilot/add-custom-instructions

Notes:
copilot-instructions.md is the primary context file for Copilot. Unlike other tools, Copilot has path-specific instructions with applyTo glob patterns that activate automatically when editing matching files. The cross-compatible reading of CLAUDE.md and GEMINI.md makes multi-tool teams easier to manage.

##==##

<!-- .slide: class="with-code" -->

# GitHub Copilot: Instructions

**Definition**: Automatic coding conventions that apply based on file path patterns

| Level         | File                                     | Scope                         |
| ------------- | ---------------------------------------- | ----------------------------- |
| Repository    | `.github/copilot-instructions.md`        | All requests                  |
| Path-specific | `.github/instructions/*.instructions.md` | Files matching `applyTo` glob |
| Personal      | `~/.copilot/copilot-instructions.md`     | All your projects             |

```yaml
---
applyTo: 'apps/backend/src/domain/**'
---
```

<br>

**When to use**: Project standards, path-specific coding conventions

**📚 Documentation**: https://docs.github.com/en/copilot/how-tos/copilot-cli/customize-copilot/add-custom-instructions

Notes:
Path-specific instructions with `applyTo` were originally unique to GitHub Copilot, but Claude Code now offers equivalent functionality via `.claude/rules/` files with a `paths` YAML frontmatter field — these also trigger automatically when Claude works with matching files, without manual invocation.

##==##

<!-- .slide: class="with-code" -->

# GitHub Copilot: Prompts

**Definition**: Reusable prompt templates for common tasks, equivalent to Claude Code commands/skills

| Field         | Required | Description                                   |
| ------------- | -------- | --------------------------------------------- |
| `description` | No       | Shown in prompt picker                        |
| `tools`       | No       | Tools available (e.g., `['search/codebase']`) |

<br>

**Location**: `.github/prompts/` (project)

**Invocation**: `#prompt-name` in Copilot Chat (note: `#` not `/`)

**Create**: Manual `.prompt.md` files — no frontmatter required, just markdown content

**📚 Documentation**: https://docs.github.com/en/copilot/how-tos/copilot-cli/customize-copilot/custom-prompts

Notes:
GitHub calls these "prompts" rather than "commands". They use the .prompt.md suffix and # for invocation (not / like Claude). The tools field specifies which Copilot tools the prompt can use. No frontmatter required - just markdown content with optional YAML frontmatter.

##==##

<!-- .slide: class="exercice" -->

# Exercises: Github Copilot Deep Dive

## Lab 41

<br>

### 👉 Follow **instructions** in

### <code data-markdown-preview="/labs/lab-41-agentic-tools-deep-dive/README.md">labs/lab-41-agentic-tools-deep-dive/README.md</code>

### 📚 Exercises 1 to 4, Section B (Github Copilot)

Notes:

- Follow the instructions in the lab README.md for detailed steps.

##==##

<!-- .slide: class="exercice" -->

# Exercises: Github Copilot Deep Dive

## Lab 41

<br>

### 💡 Read **solution** at

### <code data-markdown-preview="/labs/lab-41-agentic-tools-deep-dive-solution/README.md">labs/lab-41-agentic-tools-deep-dive-solution/README.md</code>

### 📚 Exercises 1 to 4, Section B (Github Copilot)

Notes:

- Read the lab README.md for example of solutions.

##==##

<!-- .slide: class="with-code" -->

# GitHub Copilot: Custom Agents

**Definition**: Specialized subagents with isolated context for task-specific workflows

| Field         | Required | Description                           |
| ------------- | -------- | ------------------------------------- |
| `description` | Yes      | Agent's purpose and when to use it    |
| `name`        | No       | Display name (defaults to filename)   |
| `tools`       | No       | Allowed tools array (defaults to all) |
| `model`       | No       | Model to use (inherits if omitted)    |

<br>

**Location**: `.github/agents/` (project) · `~/.copilot/agents/` (personal)

**Invocation**: `/agent name`, `copilot --agent name`, or natural language

**Create**: Manual `.agent.md` files or via plugins

Notes:
Copilot agents use the .agent.md naming convention (not just .md like Claude). File format is Markdown with .agent.md suffix and YAML frontmatter (max 30K chars). User-level agents override project-level when names conflict. Agents can also be distributed via plugins for team sharing.

##==##

<!-- .slide: class="with-code" -->

# GitHub Copilot: Custom Agents

**Definition**: Specialized subagents with isolated context for task-specific workflows

| Field                      | Required | Description                           |
| -------------------------- | -------- | ------------------------------------- |
| `disable-model-invocation` | No       | `true` to prevent auto-delegation     |
| `user-invocable`           | No       | `false` to hide from manual selection |
| `mcp-servers`              | No       | Additional MCP servers for this agent |

<br>

**📚 Documentation**: https://docs.github.com/en/copilot/how-tos/copilot-cli/customize-copilot/create-custom-agents-for-cli

Notes:
Copilot agents use the .agent.md naming convention (not just .md like Claude). File format is Markdown with .agent.md suffix and YAML frontmatter (max 30K chars). User-level agents override project-level when names conflict. Agents can also be distributed via plugins for team sharing.

##==##

<!-- .slide: class="exercice" -->

# Exercises: Github Copilot Deep Dive

## Lab 41

<br>

### 👉 Follow **instructions** in

### <code data-markdown-preview="/labs/lab-41-agentic-tools-deep-dive/README.md">labs/lab-41-agentic-tools-deep-dive/README.md</code>

### 📚 Exercises 5 to 6, Section B (Github Copilot)

Notes:

- Follow the instructions in the lab README.md for detailed steps.

##==##

<!-- .slide: class="exercice" -->

# Exercises: Github Copilot Deep Dive

## Lab 41

<br>

### 💡 Read **solution** at

### <code data-markdown-preview="/labs/lab-41-agentic-tools-deep-dive-solution/README.md">labs/lab-41-agentic-tools-deep-dive-solution/README.md</code>

### 📚 Exercises 5 to 6, Section B (Github Copilot)

Notes:

- Read the lab README.md for example of solutions.

##==##

<!-- .slide: class="with-code" -->

# GitHub Copilot: Agent Skills

**Definition**: Reusable prompt instructions that Copilot loads on demand. Detailed, task-specific guidance that activates contextually — use custom instructions for simple always-on rules

| Field         | Required | Description                              |
| ------------- | -------- | ---------------------------------------- |
| `name`        | Yes      | Skill identifier (defaults to dir name)  |
| `description` | Yes      | When Copilot should auto-load this skill |
| `license`     | No       | Applicable licensing terms               |

<br>

**Location**: `.github/skills/<name>/SKILL.md` (project) · `~/.copilot/skills/` (personal)

**Invocation**: `/skill-name` or auto-loaded by Copilot when relevant

**Create**: Manual `SKILL.md` files or install from registries

Notes:
Skills follow the Agent Skills open standard (agentskills.io) working across multiple AI tools. Copilot supports both .github/skills/ and .claude/skills/ locations for cross-tool compatibility. Skills differ from custom instructions: instructions are always-on simple rules, skills are detailed task-specific guidance loaded on demand. Skill descriptions are loaded at session start; full content loads only when invoked.

##==##

<!-- .slide: class="with-code" -->

# GitHub Copilot: Agent Skills

**Definition**: Reusable prompt instructions that Copilot loads on demand. Detailed, task-specific guidance that activates contextually — use custom instructions for simple always-on rules

**Structure**:

```
my-skill/
├── SKILL.md           # Instructions (required)
├── templates/         # Templates to fill in
├── examples/          # Example outputs
├── scripts/           # Executable scripts
└── references/        # Reference documentation
```

<br>

**Public Registries**: [🔗 https://skills.sh](https://skills.sh) - [🔗 https://tessl.io/registry](https://tessl.io/registry)

Notes:
Skills use the same [open format](https://agentskills.io) across all platforms making them the most portable feature. Copilot supports both .github/skills/ and .claude/skills/ locations for cross-tool compatibility. Use /skills list to see available skills. CLI commands: /skills list, /skills info, /skills add, /skills reload.

##==##

<!-- .slide: class="with-code" -->

# GitHub Copilot: Agent Skills

**Definition**: Reusable prompt instructions that Copilot loads on demand. Detailed, task-specific guidance that activates contextually — use custom instructions for simple always-on rules

| CLI Command      | Purpose                                |
| ---------------- | -------------------------------------- |
| `/skills list`   | Display available skills               |
| `/skills info`   | Show skill details and location        |
| `/skills add`    | Add alternative skill storage location |
| `/skills reload` | Refresh skills during session          |
| `/skills remove` | Remove directly-added skills           |

<br>

**📚 Documentation**: https://docs.github.com/en/copilot/how-tos/copilot-cli/customize-copilot/create-skills

Notes:
Skills follow the Agent Skills open standard (agentskills.io) working across multiple AI tools. Copilot supports both .github/skills/ and .claude/skills/ locations for cross-tool compatibility. Use /skills list to see available skills. The /skills add command lets you add directories outside the default locations. Skills can also be distributed via plugins for team sharing.

##==##

<!-- .slide: class="exercice" -->

# Exercises: Github Copilot Deep Dive

## Lab 41

<br>

### 👉 Follow **instructions** in

### <code data-markdown-preview="/labs/lab-41-agentic-tools-deep-dive/README.md">labs/lab-41-agentic-tools-deep-dive/README.md</code>

### 📚 Exercises 7 to 9, Section B (Github Copilot)

Notes:

- Follow the instructions in the lab README.md for detailed steps.

##==##

<!-- .slide: class="exercice" -->

# Exercises: Github Copilot Deep Dive

## Lab 41

<br>

### 💡 Read **solution** at

### <code data-markdown-preview="/labs/lab-41-agentic-tools-deep-dive-solution/README.md">labs/lab-41-agentic-tools-deep-dive-solution/README.md</code>

### 📚 Exercises 7 to 9, Section B (Github Copilot)

Notes:

- Read the lab README.md for example of solutions.

##==##

<!-- .slide: class="with-code" -->

# GitHub Copilot: Hooks

**Definition**: Shell commands executing at specific lifecycle points during agent operations

| Event                         | When it fires               |
| ----------------------------- | --------------------------- |
| `sessionStart` / `sessionEnd` | Session lifecycle           |
| `preToolUse` / `postToolUse`  | Before/after tool execution |
| `userPromptSubmitted`         | After user sends prompt     |
| `errorOccurred`               | On error                    |
| `agentStop` / `subagentStop`  | Agent/subagent completes    |

Notes:
Copilot hooks are script-based (shell execution), unlike Claude's prompt-based approach. Cross-platform support with both bash and powershell is unique to Copilot. Hooks support 8 lifecycle event types. Use preToolUse for validation and agentStop/subagentStop for cleanup.

##==##

<!-- .slide: class="with-code" -->

# GitHub Copilot: Hooks

**Definition**: Shell commands executing at specific lifecycle points during agent operations

**Config format**: JSON files in `.github/hooks/` (`version: 1` required)

**Hook fields**: `type` ("command"), `bash`, `powershell`, `cwd`, `timeoutSec` (default 30), `env`

**Cross-platform**: Supports both bash and PowerShell scripts

**📚 Documentation**: https://docs.github.com/en/copilot/how-tos/copilot-cli/customize-copilot/use-hooks

Notes:
Copilot hooks are script-based (shell execution), unlike Claude's prompt-based approach. Cross-platform support with both bash and powershell is unique to Copilot. Hooks support 8 lifecycle event types. Use preToolUse for validation and agentStop/subagentStop for cleanup.

##==##

<!-- .slide: -->

# GitHub Copilot: Plugins

**Definition**: Distributable packages bundling agents, skills, hooks, and MCP servers

**Manifest**: `plugin.json` at plugin root

| CLI Command                                | Purpose                            |
| ------------------------------------------ | ---------------------------------- |
| `copilot plugin install <source>`          | From marketplace, GitHub, or local |
| `copilot plugin list`                      | View installed                     |
| `copilot plugin uninstall <name>`          | Remove                             |
| `copilot plugin marketplace browse <name>` | Discover plugins                   |
| `copilot plugin marketplace add <source>`  | Add custom marketplace             |

**Contents**: `agents/`, `skills/`, `hooks.json`, `.mcp.json`

**📚 Documentation**: https://docs.github.com/en/copilot/how-tos/copilot-cli/customize-copilot/plugins-creating

Notes:
Copilot plugin system is similar to Claude Code's. The plugin.json manifest format is cross-compatible with Claude's .claude-plugin convention. Two built-in marketplaces are included by default. Plugins can be installed from any GitHub repo.

##==##

<!-- .slide: class="exercice" -->

# Exercises: Github Copilot Deep Dive

## Lab 41

<br>

### 👉 Follow **instructions** in

### <code data-markdown-preview="/labs/lab-41-agentic-tools-deep-dive/README.md">labs/lab-41-agentic-tools-deep-dive/README.md</code>

### 📚 Exercises 10 to 11, Section B (Github Copilot)

Notes:

- Follow the instructions in the lab README.md for detailed steps.

##==##

<!-- .slide: class="exercice" -->

# Exercises: Github Copilot Deep Dive

## Lab 41

<br>

### 💡 Read **solution** at

### <code data-markdown-preview="/labs/lab-41-agentic-tools-deep-dive-solution/README.md">labs/lab-41-agentic-tools-deep-dive-solution/README.md</code>

### 📚 Exercises 10 to 11, Section B (Github Copilot)

Notes:

- Read the lab README.md for example of solutions.

##==##

<!-- .slide: -->

# GitHub Copilot: Configuration

**Definition**: Project and user-level settings controlling Copilot's behavior, instructions, and integrations

| Level            | Source                               | Scope              |
| ---------------- | ------------------------------------ | ------------------ |
| Repository       | `copilot-instructions.md`            | All requests       |
| Path-specific    | `.instructions.md` files             | Matching paths     |
| Agent-specific   | `.agent.md` files                    | When agent invoked |
| Cross-compatible | `CLAUDE.md`, `GEMINI.md`             | Multi-tool repos   |
| Personal         | `~/.copilot/copilot-instructions.md` | All projects       |

Notes:
Copilot has the richest instruction hierarchy - it auto-detects and combines instructions from multiple sources based on context. Cross-compatibility with CLAUDE.md and GEMINI.md enables multi-tool teams to share project context. Settings follow priority: path-specific > repository > personal.

##==##

<!-- .slide: -->

# GitHub Copilot: Configuration

**Definition**: Project and user-level settings controlling Copilot's behavior, instructions, and integrations
<br>

**Project instructions**: `AGENTS.md` (shared via git) · `.github/copilot-instructions.md` (project-wide)

**Bootstrap**: Copilot auto-detects instructions from multiple sources based on context

**📚 Documentation**: https://docs.github.com/en/copilot/how-tos/copilot-cli/customize-copilot/overview

Notes:
Copilot has the richest instruction hierarchy - it auto-detects and combines instructions from multiple sources based on context. Cross-compatibility with CLAUDE.md and GEMINI.md enables multi-tool teams to share project context. Settings follow priority: path-specific > repository > personal.

##==##

<!-- .slide: -->

# **GitHub Copilot: Feature Summary**

<br>

| Feature      | Location                  | Invocation        | Key Trait               |
| ------------ | ------------------------- | ----------------- | ----------------------- |
| Agents       | `.github/agents/`         | `@name`, `/agent` | `.agent.md` suffix      |
| Prompts      | `.github/prompts/`        | `#name`           | `.prompt.md` suffix     |
| Instructions | `.github/instructions/`   | Auto (path)       | `applyTo` scoping       |
| Skills       | `.github/skills/`         | `/name`, auto     | Cross-platform SKILL.md |
| Hooks        | `.github/hooks/`          | Auto (8 events)   | Script-based (bash+ps1) |
| Plugins      | `copilot plugin`          | CLI install       | Bundled distribution    |
| Config       | `copilot-instructions.md` | At startup        | Cross-compatible        |

Notes:
Copilot's unique strengths: path-specific instructions (applyTo), cross-platform hooks (bash+powershell), cross-compatible instruction reading, and GitHub-integrated features like /delegate.

##==##

<!-- .slide: -->

# GitHub Copilot: When to Use What

## Choosing the Right Feature

| Scenario                             | Use This          | Why                                                 |
| ------------------------------------ | ----------------- | --------------------------------------------------- |
| Need domain-expert AI guidance       | **Custom Agent**  | Persistent role in `.github/agents/`, `/agent name` |
| Need reusable prompt for a task      | **Prompt**        | One-shot template in `.github/prompts/`             |
| Need to bundle & distribute tooling  | **Plugin**        | `copilot plugin install` packages capabilities      |
| Need to control permissions/behavior | **Configuration** | Policy settings + `copilot-instructions.md`         |

<br>

Notes:
GitHub Copilot adds an Instructions layer — project-wide guidance applied to every interaction — that other tools lack. Prompts are the equivalent of custom commands. The /delegate command uniquely sends work to a background coding agent that commits to a branch and opens a PR.

##==##

<!-- .slide: -->

# GitHub Copilot: When to Use What

## Choosing the Right Feature

| Scenario                             | Use This          | Why                                            |
| ------------------------------------ | ----------------- | ---------------------------------------------- |
| Need to control permissions/behavior | **Configuration** | Policy settings + `copilot-instructions.md`    |
| Need project-wide AI behavior rules  | **Instructions**  | `copilot-instructions.md` applied globally     |
| Need shared knowledge across agents  | **Agent Skill**   | Composable, auto-loaded from `.github/skills/` |
| Need automatic validation on edits   | **Hook**          | Pre/Post triggers defined in `.github/hooks/`  |

<br>

**Agents** = conversational personas | **Prompts** = single-task templates

**Skills** = composable knowledge | **Hooks** = automatic enforcement | **Instructions** = project-wide context

Notes:
GitHub Copilot adds an Instructions layer — project-wide guidance applied to every interaction — that other tools lack. Prompts are the equivalent of custom commands. The /delegate command uniquely sends work to a background coding agent that commits to a branch and opens a PR.
