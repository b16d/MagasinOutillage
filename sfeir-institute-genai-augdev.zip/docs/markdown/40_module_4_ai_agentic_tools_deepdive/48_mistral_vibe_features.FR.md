<!-- .slide: class="transition" -->

# Mistral Vibe en profondeur

## Fonctionnalités CLI, agents, skills, hooks, MCP, mode ACP & configuration

Notes:

Ce module plonge dans Mistral Vibe, un CLI de codage agentique piloté par la commande `vibe`. Nous passerons en revue ses symboles et flags CLI, ses agents intégrés et personnalisés, le système de skills, les hooks et la configuration en TOML, l'intégration MCP, et ses deux capacités les plus marquantes — le folder-trust et le mode ACP. Présentez cela comme une visite guidée pratique : tout ce qui est couvert ici correspond directement à ce que les stagiaires feront dans le Lab 41. Rappelez à la salle que cet outil évolue vite, et que la documentation actuelle est donc la référence qui fait foi.

##==##

<!-- .slide: class="with-code" -->

# **Mistral Vibe : aperçu du CLI**

**Définition** : Vibe est un CLI de codage agentique lancé via la commande `vibe`. Dans l'invite interactive, trois symboles pilotent l'essentiel des interactions.

| Symbole | Rôle                | Exemple                    |
| ------- | ------------------- | -------------------------- |
| `@`     | Fichiers/contexte   | `@src/app.py explain this` |
| `/`     | Lancer une commande | `/help`, `/setup`          |
| `!`     | Exécuter cmd shell  | `!npm test`                |

<br>

**Lancement** : `vibe` démarre la session interactive dans le répertoire courant

**Configuration** : `vibe --setup` ouvre l'assistant de configuration interactif

**📚 Documentation** : https://docs.mistral.ai/vibe/

Notes:

L'invite de Vibe s'articule autour de trois symboles rapides, pour que les actions courantes restent à une frappe. Le symbole `@` tire des fichiers ou des répertoires dans la fenêtre de contexte, `/` déclenche les slash commands enregistrées, et `!` sort vers le shell pour lancer une commande sans quitter la session. La commande `vibe` sans argument est le point d'entrée quotidien, alors que `vibe --setup` est la première chose qu'un nouvel utilisateur doit lancer pour configurer sa clé d'API, son modèle et ses valeurs par défaut. Rappelez aux stagiaires que ces symboles sont la façon la plus rapide de travailler — aucun menu nécessaire.

##==##

<!-- .slide: class="with-code" -->

# **Mistral Vibe : aperçu du CLI**

**Définition** : la continuité de session et les modes d'intégration passent par des flags dédiés et un binaire compagnon.

| Commande / Flag   | Rôle                                     |
| ----------------- | ---------------------------------------- |
| `vibe --continue` | Reprendre la dernière session            |
| `vibe --resume`   | Choisir une session passée à reprendre   |
| `vibe --setup`    | Assistant de configuration interactif    |
| `vibe-acp`        | Lancer Vibe en serveur ACP pour éditeurs |

<br>

**Installation** : `curl -LsSf https://mistral.ai/vibe/install.sh | bash` ou `uv tool install mistral-vibe`

**📚 Documentation** : https://docs.mistral.ai/vibe/

Notes:

La continuité de session compte pour les tâches longues : `--continue` ramène directement dans la dernière conversation, tandis que `--resume` liste les sessions passées pour choisir le fil à reprendre. Le binaire `vibe-acp` lance Vibe comme serveur Agent Client Protocol, détaillé plus loin. Deux chemins d'installation sont proposés — le script d'installation shell pour démarrer vite, ou `uv tool install` pour les équipes déjà standardisées sur uv. Précisez que les commandes d'installation et les flags peuvent évoluer, les stagiaires doivent donc vérifier dans la documentation actuelle.

##==##

<!-- .slide: class="with-code" -->

# Mistral Vibe : AGENTS.md (contexte)

**Définition** : `AGENTS.md`, à la racine du projet, est le fichier de contexte persistant que Vibe charge automatiquement au début de chaque session.

| Aspect          | Détail                                        |
| --------------- | --------------------------------------------- |
| **Emplacement** | `./AGENTS.md` (racine du projet)              |
| **Chargement**  | Automatique au début de session               |
| **Partage**     | Commité dans git, partagé avec toute l'équipe |
| **Contenu**     | Conventions, étapes de build, règles projet   |

<br>

**Objectif** : donner à Vibe un contexte projet permanent pour ne pas se répéter à chaque session

**📚 Documentation** : https://docs.mistral.ai/vibe/

Notes:

`AGENTS.md` est la source unique de contexte projet persistant pour Vibe. Comme il vit à la racine du dépôt et qu'il est commité dans git, toute l'équipe partage les mêmes instructions — commandes de build, conventions de test, règles d'architecture et standards de code. Vibe le lit automatiquement au démarrage d'une session, il n'y a donc aucune étape manuelle pour le charger. Encouragez les stagiaires à garder ce fichier concis et à fort signal : il consomme des tokens de contexte à chaque session, il doit donc contenir des conventions durables, pas des notes éphémères.

##==##

<!-- .slide: class="with-code" -->

# Mistral Vibe : agents intégrés (modes)

**Définition** : Vibe fournit quatre agents intégrés interchangeables. Chacun correspond à un comportement de permission qui règle l'autonomie de l'assistant.

| Agent          | Comportement de permission              |
| -------------- | --------------------------------------- |
| `default`      | Demande avant édition et commande       |
| `plan`         | Planif. lecture seule, sans modif       |
| `accept-edits` | Accepte auto. les éditions              |
| `auto-approve` | Autonomie totale, exécute sans demander |

<br>

**Workflow** : planifier en `plan`, relire, puis passer en `accept-edits` ou `auto-approve` pour exécuter

**📚 Documentation** : https://docs.mistral.ai/vibe/

Notes:

Les quatre agents intégrés sont en réalité des profils de permission. `default` est le point de départ sûr — il marque une pause et demande avant toute édition ou commande shell. `plan` est en lecture seule, parfait pour explorer une base de code ou esquisser une approche sans risque de modification involontaire. `accept-edits` accepte automatiquement les modifications de fichiers tout en gardant les autres actions sous contrôle, et `auto-approve` accorde une autonomie totale pour des tâches de confiance et bien cadrées. Un workflow courant consiste à démarrer en `plan`, s'accorder sur l'approche, puis monter en `accept-edits` pour l'implémentation. Insistez sur le fait que `auto-approve` doit être réservé aux tâches dans lesquelles vous avez pleinement confiance.

##==##

<!-- .slide: class="with-code" -->

# Mistral Vibe : agents custom

**Définition** : au-delà des agents intégrés, vous pouvez définir vos propres agents spécialisés dans des fichiers Markdown avec un nom, une description et un system prompt.

| Champ         | Rôle                                        |
| ------------- | ------------------------------------------- |
| `name`        | Identifiant de l'agent                      |
| `description` | Quand Vibe doit utiliser cet agent          |
| System prompt | Corps Markdown définissant son comportement |

<br>

**Emplacement** : `.vibe/agents/` (définitions d'agents au niveau projet)

**Format** : fichiers Markdown — le corps sert de system prompt

**📚 Documentation** : https://docs.mistral.ai/vibe/

Notes:

Les agents personnalisés permettent d'empaqueter un persona d'expert du domaine — relecteur sécurité, rédacteur de tests, concepteur d'API — sous forme de fichier Markdown réutilisable dans `.vibe/agents/`. Chaque fichier porte un nom, une description qui indique à Vibe quand l'agent est pertinent, et un corps Markdown qui devient le system prompt. Comme il s'agit de Markdown brut commité dans le dépôt, les agents personnalisés sont faciles à versionner et à partager dans l'équipe. Soulignez qu'une description nette et spécifique est ce qui fait activer un agent au bon moment.

##==##

<!-- .slide: class="exercice" -->

# Exercices : Mistral Vibe CLI en détail

## Lab 41

<br>

### 👉 Suivre les **instructions** dans

### <code data-markdown-preview="/labs/lab-41-agentic-tools-deep-dive/README.md">labs/lab-41-agentic-tools-deep-dive/README.md</code>

### 📚 Exercices 1 à 3, section F (Mistral Vibe CLI)

Notes:

- Suivre les instructions du README.md du lab pour les étapes détaillées.

##==##

<!-- .slide: class="exercice" -->

# Exercices : Mistral Vibe CLI en détail

## Lab 41

<br>

### 💡 Lire la **solution** dans

### <code data-markdown-preview="/labs/lab-41-agentic-tools-deep-dive-solution/README.md">labs/lab-41-agentic-tools-deep-dive-solution/README.md</code>

### 📚 Exercices 1 à 3, section F (Mistral Vibe CLI)

Notes:

- Lire le README.md du lab pour des exemples de solutions.

##==##

<!-- .slide: class="with-code" -->

# Mistral Vibe : slash commands via les skills

**Définition** : les slash commands personnalisées passent par le système de skills — une skill peut exposer une commande invoquée avec `/`.

| Aspect          | Détail                                     |
| --------------- | ------------------------------------------ |
| **Mécanisme**   | Fourni par le système de skills            |
| **Invocation**  | `/command-name` dans l'invite interactive  |
| **Source**      | Définies comme skills (slide suivante)     |
| **Cas d'usage** | Prompts et workflows nommés, réutilisables |

<br>

**À retenir** : pas de dossier « commands » séparé — écrire une skill pour ajouter une slash command

**📚 Documentation** : https://docs.mistral.ai/vibe/

Notes:

Vibe unifie commandes personnalisées et skills : plutôt qu'un répertoire de commandes dédié, vous écrivez une skill et elle devient disponible comme slash command. Cela maintient un seul modèle d'extension au lieu de deux systèmes parallèles. Les utilisateurs invoquent toujours les commandes de la façon habituelle, en tapant `/` suivi du nom dans l'invite. Insistez : quand les stagiaires veulent un workflow nommé et réutilisable, la réponse dans Vibe est « écris une skill » — la skill encapsule la connaissance et expose la commande.

##==##

<!-- .slide: class="with-code" -->

# Mistral Vibe : agent skills

**Définition** : paquets d'instructions réutilisables au standard `SKILL.md` — chargés progressivement et activés à la demande.

| Fonctionnalité      | Détail                                                 |
| ------------------- | ------------------------------------------------------ |
| **Format**          | `SKILL.md` avec frontmatter name + description         |
| **Chargement**      | Progressif — description d'abord, corps à l'activation |
| **Auto-activation** | Vibe charge la bonne skill selon le contexte           |
| **Sert aussi à**    | Slash commands custom                                  |

<br>

**Chargement progressif** : seules les descriptions coûtent des tokens au démarrage ; le contenu complet se charge quand la skill est utile

**📚 Documentation** : https://docs.mistral.ai/vibe/

Notes:

Les skills sont le mécanisme d'extensibilité central de Vibe. Chaque skill est un fichier `SKILL.md` avec un frontmatter déclarant un nom et une description, plus un corps contenant les instructions détaillées. Le chargement progressif garde le contexte léger : au démarrage Vibe ne lit que les courtes descriptions, et il charge le contenu complet d'une skill uniquement quand il juge celle-ci pertinente pour la tâche. Cette auto-activation évite aux utilisateurs de devoir penser à invoquer les skills manuellement. Rappelez aux stagiaires qu'une description bien écrite est ce qui permet à Vibe de choisir la bonne skill au bon moment.

##==##

<!-- .slide: class="exercice" -->

# Exercices : Mistral Vibe CLI en détail

## Lab 41

<br>

### 👉 Suivre les **instructions** dans

### <code data-markdown-preview="/labs/lab-41-agentic-tools-deep-dive/README.md">labs/lab-41-agentic-tools-deep-dive/README.md</code>

### 📚 Exercices 4 à 6, section F (Mistral Vibe CLI)

Notes:

- Suivre les instructions du README.md du lab pour les étapes détaillées.

##==##

<!-- .slide: class="exercice" -->

# Exercices : Mistral Vibe CLI en détail

## Lab 41

<br>

### 💡 Lire la **solution** dans

### <code data-markdown-preview="/labs/lab-41-agentic-tools-deep-dive-solution/README.md">labs/lab-41-agentic-tools-deep-dive-solution/README.md</code>

### 📚 Exercices 4 à 6, section F (Mistral Vibe CLI)

Notes:

- Lire le README.md du lab pour des exemples de solutions.

##==##

<!-- .slide: class="with-code" -->

# Mistral Vibe : hooks

**Définition** : callbacks de cycle de vie déclarés en TOML dans `.vibe/hooks.toml` — exécutent une logique avant ou après des événements comme l'usage d'un outil.

```toml
# .vibe/hooks.toml
[[hooks.pre_tool_use]]
matcher = "bash"
type = "prompt"
prompt = "Check if this shell command is a git commit. If so, verify staged files follow coding standards before allowing the commit."

[[hooks.post_tool_use]]
matcher = "write|edit"
type = "prompt"
prompt = "Validate the file changes against coding-standards.md. Check they follow the project's coding standards."
```

**Emplacement** : `.vibe/hooks.toml` (niveau projet)

**Cas d'usage** : avant/après exécution d'outil — validation, formatage, garde-fous

**📚 Documentation** : https://docs.mistral.ai/vibe/

Notes:

Les hooks permettent de câbler de l'automatisation déterministe dans le cycle de vie de l'agent sans écrire de code de plugin. Ils sont déclarés en TOML dans `.vibe/hooks.toml`, ce qui garde la configuration lisible et versionnée. Chaque hook est déclaré sous une table d'événement comme `[[hooks.pre_tool_use]]`, où vous pouvez valider ou bloquer une action avant son exécution, ou `[[hooks.post_tool_use]]`, où vous pouvez formater le code ou lancer des linters après un changement. Un `matcher` restreint le hook à des outils précis (p. ex. `bash`, `write|edit`), et `type = "prompt"` exécute le `prompt` fourni à ce point du cycle de vie. Comme les hooks sont du TOML déclaratif plutôt qu'une API de scripting, ils restent accessibles aux équipes qui veulent des garde-fous sans maintenir une base de code.

##==##

<!-- .slide: class="exercice" -->

# Exercices : Mistral Vibe CLI en détail

## Lab 41

<br>

### 👉 Suivre les **instructions** dans

### <code data-markdown-preview="/labs/lab-41-agentic-tools-deep-dive/README.md">labs/lab-41-agentic-tools-deep-dive/README.md</code>

### 📚 Exercice 7, section F (Mistral Vibe CLI)

Notes:

- Suivre les instructions du README.md du lab pour les étapes détaillées.

##==##

<!-- .slide: class="exercice" -->

# Exercices : Mistral Vibe CLI en détail

## Lab 41

<br>

### 💡 Lire la **solution** dans

### <code data-markdown-preview="/labs/lab-41-agentic-tools-deep-dive-solution/README.md">labs/lab-41-agentic-tools-deep-dive-solution/README.md</code>

### 📚 Exercice 7, section F (Mistral Vibe CLI)

Notes:

- Lire le README.md du lab pour des exemples de solutions.

##==##

<!-- .slide: class="with-code" -->

# Mistral Vibe : serveurs MCP

**Définition** : Vibe peut se connecter à des serveurs Model Context Protocol (MCP) pour exposer des outils supplémentaires au modèle.

| Aspect        | Détail                                           |
| ------------- | ------------------------------------------------ |
| **Protocole** | Model Context Protocol (MCP)                     |
| **Objectif**  | Ajouter des outils au-delà des intégrés          |
| **Config**    | Déclarés dans la configuration TOML de Vibe      |
| **Résultat**  | Outils MCP dispo. automatiquement pour le modèle |

<br>

**Une fois connectés** : les outils MCP côtoient les outils natifs de Vibe sans prompt supplémentaire

**📚 Documentation** : https://docs.mistral.ai/vibe/

Notes:

Le support MCP signifie que Vibe n'est pas limité à ses outils intégrés — vous pouvez brancher des serveurs qui exposent des bases de données, des outils de suivi de tickets, des navigateurs, ou toute autre capacité qui parle Model Context Protocol. Les serveurs sont déclarés dans la configuration TOML de Vibe, et une fois connectés leurs outils deviennent disponibles automatiquement pour le modèle, aux côtés des outils natifs. C'est la façon standard d'étendre Vibe avec des intégrations personnalisées ou tierces. Renvoyez les stagiaires au Module 5 pour un traitement plus approfondi de la mise en place et de l'usage de MCP.

##==##

<!-- .slide: class="with-code" -->

# Mistral Vibe : folder-trust & mode ACP

**Définition** : deux capacités remarquables — un verrou de sécurité sur les dépôts non fiables, et un mode serveur embarquable dans les éditeurs.

| Capacité         | Rôle                                                   |
| ---------------- | ------------------------------------------------------ |
| **Folder-trust** | Demande avant de charger le `.vibe/` d'un dossier      |
| **Mode ACP**     | `vibe-acp` lance Vibe en serveur Agent Client Protocol |

<br>

**Folder-trust** : au premier lancement dans un dossier, Vibe demande de lui faire confiance avant de charger la config `.vibe/` locale — une protection contre les configs projet malveillantes

**Mode ACP** : intégrer Vibe dans tout éditeur ou client compatible ACP via `vibe-acp`

**📚 Documentation** : https://docs.mistral.ai/vibe/

Notes:

Le folder-trust est une fonctionnalité de sécurité : comme un dépôt peut embarquer sa propre config `.vibe/`, ses agents, ses hooks et ses skills, ouvrir un dépôt non fiable pourrait sinon exécuter des comportements inattendus. Vibe s'en défend en demandant votre confiance la première fois que vous lancez dans un dossier, et en ne chargeant la configuration locale du projet qu'ensuite. Le mode ACP relève de l'intégration — lancer `vibe-acp` transforme Vibe en serveur Agent Client Protocol, il peut donc être embarqué directement dans les éditeurs et clients qui parlent ACP, au lieu de tourner uniquement en autonome dans un terminal. Ensemble, ces deux capacités rendent Vibe à la fois plus sûr à lancer sur du code inconnu et plus souple à embarquer dans une chaîne d'outils élargie.

##==##

<!-- .slide: class="with-code" -->

# Mistral Vibe : configuration

**Définition** : Vibe se configure via des fichiers TOML à deux niveaux — projet et global. Les réglages projet l'emportent sur le global.

```toml
# .vibe/config.toml (project)
model = "mistral-large-latest"
permission_mode = "default"

[tools]
# tool-specific settings
```

| Niveau     | Fichier               | Portée           |
| ---------- | --------------------- | ---------------- |
| **Projet** | `.vibe/config.toml`   | Ce dépôt         |
| **Global** | `~/.vibe/config.toml` | Tous vos projets |

**Modes de permission** : `default` · `plan` · `accept-edits` · `auto-approve`

**📚 Documentation** : https://docs.mistral.ai/vibe/

Notes:

Vibe utilise TOML pour la configuration, en cohérence avec son format de hooks. Le fichier global dans `~/.vibe/config.toml` contient les valeurs par défaut de l'utilisateur, comme le choix de modèle et les identifiants d'API, tandis que le fichier projet dans `.vibe/config.toml` porte les réglages propres au dépôt et peut être commité pour l'équipe. Les valeurs projet ont la priorité sur les globales. La clé `permission_mode` fixe le comportement d'agent au démarrage — les mêmes quatre modes (default, plan, accept-edits, auto-approve) disponibles à l'exécution. Encouragez à garder les secrets dans le fichier global et les conventions partageables dans le fichier projet.

##==##

<!-- .slide: class="exercice" -->

# Exercices : Mistral Vibe CLI en détail

## Lab 41

<br>

### 👉 Suivre les **instructions** dans

### <code data-markdown-preview="/labs/lab-41-agentic-tools-deep-dive/README.md">labs/lab-41-agentic-tools-deep-dive/README.md</code>

### 📚 Exercices 8 à 9, section F (Mistral Vibe CLI)

Notes:

- Suivre les instructions du README.md du lab pour les étapes détaillées.

##==##

<!-- .slide: class="exercice" -->

# Exercices : Mistral Vibe CLI en détail

## Lab 41

<br>

### 💡 Lire la **solution** dans

### <code data-markdown-preview="/labs/lab-41-agentic-tools-deep-dive-solution/README.md">labs/lab-41-agentic-tools-deep-dive-solution/README.md</code>

### 📚 Exercices 8 à 9, section F (Mistral Vibe CLI)

Notes:

- Lire le README.md du lab pour des exemples de solutions.

##==##

<!-- .slide: -->

# **Mistral Vibe : récapitulatif**

| Fonctionnalité  | Emplacement     | Invocation        | Trait clé                  |
| --------------- | --------------- | ----------------- | -------------------------- |
| AGENTS.md       | `./AGENTS.md`   | Auto au démarrage | Contexte projet persistant |
| Agents intégrés | Intégrés        | Bascule à chaud   | default/plan/accept/auto   |
| Agents custom   | `.vibe/agents/` | Auto / contextuel | Markdown, basé description |
| Skills          | `SKILL.md`      | À la demande      | Chargement progressif      |
| Commandes       | Via les skills  | `/name`           | Livrées via les skills     |

Notes:

Ce premier tableau récapitulatif regroupe les fonctionnalités de connaissance et de comportement de Vibe. AGENTS.md est le fichier de contexte toujours actif ; les quatre agents intégrés donnent un contrôle immédiat sur l'autonomie ; les agents personnalisés ajoutent des personas de domaine ; et les skills sont le mécanisme d'extension unifiant qui alimente aussi les slash commands. Utilisez cette slide comme carte mentale rapide avant l'exercice — chaque ligne est un endroit où les stagiaires peuvent étendre ou orienter Vibe.

##==##

<!-- .slide: -->

# **Mistral Vibe : récapitulatif**

| Fonctionnalité | Emplacement         | Invocation       | Trait clé                     |
| -------------- | ------------------- | ---------------- | ----------------------------- |
| Hooks          | `.vibe/hooks.toml`  | Événements       | Callbacks TOML déclaratifs    |
| Serveurs MCP   | Config (TOML)       | Auto (outils)    | Intégration d'outils externes |
| Config         | `.vibe/config.toml` | Démarrage        | Projet + global, TOML         |
| Mode ACP       | Binaire `vibe-acp`  | Dans l'éditeur   | Serveur Agent Client Protocol |
| Folder-trust   | Premier lancement   | Prompt confiance | Verrou sécurité sur `.vibe/`  |

Notes:

Ce second récapitulatif couvre les fonctionnalités d'automatisation, d'intégration et de sûreté de Vibe. Les hooks fournissent une automatisation déclarative du cycle de vie en TOML ; les serveurs MCP étendent l'outillage ; la configuration est superposée projet-sur-global en TOML ; le mode ACP permet à Vibe de vivre dans les éditeurs ; et le folder-trust protège des configs projet non fiables. Avec le tableau précédent, ces deux slides couvrent toute la surface que les stagiaires toucheront dans le lab.

##==##

<!-- .slide: -->

# Mistral Vibe : quoi utiliser quand

## Choisir la bonne fonctionnalité

| Scénario                          | Utiliser             | Pourquoi                                                |
| --------------------------------- | -------------------- | ------------------------------------------------------- |
| Conventions projet permanentes    | **AGENTS.md**        | Chargé auto au démarrage, partagé via git               |
| Analyse lecture seule sans risque | **agent `plan`**     | Aucune modif — exploration et planif. sûres             |
| Expertise métier dédiée           | **Agent custom**     | Persona Markdown dans `.vibe/agents/`, basé description |
| Workflow nommé réutilisable       | **Skill (commande)** | `/name` via le système de skills, auto-activée          |

<br>

**AGENTS.md** = contexte permanent | **Agents** = planif. sûre vs exécution autonome

Notes:

Cette slide aide les stagiaires à associer un besoin à la bonne fonctionnalité de Vibe. Prenez AGENTS.md quand la connaissance doit toujours être présente ; basculez sur l'agent plan quand vous voulez une analyse sans aucun risque d'édition ; écrivez un agent personnalisé quand vous avez besoin d'un persona spécialiste persistant ; et écrivez une skill quand vous voulez un workflow nommé et réutilisable que Vibe peut activer de lui-même. Le fil rouge : Vibe privilégie un petit ensemble de mécanismes composables plutôt que beaucoup de mécanismes qui se recouvrent.

##==##

<!-- .slide: -->

# Mistral Vibe : quoi utiliser quand

## Choisir la bonne fonctionnalité

| Scénario                      | Utiliser         | Pourquoi                                             |
| ----------------------------- | ---------------- | ---------------------------------------------------- |
| Contrôler l'usage des outils  | **Hooks**        | TOML déclaratif dans `.vibe/hooks.toml`, avant/après |
| Ajouter outils / API externes | **Serveurs MCP** | Connecter serveurs MCP via config TOML               |
| Vibe dans un éditeur          | **Mode ACP**     | `vibe-acp` expose un serveur Agent Client Protocol   |
| Dépôt inconnu, sans risque    | **Folder-trust** | Demande avant de charger le `.vibe/` local           |

<br>

**Hooks** = garde-fous déterministes | **MCP** = extension de capacités | **ACP** = intégration

Notes:

Le second tableau de décision couvre l'automatisation et l'intégration. Utilisez les hooks quand vous voulez des garde-fous déterministes, toujours exécutés, autour de l'usage des outils ; utilisez les serveurs MCP pour donner à Vibe de nouvelles capacités comme des bases de données ou des navigateurs ; utilisez le mode ACP quand vous voulez Vibe dans votre éditeur plutôt qu'en terminal autonome ; et comptez sur le folder-trust comme filet de sécurité à l'ouverture de dépôts auxquels vous ne faites pas pleinement confiance. Concluez en rappelant aux stagiaires que ces fonctionnalités évoluent, ils doivent donc vérifier les flags, noms de fichiers et comportements exacts dans la documentation actuelle sur https://docs.mistral.ai/vibe/.
