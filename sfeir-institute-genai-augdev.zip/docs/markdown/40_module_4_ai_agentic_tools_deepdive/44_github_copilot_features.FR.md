<!-- .slide: class="transition" -->

# GitHub Copilot en profondeur

## Fonctionnalités CLI, Instructions, Prompts, Agents, Skills, Hooks, Plugins et Configuration

##==##

<!-- .slide: -->

# **GitHub Copilot : aperçu du CLI**

| Fonctionnalité         | Comment     | Exemple                          |
| ---------------------- | ----------- | -------------------------------- |
| Inclure des fichiers   | symbole `@` | `@ src/api.ts review this`       |
| Commandes slash        | préfixe `/` | `/help`, `/compact`, `/init`     |
| Exécuter le shell      | préfixe `!` | `! npm test`                     |
| Modes de permission    | `Shift+Tab` | Standard → Plan → Autopilot      |
| Effort de raisonnement | `--effort`  | `low`, `medium`, `high`, `xhigh` |

<br>

**📚 Documentation** : https://docs.github.com/en/copilot/reference/copilot-cli-reference/cli-command-reference

Notes:
Ce sont les fonctionnalités de base. Maîtrisez @ / ! avant d'aborder la personnalisation. Les modes de permission contrôlent l'autonomie de Copilot : Standard (demande l'autorisation), Plan (planification en lecture seule), Autopilot (autonomie totale, aussi via --yolo ou --allow-all). Le flag --effort contrôle la profondeur de raisonnement, comme l'extended thinking de Claude. Le CLI Copilot est passé en GA le 25 février 2026 et est multi-fournisseurs — vous pouvez choisir des modèles chez Anthropic, OpenAI et Google par tâche/session (ex. Claude Sonnet 5 est passé en GA pour Copilot le 30 juin 2026) ; le choix se fait dans `/model`.

##==##

<!-- .slide: -->

# **GitHub Copilot : aperçu du CLI**

| Fonctionnalité      | Comment                 | Exemple                                |
| ------------------- | ----------------------- | -------------------------------------- |
| Reprise de session  | `--resume` \| `/resume` | Reprendre une conversation précédente  |
| Gestion du contexte | `/compact`              | Compresser à la limite de contexte     |
| Effacer le contexte | `/clear`                | Efface tout le contexte, repart à zéro |
| Déléguer            | `/delegate`             | Tâche async → nouvelle branche + PR    |
| Mode fleet          | `/fleet`                | Exécution parallèle de sous-agents     |

<br>

**📚 Documentation** : https://docs.github.com/en/copilot/reference/copilot-cli-reference/cli-command-reference

Notes:
La commande /delegate est propre à Copilot - elle envoie le travail à un agent de codage en arrière-plan qui commite sur une branche et ouvre une PR. /fleet permet l'exécution parallèle de sous-agents pour terminer les tâches plus vite. Utilisez --continue pour reprendre la session la plus récente ou --resume pour choisir dans une liste. Copilot propose aussi /diff pour relire les changements, /session pour les infos du workspace et /share pour exporter les sessions.

##==##

<!-- .slide: class="with-code" -->

# GitHub Copilot : copilot-instructions.md (fichier de contexte)

**Définition** : instructions à l'échelle du dépôt, chargées automatiquement dans chaque interaction avec Copilot. Fournit les conventions du projet, les règles d'architecture et les standards de code.

| Niveau                   | Fichier                                  | Portée                             |
| ------------------------ | ---------------------------------------- | ---------------------------------- |
| **Dépôt**                | `.github/copilot-instructions.md`        | Toutes les requêtes                |
| **Personnel**            | `~/.copilot/copilot-instructions.md`     | Tous vos projets                   |
| **Spécifique au chemin** | `.github/instructions/*.instructions.md` | Fichiers correspondant à `applyTo` |

**Créer/Mettre à jour** : `/init` génère le fichier depuis l'analyse du projet, ou création manuelle

**Détection automatique** : Copilot combine automatiquement les instructions de tous les niveaux selon le contexte

**Inter-compatible** : Copilot lit aussi les fichiers `CLAUDE.md`, `GEMINI.md` et `AGENTS.md`

**📚 Documentation** : https://docs.github.com/en/copilot/how-tos/copilot-cli/customize-copilot/add-custom-instructions

Notes:
copilot-instructions.md est le fichier de contexte principal de Copilot. Contrairement aux autres outils, Copilot propose des instructions spécifiques à un chemin, avec des motifs glob applyTo qui s'activent automatiquement à l'édition des fichiers correspondants. La lecture inter-compatible de CLAUDE.md et GEMINI.md facilite la gestion des équipes multi-outils.

##==##

<!-- .slide: class="with-code" -->

# GitHub Copilot : Instructions

**Définition** : conventions de code automatiques, appliquées selon des motifs de chemins de fichiers

| Niveau               | Fichier                                  | Portée                                   |
| -------------------- | ---------------------------------------- | ---------------------------------------- |
| Dépôt                | `.github/copilot-instructions.md`        | Toutes les requêtes                      |
| Spécifique au chemin | `.github/instructions/*.instructions.md` | Fichiers correspondant au glob `applyTo` |
| Personnel            | `~/.copilot/copilot-instructions.md`     | Tous vos projets                         |

```yaml
---
applyTo: 'apps/backend/src/domain/**'
---
```

<br>

**Quand l'utiliser** : standards du projet, conventions de code spécifiques à un chemin

**📚 Documentation** : https://docs.github.com/en/copilot/how-tos/copilot-cli/customize-copilot/add-custom-instructions

Notes:
Les instructions spécifiques à un chemin avec `applyTo` étaient à l'origine propres à GitHub Copilot, mais Claude Code offre désormais l'équivalent via les fichiers `.claude/rules/` avec un champ `paths` en frontmatter YAML — eux aussi se déclenchent automatiquement quand Claude travaille sur les fichiers correspondants, sans invocation manuelle.

##==##

<!-- .slide: class="with-code" -->

# GitHub Copilot : Prompts

**Définition** : modèles de prompts réutilisables pour les tâches courantes, équivalents aux commandes/skills de Claude Code

| Champ         | Requis | Description                                    |
| ------------- | ------ | ---------------------------------------------- |
| `description` | Non    | Affiché dans le sélecteur de prompts           |
| `tools`       | Non    | Outils disponibles (ex. `['search/codebase']`) |

<br>

**Emplacement** : `.github/prompts/` (projet)

**Invocation** : `#prompt-name` dans Copilot Chat (note : `#` et non `/`)

**Créer** : fichiers `.prompt.md` manuels — aucun frontmatter requis, juste du contenu markdown

**📚 Documentation** : https://docs.github.com/en/copilot/how-tos/copilot-cli/customize-copilot/custom-prompts

Notes:
GitHub les appelle « prompts » plutôt que « commandes ». Ils utilisent le suffixe .prompt.md et le # pour l'invocation (et non / comme Claude). Le champ tools précise quels outils Copilot le prompt peut utiliser. Aucun frontmatter requis - juste du contenu markdown, avec un frontmatter YAML facultatif.

##==##

<!-- .slide: class="exercice" -->

# Exercices : Github Copilot en profondeur

## Lab 41

<br>

### 👉 Suivez les **instructions** dans

### <code data-markdown-preview="/labs/lab-41-agentic-tools-deep-dive/README.md">labs/lab-41-agentic-tools-deep-dive/README.md</code>

### 📚 Exercices 1 à 4, section B (Github Copilot)

Notes:

- Suivez les instructions du README.md du lab pour les étapes détaillées.

##==##

<!-- .slide: class="exercice" -->

# Exercices : Github Copilot en profondeur

## Lab 41

<br>

### 💡 Lisez la **solution** dans

### <code data-markdown-preview="/labs/lab-41-agentic-tools-deep-dive-solution/README.md">labs/lab-41-agentic-tools-deep-dive-solution/README.md</code>

### 📚 Exercices 1 à 4, section B (Github Copilot)

Notes:

- Consultez le README.md du lab pour des exemples de solutions.

##==##

<!-- .slide: class="with-code" -->

# GitHub Copilot : Custom Agents

**Définition** : sous-agents spécialisés à contexte isolé, pour des workflows dédiés à une tâche

| Champ         | Requis | Description                                    |
| ------------- | ------ | ---------------------------------------------- |
| `description` | Oui    | Rôle de l'agent et quand l'utiliser            |
| `name`        | Non    | Nom affiché (par défaut le nom du fichier)     |
| `tools`       | Non    | Tableau des outils autorisés (tous par défaut) |
| `model`       | Non    | Modèle à utiliser (hérité si omis)             |

<br>

**Emplacement** : `.github/agents/` (projet) · `~/.copilot/agents/` (personnel)

**Invocation** : `/agent name`, `copilot --agent name`, ou en langage naturel

**Créer** : fichiers `.agent.md` manuels ou via des plugins

Notes:
Les agents Copilot suivent la convention de nommage .agent.md (et non juste .md comme Claude). Le format du fichier est du Markdown avec le suffixe .agent.md et un frontmatter YAML (max 30K caractères). Les agents au niveau utilisateur ont priorité sur ceux du projet en cas de conflit de noms. Les agents peuvent aussi être distribués via des plugins pour le partage en équipe.

##==##

<!-- .slide: class="with-code" -->

# GitHub Copilot : Custom Agents

**Définition** : sous-agents spécialisés à contexte isolé, pour des workflows dédiés à une tâche

| Champ                      | Requis | Description                                   |
| -------------------------- | ------ | --------------------------------------------- |
| `disable-model-invocation` | Non    | `true` pour empêcher l'auto-délégation        |
| `user-invocable`           | Non    | `false` pour masquer de la sélection manuelle |
| `mcp-servers`              | Non    | Serveurs MCP additionnels pour cet agent      |

<br>

**📚 Documentation** : https://docs.github.com/en/copilot/how-tos/copilot-cli/customize-copilot/create-custom-agents-for-cli

Notes:
Les agents Copilot suivent la convention de nommage .agent.md (et non juste .md comme Claude). Le format du fichier est du Markdown avec le suffixe .agent.md et un frontmatter YAML (max 30K caractères). Les agents au niveau utilisateur ont priorité sur ceux du projet en cas de conflit de noms. Les agents peuvent aussi être distribués via des plugins pour le partage en équipe.

##==##

<!-- .slide: class="exercice" -->

# Exercices : Github Copilot en profondeur

## Lab 41

<br>

### 👉 Suivez les **instructions** dans

### <code data-markdown-preview="/labs/lab-41-agentic-tools-deep-dive/README.md">labs/lab-41-agentic-tools-deep-dive/README.md</code>

### 📚 Exercices 5 à 6, section B (Github Copilot)

Notes:

- Suivez les instructions du README.md du lab pour les étapes détaillées.

##==##

<!-- .slide: class="exercice" -->

# Exercices : Github Copilot en profondeur

## Lab 41

<br>

### 💡 Lisez la **solution** dans

### <code data-markdown-preview="/labs/lab-41-agentic-tools-deep-dive-solution/README.md">labs/lab-41-agentic-tools-deep-dive-solution/README.md</code>

### 📚 Exercices 5 à 6, section B (Github Copilot)

Notes:

- Consultez le README.md du lab pour des exemples de solutions.

##==##

<!-- .slide: class="with-code" -->

# GitHub Copilot : Agent Skills

**Définition** : instructions de prompt réutilisables que Copilot charge à la demande. Guidage détaillé et spécifique à une tâche, activé selon le contexte — préférez les instructions personnalisées pour les règles simples toujours actives

| Champ         | Requis | Description                                         |
| ------------- | ------ | --------------------------------------------------- |
| `name`        | Oui    | Identifiant du skill (par défaut le nom du dossier) |
| `description` | Oui    | Quand Copilot doit charger ce skill automatiquement |
| `license`     | Non    | Conditions de licence applicables                   |

<br>

**Emplacement** : `.github/skills/<name>/SKILL.md` (projet) · `~/.copilot/skills/` (personnel)

**Invocation** : `/skill-name`, ou chargement automatique par Copilot si pertinent

**Créer** : fichiers `SKILL.md` manuels ou installation depuis des registres

Notes:
Les skills suivent le standard ouvert Agent Skills (agentskills.io), qui fonctionne sur plusieurs outils d'IA. Copilot prend en charge les emplacements .github/skills/ et .claude/skills/ pour la compatibilité inter-outils. Les skills diffèrent des instructions personnalisées : les instructions sont des règles simples toujours actives, les skills un guidage détaillé et spécifique à une tâche, chargé à la demande. Les descriptions de skills sont chargées au démarrage de la session ; le contenu complet ne l'est qu'à l'invocation.

##==##

<!-- .slide: class="with-code" -->

# GitHub Copilot : Agent Skills

**Définition** : instructions de prompt réutilisables que Copilot charge à la demande. Guidage détaillé et spécifique à une tâche, activé selon le contexte — préférez les instructions personnalisées pour les règles simples toujours actives

**Structure** :

```
my-skill/
├── SKILL.md           # Instructions (required)
├── templates/         # Templates to fill in
├── examples/          # Example outputs
├── scripts/           # Executable scripts
└── references/        # Reference documentation
```

<br>

**Registres publics** : [🔗 https://skills.sh](https://skills.sh) - [🔗 https://tessl.io/registry](https://tessl.io/registry)

Notes:
Les skills utilisent le même [format ouvert](https://agentskills.io) sur toutes les plateformes, ce qui en fait la fonctionnalité la plus portable. Copilot prend en charge les emplacements .github/skills/ et .claude/skills/ pour la compatibilité inter-outils. Utilisez /skills list pour voir les skills disponibles. Commandes CLI : /skills list, /skills info, /skills add, /skills reload.

##==##

<!-- .slide: class="with-code" -->

# GitHub Copilot : Agent Skills

**Définition** : instructions de prompt réutilisables que Copilot charge à la demande. Guidage détaillé et spécifique à une tâche, activé selon le contexte — préférez les instructions personnalisées pour les règles simples toujours actives

| Commande CLI     | Objectif                                       |
| ---------------- | ---------------------------------------------- |
| `/skills list`   | Afficher les skills disponibles                |
| `/skills info`   | Afficher les détails et l'emplacement du skill |
| `/skills add`    | Ajouter un emplacement de stockage de skills   |
| `/skills reload` | Rafraîchir les skills en cours de session      |
| `/skills remove` | Retirer les skills ajoutés directement         |

<br>

**📚 Documentation** : https://docs.github.com/en/copilot/how-tos/copilot-cli/customize-copilot/create-skills

Notes:
Les skills suivent le standard ouvert Agent Skills (agentskills.io), qui fonctionne sur plusieurs outils d'IA. Copilot prend en charge les emplacements .github/skills/ et .claude/skills/ pour la compatibilité inter-outils. Utilisez /skills list pour voir les skills disponibles. La commande /skills add permet d'ajouter des dossiers hors des emplacements par défaut. Les skills peuvent aussi être distribués via des plugins pour le partage en équipe.

##==##

<!-- .slide: class="exercice" -->

# Exercices : Github Copilot en profondeur

## Lab 41

<br>

### 👉 Suivez les **instructions** dans

### <code data-markdown-preview="/labs/lab-41-agentic-tools-deep-dive/README.md">labs/lab-41-agentic-tools-deep-dive/README.md</code>

### 📚 Exercices 7 à 9, section B (Github Copilot)

Notes:

- Suivez les instructions du README.md du lab pour les étapes détaillées.

##==##

<!-- .slide: class="exercice" -->

# Exercices : Github Copilot en profondeur

## Lab 41

<br>

### 💡 Lisez la **solution** dans

### <code data-markdown-preview="/labs/lab-41-agentic-tools-deep-dive-solution/README.md">labs/lab-41-agentic-tools-deep-dive-solution/README.md</code>

### 📚 Exercices 7 à 9, section B (Github Copilot)

Notes:

- Consultez le README.md du lab pour des exemples de solutions.

##==##

<!-- .slide: class="with-code" -->

# GitHub Copilot : Hooks

**Définition** : commandes shell exécutées à des points précis du cycle de vie des opérations de l'agent

| Événement                     | Déclenchement                             |
| ----------------------------- | ----------------------------------------- |
| `sessionStart` / `sessionEnd` | Cycle de vie de la session                |
| `preToolUse` / `postToolUse`  | Avant/après l'exécution d'un outil        |
| `userPromptSubmitted`         | Après l'envoi du prompt par l'utilisateur |
| `errorOccurred`               | En cas d'erreur                           |
| `agentStop` / `subagentStop`  | Fin de l'agent/sous-agent                 |

Notes:
Les hooks Copilot sont basés sur des scripts (exécution shell), à la différence de l'approche par prompt de Claude. La prise en charge multiplateforme, à la fois bash et powershell, est propre à Copilot. Les hooks couvrent 8 types d'événements du cycle de vie. Utilisez preToolUse pour la validation et agentStop/subagentStop pour le nettoyage.

##==##

<!-- .slide: class="with-code" -->

# GitHub Copilot : Hooks

**Définition** : commandes shell exécutées à des points précis du cycle de vie des opérations de l'agent

**Format de config** : fichiers JSON dans `.github/hooks/` (`version: 1` requis)

**Champs d'un hook** : `type` ("command"), `bash`, `powershell`, `cwd`, `timeoutSec` (30 par défaut), `env`

**Multiplateforme** : prend en charge les scripts bash et PowerShell

**📚 Documentation** : https://docs.github.com/en/copilot/how-tos/copilot-cli/customize-copilot/use-hooks

Notes:
Les hooks Copilot sont basés sur des scripts (exécution shell), à la différence de l'approche par prompt de Claude. La prise en charge multiplateforme, à la fois bash et powershell, est propre à Copilot. Les hooks couvrent 8 types d'événements du cycle de vie. Utilisez preToolUse pour la validation et agentStop/subagentStop pour le nettoyage.

##==##

<!-- .slide: -->

# GitHub Copilot : Plugins

**Définition** : paquets distribuables regroupant agents, skills, hooks et serveurs MCP

**Manifeste** : `plugin.json` à la racine du plugin

| Commande CLI                               | Objectif                                  |
| ------------------------------------------ | ----------------------------------------- |
| `copilot plugin install <source>`          | Depuis le marketplace, GitHub ou en local |
| `copilot plugin list`                      | Voir les plugins installés                |
| `copilot plugin uninstall <name>`          | Supprimer                                 |
| `copilot plugin marketplace browse <name>` | Découvrir des plugins                     |
| `copilot plugin marketplace add <source>`  | Ajouter un marketplace personnalisé       |

**Contenu** : `agents/`, `skills/`, `hooks.json`, `.mcp.json`

**📚 Documentation** : https://docs.github.com/en/copilot/how-tos/copilot-cli/customize-copilot/plugins-creating

Notes:
Le système de plugins de Copilot est similaire à celui de Claude Code. Le format du manifeste plugin.json est inter-compatible avec la convention .claude-plugin de Claude. Deux marketplaces intégrés sont inclus par défaut. Les plugins peuvent être installés depuis n'importe quel dépôt GitHub.

##==##

<!-- .slide: class="exercice" -->

# Exercices : Github Copilot en profondeur

## Lab 41

<br>

### 👉 Suivez les **instructions** dans

### <code data-markdown-preview="/labs/lab-41-agentic-tools-deep-dive/README.md">labs/lab-41-agentic-tools-deep-dive/README.md</code>

### 📚 Exercices 10 à 11, section B (Github Copilot)

Notes:

- Suivez les instructions du README.md du lab pour les étapes détaillées.

##==##

<!-- .slide: class="exercice" -->

# Exercices : Github Copilot en profondeur

## Lab 41

<br>

### 💡 Lisez la **solution** dans

### <code data-markdown-preview="/labs/lab-41-agentic-tools-deep-dive-solution/README.md">labs/lab-41-agentic-tools-deep-dive-solution/README.md</code>

### 📚 Exercices 10 à 11, section B (Github Copilot)

Notes:

- Consultez le README.md du lab pour des exemples de solutions.

##==##

<!-- .slide: -->

# GitHub Copilot : configuration

**Définition** : réglages au niveau projet et utilisateur qui contrôlent le comportement, les instructions et les intégrations de Copilot

| Niveau               | Source                               | Portée                    |
| -------------------- | ------------------------------------ | ------------------------- |
| Dépôt                | `copilot-instructions.md`            | Toutes les requêtes       |
| Spécifique au chemin | fichiers `.instructions.md`          | Chemins correspondants    |
| Spécifique à l'agent | fichiers `.agent.md`                 | À l'invocation de l'agent |
| Inter-compatible     | `CLAUDE.md`, `GEMINI.md`             | Dépôts multi-outils       |
| Personnel            | `~/.copilot/copilot-instructions.md` | Tous les projets          |

Notes:
Copilot a la hiérarchie d'instructions la plus riche - il détecte et combine automatiquement les instructions de plusieurs sources selon le contexte. L'inter-compatibilité avec CLAUDE.md et GEMINI.md permet aux équipes multi-outils de partager le contexte projet. Priorité des réglages : spécifique au chemin > dépôt > personnel.

##==##

<!-- .slide: -->

# GitHub Copilot : configuration

**Définition** : réglages au niveau projet et utilisateur qui contrôlent le comportement, les instructions et les intégrations de Copilot
<br>

**Instructions projet** : `AGENTS.md` (partagé via git) · `.github/copilot-instructions.md` (à l'échelle du projet)

**Bootstrap** : Copilot détecte automatiquement les instructions de plusieurs sources selon le contexte

**📚 Documentation** : https://docs.github.com/en/copilot/how-tos/copilot-cli/customize-copilot/overview

Notes:
Copilot a la hiérarchie d'instructions la plus riche - il détecte et combine automatiquement les instructions de plusieurs sources selon le contexte. L'inter-compatibilité avec CLAUDE.md et GEMINI.md permet aux équipes multi-outils de partager le contexte projet. Priorité des réglages : spécifique au chemin > dépôt > personnel.

##==##

<!-- .slide: -->

# **GitHub Copilot : tableau récapitulatif**

<br>

| Fonctionnalité | Emplacement               | Invocation          | Particularité            |
| -------------- | ------------------------- | ------------------- | ------------------------ |
| Agents         | `.github/agents/`         | `@name`, `/agent`   | suffixe `.agent.md`      |
| Prompts        | `.github/prompts/`        | `#name`             | suffixe `.prompt.md`     |
| Instructions   | `.github/instructions/`   | Auto (chemin)       | Ciblage via `applyTo`    |
| Skills         | `.github/skills/`         | `/name`, auto       | SKILL.md multiplateforme |
| Hooks          | `.github/hooks/`          | Auto (8 événements) | Basé script (bash+ps1)   |
| Plugins        | `copilot plugin`          | Installation CLI    | Distribution packagée    |
| Config         | `copilot-instructions.md` | Au démarrage        | Inter-compatible         |

Notes:
Les forces propres à Copilot : instructions spécifiques à un chemin (applyTo), hooks multiplateformes (bash+powershell), lecture inter-compatible des instructions, et des fonctionnalités intégrées à GitHub comme /delegate.

##==##

<!-- .slide: -->

# GitHub Copilot : quand utiliser quoi

## Choisir la bonne fonctionnalité

| Scénario                                     | Utiliser          | Pourquoi                                              |
| -------------------------------------------- | ----------------- | ----------------------------------------------------- |
| Besoin d'une expertise IA métier             | **Custom Agent**  | Rôle persistant dans `.github/agents/`, `/agent name` |
| Besoin d'un prompt réutilisable              | **Prompt**        | Modèle one-shot dans `.github/prompts/`               |
| Besoin de packager et distribuer l'outillage | **Plugin**        | `copilot plugin install` package les capacités        |
| Besoin de contrôler permissions/comportement | **Configuration** | Réglages de politique + `copilot-instructions.md`     |

<br>

Notes:
GitHub Copilot ajoute une couche Instructions — un guidage à l'échelle du projet appliqué à chaque interaction — que les autres outils n'ont pas. Les prompts sont l'équivalent des commandes personnalisées. La commande /delegate est unique : elle envoie le travail à un agent de codage en arrière-plan qui commite sur une branche et ouvre une PR.

##==##

<!-- .slide: -->

# GitHub Copilot : quand utiliser quoi

## Choisir la bonne fonctionnalité

| Scénario                                     | Utiliser          | Pourquoi                                            |
| -------------------------------------------- | ----------------- | --------------------------------------------------- |
| Besoin de contrôler permissions/comportement | **Configuration** | Réglages de politique + `copilot-instructions.md`   |
| Besoin de règles de comportement IA globales | **Instructions**  | `copilot-instructions.md` appliqué globalement      |
| Besoin de savoir partagé entre agents        | **Agent Skill**   | Composable, chargé auto depuis `.github/skills/`    |
| Besoin de validation automatique sur édition | **Hook**          | Déclencheurs Pre/Post définis dans `.github/hooks/` |

<br>

**Agents** = personas conversationnels | **Prompts** = modèles mono-tâche

**Skills** = connaissances composables | **Hooks** = application automatique | **Instructions** = contexte projet global

Notes:
GitHub Copilot ajoute une couche Instructions — un guidage à l'échelle du projet appliqué à chaque interaction — que les autres outils n'ont pas. Les prompts sont l'équivalent des commandes personnalisées. La commande /delegate est unique : elle envoie le travail à un agent de codage en arrière-plan qui commite sur une branche et ouvre une PR.
