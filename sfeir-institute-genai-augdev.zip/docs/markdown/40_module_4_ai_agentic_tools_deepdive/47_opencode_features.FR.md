<!-- .slide: class="transition" -->

# OpenCode Deep Dive

## Fonctionnalités CLI, agents, commandes, skills, plugins, modes et configuration

##==##

<!-- .slide: -->

# **OpenCode : la CLI en bref**

| Fonctionnalité       | Comment          | Exemple                                         |
| -------------------- | ---------------- | ----------------------------------------------- |
| Commandes slash      | préfixe `/`      | `/init`, `/help`, `/status`                     |
| Palette de commandes | `Ctrl+P`         | Chercher et exécuter toutes les commandes       |
| Changer d'agent      | `Tab`            | Bascule entre `build` et `plan`                 |
| Changer de modèle    | `Ctrl+X M`       | Choisir provider/modèle en interactif           |
| Permissions          | Dialogue ou `-p` | Approuver / refuser / autoriser pour la session |

<br>

**Touche leader** : `Ctrl+X` (personnalisable) — la plupart des actions multi-touches utilisent `Ctrl+X <key>`

**📚 Documentation** : https://opencode.ai/docs/

Notes:
OpenCode utilise une interface terminal (TUI) construite avec Bubble Tea. Le motif de touche leader (Ctrl+X par défaut) évite les conflits avec les séquences du terminal. Ctrl+P ouvre la palette de commandes pour chercher toutes les commandes enregistrées. La touche Tab est le moyen le plus rapide de basculer entre les deux agents principaux intégrés.

##==##

<!-- .slide: -->

# **OpenCode : la CLI en bref**

| Fonctionnalité       | Comment             | Exemple                                         |
| -------------------- | ------------------- | ----------------------------------------------- |
| Mode non interactif  | `opencode -p`       | `opencode -p "fix tests"`                       |
| Lister les modèles   | `opencode models`   | Affiche toutes les combinaisons provider/modèle |
| Démarrer le serveur  | `opencode serve`    | API headless pour les intégrations              |
| Gestion des sessions | `opencode sessions` | Lister et exporter les sessions passées         |
| Nouvelle session     | `Ctrl+X N`          | Démarrer une nouvelle conversation              |

<br>

**📚 Documentation** : https://opencode.ai/docs/cli/

Notes:
Le flag -p lance opencode en mode non interactif — idéal pour le scripting, la CI/CD et l'automatisation. Toutes les permissions sont auto-approuvées dans ce mode. Les sessions sont stockées en SQLite et exportables en JSON. La commande opencode serve expose une API headless utilisable pour orchestrer plusieurs instances via des scripts externes.

##==##

<!-- .slide: class="with-code" -->

# OpenCode : AGENTS.md (fichier de contexte)

**Définition** : instructions projet persistantes qu'OpenCode lit au début de chaque session. Fournit contexte, conventions et règles spécifiques au projet.

| Niveau                 | Fichier                        | Portée                                            |
| ---------------------- | ------------------------------ | ------------------------------------------------- |
| **Projet**             | `./AGENTS.md`                  | Partagé avec l'équipe via git                     |
| **Global utilisateur** | `~/.config/opencode/AGENTS.md` | Personnel, s'applique à tous les projets          |
| **Imbriqué**           | `<subdir>/AGENTS.md`           | Spécifique au sous-dossier (le plus proche gagne) |

<br>

**Créer/Mettre à jour** : `/init` analyse la base de code et crée ou met à jour AGENTS.md

**Instructions supplémentaires** : pointer `opencode.json` vers n'importe quel fichier `.md` via la clé de config `instructions`

**📚 Documentation** : https://opencode.ai/docs/rules/

Notes:
AGENTS.md est le même standard que celui utilisé par Codex CLI — l'équivalent OpenCode du CLAUDE.md de Claude. La commande /init scanne votre projet pour le générer automatiquement avec les étapes de build, les tests et les conventions. Les AGENTS.md imbriqués permettent aux packages d'un monorepo de porter leur propre contexte. L'option de config instructions permet de réutiliser des docs existantes sans dupliquer le contenu dans AGENTS.md.

##==##

<!-- .slide: class="with-code" -->

# OpenCode : modes intégrés (agents)

**Définition** : OpenCode fournit deux agents principaux, permutables avec `Tab`. Les modes adaptent outils, prompts et permissions selon l'usage.

| Mode    | Description                               | Outils activés         |
| ------- | ----------------------------------------- | ---------------------- |
| `build` | Par défaut — développement complet        | Tous les outils        |
| `plan`  | Analyse et planification en lecture seule | Pas d'outils d'édition |

<br>

**Basculer** : `Tab` pour permuter · `Ctrl+X M` pour choisir un mode

**Modes personnalisés** : définis dans `opencode.json`, section modes de `$schema`

**📚 Documentation** : https://opencode.ai/docs/modes/

Notes:
Le mode build est celui par défaut — il donne au modèle un accès complet aux opérations fichiers et aux commandes système. Le mode plan désactive les outils d'édition, ce qui le rend sûr pour l'exploration de code, la revue d'architecture ou la planification sans modification involontaire. La touche Tab offre le workflow le plus rapide : basculer en plan, obtenir la décision d'architecture, puis revenir en build avec Tab pour l'implémenter.

##==##

<!-- .slide: class="with-code" -->

# OpenCode : agents personnalisés

**Définition** : agents IA spécialisés avec system prompt, réglages de modèle et accès aux outils sur mesure — définis en fichiers Markdown

| Champ         | Requis | Description                                                 |
| ------------- | ------ | ----------------------------------------------------------- |
| `name`        | Non    | Identifiant (par défaut, le nom de fichier sans extension)  |
| `description` | Oui    | Quand OpenCode doit activer cet agent                       |
| `model`       | Non    | Surcharge provider/modèle (ex. `anthropic/claude-sonnet-5`) |

<br>

**Emplacement** : `.opencode/agents/` (projet) · `~/.config/opencode/agents/` (global)

**Format** : fichiers Markdown (`.md`) avec frontmatter YAML

**📚 Documentation** : https://opencode.ai/docs/agents/

Notes:
Les agents personnalisés d'OpenCode suivent le même motif Markdown + frontmatter YAML que Claude Code. Le champ description est critique — OpenCode lit les descriptions au démarrage pour décider quand activer un agent selon le contexte. Les agents peuvent surcharger le modèle, donnant à différents spécialistes l'accès à différents providers IA ou niveaux de modèle.

##==##

<!-- .slide: class="exercice" -->

# Exercices : Opencode CLI en profondeur

## Lab 41

<br>

### 👉 Suivre les **instructions** dans

### <code data-markdown-preview="/labs/lab-41-agentic-tools-deep-dive/README.md">labs/lab-41-agentic-tools-deep-dive/README.md</code>

### 📚 Exercices 1 à 3, section E (Opencode CLI)

Notes:

- Suivre les instructions du README.md du lab pour les étapes détaillées.

##==##

<!-- .slide: class="exercice" -->

# Exercices : Opencode CLI en profondeur

## Lab 41

<br>

### 💡 Lire la **solution** dans

### <code data-markdown-preview="/labs/lab-41-agentic-tools-deep-dive-solution/README.md">labs/lab-41-agentic-tools-deep-dive-solution/README.md</code>

### 📚 Exercices 1 à 3, section E (Opencode CLI)

Notes:

- Lire le README.md du lab pour des exemples de solutions.

##==##

<!-- .slide: class="with-code" -->

# OpenCode : commandes personnalisées

**Définition** : commandes slash définies par l'utilisateur qui envoient des prompts prédéfinis à l'assistant IA — stockées en fichiers Markdown

| Fonctionnalité   | Détails                                                                  |
| ---------------- | ------------------------------------------------------------------------ |
| **Emplacement**  | `.opencode/commands/` (projet) · `~/.config/opencode/commands/` (global) |
| **Format**       | fichiers `.md` — le nom de fichier devient l'ID de commande              |
| **Invocation**   | `/nom-commande` dans le prompt de la TUI                                 |
| **Option agent** | clé frontmatter `agent:` pour router vers un agent précis                |

<br>

**Exemple** : `.opencode/commands/code-reviewer.md` → invoquée via `/code-reviewer`

**📚 Documentation** : https://opencode.ai/docs/commands/

Notes:
Les commandes personnalisées sont l'équivalent des commandes personnalisées de Claude dans .claude/commands/. Ce sont des fichiers Markdown dont le nom devient la commande slash. Utilisez la clé frontmatter agent pour router la commande vers un agent personnalisé précis. Les commandes sont idéales pour les tâches répétitives : revue de code, contrôles d'architecture, génération de documentation.

##==##

<!-- .slide: class="with-code" -->

# OpenCode : Agent Skills

**Définition** : instructions de prompt réutilisables suivant le standard SKILL.md — chargées à la demande via l'outil natif skill

| Fonctionnalité      | Détails                                                                             |
| ------------------- | ----------------------------------------------------------------------------------- |
| **Emplacement**     | `.opencode/skills/<name>/SKILL.md` (projet) · `~/.config/opencode/skills/` (global) |
| **Chargement**      | Progressif — description seule au démarrage ; contenu complet à l'activation        |
| **Auto-activation** | L'agent voit les skills disponibles et charge la bonne selon le contexte            |

<br>

**Registres publics** : [🔗 https://skills.sh](https://skills.sh) — [🔗 https://tessl.io/registry](https://tessl.io/registry)

**📚 Documentation** : https://opencode.ai/docs/skills

Notes:
OpenCode supporte le même format SKILL.md multi-plateforme que Claude Code, Codex CLI, Gemini CLI et GitHub Copilot. Les skills peuvent embarquer leurs propres définitions de serveurs MCP dans le frontmatter (mcp.json), ce qui en fait des packages de connaissance autonomes. L'outil natif skill signifie que les skills sont chargées automatiquement dans le contexte quand l'agent les juge pertinentes — aucune invocation explicite $name nécessaire.

##==##

<!-- .slide: class="exercice" -->

# Exercices : Opencode CLI en profondeur

## Lab 41

<br>

### 👉 Suivre les **instructions** dans

### <code data-markdown-preview="/labs/lab-41-agentic-tools-deep-dive/README.md">labs/lab-41-agentic-tools-deep-dive/README.md</code>

### 📚 Exercices 4 à 7, section E (Opencode CLI)

Notes:

- Suivre les instructions du README.md du lab pour les étapes détaillées.

##==##

<!-- .slide: class="exercice" -->

# Exercices : Opencode CLI en profondeur

## Lab 41

<br>

### 💡 Lire la **solution** dans

### <code data-markdown-preview="/labs/lab-41-agentic-tools-deep-dive-solution/README.md">labs/lab-41-agentic-tools-deep-dive-solution/README.md</code>

### 📚 Exercices 4 à 7, section E (Opencode CLI)

Notes:

- Lire le README.md du lab pour des exemples de solutions.

##==##

<!-- .slide: class="with-code" -->

# OpenCode : plugins

**Définition** : étendre OpenCode avec des comportements sur mesure via des plugins JavaScript/TypeScript — se brancher sur les événements d'outils et ajouter des outils

```js
// .opencode/plugins/pre-validate.js
export const PreValidatePlugin = async ({ $ }) => {
  return {
    'tool.execute.before': async (input, output) => {
      if (input.tool === 'bash') {
        await $`./scripts/validate.sh ${output.args.command}`;
      }
    },
  };
};
```

**Emplacement** : `.opencode/plugins/` (projet) · `~/.config/opencode/plugins/` (global)

**Événements clés** : `tool.execute.before` · `tool.execute.after` · `session.idle` · `shell.env`

**📚 Documentation** : https://opencode.ai/docs/plugins/

Notes:
Les plugins OpenCode sont des fichiers JavaScript ou TypeScript placés dans `.opencode/plugins/`. Chaque plugin exporte une fonction qui retourne un objet de hooks indexé par nom d'événement. L'événement `tool.execute.before` se déclenche avant chaque appel d'outil — utilisez-le pour la pré-validation, le blocage d'opérations dangereuses ou la modification des arguments. Contrairement aux hooks configurés en JSON dans settings.json de Claude Code, les plugins OpenCode sont du code complet avec accès à l'API shell de Bun ($), au client SDK opencode et aux packages npm. Ou configurez via `opencode.json` sous la clé `"plugin"` pour charger depuis npm.

##==##

<!-- .slide: class="exercice" -->

# Exercices : Opencode CLI en profondeur

## Lab 41

<br>

### 👉 Suivre les **instructions** dans

### <code data-markdown-preview="/labs/lab-41-agentic-tools-deep-dive/README.md">labs/lab-41-agentic-tools-deep-dive/README.md</code>

### 📚 Exercice 8, section E (Opencode CLI)

Notes:

- Suivre les instructions du README.md du lab pour les étapes détaillées.

##==##

<!-- .slide: class="exercice" -->

# Exercices : Opencode CLI en profondeur

## Lab 41

<br>

### 💡 Lire la **solution** dans

### <code data-markdown-preview="/labs/lab-41-agentic-tools-deep-dive-solution/README.md">labs/lab-41-agentic-tools-deep-dive-solution/README.md</code>

### 📚 Exercice 8, section E (Opencode CLI)

Notes:

- Lire le README.md du lab pour des exemples de solutions.

##==##

<!-- .slide: class="with-code" -->

# OpenCode : configuration

**Définition** : réglages niveau projet et utilisateur dans `opencode.json` (JSONC supporté)

| Réglage        | Rôle                        | Exemple                              |
| -------------- | --------------------------- | ------------------------------------ |
| `model`        | Modèle par défaut           | `"anthropic/claude-sonnet-5"`        |
| `provider`     | Clés d'API des providers    | `{ "anthropic": { "apiKey": "…" } }` |
| `instructions` | Fichier de contexte en plus | `"./team-conventions.md"`            |

<br>

**Config projet** : `./opencode.json` (précédence la plus haute)

**Config utilisateur** : `~/.config/opencode/opencode.json`

**📚 Documentation** : https://opencode.ai/docs/config/

Notes:
OpenCode utilise une stratégie de fusion "le dernier gagne" : config utilisateur → config projet → flags CLI. Stockez les clés d'API dans la config utilisateur et les conventions projet dans la config projet. La clé instructions permet de pointer vers n'importe quel fichier markdown (par exemple votre README existant ou un doc de conventions d'équipe) sans le dupliquer dans AGENTS.md.

##==##

<!-- .slide: class="with-code" -->

# OpenCode : configuration

**Définition** : réglages niveau projet et utilisateur dans `opencode.json` (JSONC supporté)

| Réglage              | Rôle                           | Exemple                                       |
| -------------------- | ------------------------------ | --------------------------------------------- |
| `disabled_providers` | Ignorer les providers autoload | `["openai"]`                                  |
| `permission`         | Règles d'exécution des outils  | `{ "allow": ["read_file"], "ask": ["bash"] }` |
| `mcp`                | Définitions de serveurs MCP    | `{ "my-tool": { "type": "local", … } }`       |

<br>

**Config TUI** : `tui.json` (ou `tui.jsonc`) séparé pour les préférences d'interface

**📚 Documentation** : https://opencode.ai/docs/config/

Notes:
Le réglage disabled_providers est utile quand plusieurs identifiants de providers existent mais qu'un seul doit être actif sur un projet. La config permission permet de pré-autoriser certains outils (comme read_file) sans demande à l'utilisateur, gardant les workflows fluides tout en encadrant les opérations plus risquées comme bash.

##==##

<!-- .slide: class="exercice" -->

# Exercices : Opencode CLI en profondeur

## Lab 41

<br>

### 👉 Suivre les **instructions** dans

### <code data-markdown-preview="/labs/lab-41-agentic-tools-deep-dive/README.md">labs/lab-41-agentic-tools-deep-dive/README.md</code>

### 📚 Exercice 9 (optionnel), section E (Opencode CLI)

Notes:

- Suivre les instructions du README.md du lab pour les étapes détaillées.

##==##

<!-- .slide: class="exercice" -->

# Exercices : Opencode CLI en profondeur

## Lab 41

<br>

### 💡 Lire la **solution** dans

### <code data-markdown-preview="/labs/lab-41-agentic-tools-deep-dive-solution/README.md">labs/lab-41-agentic-tools-deep-dive-solution/README.md</code>

### 📚 Exercice 9 (optionnel), section E (Opencode CLI)

Notes:

- Lire le README.md du lab pour des exemples de solutions.

##==##

<!-- .slide: -->

# **OpenCode : synthèse des fonctionnalités**

| Fonctionnalité | Emplacement                | Invocation         | Trait clé                       |
| -------------- | -------------------------- | ------------------ | ------------------------------- |
| AGENTS.md      | `./AGENTS.md`              | Auto au démarrage  | Contexte multi-outils           |
| Modes          | Intégrés / `opencode.json` | `Tab` / `Ctrl+P`   | Build vs Plan nativement        |
| Agents         | `.opencode/agents/`        | Auto / contextuel  | Markdown, basé description      |
| Commandes      | `.opencode/commands/`      | `/nom`             | Commandes slash, one-shot       |
| Skills         | `.opencode/skills/<name>/` | Auto / appel outil | SKILL.md, chargement progressif |

Notes:
Les plugins OpenCode dans `.opencode/plugins/` servent à la fois de système de hooks et de plugins. Utilisez l'événement `tool.execute.before` pour la logique de pré-validation (équivalent du PreToolUse de Claude Code) et `tool.execute.after` pour le post-traitement. Le système de permissions fournit des règles déclaratives allow/ask/deny ; les plugins offrent un contrôle programmatique complet via du code JS/TS. La bascule intégrée entre modes build/plan est une fonctionnalité distinctive absente des autres outils. Le support multi-providers et la licence MIT le rendent unique dans l'écosystème.

##==##

<!-- .slide: -->

# **OpenCode : synthèse des fonctionnalités**

| Fonctionnalité | Emplacement                | Invocation          | Trait clé                      |
| -------------- | -------------------------- | ------------------- | ------------------------------ |
| Plugins        | `.opencode/plugins/`       | Hooks événementiels | JS/TS, `tool.execute.before`   |
| Permissions    | `opencode.json` / dialogue | Par appel d'outil   | Autoriser / Demander / Refuser |
| Serveurs MCP   | `opencode.json` / skill    | Auto (outils)       | Local ou distant, extensible   |
| Config         | `opencode.json`            | Au démarrage        | Fusion multi-niveaux           |

Notes:
Les plugins OpenCode dans `.opencode/plugins/` servent à la fois de système de hooks et de plugins. Utilisez l'événement `tool.execute.before` pour la logique de pré-validation (équivalent du PreToolUse de Claude Code) et `tool.execute.after` pour le post-traitement. Le système de permissions fournit des règles déclaratives allow/ask/deny ; les plugins offrent un contrôle programmatique complet via du code JS/TS. La bascule intégrée entre modes build/plan est une fonctionnalité distinctive absente des autres outils. Le support multi-providers et la licence MIT le rendent unique dans l'écosystème.

##==##

<!-- .slide: -->

# OpenCode : quoi utiliser quand

## Choisir la bonne fonctionnalité

| Scénario                             | Utiliser                   | Pourquoi                                                    |
| ------------------------------------ | -------------------------- | ----------------------------------------------------------- |
| Conventions projet toujours actives  | **AGENTS.md**              | Lu auto au démarrage, même format que Codex CLI             |
| Analyse en lecture seule sans risque | **Mode plan**              | `Tab` pour basculer — pas d'édition, idéal revue d'archi    |
| Expertise IA sur un domaine          | **Agent personnalisé**     | Persona Markdown dans `.opencode/agents/`, basé description |
| Prompt réutilisable pour une tâche   | **Commande personnalisée** | `/nom-commande` dans `.opencode/commands/` — one-shot       |

<br>

**AGENTS.md** = contexte projet permanent | **Modes** = exploration sûre vs codage actif

Notes:
La philosophie d'OpenCode est la simplicité : deux modes intégrés (build/plan) couvrent la plupart des besoins de workflow sans définir d'agents personnalisés. N'ajoutez des agents personnalisés que lorsque vous avez besoin d'une persona experte persistante. Les skills couvrent le cas d'usage de la connaissance composable. Le système de permissions remplace les hooks pour l'application de la qualité.

##==##

<!-- .slide: -->

# OpenCode : quoi utiliser quand

## Choisir la bonne fonctionnalité

| Scénario                           | Utiliser            | Pourquoi                                                    |
| ---------------------------------- | ------------------- | ----------------------------------------------------------- |
| Connaissance partagée entre agents | **Agent Skill**     | SKILL.md dans `.opencode/skills/`, chargé auto à la demande |
| Contrôle de l'exécution des outils | **Permissions**     | config `permission` dans `opencode.json`, ou dialogues      |
| Outils sur mesure / API externes   | **Serveurs MCP**    | clé `mcp` dans `opencode.json` ou MCP embarqué dans skill   |
| Changer de provider IA librement   | **Config provider** | 75+ providers, apportez votre propre clé d'API              |

<br>

**Skills** = connaissance composable | **Permissions** = contrôle d'exécution _(Hooks & Plugins : N/A)_

Notes:
OpenCode ne supporte pas les hooks ni les plugins. Utilisez permissions + modes pour le cas d'usage des hooks (application de règles avant/après action). Pour le cas d'usage des plugins, les skills avec serveurs MCP embarqués sont l'approche recommandée. Le large support de providers (75+ providers, dont Ollama en local) est le différenciateur majeur d'OpenCode pour les équipes ayant des accords variés avec les fournisseurs d'IA.
