<!-- .slide: class="transition" -->

# Claude Code Deep Dive

## CLI Features, Agents, Commands, Skills, Hooks, Plugins & Configuration

##==##

<!-- .slide: -->

# **Claude Code: CLI Overview**

| Feature           | How         | Example                      |
| ----------------- | ----------- | ---------------------------- |
| Include files     | `@` symbol  | `@src/api/ review this`      |
| Slash commands    | `/` prefix  | `/help`, `/compact`, `/init` |
| Execute bash      | `!` prefix  | `!npm test`                  |
| Permission modes  | `Shift+Tab` | Normal → Plan → Auto-Accept  |
| Extended thinking | `Alt+T`     | Toggle on/off                |

<br>

**📚 Documentation**: https://code.claude.com/docs/en/interactive-mode

Notes:
These are the foundational features. Master @ # / ! before diving into customization. Permission modes control Claude's autonomy: Normal (asks permission), Plan (read-only), Auto-Accept (full autonomy).

##==##

<!-- .slide: -->

# **Claude Code: CLI Overview**

| Feature            | How                          | Example                                       |
| ------------------ | ---------------------------- | --------------------------------------------- |
| History            | `Esc Esc` \| `/rewind`       | Restore code/conversation to a previous point |
| Session            | `/resume`                    | Resume a previous conversation                |
| Context management | `/compact`                   | Compress at 70-85% capacity                   |
| Long-absence recap | `/recap`                     | Inject context summary after 75+ min away     |
| Clear context      | `/clear`                     | Wipes all context, fresh start                |
| Effort level       | `/effort`                    | Slider: low → medium → high → **xhigh**       |
| Voice mode         | `/voice` then `SPACE (hold)` | Toggle on/off                                 |
| Stop all agents    | `Ctrl+X` `Ctrl+K`            | Kill all background agents (was `Ctrl+F`)     |

<br>

**📚 Documentation**: https://code.claude.com/docs/en/interactive-mode

Notes:
These are the foundational features. Master @ # / ! before diving into customization. Permission modes control Claude's autonomy: Normal (asks permission), Plan (read-only), Auto-Accept (full autonomy). Note: `/vim` and `/tag` were removed in early 2026 — use `/config` → Editor mode for vim-style editing. The new `/effort` command exposes a 4-level slider; `xhigh` is available on the current Opus-class/flagship models (Opus 4.8, Fable 5). `/ultrareview` triggers a billed cloud review of the current branch (or a GitHub PR by number) and is operator-initiated, not agent-callable.

##==##

<!-- .slide: -->

# **Claude Code: CLI Overview**

| Slash command           | Purpose                                                 |
| ----------------------- | ------------------------------------------------------- |
| `/ultrareview [target]` | Multi-agent cloud code review of current branch or PR   |
| `/team-onboarding`      | Generate teammate ramp-up guide for the current project |
| `/insights`             | Generate a report analyzing your Claude Code sessions   |
| `/powerup`              | Interactive lessons on Claude Code with animated demos  |

<br>

**📚 Documentation**: https://code.claude.com/docs/en/changelog

Notes:
These commands shipped between January and July 2026 (current as of v2.1.215, 2026-07-19). `/ultrareview` is the most teaching-relevant — it spins up cloud reviewers in parallel and bundles results back into the local session. `/less-permission-prompts` is the quickest way to reduce friction in long-running sessions. `/recap` automatically fires after a configurable idle threshold (default 75 min) but can also be invoked manually. The `Ctrl+F` → `Ctrl+X Ctrl+K` rebinding was made because `Ctrl+F` was shadowing readline forward-char.

##==##

<!-- .slide: class="with-code" -->

# Claude Code: CLAUDE.md (Context File)

**Definition**: Persistent project instructions that Claude reads at the start of every session. Provides project-specific context, conventions, and guidelines.

| Level              | File                  | Scope                             |
| ------------------ | --------------------- | --------------------------------- |
| **Project shared** | `./CLAUDE.md`         | Shared with team via git          |
| **Project local**  | `./CLAUDE.local.md`   | Personal, gitignored              |
| **User global**    | `~/.claude/CLAUDE.md` | Personal, applies to all projects |

**Create/Update**: `/init` analyzes existing code and generates CLAUDE.md (tech stack, build commands, conventions)

**Edit**: `/memory` opens CLAUDE.md for editing

**📚 Documentation**: https://code.claude.com/docs/en/memory

Notes:
CLAUDE.md is the foundation of project context. The /init command scans your codebase to auto-generate relevant instructions. The # shortcut lets you quickly add instructions without leaving the conversation. Project-shared files go in git; personal preferences go in CLAUDE.local.md. Nested CLAUDE.md files in subdirectories provide directory-specific context.

##==##

<!-- .slide: class="with-code" -->

# Claude Code: Rules (`.claude/rules/`)

**Definition**: Modular, file-scoped instruction files that extend CLAUDE.md. Each rule covers one topic and can be scoped to specific file paths using glob patterns.

| Feature          | Details                                                              |
| ---------------- | -------------------------------------------------------------------- |
| **Format**       | Markdown files (`.md`) in `.claude/rules/`                           |
| **Path scoping** | `paths` YAML frontmatter with glob patterns                          |
| **Loading**      | Without `paths`: at launch. With `paths`: when matching files opened |
| **User rules**   | `~/.claude/rules/` for personal cross-project rules                  |

Notes:
Rules are ideal for large projects where a single CLAUDE.md becomes unwieldy. Path-specific rules save context by only loading when Claude works with matching files. Use descriptive filenames like testing.md or api-design.md. Symlinks let teams share rules across repos.

##==##

<!-- .slide: class="with-code" -->

# Claude Code: Rules (`.claude/rules/`)

```yaml
---
paths:
  - 'src/api/**/*.ts'
---
# API rules: validate input, standard error format...
```

**vs CLAUDE.md**: CLAUDE.md = single file, always loaded. Rules = modular, can be path-scoped

**📚 Documentation**: https://code.claude.com/docs/en/memory

Notes:
Rules are ideal for large projects where a single CLAUDE.md becomes unwieldy. Path-specific rules save context by only loading when Claude works with matching files. Use descriptive filenames like testing.md or api-design.md. Symlinks let teams share rules across repos.

##==##

<!-- .slide: class="exercice" -->

# Exercises: Claude Code Deep Dive

## Lab 41

<br>

### 👉 Follow **instructions** in

### <code data-markdown-preview="/labs/lab-41-agentic-tools-deep-dive/README.md">labs/lab-41-agentic-tools-deep-dive/README.md</code>

### 📚 Exercises 1 to 2, Section A (Claude Code)

Notes:

- Follow the instructions in the lab README.md for detailed steps.

##==##

<!-- .slide: class="exercice" -->

# Exercises: Claude Code Deep Dive

## Lab 41

<br>

### 💡 Read **solution** at

### <code data-markdown-preview="/labs/lab-41-agentic-tools-deep-dive-solution/README.md">labs/lab-41-agentic-tools-deep-dive-solution/README.md</code>

### 📚 Section A (Claude Code), Exercises 1-3

Notes:

- Read the lab README.md for example of solutions.

##==##

<!-- .slide: class="with-code" -->

# Claude Code: Custom Agents

**Definition**: Specialized AI subagents with isolated context, custom system prompts, and restricted tool access

| Field         | Required | Description                                        |
| ------------- | -------- | -------------------------------------------------- |
| `name`        | Yes      | Unique identifier (lowercase, hyphens)             |
| `description` | Yes      | When Claude should delegate to this agent          |
| `tools`       | No       | Allowed tools (inherits all if omitted)            |
| `model`       | No       | `sonnet`, `opus`, `haiku`, or full model ID        |
| `color`       | No       | Color of your sub agent to help identify it in CLI |

**Location**: `.claude/agents/` (project) · `~/.claude/agents/` (personal)

**Invocation**: `@agent-name`, natural language, or `claude --agent name`

**Create**: `/agents` interactive command or manual `.md` file

Notes:
Subagents run in isolated context windows preserving main conversation context. As of mid-2026 subagents run in the **background by default** — Claude keeps working while they run and picks up results when they finish; it only runs one in the foreground when it needs the result before continuing, and background subagents surface every permission prompt in the main session (pin behavior with the `background` frontmatter field). They cannot spawn other subagents. Use /agents to create interactively or write .md files manually. The description field is critical - Claude uses it to decide when to delegate. Memory enables cross-session learning.

##==##

<!-- .slide: class="with-code" -->

# Claude Code: Custom Agents

**Definition**: Specialized AI subagents with isolated context, custom system prompts, and restricted tool access

| Field            | Required | Description                                  |
| ---------------- | -------- | -------------------------------------------- |
| `permissionMode` | No       | `default`, `plan`, `bypassPermissions`, etc. |
| `maxTurns`       | No       | Max agentic turns before stopping            |
| `skills`         | No       | Skills to preload into agent context         |
| `hooks`          | No       | Lifecycle hooks scoped to this agent         |
| `background`     | No       | Pin foreground/background execution          |

<br>

**📚 Documentation**: https://code.claude.com/docs/en/sub-agents

Notes:
Subagents run in isolated context windows preserving main conversation context. They cannot spawn other subagents. Use /agents to create interactively or write .md files manually. The description field is critical - Claude uses it to decide when to delegate. Memory enables cross-session learning.

##==##

<!-- .slide: class="with-code" -->

# Claude Code: Custom Agents

**Definition**: Specialized AI subagents with isolated context, custom system prompts, and restricted tool access

| Field           | Required | Description                                           |
| --------------- | -------- | ----------------------------------------------------- |
| `memory`        | No       | `user`, `project`, or `local` for persistence         |
| `isolation`     | No       | `worktree` runs the agent in a temporary git worktree |
| `cwd`           | No       | Override working directory for this agent             |
| `initialPrompt` | No       | Auto-submitted first turn when invoked                |
| `mcpServers`    | No       | Per-agent MCP server config (loaded on `--agent`)     |

<br>

**📚 Documentation**: https://code.claude.com/docs/en/sub-agents

Notes:
Subagents run in isolated context windows preserving main conversation context. They cannot spawn other subagents. Use /agents to create interactively or write .md files manually. The description field is critical - Claude uses it to decide when to delegate. Memory enables cross-session learning.

##==##

<!-- .slide: -->

# Claude Code: Agent Teams _(Experimental)_

**Definition**: Multiple **independent Claude Code sessions** coordinated by a team lead, with shared task lists, inter-agent messaging, and parallel execution in separate git worktrees

| Component     | Role                                                     |
| ------------- | -------------------------------------------------------- |
| **Team lead** | Creates team, spawns teammates, coordinates work         |
| **Teammates** | Separate Claude Code instances working on assigned tasks |
| **Task list** | Shared work items that teammates claim and complete      |
| **Mailbox**   | Messaging system for direct inter-agent communication    |

**Invocation**: Natural language ("Create an agent team to...") or Claude proposes

**Display modes**: `in-process` (default) or `tmux` split panes (`Shift+Down` to cycle)

**`/agents` UI**: tabbed Library (defined agents, Run/View actions) + Running (live subagents)

**📚 Documentation**: https://code.claude.com/docs/en/agent-teams

Notes:
Agent teams are still experimental as of July 2026 (verified against the Claude Code changelog v2.1.215). Use teams when workers need to communicate with each other (e.g., competing hypotheses, cross-layer coordination). Use subagents when you just need focused workers reporting results back. Teams use significantly more tokens but enable research, review, debugging with parallel hypotheses, and cross-layer feature work. Background subagents that fail now report partial progress back to the parent agent — useful when long-running research dies mid-task.

##==##

<!-- .slide: class="exercice" -->

# Exercises: Claude Code Deep Dive

## Lab 41

<br>

### 👉 Follow **instructions** in

### <code data-markdown-preview="/labs/lab-41-agentic-tools-deep-dive/README.md">labs/lab-41-agentic-tools-deep-dive/README.md</code>

### 📚 Exercises 3 to 4, Section A (Claude Code)

Notes:

- Follow the instructions in the lab README.md for detailed steps.

##==##

<!-- .slide: class="exercice" -->

# Exercises: Claude Code Deep Dive

## Lab 41

<br>

### 💡 Read **solution** at

### <code data-markdown-preview="/labs/lab-41-agentic-tools-deep-dive-solution/README.md">labs/lab-41-agentic-tools-deep-dive-solution/README.md</code>

### 📚 Exercises 3 to 4, Section A (Claude Code)

Notes:

- Read the lab README.md for example of solutions.

##==##

<!-- .slide: class="with-code" -->

# Claude Code: Custom Commands

**Definition**: Reusable prompt instructions that Claude loads on demand. Custom commands (`.claude/commands/`) have been **merged into skills** - both create `/slash-commands` and share the same frontmatter spec

| Field                      | Required    | Description                                     |
| -------------------------- | ----------- | ------------------------------------------------ |
| `name`                     | No          | Slash command name (defaults to dir name)       |
| `description`              | Recommended | When Claude should auto-load this command/skill |

Notes:
Skills follow the Agent Skills open standard (agentskills.io) working across multiple AI tools. Commands in .claude/commands/ still work but skills are recommended - they support directories for bundled files, frontmatter for invocation control, and auto-detection. Use disable-model-invocation for side-effect actions like deploy.

##==##

<!-- .slide: class="with-code" -->

# Claude Code: Agent Skills

**Definition**: Reusable prompt instructions that Claude loads on demand. 

<br>

**Location**: `.claude/skills/<name>/SKILL.md` (project) · `~/.claude/skills/` (personal)

**Invocation**: `/skill-name [args]` or auto-loaded by Claude when relevant

**Arguments**: `$ARGUMENTS`, `$0`, `$1`, dynamic context with `` !`command` ``

Notes:
Skills follow the Agent Skills open standard (agentskills.io) working across multiple AI tools. Commands in .claude/commands/ still work but skills are recommended - they support directories for bundled files, frontmatter for invocation control, and auto-detection. Use disable-model-invocation for side-effect actions like deploy.

##==##

<!-- .slide: class="with-code" -->

# Claude Code: Agent Skills

**Definition**: Reusable prompt instructions that Claude loads on demand.

| Field           | Required | Description                                    |
| --------------- | -------- | ---------------------------------------------- |
| `allowed-tools` | No       | Tools allowed when skill is active             |
| `argument-hint` | No       | Hint for autocomplete (e.g., `[issue-number]`) |
| `context`       | No       | `fork` to run in isolated subagent             |
| `model`         | No       | Model override when skill is active            |

**Location**: `.claude/skills/<name>/SKILL.md` (project) · `~/.claude/skills/` (personal)

**Invocation**: `/skill-name [args]` or auto-loaded by Claude when relevant

**Arguments**: `$ARGUMENTS`, `$0`, `$1`, dynamic context with `` !`command` ``

Notes:
Skills follow the Agent Skills open standard (agentskills.io) working across multiple AI tools. Commands in .claude/commands/ still work but skills are recommended - they support directories for bundled files, frontmatter for invocation control, and auto-detection. Use disable-model-invocation for side-effect actions like deploy.

##==##

<!-- .slide: class="with-code" -->

# Claude Code: Agent Skills

**Definition**: Reusable prompt instructions that Claude loads on demand. Custom commands (`.claude/commands/`) have been **merged into skills** - both create `/slash-commands`

| Field           | Required | Description                                    |
| --------------- | -------- | ---------------------------------------------- |
| `allowed-tools` | No       | Tools allowed when skill is active             |
| `argument-hint` | No       | Hint for autocomplete (e.g., `[issue-number]`) |
| `context`       | No       | `fork` to run in isolated subagent             |
| `model`         | No       | Model override when skill is active            |

**Location**: `.claude/skills/<name>/SKILL.md` (project) · `~/.claude/skills/` (personal)

**Invocation**: `/skill-name [args]` or auto-loaded by Claude when relevant

**Arguments**: `$ARGUMENTS`, `$0`, `$1`, dynamic context with `` !`command` ``

Notes:
Skills follow the Agent Skills open standard (agentskills.io) working across multiple AI tools. Commands in .claude/commands/ still work but skills are recommended - they support directories for bundled files, frontmatter for invocation control, and auto-detection. Use disable-model-invocation for side-effect actions like deploy.

##==##

<!-- .slide: class="with-code" -->

# Claude Code: Agent Skills

**Definition**: Reusable prompt instructions that Claude loads on demand. Custom commands (`.claude/commands/`) have been **merged into skills** - both create `/slash-commands`

**Structure**:

```
my-skill/
├── SKILL.md           # Instructions (required)
├── templates/         # Templates for Claude to fill in
├── examples/          # Example outputs
├── scripts/           # Executable scripts
└── references/        # Reference documentation
```

**How it works**: Skill descriptions are loaded into context at session start. Full content loads only when invoked (manually or by Claude). Keep SKILL.md under 500 lines.

**Stacked skills**: Invoke several at once — `/skill-a /skill-b do XYZ` loads all leading skills (up to 5), not just the first

**Public Registries**: [🔗 https://skills.sh](https://skills.sh) - [🔗 https://tessl.io/registry](https://tessl.io/registry)

**📚 Documentation**: https://code.claude.com/docs/en/skills

Notes:
Skills differ from agents and commands: agents are conversational personas, commands/skills are prompt templates. Skills add automatic context loading - Claude reads descriptions at startup and loads full content when relevant. Public registries enable sharing across teams and platforms without building from scratch.

##==##

<!-- .slide: class="exercice" -->

# Exercises: Claude Code Deep Dive

## Lab 41

<br>

### 👉 Follow **instructions** in

### <code data-markdown-preview="/labs/lab-41-agentic-tools-deep-dive/README.md">labs/lab-41-agentic-tools-deep-dive/README.md</code>

### 📚 Exercises 5 to 8, Section A (Claude Code)

Notes:

- Follow the instructions in the lab README.md for detailed steps.

##==##

<!-- .slide: class="exercice" -->

# Exercises: Claude Code Deep Dive

## Lab 41

<br>

### 💡 Read **solution** at

### <code data-markdown-preview="/labs/lab-41-agentic-tools-deep-dive-solution/README.md">labs/lab-41-agentic-tools-deep-dive-solution/README.md</code>

### 📚 Exercises 5 to 8, Section A (Claude Code)

Notes:

- Read the lab README.md for example of solutions.

##==##

<!-- .slide: class="with-code" -->

# Claude Code: Hooks

**Definition**: Lifecycle callbacks that run shell **commands** or **prompts** before/after tool execution and on environment / session events

| Event           | Matcher    | When it fires                           |
| --------------- | ---------- | --------------------------------------- |
| `PreToolUse`    | Tool name  | Before tool runs (can block)            |
| `PostToolUse`   | Tool name  | After tool completes                    |
| `SubagentStart` | Agent name | When subagent begins                    |
| `SubagentStop`  | Agent name | When subagent completes                 |
| `CwdChanged`    | —          | Working directory changed (`/cd`, etc.) |
| `FileChange`   | Path glob  | File modified outside Claude's tools    |

Notes:
Claude Code uniquely supports prompt-based hooks where Claude evaluates a prompt to decide what to do — this is more flexible than script-based hooks but less deterministic. Hooks can also invoke MCP tools directly via `type: "mcp_tool"`. The conditional `if` field lets one hook entry handle many tool patterns without separate matchers. `CwdChanged` and `FileChanged` are 2026 additions that close the gap on observability for non-tool-driven events.

##==##

<!-- .slide: class="with-code" -->

# Claude Code: Hooks

| Event              | Matcher | When it fires                                    |
| ------------------ | ------- | ------------------------------------------------ |
| `TaskCreated`      | —       | A new task was added to the task list            |
| `PreCompact`       | —       | Before the conversation is compacted             |
| `WorktreeCreate`   | —       | A new git worktree is created (e.g. by an agent) |
| `PermissionDenied` | —       | A permission prompt was denied by the user       |

<br>

**Exit codes**: `0` = allow, `2` = block action

**Output override**: `PostToolUse` can replace tool output via `hookSpecificOutput.updatedToolOutput`

**📚 Documentation**: https://code.claude.com/docs/en/hooks-guide

Notes:
Use `PreToolUse` to validate before actions, `PostToolUse` for post-action verification. `PreCompact` is the right place to dump important state to a file before context compression. `PermissionDenied` is useful for sending Slack pings when the agent gets blocked overnight. `TaskCreated` and `WorktreeCreate` enable telemetry on agent planning and parallelism. The `updatedToolOutput` override gives hooks the power to redact secrets out of tool results before Claude sees them.

##==##

<!-- .slide: class="with-code" -->

# Claude Code: Hooks

**Definition**: Lifecycle callbacks that run shell **commands** or **prompts** before/after tool execution and on environment / session events

**Hook types**: `command` (run shell script) · `prompt` (Claude evaluates) · `mcp_tool` (invoke MCP tool directly)

**Location**: `.claude/settings.json` → `hooks` key

**Matcher syntax**: Tool name string, pipe `|` for OR (e.g., `Write|Edit`)

**Conditional**: `if` field accepts permission-rule syntax (e.g., `Bash(git *)`) to filter execution

Notes:
Claude Code uniquely supports prompt-based hooks where Claude evaluates a prompt to decide what to do — this is more flexible than script-based hooks but less deterministic. Hooks can also invoke MCP tools directly via `type: "mcp_tool"`. The conditional `if` field lets one hook entry handle many tool patterns without separate matchers. `CwdChanged` and `FileChanged` are 2026 additions that close the gap on observability for non-tool-driven events.

##==##

<!-- .slide: -->

# Claude Code: Plugins

**Definition**: Distributable packages that bundle **agents**, **skills**, **hooks**, **MCP servers**, and **executables** into installable extensions

**Manifest**: `plugin.json` in `.claude-plugin/` directory

| CLI Command                      | Purpose                                         |
| -------------------------------- | ----------------------------------------------- |
| `claude plugin install <source>` | Install from marketplace, GitHub, or local path |
| `claude plugin update <name>`    | Update to latest version                        |
| `claude plugin uninstall <name>` | Remove plugin                                   |
| `claude plugin tag`              | Create release git tags with version validation |

Notes:
Plugins are the highest-level abstraction. They bundle multiple feature types into a single installable package. Use `claude plugin marketplace` to discover community plugins. Plugin agents cannot define hooks, mcpServers, or permissionMode for security — copy to `.claude/agents/` if needed. The `userConfig` manifest field is the 2026 way to ask the user for setup values at install/enable time without forcing them to hand-edit `settings.json`. `claude plugin tag` is the recommended path to publish versioned releases. The plugin.json format is compatible with GitHub Copilot plugins.

##==##

<!-- .slide: -->

# Claude Code: Plugins

**Definition**: Distributable packages that bundle **agents**, **skills**, **hooks**, **MCP servers**, and **executables** into installable extensions

**Manifest**: `plugin.json` in `.claude-plugin/` directory

<br>

**Namespace**: Plugin commands are namespaced as `/plugin-name:command-name`

**When to use**: Sharing team tooling setups, distributing standardized workflows across projects and teams

Notes:
Plugins are the highest-level abstraction. They bundle multiple feature types into a single installable package. Use `claude plugin marketplace` to discover community plugins. Plugin agents cannot define hooks, mcpServers, or permissionMode for security — copy to `.claude/agents/` if needed. The `userConfig` manifest field is the 2026 way to ask the user for setup values at install/enable time without forcing them to hand-edit `settings.json`. `claude plugin tag` is the recommended path to publish versioned releases. The plugin.json format is compatible with GitHub Copilot plugins.

##==##

<!-- .slide: -->

# Claude Code: Plugins

**Definition**: Distributable packages that bundle **agents**, **skills**, **hooks**, and **MCP servers** into installable extensions

**Manifest**: `plugin.json` in `.claude-plugin/` directory

| CLI Command                        | Purpose                    |
| ---------------------------------- | -------------------------- |
| `claude plugin marketplace browse` | Discover available plugins |
| `claude plugin list`               | View installed plugins     |

**📚 Documentation**: https://code.claude.com/docs/en/plugins

Notes:
The skill-bundling change matters because earlier plugin releases used directory names for invocation, which broke when teams renamed plugin folders. With `"skills": ["./"]`, the SKILL.md frontmatter `name` is the stable invocation key. `alwaysLoad` is an escape hatch for plugins where deferred tool loading would surprise the user. `allowedChannelPlugins` is part of the managed-settings story for enterprise rollouts.

##==##

<!-- .slide: -->

# Claude Code: Plugins

**Definition**: Distributable packages that bundle **agents**, **skills**, **hooks**, and **MCP servers** into installable extensions

**Manifest**: `plugin.json` in `.claude-plugin/` directory

**Skill bundling**: declare via `"skills": ["./"]` to use the skill's frontmatter `name` for stable invocation

**MCP option**: `alwaysLoad: true` skips tool-search deferral for the plugin's MCP server

**Admin gating**: enterprise admins can scope plugins via `allowedChannelPlugins`; blocked plugins are hidden from the marketplace

**📚 Documentation**: https://code.claude.com/docs/en/plugins

Notes:
The skill-bundling change matters because earlier plugin releases used directory names for invocation, which broke when teams renamed plugin folders. With `"skills": ["./"]`, the SKILL.md frontmatter `name` is the stable invocation key. `alwaysLoad` is an escape hatch for plugins where deferred tool loading would surprise the user. `allowedChannelPlugins` is part of the managed-settings story for enterprise rollouts.

##==##

<!-- .slide: class="exercice" -->

# Exercises: Claude Code Deep Dive

## Lab 41

<br>

### 👉 Follow **instructions** in

### <code data-markdown-preview="/labs/lab-41-agentic-tools-deep-dive/README.md">labs/lab-41-agentic-tools-deep-dive/README.md</code>

### 📚 Exercises 9-10, Section A (Claude Code)

Notes:

- Follow the instructions in the lab README.md for detailed steps.

##==##

<!-- .slide: class="exercice" -->

# Exercises: Claude Code Deep Dive

## Lab 41

<br>

### 💡 Read **solution** at

### <code data-markdown-preview="/labs/lab-41-agentic-tools-deep-dive-solution/README.md">labs/lab-41-agentic-tools-deep-dive-solution/README.md</code>

### 📚 Exercises 9-10, Section A (Claude Code)

Notes:

- Read the lab README.md for example of solutions.

##==##

<!-- .slide: -->

# Claude Code: Configuration (settings.json)

**Definition**: Project and user-level settings controlling Claude's behavior, permissions, and integrations

| Setting        | Purpose             | Example                 |
| -------------- | ------------------- | ----------------------- |
| `allowedTools` | Auto-permit tools   | `["Bash(npm:*)"]`       |
| `deniedTools`  | Block tools         | `["Bash(rm -rf:*)"]`    |
| `hooks`        | Lifecycle callbacks | PreToolUse, PostToolUse |

<br>

**Location**: `.claude/settings.json` (project) · `.claude/settings.local.json` (personal) ·`~/.claude/settings.json` (user)

**Project instructions**: `CLAUDE.md` (shared via git) · `CLAUDE.local.md` (personal)

**Bootstrap**: `/init` analyzes project and generates CLAUDE.md · `/config` persists changes back to `~/.claude/settings.json`

Notes:
Settings follow a priority hierarchy: CLI flags > policy > project > user settings. CLAUDE.md serves as persistent project instructions — similar to AGENTS.md for Codex. The /init command scans your codebase to auto-generate relevant instructions including tech stack, build commands, and conventions. Invalid enum values now invalidate just the affected key (not the whole `settings.json`); `cleanupPeriodDays: 0` is rejected outright (was silently disabling persistence).

##==##

<!-- .slide: -->

# Claude Code: Configuration (settings.json)

**Definition**: Project and user-level settings controlling Claude's behavior, permissions, and integrations

| Setting            | Purpose               | Example                |
| ------------------ | --------------------- | ---------------------- |
| `env`              | Environment variables | `{"NODE_ENV": "test"}` |
| `mcpServers`       | MCP integrations      | Server configurations  |
| `permissions.deny` | Block agents/skills   | `["Agent(Explore)"]`   |

<br>

**📚 Documentation**: https://code.claude.com/docs/en/settings

Notes:
Settings follow a priority hierarchy: CLI flags > policy > project > user settings. CLAUDE.md serves as persistent project instructions — similar to AGENTS.md for Codex.

##==##

<!-- .slide: class="exercice" -->

# Exercises: Claude Code Deep Dive

## Lab 41

<br>

### 👉 Follow **instructions** in

### <code data-markdown-preview="/labs/lab-41-agentic-tools-deep-dive/README.md">labs/lab-41-agentic-tools-deep-dive/README.md</code>

### 📚 Exercise 11 (optional), Section A (Claude Code)

Notes:

- Follow the instructions in the lab README.md for detailed steps.

##==##

<!-- .slide: class="exercice" -->

# Exercises: Claude Code Deep Dive

## Lab 41

<br>

### 💡 Read **solution** at

### <code data-markdown-preview="/labs/lab-41-agentic-tools-deep-dive-solution/README.md">labs/lab-41-agentic-tools-deep-dive-solution/README.md</code>

### 📚 Exercise 11 (optional), Section A (Claude Code)

Notes:

- Read the lab README.md for example of solutions.

##==##

<!-- .slide: -->

# **Claude Code: Feature Summary**

| Feature     | Location            | Invocation         | Key Trait                                 |
| ----------- | ------------------- | ------------------ | ----------------------------------------- |
| CLAUDE.md   | `./CLAUDE.md`       | Auto at startup    | Project context                           |
| Rules       | `.claude/rules/`    | Auto (path-scoped) | Modular, glob-matched                     |
| Agents      | `.claude/agents/`   | `@name`            | Conversational persona; `isolation`/`cwd` |
| Agent Teams | settings.json (env) | Natural language   | Multi-session parallel _(experimental)_   |
| Commands    | `.claude/commands/` | `/name`            | One-shot template (merged into Skills)    |
| Skills      | `.claude/skills/`   | Automatic          | Composable knowledge                      |

Notes:
Claude Code has the richest customization ecosystem among the 4 tools — it's the only one supporting all the feature types listed above. **Sonnet 5** (released June 30, 2026) is now the default model in Claude Code for Pro/Team/Enterprise seats; **Opus 4.8** is the flagship Opus-class model and unlocks the `xhigh` effort tier; default effort is `high` on Opus 4.8 / Sonnet 5 (was `medium`). Long-running tasks gained the **EndConversation** tool and **progress heartbeats**. Native macOS/Linux builds replace the standalone `Glob`/`Grep` tools with embedded `bfs`/`ugrep` invoked via the Bash tool. Windows users can opt into the PowerShell tool preview (`CLAUDE_CODE_USE_POWERSHELL_TOOL=1`); Git Bash is no longer required.

##==##

<!-- .slide: -->

# **Claude Code: Feature Summary**

| Feature       | Location          | Invocation          | Key Trait                                  |
| ------------- | ----------------- | ------------------- | ------------------------------------------ |
| Hooks         | `settings.json`   | Auto (event-driven) | 10 events incl. `CwdChanged`, `PreCompact` |
| Plugins       | `.claude-plugin/` | `/plugin:command`   | Bundled distribution; `userConfig`, `bin/` |
| Config        | `settings.json`   | At startup          | Permissions, sandbox, TUI, deep-links      |
| Effort levels | `/effort` slider  | Per-turn            | low → medium → high → **xhigh** (Opus 4.8+) |

Notes:
Claude Code has the richest customization ecosystem among the 4 tools — it's the only one supporting all the feature types listed above. **Sonnet 5** (released June 30, 2026) is now the default model in Claude Code for Pro/Team/Enterprise seats; **Opus 4.8** is the flagship Opus-class model and unlocks the `xhigh` effort tier; default effort is `high` on Opus 4.8 / Sonnet 5 (was `medium`). Long-running tasks gained the **EndConversation** tool and **progress heartbeats**. Native macOS/Linux builds replace the standalone `Glob`/`Grep` tools with embedded `bfs`/`ugrep` invoked via the Bash tool. Windows users can opt into the PowerShell tool preview (`CLAUDE_CODE_USE_POWERSHELL_TOOL=1`); Git Bash is no longer required.

##==##

<!-- .slide: -->

# Claude Code: When to Use What

## Choosing the Right Feature

| Scenario                             | Use This           | Why                                                    |
| ------------------------------------ | ------------------ | ------------------------------------------------------ |
| Need path-scoped coding conventions  | **Rules**          | `.claude/rules/` with glob `paths` frontmatter         |
| Need domain-expert AI guidance       | **Custom Agent**   | Isolated context, restricted tools, `@name`            |
| Need parallel work with coordination | **Agent Team**     | Multiple sessions, shared tasks, inter-agent messaging |
| Need reusable prompt for a task      | **Custom Command** | One-shot `/command` in `.claude/commands/`             |

**CLAUDE.md** = always-on project context | **Rules** = modular, path-scoped instructions

**Agents** = single isolated worker | **Agent Teams** = coordinated parallel workers

Notes:
Claude Code supports all 6 feature types — the richest ecosystem of the 4 tools. The key question: human invocation (agent/command) or automatic (hook)? Reusable knowledge (skill) or complete persona (agent)? Distribution package (plugin) or access control (config)?

##==##

<!-- .slide: -->

# Claude Code: When to Use What

## Choosing the Right Feature

| Scenario                             | Use This          | Why                                             |
| ------------------------------------ | ----------------- | ----------------------------------------------- |
| Need shared knowledge across agents  | **Agent Skill**   | Composable, auto-loaded from `.claude/skills/`  |
| Need automatic validation on edits   | **Hook**          | Pre/Post triggers defined in `settings.json`    |
| Need to bundle & distribute tooling  | **Plugin**        | Bundles agents+commands in `.claude/plugins/`   |
| Need to control permissions/behavior | **Configuration** | `settings.json` for permissions, profiles, deny |

<br>

**Skills** = composable knowledge | **Hooks** = automatic enforcement

Notes:
Claude Code supports all 6 feature types — the richest ecosystem of the 4 tools. The key question: human invocation (agent/command) or automatic (hook)? Reusable knowledge (skill) or complete persona (agent)? Distribution package (plugin) or access control (config)?
