<!-- .slide: class="transition" -->

# Gemini CLI en profondeur

## Fonctionnalités CLI, agents, commandes, skills, hooks, extensions et configuration

> ⚠️ **Retiré en mai 2026** — Gemini CLI a été retiré par Google en mai 2026 et l'accès grand public a pris fin le **18 juin 2026**. Son successeur est l'**Antigravity CLI**, écrit en Go (dévoilé à Google I/O 2026, orchestration multi-agents asynchrone). Les slides ci-dessous sont conservées à titre historique et comparatif ; les commandes et endpoints peuvent ne plus fonctionner.

Notes:
Cette partie est conservée uniquement à titre historique et comparatif. Gemini CLI a été retiré en mai 2026 (fin de l'accès grand public le 18 juin 2026) et remplacé par l'Antigravity CLI de Google. Présentez-la comme « comment Gemini CLI fonctionnait », et non comme un outil disponible aujourd'hui — orientez les apprenants vers l'Antigravity CLI pour l'agent terminal actuel de Google.

##==##

<!-- .slide: -->

# **Gemini CLI : aperçu de la CLI**

> ⚠️ **Retiré en mai 2026** — conservé pour référence. Successeur : **Antigravity CLI**.

| Fonctionnalité       | Comment     | Détails                                                |
| -------------------- | ----------- | ------------------------------------------------------ |
| Inclure des fichiers | symbole `@` | `@src/api/` - ajout au contexte                        |
| Commandes slash      | préfixe `/` | `/help`, `/compress`, `/memory`, `/model`, `/settings` |
| Mode shell           | bascule `!` | Accès shell persistant                                 |
| Rembobiner           | `Esc Esc`   | Parcourir et rembobiner les interactions               |
| Basculer le thinking | `Tab`       | Extended thinking activé/désactivé                     |
| Modes de permission  | `Shift+Tab` | Faire défiler les modes                                |
| Reprise de session   | `/resume`   | Continuer la session précédente                        |
| Google Search        | Intégré     | Ancrage factuel avec citations                         |

<br>

**📚 Documentation** : https://geminicli.com/docs/

Notes:
⚠️ Retiré en mai 2026 (fin de l'accès grand public le 18 juin 2026) ; remplacé par l'Antigravity CLI. Le contenu ci-dessous est conservé pour référence. La fonctionnalité unique de Gemini CLI est l'ancrage Google Search, pour une exactitude factuelle avec citations. La fonction de rembobinage (Esc Esc) parcourt les interactions précédentes. GEMINI.md remonte les répertoires parents jusqu'à la racine .git.

##==##

<!-- .slide: class="with-code" -->

# Gemini CLI : GEMINI.md (fichier de contexte)

**Définition** : instructions projet persistantes chargées au démarrage de la session. Gemini lit tous les fichiers GEMINI.md, du répertoire de travail jusqu'à la racine git.

| Niveau       | Fichier               | Portée                      |
| ------------ | --------------------- | --------------------------- |
| **Global**   | `~/.gemini/GEMINI.md` | Personnel, tous les projets |
| **Projet**   | `./GEMINI.md`         | Tout le projet, via git     |
| **Imbriqué** | `<subdir>/GEMINI.md`  | Spécifique au répertoire    |

**Créer/Mettre à jour** : création manuelle ou `/memory add <text>` pour ajouter

**Commandes mémoire** : `/memory show`, `/memory add`, `/memory refresh`

**Imports** : syntaxe `@file.md` pour des imports modulaires

**📚 Documentation** : https://geminicli.com/docs/cli/tutorials/memory-management/

Notes:
GEMINI.md repose sur une hiérarchie de fichiers - tous les fichiers du répertoire de travail jusqu'à la racine .git sont concaténés. Cela permet des instructions spécifiques à un répertoire dans les monorepos. Les commandes /memory gèrent le GEMINI.md global. Contrairement au /init de Claude Code, Gemini CLI ne génère pas automatiquement GEMINI.md depuis l'analyse du projet.

##==##

<!-- .slide: class="with-code" -->

# Gemini CLI : agents personnalisés _(expérimental)_

**Définition** : agents spécialistes indépendants, avec boucle de contexte séparée, outils ciblés et prompt système personnalisé

| Champ         | Requis | Description                                   |
| ------------- | ------ | --------------------------------------------- |
| `name`        | Oui    | Slug unique (minuscules, tirets, underscores) |
| `description` | Oui    | Indice de routage pour l'auto-délégation      |
| `kind`        | Non    | `local` (défaut) ou `remote`                  |
| `tools`       | Non    | Outils autorisés (jokers : `*`, `mcp_*`)      |

**📚 Documentation** : https://geminicli.com/docs/core/subagents/

Notes:
Les sous-agents sont expérimentaux dans Gemini CLI. Ils tournent dans des boucles de contexte isolées, ce qui évite de gonfler l'historique. Une protection contre la récursion empêche un sous-agent d'appeler d'autres sous-agents. Le champ tools accepte des jokers pour un cadrage souple des outils. Les agents intégrés incluent codebase_investigator et browser_agent.

##==##

<!-- .slide: class="with-code" -->

# Gemini CLI : agents personnalisés _(expérimental)_

**Définition** : agents spécialistes indépendants, avec boucle de contexte séparée, outils ciblés et prompt système personnalisé

**Emplacement** : `.gemini/agents/*.md` (projet) · `~/.gemini/agents/*.md` (personnel)

**Invocation** : `@agent-name prompt` ou délégation automatique

**Activer** : `"experimental": { "enableAgents": true }` dans settings.json

**📚 Documentation** : https://geminicli.com/docs/core/subagents/

Notes:
Les sous-agents sont expérimentaux dans Gemini CLI. Ils tournent dans des boucles de contexte isolées, ce qui évite de gonfler l'historique. Une protection contre la récursion empêche un sous-agent d'appeler d'autres sous-agents. Le champ tools accepte des jokers pour un cadrage souple des outils. Les agents intégrés incluent codebase_investigator et browser_agent.

##==##

<!-- .slide: class="with-code" -->

# Gemini CLI : agents personnalisés _(expérimental)_

**Définition** : agents spécialistes indépendants, avec boucle de contexte séparée, outils ciblés et prompt système personnalisé

| Champ          | Requis | Description                       |
| -------------- | ------ | --------------------------------- |
| `model`        | Non    | Surcharge du modèle               |
| `temperature`  | Non    | 0.0-2.0 (défaut 1)                |
| `max_turns`    | Non    | Limite de tours (défaut 30)       |
| `timeout_mins` | Non    | Temps d'exécution max (défaut 10) |

**📚 Documentation** : https://geminicli.com/docs/core/subagents/

Notes:
Les sous-agents sont expérimentaux dans Gemini CLI. Ils tournent dans des boucles de contexte isolées, ce qui évite de gonfler l'historique. Une protection contre la récursion empêche un sous-agent d'appeler d'autres sous-agents. Le champ tools accepte des jokers pour un cadrage souple des outils. Les agents intégrés incluent codebase_investigator et browser_agent.

##==##

<!-- .slide: class="exercice" -->

# Exercices : Gemini CLI en profondeur

## Lab 41

<br>

### 👉 Suivez les **instructions** dans

### <code data-markdown-preview="/labs/lab-41-agentic-tools-deep-dive/README.md">labs/lab-41-agentic-tools-deep-dive/README.md</code>

### 📚 Exercices 1 à 2, section C (Gemini CLI)

Notes:

- Suivez les instructions du README.md du lab pour les étapes détaillées.

##==##

<!-- .slide: class="exercice" -->

# Exercices : Gemini CLI en profondeur

## Lab 41

<br>

### 💡 Consultez la **solution** dans

### <code data-markdown-preview="/labs/lab-41-agentic-tools-deep-dive-solution/README.md">labs/lab-41-agentic-tools-deep-dive-solution/README.md</code>

### 📚 Exercices 1 à 2, section C (Gemini CLI)

Notes:

- Consultez le README.md du lab pour des exemples de solutions.

##==##

<!-- .slide: class="with-code" -->

# Gemini CLI : commandes personnalisées

**Définition** : raccourcis de prompts réutilisables basés sur TOML, pour les workflows fréquents

| Syntaxe       | Objectif               | Exemple                                     |
| ------------- | ---------------------- | ------------------------------------------- |
| `{{args}}`    | Arguments utilisateur  | `/review {{args}}`                          |
| `!{command}`  | Exécution shell inline | `!{git diff --staged}`                      |
| `@{filepath}` | Injection de contenu   | `@{.gemini/references/coding-standards.md}` |

**📚 Documentation** : https://geminicli.com/docs/cli/custom-commands/

Notes:
Gemini CLI utilise TOML pour les commandes, ce qui est unique parmi les 4 outils. La syntaxe !{} exécute des commandes shell inline avant que le prompt n'atteigne le modèle - c'est un prétraitement, pas une exécution par Gemini. Le namespacing par sous-répertoire permet d'organiser des collections de commandes.

##==##

<!-- .slide: class="with-code" -->

# Gemini CLI : commandes personnalisées

**Définition** : raccourcis de prompts réutilisables basés sur TOML, pour les workflows fréquents

**Format de fichier** : TOML (`.toml`) avec les champs `prompt` (requis) et `description` (facultatif)

**Emplacement** : `~/.gemini/commands/` (global) · `.gemini/commands/` (projet, prioritaire)

**Nommage** : chemin du fichier → nom de commande ; les sous-dossiers créent des espaces de noms (`git/commit.toml` → `/git:commit`)

**Invocation** : `/command-name args` · **Recharger** : `/commands reload`

**📚 Documentation** : https://geminicli.com/docs/cli/custom-commands/

Notes:
Gemini CLI utilise TOML pour les commandes, ce qui est unique parmi les 4 outils. La syntaxe !{} exécute des commandes shell inline avant que le prompt n'atteigne le modèle - c'est un prétraitement, pas une exécution par Gemini. Le namespacing par sous-répertoire permet d'organiser des collections de commandes.

##==##

<!-- .slide: class="with-code" -->

# Gemini CLI : Agent Skills

**Définition** : instructions de prompt réutilisables que Gemini charge à la demande. Des consignes détaillées, propres à une tâche, activées selon le contexte

| Commande CLI                          | Objectif                      |
| ------------------------------------- | ----------------------------- |
| `gemini skills list`                  | Lister les skills découverts  |
| `gemini skills install <url>`         | Installer depuis un dépôt git |
| `gemini skills link <path>`           | Lier un skill local (à chaud) |
| `gemini skills enable/disable <name>` | Activer/désactiver un skill   |

Notes:
Gemini CLI offre la CLI de skills la plus riche des 4 outils, avec les commandes install, link et enable/disable. Les skills utilisent la divulgation progressive - seules les métadonnées sont chargées au départ, le contenu complet à l'activation. L'outil intégré activate_skill permet une invocation explicite.

##==##

<!-- .slide: class="with-code" -->

# Gemini CLI : Agent Skills

**Définition** : instructions de prompt réutilisables que Gemini charge à la demande. Des consignes détaillées, propres à une tâche, activées selon le contexte

**Emplacement (priorité)** : `.gemini/skills/` ou `.agents/skills/` (workspace) · `~/.gemini/skills/` (utilisateur) · fournis par une extension

**Activation** : découverte automatique au démarrage ; le modèle appelle l'outil `activate_skill` ; consentement de l'utilisateur demandé avant le chargement

**Registres publics** : [🔗 https://skills.sh](https://skills.sh) - [🔗 https://tessl.io/registry](https://tessl.io/registry)

Notes:
Gemini CLI offre la CLI de skills la plus riche des 4 outils, avec les commandes install, link et enable/disable. Les skills utilisent la divulgation progressive - seules les métadonnées sont chargées au départ, le contenu complet à l'activation. L'outil intégré activate_skill permet une invocation explicite.

##==##

<!-- .slide: class="with-code" -->

# Gemini CLI : Agent Skills

**Définition** : instructions de prompt réutilisables que Gemini charge à la demande. Des consignes détaillées, propres à une tâche, activées selon le contexte

**Structure** :

```
my-skill/
├── SKILL.md           # Instructions (required)
├── templates/         # Templates to fill in
├── examples/          # Example outputs
├── scripts/           # Executable scripts
└── references/        # Reference documentation
```

<br>

**📚 Documentation** : https://geminicli.com/docs/cli/skills/

Notes:
Gemini CLI offre la CLI de skills la plus riche des 4 outils, avec les commandes install, link et enable/disable. Les skills utilisent la divulgation progressive - seules les métadonnées sont chargées au départ, le contenu complet à l'activation. L'outil intégré activate_skill permet une invocation explicite.

##==##

<!-- .slide: class="exercice" -->

# Exercices : Gemini CLI en profondeur

## Lab 41

<br>

### 👉 Suivez les **instructions** dans

### <code data-markdown-preview="/labs/lab-41-agentic-tools-deep-dive/README.md">labs/lab-41-agentic-tools-deep-dive/README.md</code>

### 📚 Exercices 3 à 6, section C (Gemini CLI)

Notes:

- Suivez les instructions du README.md du lab pour les étapes détaillées.

##==##

<!-- .slide: class="exercice" -->

# Exercices : Gemini CLI en profondeur

## Lab 41

<br>

### 💡 Consultez la **solution** dans

### <code data-markdown-preview="/labs/lab-41-agentic-tools-deep-dive-solution/README.md">labs/lab-41-agentic-tools-deep-dive-solution/README.md</code>

### 📚 Exercices 3 à 6, section C (Gemini CLI)

Notes:

- Consultez le README.md du lab pour des exemples de solutions.

##==##

<!-- .slide: class="with-code" -->

# Gemini CLI : Hooks

**Définition** : scripts événementiels qui interceptent et modifient le comportement de la CLI à des points du cycle de vie, via JSON sur stdin/stdout

| Événement                     | Quand il se déclenche       |
| ----------------------------- | --------------------------- |
| `BeforeTool`                  | Avant exécution de l'outil  |
| `AfterTool`                   | Après exécution de l'outil  |
| `BeforeAgent` / `AfterAgent`  | Cycle de vie de l'agent     |
| `BeforeModel` / `AfterModel`  | Cycle de vie de l'appel LLM |
| `SessionStart` / `SessionEnd` | Cycle de vie de la session  |
| `Notification`                | Notifications système       |
| `PreCompress`                 | Avant compression contexte  |

Notes:
Gemini CLI prend en charge 11 types d'événements de hooks - le plus complet des 4 outils. Les hooks communiquent via JSON sur stdin/stdout avec une sortie structurée. La commande gemini hooks migrate convertit les hooks Claude Code au format Gemini. Utilisez BeforeTool pour la validation et AfterTool pour les vérifications après action.

##==##

<!-- .slide: class="with-code" -->

# Gemini CLI : Hooks

**Définition** : scripts événementiels qui interceptent et modifient le comportement de la CLI à des points du cycle de vie, via JSON sur stdin/stdout

**Config** : `settings.json` → clé `hooks` avec `matcher` (regex) et tableau `hooks[]`

**Champs d'un hook** : `type` ("command"), `command` (shell), `timeout` (ms, 60000 par défaut)

**Communication** : JSON stdin/stdout · Codes de sortie : `0` = autoriser, `2` = bloquer

**Champs de sortie** : `decision` ("allow"/"deny"), `reason`, `systemMessage`, `suppressOutput`

**Migrer depuis Claude** : `gemini hooks migrate`

**📚 Documentation** : https://geminicli.com/docs/hooks/

Notes:
Gemini CLI prend en charge 11 types d'événements de hooks - le plus complet des 4 outils. Les hooks communiquent via JSON sur stdin/stdout avec une sortie structurée. La commande gemini hooks migrate convertit les hooks Claude Code au format Gemini. Utilisez BeforeTool pour la validation et AfterTool pour les vérifications après action.

##==##

<!-- .slide: class="exercice" -->

# Exercices : Gemini CLI en profondeur

## Lab 41

<br>

### 👉 Suivez les **instructions** dans

### <code data-markdown-preview="/labs/lab-41-agentic-tools-deep-dive/README.md">labs/lab-41-agentic-tools-deep-dive/README.md</code>

### 📚 Exercice 7, section C (Gemini CLI)

Notes:

- Suivez les instructions du README.md du lab pour les étapes détaillées.

##==##

<!-- .slide: class="exercice" -->

# Exercices : Gemini CLI en profondeur

## Lab 41

<br>

### 💡 Consultez la **solution** dans

### <code data-markdown-preview="/labs/lab-41-agentic-tools-deep-dive-solution/README.md">labs/lab-41-agentic-tools-deep-dive-solution/README.md</code>

### 📚 Exercice 7, section C (Gemini CLI)

Notes:

- Consultez le README.md du lab pour des exemples de solutions.

##==##

<!-- .slide: class="with-code" -->

# Gemini CLI : Extensions

**Définition** : paquets modulaires regroupant serveurs MCP, commandes, hooks, skills, agents, thèmes et policies

| Commande CLI                             | Objectif                       |
| ---------------------------------------- | ------------------------------ |
| `gemini extensions install <source>`     | Depuis GitHub ou en local      |
| `gemini extensions new <path>`           | Générer depuis un template     |
| `gemini extensions list`                 | Voir les extensions installées |
| `gemini extensions validate <path>`      | Valider le manifeste           |
| `gemini extensions config <name>`        | Configurer les réglages        |
| `gemini extensions update <name\|--all>` | Mettre à jour les extensions   |

Notes:
Les extensions sont l'équivalent des plugins chez Gemini CLI. Elles peuvent définir des réglages qui sont demandés à l'utilisateur à l'installation. La galerie inclut des extensions partenaires de Figma, Jira, Stripe et Snyk. Utilisez gemini extensions new pour générer un squelette depuis un template et développer rapidement.

##==##

<!-- .slide: class="with-code" -->

# Gemini CLI : Extensions

**Définition** : paquets modulaires regroupant serveurs MCP, commandes, hooks, skills, agents, thèmes et policies

**Manifeste** : `gemini-extension.json` à la racine de l'extension

**Contenu** : `commands/`, `hooks/`, `skills/`, `agents/`, `policies/`, `themes/`, serveurs MCP

**Galerie** : **557+ extensions** sur geminicli.com/extensions/

**Substitution de variables** : `${extensionPath}`, `${workspacePath}`, `${/}`

**📚 Documentation** : https://geminicli.com/docs/extensions/

Notes:
Les extensions sont l'équivalent des plugins chez Gemini CLI. Elles peuvent définir des réglages qui sont demandés à l'utilisateur à l'installation. La galerie inclut des extensions partenaires de Figma, Jira, Stripe et Snyk. Utilisez gemini extensions new pour générer un squelette depuis un template et développer rapidement.

##==##

<!-- .slide: class="exercice" -->

# Exercices : Gemini CLI en profondeur

## Lab 41

<br>

### 👉 Suivez les **instructions** dans

### <code data-markdown-preview="/labs/lab-41-agentic-tools-deep-dive/README.md">labs/lab-41-agentic-tools-deep-dive/README.md</code>

### 📚 Exercice 8, section C (Gemini CLI)

Notes:

- Suivez les instructions du README.md du lab pour les étapes détaillées.

##==##

<!-- .slide: class="exercice" -->

# Exercices : Gemini CLI en profondeur

## Lab 41

<br>

### 💡 Consultez la **solution** dans

### <code data-markdown-preview="/labs/lab-41-agentic-tools-deep-dive-solution/README.md">labs/lab-41-agentic-tools-deep-dive-solution/README.md</code>

### 📚 Exercice 8, section C (Gemini CLI)

Notes:

- Consultez le README.md du lab pour des exemples de solutions.

##==##

<!-- .slide: -->

# Gemini CLI : Configuration

**Définition** : réglages au niveau projet et utilisateur, qui contrôlent le comportement, les permissions et les intégrations de Gemini

| Catégorie | Réglages                         |
| --------- | -------------------------------- |
| Modèle    | sélection du modèle, routage     |
| Sécurité  | sandbox, restrictions d'outils   |
| Hooks     | événements BeforeTool, AfterTool |
| Agents    | surcharges, enableAgents         |
| Skills    | activer/désactiver               |
| UI        | thèmes, lecteur d'écran          |

Notes:
La configuration de Gemini CLI est répartie entre settings.json pour le comportement à l'exécution et GEMINI.md pour les instructions projet. Dans la hiérarchie des réglages, le workspace surcharge l'utilisateur. Utilisez /settings pour une configuration interactive, ou éditez directement le JSON.

##==##

<!-- .slide: -->

# Gemini CLI : Configuration

**Définition** : réglages au niveau projet et utilisateur, qui contrôlent le comportement, les permissions et les intégrations de Gemini

**Emplacement** : `.gemini/settings.json` (projet) · `~/.gemini/settings.json` (utilisateur)

**Instructions projet** : `GEMINI.md` (remonte les répertoires parents jusqu'à la racine .git)

**Mémoire** : `/memory show`, `/memory add`, `/memory refresh`

**Changer de modèle** : `gemini --model`, variable d'env `GEMINI_MODEL`, commande `/model`

**📚 Documentation** : https://geminicli.com/docs/configuration/settings/

Notes:
La configuration de Gemini CLI est répartie entre settings.json pour le comportement à l'exécution et GEMINI.md pour les instructions projet. Dans la hiérarchie des réglages, le workspace surcharge l'utilisateur. Utilisez /settings pour une configuration interactive, ou éditez directement le JSON.

##==##

<!-- .slide: class="exercice" -->

# Exercices : Gemini CLI en profondeur

## Lab 41

<br>

### 👉 Suivez les **instructions** dans

### <code data-markdown-preview="/labs/lab-41-agentic-tools-deep-dive/README.md">labs/lab-41-agentic-tools-deep-dive/README.md</code>

### 📚 Exercice 9 (facultatif), section C (Gemini CLI)

Notes:

- Suivez les instructions du README.md du lab pour les étapes détaillées.

##==##

<!-- .slide: class="exercice" -->

# Exercices : Gemini CLI en profondeur

## Lab 41

<br>

### 💡 Consultez la **solution** dans

### <code data-markdown-preview="/labs/lab-41-agentic-tools-deep-dive-solution/README.md">labs/lab-41-agentic-tools-deep-dive-solution/README.md</code>

### 📚 Exercice 9 (facultatif), section C (Gemini CLI)

Notes:

- Consultez le README.md du lab pour des exemples de solutions.

##==##

<!-- .slide: -->

# **Gemini CLI : synthèse des fonctionnalités**

<br>

| Fonction   | Emplacement         | Invocation             | Trait clé                     |
| ---------- | ------------------- | ---------------------- | ----------------------------- |
| Agents     | `.gemini/agents/`   | `@name`, auto          | Expérimental, contexte isolé  |
| Commandes  | `.gemini/commands/` | `/name`                | TOML avec syntaxe shell `!{}` |
| Skills     | `.gemini/skills/`   | Auto, `activate_skill` | CLI riche (`install`, `link`) |
| Hooks      | `settings.json`     | Auto (11 événements)   | Protocole JSON stdin/stdout   |
| Extensions | `gemini extensions` | Installation CLI       | Galerie 557+, scaffolding     |
| Config     | `settings.json`     | `/settings`            | Configuration interactive     |

Notes:
Les forces propres à Gemini CLI : le plus de types d'événements de hooks (11), la CLI de skills la plus riche (install/link), l'ancrage Google Search, une galerie d'extensions de 557+ paquets, et la commande de scaffolding gemini extensions new.

##==##

<!-- .slide: -->

# Gemini CLI : quand utiliser quoi

## Choisir la bonne fonctionnalité

| Scénario                              | Utilisez                        | Pourquoi                                      |
| ------------------------------------- | ------------------------------- | --------------------------------------------- |
| Besoin d'expertise IA sur un domaine  | **Agent personnalisé** _(exp.)_ | Agent spécialiste dans `.gemini/agents/`      |
| Besoin d'un prompt réutilisable       | **Commande personnalisée**      | Modèle one-shot dans `.gemini/commands/`      |
| Contrôler permissions et comportement | **Configuration**               | `settings.json` : réglages, profils, policies |

<br>

**Agents** _(expérimental)_ = personas spécialistes | **Commandes** = modèles mono-tâche

Notes:
Les agents personnalisés de Gemini CLI sont encore expérimentaux. Les extensions fournissent des intégrations développées par Google (Web Search, Code Execution, etc.) plutôt que des paquets définis par l'utilisateur. Le settings.json contrôle à la fois les hooks et la configuration générale — contrairement aux autres outils qui séparent ces deux aspects.

##==##

<!-- .slide: -->

# Gemini CLI : quand utiliser quoi

## Choisir la bonne fonctionnalité

| Scénario                                | Utilisez        | Pourquoi                                          |
| --------------------------------------- | --------------- | ------------------------------------------------- |
| Partager des connaissances entre agents | **Agent Skill** | Composable, auto-chargé depuis `.gemini/skills/`  |
| Valider automatiquement les éditions    | **Hook**        | Déclencheurs pré/post dans `settings.json`        |
| Regrouper et distribuer de l'outillage  | **Extension**   | `gemini extensions` regroupe les capacités Google |

<br>

**Skills** = connaissances composables | **Hooks** = application automatique | **Extensions** = intégrations regroupées

Notes:
Les agents personnalisés de Gemini CLI sont encore expérimentaux. Les extensions fournissent des intégrations développées par Google (Web Search, Code Execution, etc.) plutôt que des paquets définis par l'utilisateur. Le settings.json contrôle à la fois les hooks et la configuration générale — contrairement aux autres outils qui séparent ces deux aspects.
