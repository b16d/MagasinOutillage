<!-- .slide: class="transition" -->

# Module 4: Assessment and Recap

##==##

<!-- .slide -->

# Learning Objectives Review

<br>

### What We Covered

By completing Module 4, you should now be able to:

- **Master** the CLI features of Claude Code, GitHub Copilot, Codex CLI, Gemini CLI, and OpenCode
- **Create** custom agents and custom commands/prompts for your team's workflows
- **Configure** agent skills, hooks, plugins/extensions, and configuration files
- **Choose** the right feature type (agent, command, skill, hook, plugin) for each use case

### Skills You've Practiced

<!-- .element: class="sm-padding-top" -->

- **Lab 41**: Created custom agents, commands, skills, hooks, plugins, and configuration files
- Installed and evaluated community skills from public registries (Tessl)

Notes:
This module covered the 6 key customization features across 4 agentic tools. The decision framework helps developers choose the right abstraction for each team need.

##==##

<!-- .slide: -->

# **Knowledge Check**

## **Question 1: Feature Selection**

<br>

### You need to enforce that every file edit passes a linting check automatically, without the developer invoking anything. Which feature type should you use?

**A)** Custom Agent  
**B)** Hook (via custom plugin with pre/post tool use)  
**C)** Custom Command  
**D)** Agent Skill

<details>
<summary>Answer</summary>
<strong>B) Hook (via custom plugin with pre/post tool use)</strong> - Hooks trigger automatically on tool actions (pre/post tool use) without requiring user invocation. Agents and commands require explicit invocation (<code>@name</code> or <code>/name</code>), and skills provide knowledge rather than enforcement.
</details>

Notes:
This question tests the core decision framework concept: hooks are for automatic enforcement, agents/commands are for on-demand use. Understanding this distinction is fundamental to proper feature selection.

##==##

<!-- .slide: -->

# **Knowledge Check**

## **Question 2: Persistent Expertise**

<br>

### Your team wants an AI that acts as a dedicated security reviewer — maintaining domain expertise and conversation context across a full review session. Which feature type is most appropriate?

**A)** Hook  
**B)** Agent Skill  
**C)** Custom Agent  
**D)** Custom Command

<details>
<summary>Answer</summary>
<strong>C) Custom Agent</strong> - Custom agents provide a persistent, isolated conversational persona with specialized focus and tools. Hooks enforce rules automatically but don't hold a conversation. Skills provide reusable knowledge but not an ongoing persona. Commands are one-shot templates that return a result and exit.
</details>

Notes:
This question tests the agent vs. command vs. skill distinction in a tool-agnostic way. The key signal is "maintaining context across a session" — that is the agent's defining characteristic. Hooks and skills lack the conversational continuity.

##==##

<!-- .slide: -->

# **Knowledge Check**

## **Question 3: Context Scoping**

<br>

### Your monorepo has frontend and backend directories with different coding standards. You want the AI to automatically follow the right standards per directory without loading everything into the global context. Which approach should you use?

**A)** Add all standards to the root project context file  
**B)** Path-scoped instruction files that activate based on the working directory  
**C)** A custom agent per directory, invoked explicitly  
**D)** Hooks that validate code after each edit

<details>
<summary>Answer</summary>
<strong>B) Path-scoped instruction files that activate based on the working directory</strong> - Path-scoped files load only when the AI is working in the matching directory, keeping the global context lean. The root project file is always loaded regardless of directory. Agents require explicit invocation. Hooks enforce rules after the fact but don't guide the AI during generation.
</details>

Notes:
This question tests understanding of instruction hierarchy and context efficiency — a fundamental concept common to all agentic tools. The scenario deliberately includes hooks as a distractor to reinforce the guidance vs. enforcement distinction introduced in Q1.

##==##

<!-- .slide: -->

# **Knowledge Check**

## **Question 4: Cross-Tool Portability**

<br>

### Your team wants to document a reusable code-review procedure that works for every developer, regardless of which AI coding tool they use. Which feature type best supports this?

**A)** Custom Command  
**B)** Plugin / Extension  
**C)** Hook  
**D)** Agent Skill (SKILL.md)

<details>
<summary>Answer</summary>
<strong>D) Agent Skill (SKILL.md)</strong> - The SKILL.md format is a shared cross-platform standard recognized by all major agentic tools. Skills can be copied unchanged between tool-specific folders and shared via public registries. Custom commands use tool-specific formats. Plugins are platform-specific distribution packages. Hooks are enforcement mechanisms, not reusable knowledge.
</details>

Notes:
This question highlights skills as the most portable customization primitive — a key takeaway from the module. Public registries (skills.sh, tessl.io) further reinforce that portability. Remind learners that "tool-agnostic" is the defining characteristic that makes skills valuable for team-wide adoption.

##==##

<!-- .slide: -->

# **Resources**

## **Further Learning**

<br>

### **Documentation**

- [Claude Code](https://docs.anthropic.com/en/docs/claude-code) - Agents, commands, skills, hooks, plugins
- [GitHub Copilot](https://docs.github.com/en/copilot) - Agents, prompts, instructions, hooks, plugins
- [Gemini CLI](https://geminicli.com/docs/) - Agents, commands, skills, hooks, extensions _(retired May 2026 → Antigravity CLI)_
- [Codex CLI](https://developers.openai.com/codex/) - Agents, AGENTS.md, skills, profiles, config
- [OpenCode](https://opencode.ai/docs/) - Agents, commands, skills, modes, permissions, MCP
- [Tessl Registry](https://tessl.io/registry) - Public skill registry with quality evaluation
- [skills.sh](https://skills.sh/) - Open agent skills ecosystem (600K+ skills as of mid-2026)

### **Lab Solutions**

- Review `labs/lab-41-agentic-tools-deep-dive-solution/`

Notes:
Use the photo-gallery-fullstack config folders as reference implementations for all 4 platforms. Public registries allow discovering and installing community-created skills across platforms.
