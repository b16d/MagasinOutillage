<!-- .slide: class="transition" -->

# Gemini CLI Deep Dive

## CLI Features, Agents, Commands, Skills, Hooks, Extensions & Configuration

> ⚠️ **Retired May 2026** — Gemini CLI was retired by Google in May 2026 and consumer access ended **June 18, 2026**. Its successor is the Go-based **Antigravity CLI** (unveiled at Google I/O 2026, async multi-agent orchestration). The slides below are preserved for historical/comparative reference; the commands and endpoints may no longer work.

Notes:
This track is kept for historical and comparative context only. Gemini CLI was retired in May 2026 (consumer access ended June 18, 2026) and superseded by Google's Antigravity CLI. Present it as "how Gemini CLI worked," not as a currently available tool — point learners to Antigravity CLI for Google's current terminal agent story.

##==##

<!-- .slide: -->

# **Gemini CLI: CLI Overview**

> ⚠️ **Retired May 2026** — kept for reference. Successor: **Antigravity CLI**.

| Feature          | How         | Details                                                |
| ---------------- | ----------- | ------------------------------------------------------ |
| Include files    | `@` symbol  | `@src/api/` - add to context                           |
| Slash commands   | `/` prefix  | `/help`, `/compress`, `/memory`, `/model`, `/settings` |
| Shell mode       | `!` toggle  | Persistent shell access                                |
| Rewind           | `Esc Esc`   | Browse and rewind interactions                         |
| Toggle thinking  | `Tab`       | Extended thinking on/off                               |
| Permission modes | `Shift+Tab` | Cycle through modes                                    |
| Session resume   | `/resume`   | Continue previous session                              |
| Google Search    | Built-in    | Factual grounding with citations                       |

<br>

**📚 Documentation**: https://geminicli.com/docs/

Notes:
⚠️ Retired May 2026 (consumer access ended June 18, 2026); succeeded by Antigravity CLI. Content below is preserved for reference. Gemini CLI's unique feature is Google Search grounding for factual accuracy with citations. The rewind feature (Esc Esc) navigates previous interactions. GEMINI.md follows parent directories up to .git root.

##==##

<!-- .slide: class="with-code" -->

# Gemini CLI: GEMINI.md (Context File)

**Definition**: Persistent project instructions loaded at session start. Gemini reads all GEMINI.md files from the working directory up to the git root.

| Level       | File                  | Scope                  |
| ----------- | --------------------- | ---------------------- |
| **Global**  | `~/.gemini/GEMINI.md` | Personal, all projects |
| **Project** | `./GEMINI.md`         | Project-wide, via git  |
| **Nested**  | `<subdir>/GEMINI.md`  | Directory-specific     |

**Create/Update**: Manual creation or `/memory add <text>` to append

**Memory commands**: `/memory show`, `/memory add`, `/memory refresh`

**Imports**: Use `@file.md` syntax for modular imports

**📚 Documentation**: https://geminicli.com/docs/cli/tutorials/memory-management/

Notes:
GEMINI.md uses a hierarchical file system - all files from working directory up to .git root are concatenated. This enables directory-specific instructions in monorepos. The /memory commands manage the global GEMINI.md. Unlike Claude Code's /init, Gemini CLI does not auto-generate GEMINI.md from project analysis.

##==##

<!-- .slide: class="with-code" -->

# Gemini CLI: Custom Agents _(Experimental)_

**Definition**: Independent specialist agents with separate context loops, focused tools, and custom system prompts

| Field         | Required | Description                                   |
| ------------- | -------- | --------------------------------------------- |
| `name`        | Yes      | Unique slug (lowercase, hyphens, underscores) |
| `description` | Yes      | Routing hint for auto-delegation              |
| `kind`        | No       | `local` (default) or `remote`                 |
| `tools`       | No       | Permitted tools (wildcards: `*`, `mcp_*`)     |

**📚 Documentation**: https://geminicli.com/docs/core/subagents/

Notes:
Sub-agents are experimental in Gemini CLI. They run in isolated context loops preventing history bloat. Recursion protection prevents sub-agents from calling other sub-agents. The tools field supports wildcards for flexible tool scoping. Built-in agents include codebase_investigator, browser_agent.

##==##

<!-- .slide: class="with-code" -->

# Gemini CLI: Custom Agents _(Experimental)_

**Definition**: Independent specialist agents with separate context loops, focused tools, and custom system prompts

**Location**: `.gemini/agents/*.md` (project) · `~/.gemini/agents/*.md` (personal)

**Invocation**: `@agent-name prompt` or automatic delegation

**Enable**: `"experimental": { "enableAgents": true }` in settings.json

**📚 Documentation**: https://geminicli.com/docs/core/subagents/

Notes:
Sub-agents are experimental in Gemini CLI. They run in isolated context loops preventing history bloat. Recursion protection prevents sub-agents from calling other sub-agents. The tools field supports wildcards for flexible tool scoping. Built-in agents include codebase_investigator, browser_agent.

##==##

<!-- .slide: class="with-code" -->

# Gemini CLI: Custom Agents _(Experimental)_

**Definition**: Independent specialist agents with separate context loops, focused tools, and custom system prompts

| Field          | Required | Description                     |
| -------------- | -------- | ------------------------------- |
| `model`        | No       | Model override                  |
| `temperature`  | No       | 0.0-2.0 (default 1)             |
| `max_turns`    | No       | Turn limit (default 30)         |
| `timeout_mins` | No       | Max execution time (default 10) |

**📚 Documentation**: https://geminicli.com/docs/core/subagents/

Notes:
Sub-agents are experimental in Gemini CLI. They run in isolated context loops preventing history bloat. Recursion protection prevents sub-agents from calling other sub-agents. The tools field supports wildcards for flexible tool scoping. Built-in agents include codebase_investigator, browser_agent.

##==##

<!-- .slide: class="exercice" -->

# Exercises: Gemini CLI Deep Dive

## Lab 41

<br>

### 👉 Follow **instructions** in

### <code data-markdown-preview="/labs/lab-41-agentic-tools-deep-dive/README.md">labs/lab-41-agentic-tools-deep-dive/README.md</code>

### 📚 Exercises 1 to 2, Section C (Gemini CLI)

Notes:

- Follow the instructions in the lab README.md for detailed steps.

##==##

<!-- .slide: class="exercice" -->

# Exercises: Gemini CLI Deep Dive

## Lab 41

<br>

### 💡 Read **solution** at

### <code data-markdown-preview="/labs/lab-41-agentic-tools-deep-dive-solution/README.md">labs/lab-41-agentic-tools-deep-dive-solution/README.md</code>

### 📚 Exercises 1 to 2, Section C (Gemini CLI)

Notes:

- Read the lab README.md for example of solutions.

##==##

<!-- .slide: class="with-code" -->

# Gemini CLI: Custom Commands

**Definition**: Reusable TOML-based prompt shortcuts for frequently used workflows

| Syntax        | Purpose                | Example                                     |
| ------------- | ---------------------- | ------------------------------------------- |
| `{{args}}`    | User arguments         | `/review {{args}}`                          |
| `!{command}`  | Inline shell execution | `!{git diff --staged}`                      |
| `@{filepath}` | File content injection | `@{.gemini/references/coding-standards.md}` |

**📚 Documentation**: https://geminicli.com/docs/cli/custom-commands/

Notes:
Gemini CLI uses TOML for commands, unique among the 4 tools. The !{} syntax executes shell commands inline before the prompt reaches the model - this is preprocessing, not something Gemini executes. Subdirectory namespacing allows organized command collections.

##==##

<!-- .slide: class="with-code" -->

# Gemini CLI: Custom Commands

**Definition**: Reusable TOML-based prompt shortcuts for frequently used workflows

**File format**: TOML (`.toml`) with `prompt` (required) and `description` (optional) fields

**Location**: `~/.gemini/commands/` (global) · `.gemini/commands/` (project, overrides global)

**Naming**: File path → command name; subdirs create namespaces (`git/commit.toml` → `/git:commit`)

**Invocation**: `/command-name args` · **Reload**: `/commands reload`

**📚 Documentation**: https://geminicli.com/docs/cli/custom-commands/

Notes:
Gemini CLI uses TOML for commands, unique among the 4 tools. The !{} syntax executes shell commands inline before the prompt reaches the model - this is preprocessing, not something Gemini executes. Subdirectory namespacing allows organized command collections.

##==##

<!-- .slide: class="with-code" -->

# Gemini CLI: Agent Skills

**Definition**: Reusable prompt instructions that Gemini loads on demand. Detailed, task-specific guidance that activates contextually

| CLI Command                           | Purpose                         |
| ------------------------------------- | ------------------------------- |
| `gemini skills list`                  | List discovered skills          |
| `gemini skills install <url>`         | Install from git repo           |
| `gemini skills link <path>`           | Link local skill (live updates) |
| `gemini skills enable/disable <name>` | Toggle skill                    |

Notes:
Gemini CLI has the richest skills CLI among the 4 tools with install, link, enable/disable commands. Skills use progressive disclosure - only metadata loads initially, full content on activation. The activate_skill built-in tool enables explicit invocation.

##==##

<!-- .slide: class="with-code" -->

# Gemini CLI: Agent Skills

**Definition**: Reusable prompt instructions that Gemini loads on demand. Detailed, task-specific guidance that activates contextually

**Location (priority)**: `.gemini/skills/` or `.agents/skills/` (workspace) · `~/.gemini/skills/` (user) · extension-bundled

**Activation**: Auto-discovered at session start; model calls `activate_skill` tool; user consent prompt before loading

**Public Registries**: [🔗 https://skills.sh](https://skills.sh) - [🔗 https://tessl.io/registry](https://tessl.io/registry)

Notes:
Gemini CLI has the richest skills CLI among the 4 tools with install, link, enable/disable commands. Skills use progressive disclosure - only metadata loads initially, full content on activation. The activate_skill built-in tool enables explicit invocation.

##==##

<!-- .slide: class="with-code" -->

# Gemini CLI: Agent Skills

**Definition**: Reusable prompt instructions that Gemini loads on demand. Detailed, task-specific guidance that activates contextually

**Structure**:

```
my-skill/
├── SKILL.md           # Instructions (required)
├── templates/         # Templates to fill in
├── examples/          # Example outputs
├── scripts/           # Executable scripts
└── references/        # Reference documentation
```

<br>

**📚 Documentation**: https://geminicli.com/docs/cli/skills/

Notes:
Gemini CLI has the richest skills CLI among the 4 tools with install, link, enable/disable commands. Skills use progressive disclosure - only metadata loads initially, full content on activation. The activate_skill built-in tool enables explicit invocation.

##==##

<!-- .slide: class="exercice" -->

# Exercises: Gemini CLI Deep Dive

## Lab 41

<br>

### 👉 Follow **instructions** in

### <code data-markdown-preview="/labs/lab-41-agentic-tools-deep-dive/README.md">labs/lab-41-agentic-tools-deep-dive/README.md</code>

### 📚 Exercises 3 to 6, Section C (Gemini CLI)

Notes:

- Follow the instructions in the lab README.md for detailed steps.

##==##

<!-- .slide: class="exercice" -->

# Exercises: Gemini CLI Deep Dive

## Lab 41

<br>

### 💡 Read **solution** at

### <code data-markdown-preview="/labs/lab-41-agentic-tools-deep-dive-solution/README.md">labs/lab-41-agentic-tools-deep-dive-solution/README.md</code>

### 📚 Exercises 3 to 6, Section C (Gemini CLI)

Notes:

- Read the lab README.md for example of solutions.

##==##

<!-- .slide: class="with-code" -->

# Gemini CLI: Hooks

**Definition**: Event-driven scripts intercepting and modifying CLI behavior at lifecycle points via JSON over stdin/stdout

| Event                         | When it fires              |
| ----------------------------- | -------------------------- |
| `BeforeTool`                  | Before tool execution      |
| `AfterTool`                   | After tool execution       |
| `BeforeAgent` / `AfterAgent`  | Agent lifecycle            |
| `BeforeModel` / `AfterModel`  | Model call lifecycle       |
| `SessionStart` / `SessionEnd` | Session lifecycle          |
| `Notification`                | System notifications       |
| `PreCompress`                 | Before context compression |

Notes:
Gemini CLI supports 11 hook event types - the most comprehensive among the 4 tools. Hooks communicate via JSON stdin/stdout with structured output. The gemini hooks migrate command converts Claude Code hooks to Gemini format. Use BeforeTool for validation, AfterTool for post-action checks.

##==##

<!-- .slide: class="with-code" -->

# Gemini CLI: Hooks

**Definition**: Event-driven scripts intercepting and modifying CLI behavior at lifecycle points via JSON over stdin/stdout

**Config**: `settings.json` → `hooks` key with `matcher` (regex) and `hooks[]` array

**Hook fields**: `type` ("command"), `command` (shell), `timeout` (ms, default 60000)

**Communication**: JSON stdin/stdout · Exit codes: `0` = allow, `2` = block

**Output fields**: `decision` ("allow"/"deny"), `reason`, `systemMessage`, `suppressOutput`

**Migrate from Claude**: `gemini hooks migrate`

**📚 Documentation**: https://geminicli.com/docs/hooks/

Notes:
Gemini CLI supports 11 hook event types - the most comprehensive among the 4 tools. Hooks communicate via JSON stdin/stdout with structured output. The gemini hooks migrate command converts Claude Code hooks to Gemini format. Use BeforeTool for validation, AfterTool for post-action checks.

##==##

<!-- .slide: class="exercice" -->

# Exercises: Gemini CLI Deep Dive

## Lab 41

<br>

### 👉 Follow **instructions** in

### <code data-markdown-preview="/labs/lab-41-agentic-tools-deep-dive/README.md">labs/lab-41-agentic-tools-deep-dive/README.md</code>

### 📚 Exercise 7, Section C (Gemini CLI)

Notes:

- Follow the instructions in the lab README.md for detailed steps.

##==##

<!-- .slide: class="exercice" -->

# Exercises: Gemini CLI Deep Dive

## Lab 41

<br>

### 💡 Read **solution** at

### <code data-markdown-preview="/labs/lab-41-agentic-tools-deep-dive-solution/README.md">labs/lab-41-agentic-tools-deep-dive-solution/README.md</code>

### 📚 Exercise 7, Section C (Gemini CLI)

Notes:

- Read the lab README.md for example of solutions.

##==##

<!-- .slide: class="with-code" -->

# Gemini CLI: Extensions

**Definition**: Modular packages bundling MCP servers, commands, hooks, skills, agents, themes, and policies

| CLI Command                              | Purpose                      |
| ---------------------------------------- | ---------------------------- |
| `gemini extensions install <source>`     | Install from GitHub or local |
| `gemini extensions new <path>`           | Scaffold from template       |
| `gemini extensions list`                 | View installed               |
| `gemini extensions validate <path>`      | Validate manifest            |
| `gemini extensions config <name>`        | Configure settings           |
| `gemini extensions update <name\|--all>` | Update extensions            |

Notes:
Extensions are Gemini CLI's equivalent of plugins. They can define settings that prompt users on install. The gallery includes partner extensions from Figma, Jira, Stripe, Snyk. Use gemini extensions new to scaffold from a template for rapid development.

##==##

<!-- .slide: class="with-code" -->

# Gemini CLI: Extensions

**Definition**: Modular packages bundling MCP servers, commands, hooks, skills, agents, themes, and policies

**Manifest**: `gemini-extension.json` at extension root

**Contents**: `commands/`, `hooks/`, `skills/`, `agents/`, `policies/`, `themes/`, MCP servers

**Gallery**: **557+ extensions** at geminicli.com/extensions/

**Variable substitution**: `${extensionPath}`, `${workspacePath}`, `${/}`

**📚 Documentation**: https://geminicli.com/docs/extensions/

Notes:
Extensions are Gemini CLI's equivalent of plugins. They can define settings that prompt users on install. The gallery includes partner extensions from Figma, Jira, Stripe, Snyk. Use gemini extensions new to scaffold from a template for rapid development.

##==##

<!-- .slide: class="exercice" -->

# Exercises: Gemini CLI Deep Dive

## Lab 41

<br>

### 👉 Follow **instructions** in

### <code data-markdown-preview="/labs/lab-41-agentic-tools-deep-dive/README.md">labs/lab-41-agentic-tools-deep-dive/README.md</code>

### 📚 Exercise 8, Section C (Gemini CLI)

Notes:

- Follow the instructions in the lab README.md for detailed steps.

##==##

<!-- .slide: class="exercice" -->

# Exercises: Gemini CLI Deep Dive

## Lab 41

<br>

### 💡 Read **solution** at

### <code data-markdown-preview="/labs/lab-41-agentic-tools-deep-dive-solution/README.md">labs/lab-41-agentic-tools-deep-dive-solution/README.md</code>

### 📚 Exercise 8, Section C (Gemini CLI)

Notes:

- Read the lab README.md for example of solutions.

##==##

<!-- .slide: -->

# Gemini CLI: Configuration

**Definition**: Project and user-level settings controlling Gemini's behavior, permissions, and integrations

| Category | Settings                     |
| -------- | ---------------------------- |
| Model    | model selection, routing     |
| Security | sandbox, tool restrictions   |
| Hooks    | BeforeTool, AfterTool events |
| Agents   | overrides, enableAgents      |
| Skills   | enable/disable               |
| UI       | themes, screen reader        |

Notes:
Gemini CLI configuration is split between settings.json for runtime behavior and GEMINI.md for project instructions. The settings hierarchy has workspace overriding user. Use /settings for interactive configuration or edit JSON directly.

##==##

<!-- .slide: -->

# Gemini CLI: Configuration

**Definition**: Project and user-level settings controlling Gemini's behavior, permissions, and integrations

**Location**: `.gemini/settings.json` (project) · `~/.gemini/settings.json` (user)

**Project instructions**: `GEMINI.md` (follows parent dirs to .git root)

**Memory**: `/memory show`, `/memory add`, `/memory refresh`

**Model switching**: `gemini --model`, `GEMINI_MODEL` env var, `/model` command

**📚 Documentation**: https://geminicli.com/docs/configuration/settings/

Notes:
Gemini CLI configuration is split between settings.json for runtime behavior and GEMINI.md for project instructions. The settings hierarchy has workspace overriding user. Use /settings for interactive configuration or edit JSON directly.

##==##

<!-- .slide: class="exercice" -->

# Exercises: Gemini CLI Deep Dive

## Lab 41

<br>

### 👉 Follow **instructions** in

### <code data-markdown-preview="/labs/lab-41-agentic-tools-deep-dive/README.md">labs/lab-41-agentic-tools-deep-dive/README.md</code>

### 📚 Exercise 9 (optional), Section C (Gemini CLI)

Notes:

- Follow the instructions in the lab README.md for detailed steps.

##==##

<!-- .slide: class="exercice" -->

# Exercises: Gemini CLI Deep Dive

## Lab 41

<br>

### 💡 Read **solution** at

### <code data-markdown-preview="/labs/lab-41-agentic-tools-deep-dive-solution/README.md">labs/lab-41-agentic-tools-deep-dive-solution/README.md</code>

### 📚 Exercise 9 (optional), Section C (Gemini CLI)

Notes:

- Read the lab README.md for example of solutions.

##==##

<!-- .slide: -->

# **Gemini CLI: Feature Summary**

<br>

| Feature    | Location            | Invocation             | Key Trait                       |
| ---------- | ------------------- | ---------------------- | ------------------------------- |
| Agents     | `.gemini/agents/`   | `@name`, auto          | Experimental, isolated context  |
| Commands   | `.gemini/commands/` | `/name`                | TOML with `!{}` shell syntax    |
| Skills     | `.gemini/skills/`   | Auto, `activate_skill` | Richest CLI (`install`, `link`) |
| Hooks      | `settings.json`     | Auto (11 events)       | JSON stdin/stdout protocol      |
| Extensions | `gemini extensions` | CLI install            | 557+ gallery, scaffolding       |
| Config     | `settings.json`     | `/settings`            | Interactive configuration       |

Notes:
Gemini CLI's unique strengths: most hook event types (11), richest skills CLI (install/link), Google Search grounding, extension gallery with 557+ packages, and the gemini extensions new scaffolding command.

##==##

<!-- .slide: -->

# Gemini CLI: When to Use What

## Choosing the Right Feature

| Scenario                             | Use This                  | Why                                              |
| ------------------------------------ | ------------------------- | ------------------------------------------------ |
| Need domain-expert AI guidance       | **Custom Agent** _(exp.)_ | Specialist agent in `.gemini/agents/`            |
| Need reusable prompt for a task      | **Custom Command**        | One-shot template in `.gemini/commands/`         |
| Need to control permissions/behavior | **Configuration**         | `settings.json` for settings, profiles, policies |

<br>

**Agents** _(experimental)_ = specialist personas | **Commands** = single-task templates

Notes:
Gemini CLI custom agents are still experimental. Extensions provide Google-built integrations (Web Search, Code Execution, etc.) rather than user-defined bundles. The settings.json controls both hooks and general configuration — unlike other tools that separate these concerns.

##==##

<!-- .slide: -->

# Gemini CLI: When to Use What

## Choosing the Right Feature

| Scenario                            | Use This        | Why                                             |
| ----------------------------------- | --------------- | ----------------------------------------------- |
| Need shared knowledge across agents | **Agent Skill** | Composable, auto-loaded from `.gemini/skills/`  |
| Need automatic validation on edits  | **Hook**        | Pre/Post triggers defined in `settings.json`    |
| Need to bundle & distribute tooling | **Extension**   | `gemini extensions` bundles Google capabilities |

<br>

**Skills** = composable knowledge | **Hooks** = automatic enforcement | **Extensions** = bundled integrations

Notes:
Gemini CLI custom agents are still experimental. Extensions provide Google-built integrations (Web Search, Code Execution, etc.) rather than user-defined bundles. The settings.json controls both hooks and general configuration — unlike other tools that separate these concerns.
