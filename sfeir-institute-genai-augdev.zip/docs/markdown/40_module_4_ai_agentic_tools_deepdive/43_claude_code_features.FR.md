<!-- .slide: class="transition" -->

# Claude Code Deep Dive

## Fonctionnalités CLI, agents, commandes, skills, hooks, plugins & configuration

##==##

<!-- .slide: -->

# **Claude Code : aperçu de la CLI**

| Fonctionnalité       | Comment     | Exemple                      |
| -------------------- | ----------- | ---------------------------- |
| Inclure des fichiers | symbole `@` | `@src/api/ review this`      |
| Commandes slash      | préfixe `/` | `/help`, `/compact`, `/init` |
| Exécuter du bash     | préfixe `!` | `!npm test`                  |
| Modes de permission  | `Shift+Tab` | Normal → Plan → Auto-Accept  |
| Réflexion étendue    | `Alt+T`     | Activer/désactiver           |

<br>

**📚 Documentation** : https://code.claude.com/docs/en/interactive-mode

Notes:
Ce sont les fonctionnalités de base. Maîtrisez @ # / ! avant d'aborder la personnalisation. Les modes de permission contrôlent l'autonomie de Claude : Normal (demande la permission), Plan (lecture seule), Auto-Accept (autonomie totale).

##==##

<!-- .slide: -->

# **Claude Code : aperçu de la CLI**

| Fonctionnalité          | Comment                      | Exemple                                            |
| ----------------------- | ---------------------------- | -------------------------------------------------- |
| Historique              | `Esc Esc` \| `/rewind`       | Restaure code/conversation à un point antérieur    |
| Session                 | `/resume`                    | Reprend une conversation précédente                |
| Gestion du contexte     | `/compact`                   | Compresse à 70-85 % de capacité                    |
| Récap après absence     | `/recap`                     | Injecte un résumé du contexte après 75+ min absent |
| Effacer le contexte     | `/clear`                     | Efface tout le contexte, repart à zéro             |
| Niveau d'effort         | `/effort`                    | Curseur : low → medium → high → **xhigh**          |
| Mode vocal              | `/voice` puis `SPACE (hold)` | Activer/désactiver                                 |
| Arrêter tous les agents | `Ctrl+X` `Ctrl+K`            | Tue les agents en arrière-plan (avant `Ctrl+F`)    |

<br>

**📚 Documentation** : https://code.claude.com/docs/en/interactive-mode

Notes:
Ce sont les fonctionnalités de base. Maîtrisez @ # / ! avant d'aborder la personnalisation. Les modes de permission contrôlent l'autonomie de Claude : Normal (demande la permission), Plan (lecture seule), Auto-Accept (autonomie totale). Note : `/vim` et `/tag` ont été retirés début 2026 — utilisez `/config` → mode Éditeur pour l'édition façon vim. La nouvelle commande `/effort` expose un curseur à 4 niveaux ; `xhigh` est disponible sur les modèles actuels de classe Opus/flagship (Opus 4.8, Fable 5). `/ultrareview` déclenche une revue cloud facturée de la branche courante (ou d'une PR GitHub par numéro) ; elle est lancée par l'opérateur, pas appelable par l'agent.

##==##

<!-- .slide: -->

# **Claude Code : aperçu de la CLI**

| Commande slash          | Objectif                                                   |
| ----------------------- | ---------------------------------------------------------- |
| `/ultrareview [target]` | Revue de code cloud multi-agents de la branche ou d'une PR |
| `/team-onboarding`      | Génère un guide de prise en main du projet pour l'équipe   |
| `/insights`             | Génère un rapport analysant vos sessions Claude Code       |
| `/powerup`              | Leçons interactives sur Claude Code avec démos animées     |

<br>

**📚 Documentation** : https://code.claude.com/docs/en/changelog

Notes:
Ces commandes sont arrivées entre janvier et juillet 2026 (à jour en v2.1.215, 2026-07-19). `/ultrareview` est la plus intéressante en formation — elle lance des relecteurs cloud en parallèle et réinjecte les résultats dans la session locale. `/less-permission-prompts` est le moyen le plus rapide de réduire les frictions sur les sessions longues. `/recap` se déclenche automatiquement après un seuil d'inactivité configurable (75 min par défaut) mais peut aussi être invoquée manuellement. Le passage de `Ctrl+F` à `Ctrl+X Ctrl+K` a été fait parce que `Ctrl+F` masquait le forward-char de readline.

##==##

<!-- .slide: class="with-code" -->

# Claude Code : CLAUDE.md (contexte)

**Définition** : instructions projet persistantes que Claude lit au début de chaque session. Fournit le contexte, les conventions et les règles propres au projet.

| Niveau             | Fichier               | Portée                            |
| ------------------ | --------------------- | --------------------------------- |
| **Projet partagé** | `./CLAUDE.md`         | Partagé avec l'équipe via git     |
| **Projet local**   | `./CLAUDE.local.md`   | Personnel, gitignoré              |
| **Global user**    | `~/.claude/CLAUDE.md` | Personnel, vaut pour tous projets |

**Créer/mettre à jour** : `/init` analyse le code existant et génère CLAUDE.md (stack technique, commandes de build, conventions)

**Éditer** : `/memory` ouvre CLAUDE.md pour édition

**📚 Documentation** : https://code.claude.com/docs/en/memory

Notes:
CLAUDE.md est le socle du contexte projet. La commande /init scanne votre base de code pour générer automatiquement des instructions pertinentes. Le raccourci # permet d'ajouter rapidement des instructions sans quitter la conversation. Les fichiers partagés vont dans git ; les préférences personnelles dans CLAUDE.local.md. Des CLAUDE.md imbriqués dans des sous-répertoires fournissent un contexte spécifique à ces répertoires.

##==##

<!-- .slide: class="with-code" -->

# Claude Code : Rules (`.claude/rules/`)

**Définition** : fichiers d'instructions modulaires et scopés par chemin qui étendent CLAUDE.md. Chaque rule couvre un sujet et peut être limitée à certains chemins via des globs.

| Fonctionnalité       | Détails                                                                |
| -------------------- | ---------------------------------------------------------------------- |
| **Format**           | Fichiers Markdown (`.md`) dans `.claude/rules/`                        |
| **Scope par chemin** | Frontmatter YAML `paths` avec patterns glob                            |
| **Chargement**       | Sans `paths` : au lancement. Avec `paths` : à l'ouverture des fichiers |
| **Rules user**       | `~/.claude/rules/` pour les rules personnelles inter-projets           |

Notes:
Les rules sont idéales sur les gros projets où un unique CLAUDE.md devient ingérable. Les rules scopées par chemin économisent du contexte en ne se chargeant que quand Claude travaille sur les fichiers correspondants. Utilisez des noms de fichiers parlants comme testing.md ou api-design.md. Les symlinks permettent de partager des rules entre dépôts.

##==##

<!-- .slide: class="with-code" -->

# Claude Code : Rules (`.claude/rules/`)

```yaml
---
paths:
  - 'src/api/**/*.ts'
---
# API rules: validate input, standard error format...
```

**vs CLAUDE.md** : CLAUDE.md = fichier unique, toujours chargé. Rules = modulaires, scopables par chemin

**📚 Documentation** : https://code.claude.com/docs/en/memory

Notes:
Les rules sont idéales sur les gros projets où un unique CLAUDE.md devient ingérable. Les rules scopées par chemin économisent du contexte en ne se chargeant que quand Claude travaille sur les fichiers correspondants. Utilisez des noms de fichiers parlants comme testing.md ou api-design.md. Les symlinks permettent de partager des rules entre dépôts.

##==##

<!-- .slide: class="exercice" -->

# Exercices : Claude Code Deep Dive

## Lab 41

<br>

### 👉 **Instructions** dans

### <code data-markdown-preview="/labs/lab-41-agentic-tools-deep-dive/README.md">labs/lab-41-agentic-tools-deep-dive/README.md</code>

### 📚 Exercices 1 à 2, section A (Claude Code)

Notes:

- Suivez les instructions du README.md du lab pour les étapes détaillées.

##==##

<!-- .slide: class="exercice" -->

# Exercices : Claude Code Deep Dive

## Lab 41

<br>

### 💡 **Solution** dans

### <code data-markdown-preview="/labs/lab-41-agentic-tools-deep-dive-solution/README.md">labs/lab-41-agentic-tools-deep-dive-solution/README.md</code>

### 📚 Section A (Claude Code), exercices 1-3

Notes:

- Lisez le README.md du lab pour des exemples de solutions.

##==##

<!-- .slide: class="with-code" -->

# Claude Code : sous-agents

**Définition** : sous-agents IA spécialisés avec contexte isolé, system prompt propre et accès aux outils restreint

| Champ         | Requis | Description                                         |
| ------------- | ------ | --------------------------------------------------- |
| `name`        | Oui    | Identifiant unique (minuscules, tirets)             |
| `description` | Oui    | Quand Claude doit déléguer à cet agent              |
| `tools`       | Non    | Outils autorisés (hérite de tous si omis)           |
| `model`       | Non    | `sonnet`, `opus`, `haiku`, ou ID complet de modèle  |
| `color`       | Non    | Couleur du sous-agent pour l'identifier dans la CLI |

**Emplacement** : `.claude/agents/` (projet) · `~/.claude/agents/` (personnel)

**Invocation** : `@agent-name`, langage naturel, ou `claude --agent name`

**Créer** : commande interactive `/agents` ou fichier `.md` manuel

Notes:
Les sous-agents tournent dans des fenêtres de contexte isolées, ce qui préserve le contexte de la conversation principale. Depuis mi-2026 les sous-agents tournent **en arrière-plan par défaut** — Claude continue à travailler pendant leur exécution et récupère les résultats à la fin ; il n'en lance un au premier plan que s'il a besoin du résultat pour continuer, et les sous-agents en arrière-plan remontent toutes les demandes de permission dans la session principale (figez le comportement avec le champ de frontmatter `background`). Ils ne peuvent pas lancer d'autres sous-agents. Utilisez /agents pour créer de façon interactive ou écrivez les fichiers .md à la main. Le champ description est critique : Claude s'en sert pour décider quand déléguer. La mémoire permet l'apprentissage inter-sessions.

##==##

<!-- .slide: class="with-code" -->

# Claude Code : sous-agents

**Définition** : sous-agents IA spécialisés avec contexte isolé, system prompt propre et accès aux outils restreint

| Champ            | Requis | Description                                  |
| ---------------- | ------ | -------------------------------------------- |
| `permissionMode` | Non    | `default`, `plan`, `bypassPermissions`, etc. |
| `maxTurns`       | Non    | Nb max de tours agentiques avant arrêt       |
| `skills`         | Non    | Skills à précharger dans le contexte         |
| `hooks`          | Non    | Hooks de cycle de vie scopés à cet agent     |
| `background`     | Non    | Fige l'exécution premier plan/arrière-plan   |

<br>

**📚 Documentation** : https://code.claude.com/docs/en/sub-agents

Notes:
Les sous-agents tournent dans des fenêtres de contexte isolées, ce qui préserve le contexte de la conversation principale. Ils ne peuvent pas lancer d'autres sous-agents. Utilisez /agents pour créer de façon interactive ou écrivez les fichiers .md à la main. Le champ description est critique : Claude s'en sert pour décider quand déléguer. La mémoire permet l'apprentissage inter-sessions.

##==##

<!-- .slide: class="with-code" -->

# Claude Code : sous-agents

**Définition** : sous-agents IA spécialisés avec contexte isolé, system prompt propre et accès aux outils restreint

| Champ           | Requis | Description                                                |
| --------------- | ------ | ---------------------------------------------------------- |
| `memory`        | Non    | `user`, `project` ou `local` pour la persistance           |
| `isolation`     | Non    | `worktree` exécute l'agent dans un worktree git temporaire |
| `cwd`           | Non    | Surcharge le répertoire de travail de cet agent            |
| `initialPrompt` | Non    | Premier tour auto-soumis à l'invocation                    |
| `mcpServers`    | Non    | Config MCP par agent (chargée avec `--agent`)              |

<br>

**📚 Documentation** : https://code.claude.com/docs/en/sub-agents

Notes:
Les sous-agents tournent dans des fenêtres de contexte isolées, ce qui préserve le contexte de la conversation principale. Ils ne peuvent pas lancer d'autres sous-agents. Utilisez /agents pour créer de façon interactive ou écrivez les fichiers .md à la main. Le champ description est critique : Claude s'en sert pour décider quand déléguer. La mémoire permet l'apprentissage inter-sessions.

##==##

<!-- .slide: -->

# Claude Code : Agent Teams _(expérimental)_

**Définition** : plusieurs **sessions Claude Code indépendantes** coordonnées par un team lead, avec listes de tâches partagées, messagerie inter-agents et exécution parallèle dans des worktrees git séparés

| Composant           | Rôle                                                            |
| ------------------- | --------------------------------------------------------------- |
| **Team lead**       | Crée l'équipe, lance les teammates, coordonne le travail        |
| **Teammates**       | Instances Claude Code distinctes traitant les tâches assignées  |
| **Liste de tâches** | Items de travail partagés que les teammates prennent et closent |
| **Mailbox**         | Système de messages pour la communication directe inter-agents  |

**Invocation** : langage naturel (« Crée une agent team pour... ») ou proposition de Claude

**Modes d'affichage** : `in-process` (défaut) ou panneaux `tmux` (`Shift+Down` pour cycler)

**UI `/agents`** : onglets Library (agents définis, actions Run/View) + Running (sous-agents actifs)

**📚 Documentation** : https://code.claude.com/docs/en/agent-teams

Notes:
Les agent teams sont toujours expérimentales en juillet 2026 (vérifié contre le changelog Claude Code v2.1.215). Utilisez les teams quand les workers doivent communiquer entre eux (hypothèses concurrentes, coordination inter-couches). Utilisez les sous-agents quand il vous faut juste des workers focalisés qui rendent leur résultat. Les teams consomment nettement plus de tokens mais permettent recherche, revue, débogage avec hypothèses parallèles et travail de feature inter-couches. Les sous-agents en arrière-plan qui échouent remontent désormais leur progression partielle à l'agent parent — utile quand une recherche longue meurt en cours de route.

##==##

<!-- .slide: class="exercice" -->

# Exercices : Claude Code Deep Dive

## Lab 41

<br>

### 👉 **Instructions** dans

### <code data-markdown-preview="/labs/lab-41-agentic-tools-deep-dive/README.md">labs/lab-41-agentic-tools-deep-dive/README.md</code>

### 📚 Exercices 3 à 4, section A (Claude Code)

Notes:

- Suivez les instructions du README.md du lab pour les étapes détaillées.

##==##

<!-- .slide: class="exercice" -->

# Exercices : Claude Code Deep Dive

## Lab 41

<br>

### 💡 **Solution** dans

### <code data-markdown-preview="/labs/lab-41-agentic-tools-deep-dive-solution/README.md">labs/lab-41-agentic-tools-deep-dive-solution/README.md</code>

### 📚 Exercices 3 à 4, section A (Claude Code)

Notes:

- Lisez le README.md du lab pour des exemples de solutions.

##==##

<!-- .slide: class="with-code" -->

# Claude Code : commandes perso

**Définition** : instructions de prompt réutilisables que Claude charge à la demande. Les commandes personnalisées (`.claude/commands/`) ont été **fusionnées dans les skills** — les deux créent des `/slash-commands` et partagent le même frontmatter

| Champ         | Requis     | Description                                       |
| ------------- | ---------- | ------------------------------------------------- |
| `name`        | Non        | Nom de la slash command (défaut : nom du dossier) |
| `description` | Recommandé | Quand Claude doit auto-charger cette commande     |

Notes:
Les skills suivent le standard ouvert Agent Skills (agentskills.io) qui fonctionne sur plusieurs outils IA. Les commandes dans .claude/commands/ marchent toujours mais les skills sont recommandées : elles supportent des répertoires pour les fichiers embarqués, du frontmatter pour contrôler l'invocation, et l'auto-détection. Utilisez disable-model-invocation pour les actions à effet de bord comme un déploiement.

##==##

<!-- .slide: class="with-code" -->

# Claude Code : Agent Skills

**Définition** : instructions de prompt réutilisables que Claude charge à la demande.

<br>

**Emplacement** : `.claude/skills/<name>/SKILL.md` (projet) · `~/.claude/skills/` (personnel)

**Invocation** : `/skill-name [args]` ou auto-chargée par Claude quand pertinent

**Arguments** : `$ARGUMENTS`, `$0`, `$1`, contexte dynamique avec `` !`command` ``

Notes:
Les skills suivent le standard ouvert Agent Skills (agentskills.io) qui fonctionne sur plusieurs outils IA. Les commandes dans .claude/commands/ marchent toujours mais les skills sont recommandées : elles supportent des répertoires pour les fichiers embarqués, du frontmatter pour contrôler l'invocation, et l'auto-détection. Utilisez disable-model-invocation pour les actions à effet de bord comme un déploiement.

##==##

<!-- .slide: class="with-code" -->

# Claude Code : Agent Skills

**Définition** : instructions de prompt réutilisables que Claude charge à la demande.

| Champ           | Requis | Description                                    |
| --------------- | ------ | ---------------------------------------------- |
| `allowed-tools` | Non    | Outils autorisés quand la skill est active     |
| `argument-hint` | Non    | Indice d'autocomplétion (ex. `[issue-number]`) |
| `context`       | Non    | `fork` pour exécuter dans un sous-agent isolé  |
| `model`         | Non    | Modèle surchargé quand la skill est active     |

**Emplacement** : `.claude/skills/<name>/SKILL.md` (projet) · `~/.claude/skills/` (personnel)

**Invocation** : `/skill-name [args]` ou auto-chargée par Claude quand pertinent

**Arguments** : `$ARGUMENTS`, `$0`, `$1`, contexte dynamique avec `` !`command` ``

Notes:
Les skills suivent le standard ouvert Agent Skills (agentskills.io) qui fonctionne sur plusieurs outils IA. Les commandes dans .claude/commands/ marchent toujours mais les skills sont recommandées : elles supportent des répertoires pour les fichiers embarqués, du frontmatter pour contrôler l'invocation, et l'auto-détection. Utilisez disable-model-invocation pour les actions à effet de bord comme un déploiement.

##==##

<!-- .slide: class="with-code" -->

# Claude Code : Agent Skills

**Définition** : instructions de prompt réutilisables que Claude charge à la demande. Les commandes personnalisées (`.claude/commands/`) ont été **fusionnées dans les skills** — les deux créent des `/slash-commands`

| Champ           | Requis | Description                                    |
| --------------- | ------ | ---------------------------------------------- |
| `allowed-tools` | Non    | Outils autorisés quand la skill est active     |
| `argument-hint` | Non    | Indice d'autocomplétion (ex. `[issue-number]`) |
| `context`       | Non    | `fork` pour exécuter dans un sous-agent isolé  |
| `model`         | Non    | Modèle surchargé quand la skill est active     |

**Emplacement** : `.claude/skills/<name>/SKILL.md` (projet) · `~/.claude/skills/` (personnel)

**Invocation** : `/skill-name [args]` ou auto-chargée par Claude quand pertinent

**Arguments** : `$ARGUMENTS`, `$0`, `$1`, contexte dynamique avec `` !`command` ``

Notes:
Les skills suivent le standard ouvert Agent Skills (agentskills.io) qui fonctionne sur plusieurs outils IA. Les commandes dans .claude/commands/ marchent toujours mais les skills sont recommandées : elles supportent des répertoires pour les fichiers embarqués, du frontmatter pour contrôler l'invocation, et l'auto-détection. Utilisez disable-model-invocation pour les actions à effet de bord comme un déploiement.

##==##

<!-- .slide: class="with-code" -->

# Claude Code : Agent Skills

**Définition** : instructions de prompt réutilisables que Claude charge à la demande. Les commandes personnalisées (`.claude/commands/`) ont été **fusionnées dans les skills** — les deux créent des `/slash-commands`

**Structure** :

```
my-skill/
├── SKILL.md           # Instructions (required)
├── templates/         # Templates for Claude to fill in
├── examples/          # Example outputs
├── scripts/           # Executable scripts
└── references/        # Reference documentation
```

**Fonctionnement** : les descriptions des skills sont chargées en contexte au démarrage de la session. Le contenu complet ne se charge qu'à l'invocation (manuelle ou par Claude). Gardez SKILL.md sous 500 lignes.

**Skills empilées** : invoquez-en plusieurs d'un coup — `/skill-a /skill-b do XYZ` charge toutes les skills de tête (jusqu'à 5), pas seulement la première

**Registres publics** : [🔗 https://skills.sh](https://skills.sh) - [🔗 https://tessl.io/registry](https://tessl.io/registry)

**📚 Documentation** : https://code.claude.com/docs/en/skills

Notes:
Les skills diffèrent des agents et des commandes : les agents sont des personas conversationnels, les commandes/skills sont des templates de prompt. Les skills ajoutent le chargement automatique de contexte : Claude lit les descriptions au démarrage et charge le contenu complet quand c'est pertinent. Les registres publics permettent le partage entre équipes et plateformes sans repartir de zéro.

##==##

<!-- .slide: class="exercice" -->

# Exercices : Claude Code Deep Dive

## Lab 41

<br>

### 👉 **Instructions** dans

### <code data-markdown-preview="/labs/lab-41-agentic-tools-deep-dive/README.md">labs/lab-41-agentic-tools-deep-dive/README.md</code>

### 📚 Exercices 5 à 8, section A (Claude Code)

Notes:

- Suivez les instructions du README.md du lab pour les étapes détaillées.

##==##

<!-- .slide: class="exercice" -->

# Exercices : Claude Code Deep Dive

## Lab 41

<br>

### 💡 **Solution** dans

### <code data-markdown-preview="/labs/lab-41-agentic-tools-deep-dive-solution/README.md">labs/lab-41-agentic-tools-deep-dive-solution/README.md</code>

### 📚 Exercices 5 à 8, section A (Claude Code)

Notes:

- Lisez le README.md du lab pour des exemples de solutions.

##==##

<!-- .slide: class="with-code" -->

# Claude Code : Hooks

**Définition** : callbacks de cycle de vie qui lancent des **commandes** shell ou des **prompts** avant/après l'exécution d'un outil et sur les événements d'environnement / de session

| Événement       | Matcher        | Déclenchement                               |
| --------------- | -------------- | ------------------------------------------- |
| `PreToolUse`    | Nom d'outil    | Avant l'exécution de l'outil (peut bloquer) |
| `PostToolUse`   | Nom d'outil    | Après la fin de l'outil                     |
| `SubagentStart` | Nom d'agent    | Au démarrage d'un sous-agent                |
| `SubagentStop`  | Nom d'agent    | À la fin d'un sous-agent                    |
| `CwdChanged`    | —              | Répertoire de travail changé (`/cd`, etc.)  |
| `FileChange`    | Glob de chemin | Fichier modifié hors des outils de Claude   |

Notes:
Claude Code est le seul à supporter des hooks de type prompt, où Claude évalue un prompt pour décider quoi faire — plus souple que les hooks à base de script, mais moins déterministe. Les hooks peuvent aussi invoquer des outils MCP directement via `type: "mcp_tool"`. Le champ conditionnel `if` permet à une seule entrée de hook de couvrir plusieurs patterns d'outils sans matchers séparés. `CwdChanged` et `FileChanged` sont des ajouts 2026 qui combrent le manque d'observabilité sur les événements non pilotés par un outil.

##==##

<!-- .slide: class="with-code" -->

# Claude Code : Hooks

| Événement          | Matcher | Déclenchement                               |
| ------------------ | ------- | ------------------------------------------- |
| `TaskCreated`      | —       | Une tâche a été ajoutée à la liste          |
| `PreCompact`       | —       | Avant la compaction de la conversation      |
| `WorktreeCreate`   | —       | Un worktree git est créé (ex. par un agent) |
| `PermissionDenied` | —       | Une demande de permission a été refusée     |

<br>

**Codes de sortie** : `0` = autorise, `2` = bloque l'action

**Surcharge de sortie** : `PostToolUse` peut remplacer la sortie d'outil via `hookSpecificOutput.updatedToolOutput`

**📚 Documentation** : https://code.claude.com/docs/en/hooks-guide

Notes:
Utilisez `PreToolUse` pour valider avant l'action, `PostToolUse` pour vérifier après. `PreCompact` est le bon endroit pour dumper l'état important dans un fichier avant la compression du contexte. `PermissionDenied` est utile pour envoyer des pings Slack quand l'agent se retrouve bloqué la nuit. `TaskCreated` et `WorktreeCreate` permettent de la télémétrie sur la planification et le parallélisme des agents. La surcharge `updatedToolOutput` donne aux hooks le pouvoir de masquer des secrets dans les résultats d'outils avant que Claude ne les voie.

##==##

<!-- .slide: class="with-code" -->

# Claude Code : Hooks

**Définition** : callbacks de cycle de vie qui lancent des **commandes** shell ou des **prompts** avant/après l'exécution d'un outil et sur les événements d'environnement / de session

**Types de hooks** : `command` (script shell) · `prompt` (Claude évalue) · `mcp_tool` (invoque un outil MCP directement)

**Emplacement** : `.claude/settings.json` → clé `hooks`

**Syntaxe du matcher** : nom d'outil, pipe `|` pour un OU (ex. `Write|Edit`)

**Conditionnel** : le champ `if` accepte la syntaxe des règles de permission (ex. `Bash(git *)`) pour filtrer l'exécution

Notes:
Claude Code est le seul à supporter des hooks de type prompt, où Claude évalue un prompt pour décider quoi faire — plus souple que les hooks à base de script, mais moins déterministe. Les hooks peuvent aussi invoquer des outils MCP directement via `type: "mcp_tool"`. Le champ conditionnel `if` permet à une seule entrée de hook de couvrir plusieurs patterns d'outils sans matchers séparés. `CwdChanged` et `FileChanged` sont des ajouts 2026 qui combrent le manque d'observabilité sur les événements non pilotés par un outil.

##==##

<!-- .slide: -->

# Claude Code : Plugins

**Définition** : paquets distribuables qui regroupent **agents**, **skills**, **hooks**, **serveurs MCP** et **exécutables** en extensions installables

**Manifeste** : `plugin.json` dans le répertoire `.claude-plugin/`

| Commande CLI                     | Objectif                                                |
| -------------------------------- | ------------------------------------------------------- |
| `claude plugin install <source>` | Installe depuis marketplace, GitHub ou chemin local     |
| `claude plugin update <name>`    | Met à jour vers la dernière version                     |
| `claude plugin uninstall <name>` | Supprime le plugin                                      |
| `claude plugin tag`              | Crée des tags git de release avec validation de version |

Notes:
Les plugins sont l'abstraction la plus haute. Ils regroupent plusieurs types de fonctionnalités dans un seul paquet installable. Utilisez `claude plugin marketplace` pour découvrir les plugins communautaires. Les agents de plugin ne peuvent pas définir hooks, mcpServers ni permissionMode pour raisons de sécurité — copiez-les dans `.claude/agents/` si besoin. Le champ de manifeste `userConfig` est la façon 2026 de demander à l'utilisateur ses valeurs de configuration à l'installation ou à l'activation, sans l'obliger à éditer `settings.json` à la main. `claude plugin tag` est le chemin recommandé pour publier des releases versionnées. Le format plugin.json est compatible avec les plugins GitHub Copilot.

##==##

<!-- .slide: -->

# Claude Code : Plugins

**Définition** : paquets distribuables qui regroupent **agents**, **skills**, **hooks**, **serveurs MCP** et **exécutables** en extensions installables

**Manifeste** : `plugin.json` dans le répertoire `.claude-plugin/`

<br>

**Namespace** : les commandes de plugin sont nommées `/plugin-name:command-name`

**Quand l'utiliser** : partager l'outillage d'équipe, distribuer des workflows standardisés entre projets et équipes

Notes:
Les plugins sont l'abstraction la plus haute. Ils regroupent plusieurs types de fonctionnalités dans un seul paquet installable. Utilisez `claude plugin marketplace` pour découvrir les plugins communautaires. Les agents de plugin ne peuvent pas définir hooks, mcpServers ni permissionMode pour raisons de sécurité — copiez-les dans `.claude/agents/` si besoin. Le champ de manifeste `userConfig` est la façon 2026 de demander à l'utilisateur ses valeurs de configuration à l'installation ou à l'activation, sans l'obliger à éditer `settings.json` à la main. `claude plugin tag` est le chemin recommandé pour publier des releases versionnées. Le format plugin.json est compatible avec les plugins GitHub Copilot.

##==##

<!-- .slide: -->

# Claude Code : Plugins

**Définition** : paquets distribuables qui regroupent **agents**, **skills**, **hooks** et **serveurs MCP** en extensions installables

**Manifeste** : `plugin.json` dans le répertoire `.claude-plugin/`

| Commande CLI                       | Objectif                        |
| ---------------------------------- | ------------------------------- |
| `claude plugin marketplace browse` | Découvrir les plugins existants |
| `claude plugin list`               | Voir les plugins installés      |

**📚 Documentation** : https://code.claude.com/docs/en/plugins

Notes:
Le changement sur le bundling des skills compte parce que les premières versions de plugins utilisaient le nom de répertoire pour l'invocation, ce qui cassait dès qu'une équipe renommait le dossier du plugin. Avec `"skills": ["./"]`, le `name` du frontmatter de SKILL.md devient la clé d'invocation stable. `alwaysLoad` est une porte de sortie pour les plugins où le chargement différé des outils surprendrait l'utilisateur. `allowedChannelPlugins` fait partie du dispositif de managed settings pour les déploiements en entreprise.

##==##

<!-- .slide: -->

# Claude Code : Plugins

**Définition** : paquets distribuables qui regroupent **agents**, **skills**, **hooks** et **serveurs MCP** en extensions installables

**Manifeste** : `plugin.json` dans le répertoire `.claude-plugin/`

**Bundling de skills** : déclarez `"skills": ["./"]` pour utiliser le `name` du frontmatter comme invocation stable

**Option MCP** : `alwaysLoad: true` saute le chargement différé des outils pour le serveur MCP du plugin

**Contrôle admin** : les admins entreprise peuvent restreindre les plugins via `allowedChannelPlugins` ; les plugins bloqués sont masqués de la marketplace

**📚 Documentation** : https://code.claude.com/docs/en/plugins

Notes:
Le changement sur le bundling des skills compte parce que les premières versions de plugins utilisaient le nom de répertoire pour l'invocation, ce qui cassait dès qu'une équipe renommait le dossier du plugin. Avec `"skills": ["./"]`, le `name` du frontmatter de SKILL.md devient la clé d'invocation stable. `alwaysLoad` est une porte de sortie pour les plugins où le chargement différé des outils surprendrait l'utilisateur. `allowedChannelPlugins` fait partie du dispositif de managed settings pour les déploiements en entreprise.

##==##

<!-- .slide: class="exercice" -->

# Exercices : Claude Code Deep Dive

## Lab 41

<br>

### 👉 **Instructions** dans

### <code data-markdown-preview="/labs/lab-41-agentic-tools-deep-dive/README.md">labs/lab-41-agentic-tools-deep-dive/README.md</code>

### 📚 Exercices 9-10, section A (Claude Code)

Notes:

- Suivez les instructions du README.md du lab pour les étapes détaillées.

##==##

<!-- .slide: class="exercice" -->

# Exercices : Claude Code Deep Dive

## Lab 41

<br>

### 💡 **Solution** dans

### <code data-markdown-preview="/labs/lab-41-agentic-tools-deep-dive-solution/README.md">labs/lab-41-agentic-tools-deep-dive-solution/README.md</code>

### 📚 Exercices 9-10, section A (Claude Code)

Notes:

- Lisez le README.md du lab pour des exemples de solutions.

##==##

<!-- .slide: -->

# Claude Code : configuration (settings.json)

**Définition** : réglages niveau projet et utilisateur qui contrôlent le comportement, les permissions et les intégrations de Claude

| Réglage        | Objectif                  | Exemple                 |
| -------------- | ------------------------- | ----------------------- |
| `allowedTools` | Autorise des outils       | `["Bash(npm:*)"]`       |
| `deniedTools`  | Bloque des outils         | `["Bash(rm -rf:*)"]`    |
| `hooks`        | Callbacks de cycle de vie | PreToolUse, PostToolUse |

<br>

**Emplacement** : `.claude/settings.json` (projet) · `.claude/settings.local.json` (personnel) ·`~/.claude/settings.json` (user)

**Instructions projet** : `CLAUDE.md` (partagé via git) · `CLAUDE.local.md` (personnel)

**Bootstrap** : `/init` analyse le projet et génère CLAUDE.md · `/config` persiste les changements dans `~/.claude/settings.json`

Notes:
Les réglages suivent une hiérarchie de priorité : flags CLI > policy > projet > utilisateur. CLAUDE.md sert d'instructions projet persistantes — équivalent d'AGENTS.md pour Codex. La commande /init scanne votre base de code pour générer automatiquement des instructions pertinentes : stack technique, commandes de build, conventions. Une valeur d'enum invalide n'invalide plus que la clé concernée (et non tout le `settings.json`) ; `cleanupPeriodDays: 0` est désormais rejeté (avant, il désactivait silencieusement la persistance).

##==##

<!-- .slide: -->

# Claude Code : configuration (settings.json)

**Définition** : réglages niveau projet et utilisateur qui contrôlent le comportement, les permissions et les intégrations de Claude

| Réglage            | Objectif                  | Exemple                |
| ------------------ | ------------------------- | ---------------------- |
| `env`              | Variables d'environnement | `{"NODE_ENV": "test"}` |
| `mcpServers`       | Intégrations MCP          | Configs de serveurs    |
| `permissions.deny` | Bloque agents/skills      | `["Agent(Explore)"]`   |

<br>

**📚 Documentation** : https://code.claude.com/docs/en/settings

Notes:
Les réglages suivent une hiérarchie de priorité : flags CLI > policy > projet > utilisateur. CLAUDE.md sert d'instructions projet persistantes — équivalent d'AGENTS.md pour Codex.

##==##

<!-- .slide: class="exercice" -->

# Exercices : Claude Code Deep Dive

## Lab 41

<br>

### 👉 **Instructions** dans

### <code data-markdown-preview="/labs/lab-41-agentic-tools-deep-dive/README.md">labs/lab-41-agentic-tools-deep-dive/README.md</code>

### 📚 Exercice 11 (optionnel), section A (Claude Code)

Notes:

- Suivez les instructions du README.md du lab pour les étapes détaillées.

##==##

<!-- .slide: class="exercice" -->

# Exercices : Claude Code Deep Dive

## Lab 41

<br>

### 💡 **Solution** dans

### <code data-markdown-preview="/labs/lab-41-agentic-tools-deep-dive-solution/README.md">labs/lab-41-agentic-tools-deep-dive-solution/README.md</code>

### 📚 Exercice 11 (optionnel), section A (Claude Code)

Notes:

- Lisez le README.md du lab pour des exemples de solutions.

##==##

<!-- .slide: -->

# **Claude Code : synthèse**

| Fonctionnalité | Emplacement         | Invocation          | Trait clé                                   |
| -------------- | ------------------- | ------------------- | ------------------------------------------- |
| CLAUDE.md      | `./CLAUDE.md`       | Auto au démarrage   | Contexte projet                             |
| Rules          | `.claude/rules/`    | Auto (scopé chemin) | Modulaire, matché par glob                  |
| Agents         | `.claude/agents/`   | `@name`             | Persona conversationnel ; `isolation`/`cwd` |
| Agent Teams    | settings.json (env) | Langage naturel     | Multi-sessions parallèles _(expérimental)_  |
| Commandes      | `.claude/commands/` | `/name`             | Template one-shot (fusionné dans Skills)    |
| Skills         | `.claude/skills/`   | Automatique         | Connaissance composable                     |

Notes:
Claude Code a l'écosystème de personnalisation le plus riche des 4 outils — le seul à supporter tous les types de fonctionnalités listés ci-dessus. **Sonnet 5** (sorti le 30 juin 2026) est désormais le modèle par défaut dans Claude Code pour les sièges Pro/Team/Enterprise ; **Opus 4.8** est le modèle flagship de classe Opus et débloque le niveau d'effort `xhigh` ; l'effort par défaut est `high` sur Opus 4.8 / Sonnet 5 (avant `medium`). Les tâches longues ont gagné l'outil **EndConversation** et des **battements de progression**. Les builds natifs macOS/Linux remplacent les outils `Glob`/`Grep` autonomes par `bfs`/`ugrep` embarqués et invoqués via l'outil Bash. Les utilisateurs Windows peuvent activer la préversion de l'outil PowerShell (`CLAUDE_CODE_USE_POWERSHELL_TOOL=1`) ; Git Bash n'est plus requis.

##==##

<!-- .slide: -->

# **Claude Code : synthèse**

| Fonctionnalité   | Emplacement       | Invocation          | Trait clé                                     |
| ---------------- | ----------------- | ------------------- | --------------------------------------------- |
| Hooks            | `settings.json`   | Auto (événementiel) | 10 événements dont `CwdChanged`, `PreCompact` |
| Plugins          | `.claude-plugin/` | `/plugin:command`   | Distribution groupée ; `userConfig`, `bin/`   |
| Config           | `settings.json`   | Au démarrage        | Permissions, sandbox, TUI, deep-links         |
| Niveaux d'effort | Curseur `/effort` | Par tour            | low → medium → high → **xhigh** (Opus 4.8+)   |

Notes:
Claude Code a l'écosystème de personnalisation le plus riche des 4 outils — le seul à supporter tous les types de fonctionnalités listés ci-dessus. **Sonnet 5** (sorti le 30 juin 2026) est désormais le modèle par défaut dans Claude Code pour les sièges Pro/Team/Enterprise ; **Opus 4.8** est le modèle flagship de classe Opus et débloque le niveau d'effort `xhigh` ; l'effort par défaut est `high` sur Opus 4.8 / Sonnet 5 (avant `medium`). Les tâches longues ont gagné l'outil **EndConversation** et des **battements de progression**. Les builds natifs macOS/Linux remplacent les outils `Glob`/`Grep` autonomes par `bfs`/`ugrep` embarqués et invoqués via l'outil Bash. Les utilisateurs Windows peuvent activer la préversion de l'outil PowerShell (`CLAUDE_CODE_USE_POWERSHELL_TOOL=1`) ; Git Bash n'est plus requis.

##==##

<!-- .slide: -->

# Claude Code : quoi utiliser quand

## Choisir le bon composant

| Scénario                               | Utilisez               | Pourquoi                                         |
| -------------------------------------- | ---------------------- | ------------------------------------------------ |
| Conventions de code scopées par chemin | **Rules**              | `.claude/rules/` avec frontmatter glob `paths`   |
| Expertise IA sur un domaine            | **Agent personnalisé** | Contexte isolé, outils restreints, `@name`       |
| Travail parallèle avec coordination    | **Agent Team**         | Sessions multiples, tâches partagées, messagerie |
| Prompt réutilisable pour une tâche     | **Commande perso**     | `/command` one-shot dans `.claude/commands/`     |

**CLAUDE.md** = contexte projet toujours actif | **Rules** = instructions modulaires, scopées par chemin

**Agents** = un worker isolé | **Agent Teams** = workers parallèles coordonnés

Notes:
Claude Code supporte les 6 types de fonctionnalités — l'écosystème le plus riche des 4 outils. La question clé : invocation humaine (agent/commande) ou automatique (hook) ? Connaissance réutilisable (skill) ou persona complet (agent) ? Paquet de distribution (plugin) ou contrôle d'accès (config) ?

##==##

<!-- .slide: -->

# Claude Code : quoi utiliser quand

## Choisir le bon composant

| Scénario                             | Utilisez          | Pourquoi                                        |
| ------------------------------------ | ----------------- | ----------------------------------------------- |
| Connaissance partagée entre agents   | **Agent Skill**   | Composable, auto-chargée de `.claude/skills/`   |
| Validation automatique sur édition   | **Hook**          | Déclencheurs Pre/Post dans `settings.json`      |
| Grouper et distribuer de l'outillage | **Plugin**        | Groupe agents+commandes dans `.claude/plugins/` |
| Contrôler permissions/comportement   | **Configuration** | `settings.json` : permissions, profils, deny    |

<br>

**Skills** = connaissance composable | **Hooks** = application automatique

Notes:
Claude Code supporte les 6 types de fonctionnalités — l'écosystème le plus riche des 4 outils. La question clé : invocation humaine (agent/commande) ou automatique (hook) ? Connaissance réutilisable (skill) ou persona complet (agent) ? Paquet de distribution (plugin) ou contrôle d'accès (config) ?
