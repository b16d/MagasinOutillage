<!-- .slide: class="transition" -->

# Module 4 : Bilan et synthèse

##==##

<!-- .slide -->

# Bilan des objectifs pédagogiques

<br>

### Ce que nous avons vu

À l'issue du Module 4, vous devez être capable de :

- **Maîtriser** les fonctionnalités CLI de Claude Code, GitHub Copilot, Codex CLI, Gemini CLI et OpenCode
- **Créer** des agents et commandes/prompts personnalisés pour les workflows de votre équipe
- **Configurer** skills d'agent, hooks, plugins/extensions et fichiers de configuration
- **Choisir** le bon type de fonctionnalité (agent, commande, skill, hook, plugin) selon le cas d'usage

### Compétences pratiquées

<!-- .element: class="sm-padding-top" -->

- **Lab 41** : Création d'agents, commandes, skills, hooks, plugins et fichiers de configuration
- Installation et évaluation de skills communautaires issus de registres publics (Tessl)

Notes:
Ce module a couvert les 6 fonctionnalités clés de personnalisation sur 4 outils agentiques. Le framework de décision aide les développeurs à choisir la bonne abstraction pour chaque besoin de l'équipe.

##==##

<!-- .slide: -->

# **Test de connaissances**

## **Question 1 : Choix de fonctionnalité**

<br>

### Vous devez garantir que chaque modification de fichier passe un lint automatiquement, sans que le développeur invoque quoi que ce soit. Quel type de fonctionnalité utiliser ?

**A)** Agent personnalisé  
**B)** Hook (via plugin personnalisé avec pre/post tool use)  
**C)** Commande personnalisée  
**D)** Agent Skill

<details>
<summary>Réponse</summary>
<strong>B) Hook (via plugin personnalisé avec pre/post tool use)</strong> - Les hooks se déclenchent automatiquement sur les actions d'outil (pre/post tool use), sans invocation de l'utilisateur. Agents et commandes exigent une invocation explicite (<code>@name</code> ou <code>/name</code>), et les skills fournissent de la connaissance plutôt que de l'application de règles.
</details>

Notes:
Cette question teste le concept central du framework de décision : les hooks servent à l'application automatique de règles, les agents/commandes à l'usage à la demande. Comprendre cette distinction est fondamental pour bien choisir une fonctionnalité.

##==##

<!-- .slide: -->

# **Test de connaissances**

## **Question 2 : Expertise persistante**

<br>

### Votre équipe veut une IA qui agit comme relecteur sécurité dédié — en gardant son expertise métier et le contexte de conversation sur toute une session de revue. Quel type de fonctionnalité est le plus adapté ?

**A)** Hook  
**B)** Agent Skill  
**C)** Agent personnalisé  
**D)** Commande personnalisée

<details>
<summary>Réponse</summary>
<strong>C) Agent personnalisé</strong> - Les agents personnalisés fournissent une persona conversationnelle persistante et isolée, avec un focus et des outils spécialisés. Les hooks appliquent des règles automatiquement mais ne tiennent pas de conversation. Les skills fournissent de la connaissance réutilisable, pas une persona continue. Les commandes sont des templates one-shot qui renvoient un résultat et s'arrêtent.
</details>

Notes:
Cette question teste la distinction agent / commande / skill de façon indépendante de l'outil. Le signal clé est « garder le contexte sur toute une session » — c'est la caractéristique définissant l'agent. Les hooks et les skills n'ont pas cette continuité conversationnelle.

##==##

<!-- .slide: -->

# **Test de connaissances**

## **Question 3 : Portée du contexte**

<br>

### Votre monorepo a des répertoires frontend et backend avec des standards de code différents. Vous voulez que l'IA suive automatiquement les bons standards par répertoire, sans tout charger dans le contexte global. Quelle approche utiliser ?

**A)** Ajouter tous les standards au fichier de contexte racine du projet  
**B)** Des fichiers d'instructions scopés par chemin, activés selon le répertoire de travail  
**C)** Un agent personnalisé par répertoire, invoqué explicitement  
**D)** Des hooks qui valident le code après chaque modification

<details>
<summary>Réponse</summary>
<strong>B) Des fichiers d'instructions scopés par chemin, activés selon le répertoire de travail</strong> - Les fichiers scopés par chemin ne se chargent que lorsque l'IA travaille dans le répertoire correspondant, ce qui garde le contexte global léger. Le fichier racine du projet est toujours chargé, quel que soit le répertoire. Les agents exigent une invocation explicite. Les hooks appliquent des règles a posteriori mais ne guident pas l'IA pendant la génération.
</details>

Notes:
Cette question teste la compréhension de la hiérarchie d'instructions et de l'efficacité du contexte — un concept fondamental commun à tous les outils agentiques. Le scénario inclut volontairement les hooks comme distracteur, pour renforcer la distinction guidage / application de règles introduite en Q1.

##==##

<!-- .slide: -->

# **Test de connaissances**

## **Question 4 : Portabilité inter-outils**

<br>

### Votre équipe veut documenter une procédure de revue de code réutilisable, valable pour tous les développeurs quel que soit l'outil de codage IA utilisé. Quel type de fonctionnalité convient le mieux ?

**A)** Commande personnalisée  
**B)** Plugin / Extension  
**C)** Hook  
**D)** Agent Skill (SKILL.md)

<details>
<summary>Réponse</summary>
<strong>D) Agent Skill (SKILL.md)</strong> - Le format SKILL.md est un standard multiplateforme partagé, reconnu par tous les grands outils agentiques. Les skills se copient sans modification entre les dossiers propres à chaque outil et se partagent via des registres publics. Les commandes personnalisées utilisent des formats spécifiques à l'outil. Les plugins sont des paquets de distribution liés à une plateforme. Les hooks sont des mécanismes d'application de règles, pas de la connaissance réutilisable.
</details>

Notes:
Cette question met en avant les skills comme la primitive de personnalisation la plus portable — un enseignement clé du module. Les registres publics (skills.sh, tessl.io) renforcent encore cette portabilité. Rappelez aux apprenants que « indépendant de l'outil » est la caractéristique qui rend les skills précieux pour une adoption à l'échelle de l'équipe.

##==##

<!-- .slide: -->

# **Ressources**

## **Pour aller plus loin**

<br>

### **Documentation**

- [Claude Code](https://docs.anthropic.com/en/docs/claude-code) - Agents, commandes, skills, hooks, plugins
- [GitHub Copilot](https://docs.github.com/en/copilot) - Agents, prompts, instructions, hooks, plugins
- [Gemini CLI](https://geminicli.com/docs/) - Agents, commandes, skills, hooks, extensions _(retiré en mai 2026 → Antigravity CLI)_
- [Codex CLI](https://developers.openai.com/codex/) - Agents, AGENTS.md, skills, profils, config
- [OpenCode](https://opencode.ai/docs/) - Agents, commandes, skills, modes, permissions, MCP
- [Tessl Registry](https://tessl.io/registry) - Registre public de skills avec évaluation qualité
- [skills.sh](https://skills.sh/) - Écosystème ouvert d'agent skills (600K+ skills mi-2026)

### **Corrigés des labs**

- Consulter `labs/lab-41-agentic-tools-deep-dive-solution/`

Notes:
Utilisez les dossiers de configuration de photo-gallery-fullstack comme implémentations de référence pour les 4 plateformes. Les registres publics permettent de découvrir et d'installer des skills créés par la communauté sur toutes les plateformes.
