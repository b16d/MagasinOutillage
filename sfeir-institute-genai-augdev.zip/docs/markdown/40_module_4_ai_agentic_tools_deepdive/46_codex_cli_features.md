<!-- .slide: class="transition" -->

# Codex CLI Deep Dive

## CLI Features, Agents, Skills, Profiles & Configuration

##==##

<!-- .slide: -->

# **Codex CLI: CLI Overview**

| Feature         | How        | Example                          |
| --------------- | ---------- | -------------------------------- |
| Include files   | `@` symbol | `@src/api/` fuzzy file search    |
| Invoke skills   | `$` prefix | `$skill-name "prompt"`           |
| Execute bash    | `!` prefix | `!ls`, `!git status`             |
| Slash commands  | `/` prefix | `/init`, `/model`, `/plan`       |
| Approval policy | `-a` flag  | `untrusted / on-request / never` |

<br>

**📚 Documentation**: https://developers.openai.com/codex/cli/features

Notes:
Codex CLI shares the same @/!/$ symbols as Claude Code. @ opens a fuzzy file picker over your workspace root. ! runs local shell commands. $ explicitly invokes skills. Approval policies control what Codex executes without asking: untrusted (trusted commands only), on-request (model decides), never (fully automatic).

##==##

<!-- .slide: -->

# **Codex CLI: CLI Overview**

| Feature            | How                         | Example                          |
| ------------------ | --------------------------- | -------------------------------- |
| Edit previous msg  | `Esc Esc`                   | Walk back through transcript     |
| External editor    | `Ctrl+G`                    | Compose longer prompts           |
| Session resume     | `/resume` \| `codex resume` | Restore a previous session       |
| Fork conversation  | `/fork`                     | Clone thread for exploration     |
| Context management | `/compact`                  | Summarize context to free tokens |
| Clear context      | `/clear`                    | Fresh start, preserves terminal  |

<br>

**📚 Documentation**: https://developers.openai.com/codex/cli/slash-commands

Notes:
Codex CLI has 30+ built-in slash commands. Esc Esc (from empty composer) lets you walk back through your transcript and fork from any point with Enter. Ctrl+G opens your $VISUAL/$EDITOR for composing longer prompts. Sessions are stored in ~/.codex/sessions/ as JSONL files.

##==##

<!-- .slide: class="with-code" -->

# Codex CLI: AGENTS.md (Context File)

**Definition**: Persistent project instructions that Codex reads at the start of every session. Provides project-specific context, conventions, and guidelines.

| Level           | File                 | Scope                                 |
| --------------- | -------------------- | ------------------------------------- |
| **Project**     | `./AGENTS.md`        | Shared with team via git              |
| **User global** | `~/.codex/AGENTS.md` | Personal, applies to all projects     |
| **Nested**      | `<subdir>/AGENTS.md` | Directory-specific (takes precedence) |

**Create/Update**: `/init` analyzes existing code and generates AGENTS.md (tech stack, build commands, conventions)

**Auto-read**: Codex reads at session start and applies as project guidance

**📚 Documentation**: https://developers.openai.com/codex/config-advanced

Notes:
AGENTS.md serves as Codex's equivalent to Claude's CLAUDE.md and Gemini's GEMINI.md. The /init command scaffolds it by analyzing your codebase. Nested AGENTS.md files in subdirectories provide directory-specific context (closer to working dir takes precedence). Codex uses AGENTS.md for general project context while .codex/agents/\*.toml handles specialized agent roles.

##==##

<!-- .slide: class="with-code" -->

# Codex CLI: Custom Agents

**Definition**: Specialized agents spawned in parallel for complex tasks like codebase exploration or batch processing

| Field                    | Required | Description                                |
| ------------------------ | -------- | ------------------------------------------ |
| `name`                   | Yes      | Agent identifier                           |
| `description`            | Yes      | Human-facing guidance on when to use       |
| `developer_instructions` | Yes      | Core behavioral directives (system prompt) |
| `model`                  | No       | Specific model override                    |
| `model_reasoning_effort` | No       | Reasoning depth                            |

Notes:
Codex CLI is the only platform using TOML for agent definitions. Agents run in parallel with configurable max_threads (default 6). The spawn_agents_on_csv method enables batch processing across CSV rows. Each agent can have independent sandbox modes and models.

##==##

<!-- .slide: class="with-code" -->

# Codex CLI: Custom Agents

**Definition**: Specialized agents spawned in parallel for complex tasks like codebase exploration or batch processing

**Location**: `.codex/agents/` (project) · `~/.codex/agents/` (personal)

**Invocation**: `/agent` to switch threads, automatic delegation, or `spawn_agents_on_csv` for batch

**File format**: **TOML**

Notes:
Codex CLI is the only platform using TOML for agent definitions. Agents run in parallel with configurable max_threads (default 6). The spawn_agents_on_csv method enables batch processing across CSV rows. Each agent can have independent sandbox modes and models.

##==##

<!-- .slide: class="with-code" -->

# Codex CLI: Custom Agents

**Definition**: Specialized agents spawned in parallel for complex tasks like codebase exploration or batch processing

| Field                 | Required | Description                         |
| --------------------- | -------- | ----------------------------------- |
| `sandbox_mode`        | No       | `read-only` or `workspace-write`    |
| `nickname_candidates` | No       | Display names for UI                |
| `mcp_servers`         | No       | MCP server connections              |
| `skills.config`       | No       | Skills configuration for this agent |

<br>

**📚 Documentation**: https://developers.openai.com/codex/subagents

Notes:
Codex CLI is the only platform using TOML for agent definitions. Agents run in parallel with configurable max_threads (default 6). The spawn_agents_on_csv method enables batch processing across CSV rows. Each agent can have independent sandbox modes and models.

##==##

<!-- .slide: class="exercice" -->

# Exercises: Codex CLI Deep Dive

## Lab 41

<br>

### 👉 Follow **instructions** in

### <code data-markdown-preview="/labs/lab-41-agentic-tools-deep-dive/README.md">labs/lab-41-agentic-tools-deep-dive/README.md</code>

### 📚 Exercises 1 to 2, Section D (Codex CLI)

Notes:

- Follow the instructions in the lab README.md for detailed steps.

##==##

<!-- .slide: class="exercice" -->

# Exercises: Codex CLI Deep Dive

## Lab 41

<br>

### 💡 Read **solution** at

### <code data-markdown-preview="/labs/lab-41-agentic-tools-deep-dive-solution/README.md">labs/lab-41-agentic-tools-deep-dive-solution/README.md</code>

### 📚 Exercises 1 to 2, Section D (Codex CLI)

Notes:

- Read the lab README.md for example of solutions.

##==##

<!-- .slide: class="with-code" -->

# Codex CLI: Agent Skills

**Definition**: Reusable prompt instructions that Codex loads on demand. Detailed, task-specific guidance that activates contextually

| Feature             | Details                                                |
| ------------------- | ------------------------------------------------------ |
| Explicit invocation | `$skill-name "prompt"`                                 |
| Built-in skills     | `$skill-creator`, `$skill-installer`                   |
| Config              | `[[skills.config]]` in `config.toml` to enable/disable |
| References          | Skills can bundle `references/` with project docs      |

Notes:
Codex CLI uniquely supports the $ prefix for explicit skill invocation and progressive disclosure loading. The built-in $skill-creator helps build new skills interactively. Skills can bundle reference files making them self-contained knowledge packages. The agents/openai.yaml provides extended metadata. Public registries enable sharing across teams and platforms without building from scratch.

##==##

<!-- .slide: class="with-code" -->

# Codex CLI: Agent Skills

**Definition**: Reusable prompt instructions that Codex loads on demand. Detailed, task-specific guidance that activates contextually

**How it works**: Progressive disclosure - only metadata loaded initially; full SKILL.md content loaded on activation via `$skill-name` or auto-detection

**When to use**: Reusable knowledge/procedures that should activate contextually, not task-specific commands

**Public Registries**: [🔗 https://skills.sh](https://skills.sh) - [🔗 https://tessl.io/registry](https://tessl.io/registry)

Notes:
Codex CLI uniquely supports the $ prefix for explicit skill invocation and progressive disclosure loading. The built-in $skill-creator helps build new skills interactively. Skills can bundle reference files making them self-contained knowledge packages. The agents/openai.yaml provides extended metadata. Public registries enable sharing across teams and platforms without building from scratch.

##==##

<!-- .slide: class="with-code" -->

# Codex CLI: Agent Skills

**Definition**: Reusable prompt instructions that Codex loads on demand. Detailed, task-specific guidance that activates contextually

**Structure**:

```
my-skill/
├── SKILL.md           # Instructions (required)
├── agents/            # openai.yaml metadata
├── scripts/           # Executable scripts
├── references/        # Reference documentation
└── assets/            # Additional resources
```

<br>

**📚 Documentation**: https://developers.openai.com/codex/skills/create-skill

Notes:
Codex CLI uniquely supports the $ prefix for explicit skill invocation and progressive disclosure loading. The built-in **$skill-creator** helps build new skills interactively. Skills can bundle reference files making them self-contained knowledge packages. The agents/openai.yaml provides extended metadata. Public registries enable sharing across teams and platforms without building from scratch.

##==##

<!-- .slide: class="exercice" -->

# Exercises: Codex CLI Deep Dive

## Lab 41

<br>

### 👉 Follow **instructions** in

### <code data-markdown-preview="/labs/lab-41-agentic-tools-deep-dive/README.md">labs/lab-41-agentic-tools-deep-dive/README.md</code>

### 📚 Exercises 3 to 5, Section D (Codex CLI)

Notes:

- Follow the instructions in the lab README.md for detailed steps.

##==##

<!-- .slide: class="exercice" -->

# Exercises: Codex CLI Deep Dive

## Lab 41

<br>

### 💡 Read **solution** at

### <code data-markdown-preview="/labs/lab-41-agentic-tools-deep-dive-solution/README.md">labs/lab-41-agentic-tools-deep-dive-solution/README.md</code>

### 📚 Exercises 3 to 5, Section D (Codex CLI)

Notes:

- Read the lab README.md for example of solutions.

##==##

<!-- .slide: class="with-code" -->

# Codex CLI: Rules (Command Control)

**Definition**: Starlark-based rules controlling which commands Codex can execute outside its sandbox - Codex's alternative to hooks

| Field                 | Required | Description                              |
| --------------------- | -------- | ---------------------------------------- |
| `pattern`             | Yes      | List of command literals/unions to match |
| `decision`            | Yes      | `allow`, `prompt`, or `forbidden`        |
| `justification`       | No       | Why this rule exists                     |
| `match` / `not_match` | No       | Validation test cases                    |

Notes:
Codex CLI uses Starlark rules instead of hooks for command control. This is a fundamentally different approach - rules define static policies, while hooks run dynamic scripts. Rules can be tested with codex execpolicy check before deployment. The sandbox system provides the baseline security.

##==##

<!-- .slide: class="with-code" -->

# Codex CLI: Rules (Command Control)

**Definition**: Starlark-based rules controlling which commands Codex can execute outside its sandbox - Codex's alternative to hooks

**Location**: `~/.codex/rules/default.rules` or `.codex/rules/`

**File format**: `.rules` files using Starlark `prefix_rule()` function

**Test**: `codex execpolicy check --pretty --rules <file> -- <command>`

**When to use**: Security policies, command allowlisting, team-enforced execution rules

**📚 Documentation**: https://developers.openai.com/codex/rules#create-a-rules-file

Notes:
Codex CLI uses Starlark rules instead of hooks for command control. This is a fundamentally different approach - rules define static policies, while hooks run dynamic scripts. Rules can be tested with codex execpolicy check before deployment. The sandbox system provides the baseline security.

##==##

<!-- .slide: class="with-code" -->

# Codex CLI: Configuration & Profiles

**Definition**: Project and user-level settings controlling Codex's behavior, permissions, and integrations

| Setting                  | Purpose           | Example                           |
| ------------------------ | ----------------- | --------------------------------- |
| `model`                  | Default model     | `gpt-5.6-sol`                     |
| `model_reasoning_effort` | Reasoning depth   | `low/medium/high`                 |
| `approval_policy`        | Execution control | `untrusted/on-failure/on-request` |

<br>

**Location**: `.codex/config.toml` (project) · `~/.codex/config.toml` (user)

**Features**: Enable/disable with `codex features` or `[features]` in config

**📚 Documentation**: https://developers.openai.com/codex/cli/features

Notes:
As of July 2026 Codex runs on OpenAI's **GPT-5.6** family (GA July 9, 2026): **Sol** (flagship, the Codex default — `gpt-5.6-sol`, aliased by `gpt-5.6`), **Terra** (balanced), and **Luna** (fast/economical); all three ship built into the latest Codex CLI and appear in `/model`. Profiles are Codex CLI's alternative to switching between different agent personas. Instead of loading a different agent, you switch profiles that adjust model, reasoning effort, sandbox mode, and approval policy. Project-level config requires codex trust . first. The sandbox system with writable_roots provides security boundaries.

##==##

<!-- .slide: class="with-code" -->

# Codex CLI: Configuration & Profiles

**Definition**: Project and user-level settings controlling Codex's behavior, permissions, and integrations

| Setting             | Purpose                      | Example                     |
| ------------------- | ---------------------------- | --------------------------- |
| `sandbox_mode`      | Security boundary            | `read-only/workspace-write` |
| `writable_roots`    | Directories agent can modify | `["src/", "tests/"]`        |
| `profiles.<name>.*` | Named configuration presets  | `[profiles.review]`         |

<br>

**Location**: `.codex/config.toml` (project) · `~/.codex/config.toml` (user)

**Profiles**: Named presets in `[profiles.<name>]` sections, activated with `codex --profile <name>`

**📚 Documentation**: https://developers.openai.com/codex/config-advanced#profiles

Notes:
Profiles are Codex CLI's alternative to switching between different agent personas. Instead of loading a different agent, you switch profiles that adjust model, reasoning effort, sandbox mode, and approval policy. Project-level config requires codex trust . first. The sandbox system with writable_roots provides security boundaries.

##==##

<!-- .slide: class="exercice" -->

# Exercises: Codex CLI Deep Dive

## Lab 41

<br>

### 👉 Follow **instructions** in

### <code data-markdown-preview="/labs/lab-41-agentic-tools-deep-dive/README.md">labs/lab-41-agentic-tools-deep-dive/README.md</code>

### 📚 Exercises 6 to 7, Section D (Codex CLI)

Notes:

- Follow the instructions in the lab README.md for detailed steps.

##==##

<!-- .slide: class="exercice" -->

# Exercises: Codex CLI Deep Dive

## Lab 41

<br>

### 💡 Read **solution** at

### <code data-markdown-preview="/labs/lab-41-agentic-tools-deep-dive-solution/README.md">labs/lab-41-agentic-tools-deep-dive-solution/README.md</code>

### 📚 Exercises 6 to 7, Section D (Codex CLI)

Notes:

- Read the lab README.md for example of solutions.

##==##

<!-- .slide: -->

# **Codex CLI: Feature Summary**

| Feature   | Location          | Invocation       | Key Trait                       |
| --------- | ----------------- | ---------------- | ------------------------------- |
| Agents    | `.codex/agents/`  | `/agent`, auto   | TOML format, parallel execution |
| AGENTS.md | Project root      | Auto at startup  | `/init` scaffolding             |
| Skills    | `.agents/skills/` | `$name`, auto    | Progressive loading, `$` prefix |
| Rules     | `.codex/rules/`   | Auto (policy)    | Starlark, replaces hooks        |
| Profiles  | `config.toml`     | `--profile name` | Named presets                   |
| Config    | `config.toml`     | At startup       | Sandbox + approvals             |

Notes:
Codex CLI takes a fundamentally different approach to several features: TOML for agents (vs markdown), rules for command control (vs hooks), profiles for workflow switching (vs separate agents), and sandbox for security (vs hook validation). No plugin system - extensibility via MCP servers and skills.

##==##

<!-- .slide: -->

# Codex CLI: When to Use What

## Choosing the Right Feature

| Scenario                             | Use This          | Why                                            |
| ------------------------------------ | ----------------- | ---------------------------------------------- |
| Need domain-expert AI guidance       | **Custom Agent**  | TOML-defined persona in `.codex/agents/`       |
| Need project-wide conventions        | **AGENTS.md**     | Auto-read at startup, scaffolded by `/init`    |
| Need to control permissions/behavior | **Configuration** | `config.toml` for sandbox, approvals, policies |

<br>

**Agents** = TOML personas | **AGENTS.md** = project-wide context

Notes:
Codex CLI has no Hooks (uses Starlark Rules instead) and no Plugins (use MCP servers for extensibility). Custom commands are deprecated in favor of Agent Skills. Profiles are unique to Codex — they allow switching between named workflow configurations (model, sandbox, approval policy) without changing agents.

##==##

<!-- .slide: -->

# Codex CLI: When to Use What

## Choosing the Right Feature

| Scenario                            | Use This        | Why                                                  |
| ----------------------------------- | --------------- | ---------------------------------------------------- |
| Need shared knowledge across agents | **Agent Skill** | Composable, loaded via `$name` or auto-discovery     |
| Need to enforce shell/command rules | **Rules**       | Starlark-based control in `.codex/rules/` (no Hooks) |
| Need to switch between workflows    | **Profile**     | Named presets in `config.toml`, `--profile name`     |

<br>

**Skills** = composable knowledge | **Rules** = automated enforcement _(Hooks & Plugins: N/A)_

Notes:
Codex CLI has no Hooks (uses Starlark Rules instead) and no Plugins (use MCP servers for extensibility). Custom commands are deprecated in favor of Agent Skills. Profiles are unique to Codex — they allow switching between named workflow configurations (model, sandbox, approval policy) without changing agents.
