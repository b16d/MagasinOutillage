<!-- .slide: class="transition" -->

# Mistral Vibe Deep Dive

## CLI Features, Agents, Skills, Hooks, MCP, ACP Mode & Configuration

Notes:

This module dives into Mistral Vibe, an agentic coding CLI driven by the `vibe` command. We'll walk through its CLI symbols and flags, its built-in and custom agents, the skills system, TOML-based hooks and configuration, MCP integration, and its two standout capabilities — folder-trust and ACP mode. Frame this as a hands-on tour: everything covered here maps directly to what trainees will do in Lab 41. Remind the room that this tool evolves quickly, so the current documentation is the authoritative reference.

##==##

<!-- .slide: class="with-code" -->

# **Mistral Vibe: CLI Overview**

**Definition**: Vibe is an agentic coding CLI launched with the `vibe` command. In the interactive prompt, three symbols drive most interactions.

| Symbol | Purpose               | Example                    |
| ------ | --------------------- | -------------------------- |
| `@`    | Include files/context | `@src/app.py explain this` |
| `/`    | Run a slash command   | `/help`, `/setup`          |
| `!`    | Execute a shell cmd   | `!npm test`                |

<br>

**Launch**: `vibe` starts the interactive session in the current directory

**Setup**: `vibe --setup` opens the interactive configuration wizard

**📚 Documentation**: https://docs.mistral.ai/vibe/

Notes:

Vibe's prompt is built around three quick symbols so common actions stay one keystroke away. The `@` symbol pulls files or directories into the context window, `/` triggers registered slash commands, and `!` shells out to run a command without leaving the session. The `vibe` command with no arguments is the everyday entry point, while `vibe --setup` is the first thing a new user should run to configure their API key, model, and defaults. Remind trainees these symbols are the fastest way to work — no menus required.

##==##

<!-- .slide: class="with-code" -->

# **Mistral Vibe: CLI Overview**

**Definition**: Session continuity and integration modes are exposed through dedicated flags and a companion binary.

| Command / Flag    | Purpose                               |
| ----------------- | ------------------------------------- |
| `vibe --continue` | Resume the most recent session        |
| `vibe --resume`   | Pick a past session to resume         |
| `vibe --setup`    | Interactive configuration wizard      |
| `vibe-acp`        | Run Vibe as an ACP server for editors |

<br>

**Install**: `curl -LsSf https://mistral.ai/vibe/install.sh | bash` or `uv tool install mistral-vibe`

**📚 Documentation**: https://docs.mistral.ai/vibe/

Notes:

Session continuity matters for long tasks: `--continue` jumps straight back into the last conversation, while `--resume` lists past sessions so you can choose which thread to pick up. The `vibe-acp` binary runs Vibe as an Agent Client Protocol server, covered in detail later. Two install paths are offered — the shell installer script for a quick start, or `uv tool install` for teams that already standardize on uv. Mention that install commands and flags can evolve, so trainees should confirm against current docs.

##==##

<!-- .slide: class="with-code" -->

# Mistral Vibe: AGENTS.md (Context File)

**Definition**: `AGENTS.md` at the project root is the persistent context file that Vibe auto-loads at the start of every session.

| Aspect       | Detail                                       |
| ------------ | -------------------------------------------- |
| **Location** | `./AGENTS.md` (project root)                 |
| **Loading**  | Automatic at session start                   |
| **Shared**   | Committed to git, shared with the whole team |
| **Content**  | Conventions, build steps, project guidelines |

<br>

**Purpose**: Give Vibe standing project context so you don't repeat yourself each session

**📚 Documentation**: https://docs.mistral.ai/vibe/

Notes:

`AGENTS.md` is the single source of persistent project context for Vibe. Because it lives at the repository root and is committed to git, the whole team shares the same instructions — build commands, testing conventions, architectural rules, and coding standards. Vibe reads it automatically when a session starts, so there's no manual step to load it. Encourage trainees to keep this file concise and high-signal: it consumes context tokens on every session, so it should hold durable conventions, not transient notes.

##==##

<!-- .slide: class="with-code" -->

# Mistral Vibe: Built-in Agents (Modes)

**Definition**: Vibe ships four built-in agents you switch between. Each maps to a permission behavior controlling how much autonomy the assistant has.

| Agent          | Permission Behavior                   |
| -------------- | ------------------------------------- |
| `default`      | Asks before edits and commands        |
| `plan`         | Read-only planning, no changes        |
| `accept-edits` | Auto-accepts file edits               |
| `auto-approve` | Full autonomy, runs without prompting |

<br>

**Workflow**: Plan in `plan`, review, then switch to `accept-edits` or `auto-approve` to execute

**📚 Documentation**: https://docs.mistral.ai/vibe/

Notes:

The four built-in agents are really permission profiles. `default` is the safe starting point — it pauses and asks before edits or shell commands. `plan` is read-only, perfect for exploring a codebase or drafting an approach without any risk of unintended changes. `accept-edits` auto-accepts file modifications but still gates other actions, and `auto-approve` grants full autonomy for trusted, well-scoped tasks. A common workflow is to start in `plan`, agree on the approach, then escalate to `accept-edits` for the implementation. Stress that `auto-approve` should be reserved for tasks you fully trust.

##==##

<!-- .slide: class="with-code" -->

# Mistral Vibe: Custom Agents

**Definition**: Beyond the built-in agents, you can define your own specialized agents as Markdown files with a name, description, and system prompt.

| Field         | Purpose                                     |
| ------------- | ------------------------------------------- |
| `name`        | Identifier for the agent                    |
| `description` | When Vibe should use this agent             |
| System prompt | Markdown body defining the agent's behavior |

<br>

**Location**: `.vibe/agents/` (project-level custom agent definitions)

**Format**: Markdown files — the body is the agent's system prompt

**📚 Documentation**: https://docs.mistral.ai/vibe/

Notes:

Custom agents let you package a domain-expert persona — a security reviewer, a test writer, an API designer — as a reusable Markdown file in `.vibe/agents/`. Each file carries a name, a description that tells Vibe when the agent is relevant, and a Markdown body that becomes the system prompt. Because they're plain Markdown committed to the repo, custom agents are easy to version and share across the team. Point out that a sharp, specific description is what makes an agent activate at the right moment.

##==##

<!-- .slide: class="exercice" -->

# Exercises: Mistral Vibe CLI Deep Dive

## Lab 41

<br>

### 👉 Follow **instructions** in

### <code data-markdown-preview="/labs/lab-41-agentic-tools-deep-dive/README.md">labs/lab-41-agentic-tools-deep-dive/README.md</code>

### 📚 Exercises 1 to 3, Section F (Mistral Vibe CLI)

Notes:

- Follow the instructions in the lab README.md for detailed steps.

##==##

<!-- .slide: class="exercice" -->

# Exercises: Mistral Vibe CLI Deep Dive

## Lab 41

<br>

### 💡 Read **solution** at

### <code data-markdown-preview="/labs/lab-41-agentic-tools-deep-dive-solution/README.md">labs/lab-41-agentic-tools-deep-dive-solution/README.md</code>

### 📚 Exercises 1 to 3, Section F (Mistral Vibe CLI)

Notes:

- Read the lab README.md for example of solutions.

##==##

<!-- .slide: class="with-code" -->

# Mistral Vibe: Slash Commands via Skills

**Definition**: Custom slash commands in Vibe are delivered through the skills system — a skill can expose a command you invoke with `/`.

| Aspect         | Detail                                    |
| -------------- | ----------------------------------------- |
| **Mechanism**  | Provided through the skills system        |
| **Invocation** | `/command-name` in the interactive prompt |
| **Source**     | Defined as skills (see next slide)        |
| **Use case**   | Repeatable, named prompts and workflows   |

<br>

**Takeaway**: There's no separate "commands" folder — author a skill to add a custom slash command

**📚 Documentation**: https://docs.mistral.ai/vibe/

Notes:

Vibe unifies custom commands and skills: rather than a dedicated commands directory, you author a skill and it becomes available as a slash command. This keeps a single extension model instead of two parallel systems. Users still invoke commands the familiar way, typing `/` followed by the name in the prompt. Emphasize that when trainees want a reusable, named workflow, the answer in Vibe is "write a skill" — the skill both encapsulates the knowledge and surfaces the command.

##==##

<!-- .slide: class="with-code" -->

# Mistral Vibe: Agent Skills

**Definition**: Reusable instruction packages following the `SKILL.md` standard — loaded progressively and activated on demand.

| Feature             | Detail                                                   |
| ------------------- | -------------------------------------------------------- |
| **Format**          | `SKILL.md` with name + description frontmatter           |
| **Loading**         | Progressive — description first, full body on activation |
| **Auto-activation** | Vibe loads the right skill contextually                  |
| **Also powers**     | Custom slash commands                                    |

<br>

**Progressive loading**: only descriptions cost tokens at startup; full content loads when a skill is needed

**📚 Documentation**: https://docs.mistral.ai/vibe/

Notes:

Skills are Vibe's core extensibility mechanism. Each skill is a `SKILL.md` file with frontmatter declaring a name and description, plus a body containing the detailed instructions. Progressive loading keeps context lean: at startup Vibe only reads the short descriptions, and it loads a skill's full content only when it decides the skill is relevant to the task. This auto-activation means users don't have to remember to invoke skills manually. Remind trainees that a well-written description is what lets Vibe pick the right skill at the right time.

##==##

<!-- .slide: class="exercice" -->

# Exercises: Mistral Vibe CLI Deep Dive

## Lab 41

<br>

### 👉 Follow **instructions** in

### <code data-markdown-preview="/labs/lab-41-agentic-tools-deep-dive/README.md">labs/lab-41-agentic-tools-deep-dive/README.md</code>

### 📚 Exercises 4 to 6, Section F (Mistral Vibe CLI)

Notes:

- Follow the instructions in the lab README.md for detailed steps.

##==##

<!-- .slide: class="exercice" -->

# Exercises: Mistral Vibe CLI Deep Dive

## Lab 41

<br>

### 💡 Read **solution** at

### <code data-markdown-preview="/labs/lab-41-agentic-tools-deep-dive-solution/README.md">labs/lab-41-agentic-tools-deep-dive-solution/README.md</code>

### 📚 Exercises 4 to 6, Section F (Mistral Vibe CLI)

Notes:

- Read the lab README.md for example of solutions.

##==##

<!-- .slide: class="with-code" -->

# Mistral Vibe: Hooks

**Definition**: Lifecycle callbacks defined declaratively in TOML at `.vibe/hooks.toml` — run logic before or after events like tool execution.

```toml
# .vibe/hooks.toml
[[hooks.pre_tool_use]]
matcher = "bash"
type = "prompt"
prompt = "Check if this shell command is a git commit. If so, verify staged files follow coding standards before allowing the commit."

[[hooks.post_tool_use]]
matcher = "write|edit"
type = "prompt"
prompt = "Validate the file changes against coding-standards.md. Check they follow the project's coding standards."
```

**Location**: `.vibe/hooks.toml` (project-level)

**Use cases**: pre/post tool execution — validation, formatting, guardrails

**📚 Documentation**: https://docs.mistral.ai/vibe/

Notes:

Hooks let you wire deterministic automation into the agent's lifecycle without writing plugin code. They are declared in TOML at `.vibe/hooks.toml`, keeping configuration readable and version-controlled. Each hook is declared under an event table such as `[[hooks.pre_tool_use]]`, where you can validate or block an action before it runs, or `[[hooks.post_tool_use]]`, where you can format code or run linters after a change. A `matcher` scopes the hook to specific tools (e.g. `bash`, `write|edit`), and `type = "prompt"` runs the given `prompt` at that point in the lifecycle. Because hooks are declarative TOML rather than a scripting API, they're approachable for teams that want guardrails without maintaining a codebase.

##==##

<!-- .slide: class="exercice" -->

# Exercises: Mistral Vibe CLI Deep Dive

## Lab 41

<br>

### 👉 Follow **instructions** in

### <code data-markdown-preview="/labs/lab-41-agentic-tools-deep-dive/README.md">labs/lab-41-agentic-tools-deep-dive/README.md</code>

### 📚 Exercise 7, Section F (Mistral Vibe CLI)

Notes:

- Follow the instructions in the lab README.md for detailed steps.

##==##

<!-- .slide: class="exercice" -->

# Exercises: Mistral Vibe CLI Deep Dive

## Lab 41

<br>

### 💡 Read **solution** at

### <code data-markdown-preview="/labs/lab-41-agentic-tools-deep-dive-solution/README.md">labs/lab-41-agentic-tools-deep-dive-solution/README.md</code>

### 📚 Exercise 7, Section F (Mistral Vibe CLI)

Notes:

- Read the lab README.md for example of solutions.

##==##

<!-- .slide: class="with-code" -->

# Mistral Vibe: MCP Servers

**Definition**: Vibe can connect to Model Context Protocol (MCP) servers to expose additional tools to the model.

| Aspect       | Detail                                         |
| ------------ | ---------------------------------------------- |
| **Protocol** | Model Context Protocol (MCP)                   |
| **Purpose**  | Add external tools beyond the built-ins        |
| **Config**   | Declared in Vibe's TOML configuration          |
| **Result**   | MCP tools available to the model automatically |

<br>

**Once connected**: MCP tools sit alongside Vibe's native tools with no extra prompting

**📚 Documentation**: https://docs.mistral.ai/vibe/

Notes:

MCP support means Vibe isn't limited to its built-in tools — you can plug in servers that expose databases, issue trackers, browsers, or any other capability that speaks the Model Context Protocol. Servers are declared in Vibe's TOML configuration, and once connected their tools become available to the model automatically, alongside the native tools. This is the standard way to extend Vibe with custom or third-party integrations. Point trainees to Module 5 for a deeper treatment of MCP setup and usage.

##==##

<!-- .slide: class="with-code" -->

# Mistral Vibe: Folder-Trust & ACP Mode

**Definition**: Two standout capabilities — a security gate on untrusted repos, and an embeddable server mode for editors.

| Capability       | What it does                                            |
| ---------------- | ------------------------------------------------------- |
| **Folder-trust** | Prompts before loading a directory's `.vibe/` config    |
| **ACP mode**     | `vibe-acp` runs Vibe as an Agent Client Protocol server |

<br>

**Folder-trust**: on first launch in a directory, Vibe asks you to trust it before loading local `.vibe/` config — a guard against malicious project configs

**ACP mode**: embed Vibe inside any ACP-compatible editor or client via `vibe-acp`

**📚 Documentation**: https://docs.mistral.ai/vibe/

Notes:

Folder-trust is a security feature: because a repository can ship its own `.vibe/` config, agents, hooks, and skills, opening an untrusted repo could otherwise execute unexpected behavior. Vibe defends against this by prompting for trust the first time you launch in a directory, and only then loading that project's local configuration. ACP mode is about integration — running `vibe-acp` turns Vibe into an Agent Client Protocol server, so it can be embedded directly inside editors and clients that speak ACP, rather than only running standalone in a terminal. Together these make Vibe both safer to run on unknown code and flexible to embed in a wider toolchain.

##==##

<!-- .slide: class="with-code" -->

# Mistral Vibe: Configuration

**Definition**: Vibe is configured with TOML files at two levels — project and global. Project settings override global ones.

```toml
# .vibe/config.toml (project)
model = "mistral-large-latest"
permission_mode = "default"

[tools]
# tool-specific settings
```

| Level       | File                  | Scope                      |
| ----------- | --------------------- | -------------------------- |
| **Project** | `.vibe/config.toml`   | This repository            |
| **Global**  | `~/.vibe/config.toml` | All projects for this user |

**Permission modes**: `default` · `plan` · `accept-edits` · `auto-approve`

**📚 Documentation**: https://docs.mistral.ai/vibe/

Notes:

Vibe uses TOML for configuration, consistent with its hooks format. The global file at `~/.vibe/config.toml` holds user-wide defaults like your model choice and API credentials, while the project file at `.vibe/config.toml` carries repository-specific settings and can be committed for the team. Project values take precedence over global ones. The `permission_mode` key sets the starting agent behavior — the same four modes (default, plan, accept-edits, auto-approve) available at runtime. Encourage keeping secrets in the global file and shareable conventions in the project file.

##==##

<!-- .slide: class="exercice" -->

# Exercises: Mistral Vibe CLI Deep Dive

## Lab 41

<br>

### 👉 Follow **instructions** in

### <code data-markdown-preview="/labs/lab-41-agentic-tools-deep-dive/README.md">labs/lab-41-agentic-tools-deep-dive/README.md</code>

### 📚 Exercises 8 to 9, Section F (Mistral Vibe CLI)

Notes:

- Follow the instructions in the lab README.md for detailed steps.

##==##

<!-- .slide: class="exercice" -->

# Exercises: Mistral Vibe CLI Deep Dive

## Lab 41

<br>

### 💡 Read **solution** at

### <code data-markdown-preview="/labs/lab-41-agentic-tools-deep-dive-solution/README.md">labs/lab-41-agentic-tools-deep-dive-solution/README.md</code>

### 📚 Exercises 8 to 9, Section F (Mistral Vibe CLI)

Notes:

- Read the lab README.md for example of solutions.

##==##

<!-- .slide: -->

# **Mistral Vibe: Feature Summary**

| Feature         | Location        | Invocation        | Key Trait                   |
| --------------- | --------------- | ----------------- | --------------------------- |
| AGENTS.md       | `./AGENTS.md`   | Auto at startup   | Persistent project context  |
| Built-in agents | Built-in        | Runtime switch    | default/plan/accept/auto    |
| Custom agents   | `.vibe/agents/` | Auto / contextual | Markdown, description-based |
| Skills          | `SKILL.md`      | Auto on demand    | Progressive loading         |
| Commands        | Skills system   | `/name`           | Delivered via skills        |

Notes:

This first summary table groups Vibe's knowledge and behavior features. AGENTS.md is the always-on context file; the four built-in agents give instant control over autonomy; custom agents add domain personas; and skills are the unifying extension mechanism that also powers slash commands. Use this slide as a quick mental map before the exercise — each row is a place trainees can extend or steer Vibe.

##==##

<!-- .slide: -->

# **Mistral Vibe: Feature Summary**

| Feature      | Location            | Invocation   | Key Trait                    |
| ------------ | ------------------- | ------------ | ---------------------------- |
| Hooks        | `.vibe/hooks.toml`  | Event-based  | Declarative TOML callbacks   |
| MCP Servers  | Config (TOML)       | Auto (tools) | External tool integration    |
| Config       | `.vibe/config.toml` | At startup   | Project + global, TOML       |
| ACP mode     | `vibe-acp` binary   | Editor embed | Agent Client Protocol server |
| Folder-trust | First launch        | Trust prompt | Security gate on `.vibe/`    |

Notes:

This second summary covers Vibe's automation, integration, and safety features. Hooks provide declarative lifecycle automation in TOML; MCP servers extend the toolset; configuration is layered project-over-global in TOML; ACP mode lets Vibe live inside editors; and folder-trust guards against untrusted project configs. Together with the previous table these two slides cover the full surface area trainees will touch in the lab.

##==##

<!-- .slide: -->

# Mistral Vibe: When to Use What

## Choosing the Right Feature

| Scenario                        | Use This            | Why                                                    |
| ------------------------------- | ------------------- | ------------------------------------------------------ |
| Always-on project conventions   | **AGENTS.md**       | Auto-loaded at startup, shared via git                 |
| Read-only analysis without risk | **`plan` agent**    | No changes made — safe exploration and planning        |
| Domain-expert guidance          | **Custom agent**    | Markdown persona in `.vibe/agents/`, description-based |
| Reusable named workflow         | **Skill (command)** | `/name` via the skills system, auto-activated          |

<br>

**AGENTS.md** = standing context | **Agents** = safe planning vs autonomous execution

Notes:

This slide helps trainees match a need to the right Vibe feature. Reach for AGENTS.md when the knowledge should always be present; switch to the plan agent when you want analysis with zero risk of edits; author a custom agent when you need a persistent specialist persona; and write a skill when you want a reusable, named workflow that Vibe can activate on its own. The recurring theme is that Vibe favors a small set of composable mechanisms over many overlapping ones.

##==##

<!-- .slide: -->

# Mistral Vibe: When to Use What

## Choosing the Right Feature

| Scenario                        | Use This         | Why                                                     |
| ------------------------------- | ---------------- | ------------------------------------------------------- |
| Enforce checks around tool runs | **Hooks**        | Declarative TOML in `.vibe/hooks.toml`, pre/post events |
| Add external tools / APIs       | **MCP servers**  | Connect MCP servers via TOML config                     |
| Embed Vibe in an editor         | **ACP mode**     | `vibe-acp` exposes an Agent Client Protocol server      |
| Work safely in an unknown repo  | **Folder-trust** | Prompt before loading local `.vibe/` config             |

<br>

**Hooks** = deterministic guardrails | **MCP** = capability extension | **ACP** = integration

Notes:

The second decision table covers automation and integration. Use hooks when you want deterministic, always-run guardrails around tool execution; use MCP servers to give Vibe new capabilities like databases or browsers; use ACP mode when you want Vibe inside your editor rather than a standalone terminal; and rely on folder-trust as your safety net when opening repositories you don't fully trust. Close by reminding trainees that these features evolve, so they should confirm exact flags, file names, and behaviors against the current documentation at https://docs.mistral.ai/vibe/.
