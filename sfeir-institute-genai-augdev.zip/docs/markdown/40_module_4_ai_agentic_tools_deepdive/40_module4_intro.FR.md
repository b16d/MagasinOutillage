<!-- .slide: class="transition" -->

# Vue d'ensemble du module 4

## Outils agentiques en profondeur : forces, fonctionnalités, quand utiliser quoi

##==##

<!-- .slide -->

# Objectifs pédagogiques

À la fin de ce module, vous saurez :

- **Maîtriser** les principales fonctionnalités, commandes et raccourcis CLI de Claude Code, GitHub Copilot, Codex CLI, Gemini CLI et OpenCode
- **Créer** des agents et des commandes personnalisés adaptés aux workflows de votre équipe
- **Configurer** skills d'agent, hooks, plugins et fichiers de configuration pour automatiser le contrôle qualité
- **Choisir** le bon type de fonctionnalité (agent, commande, skill, hook, plugin) selon le cas d'usage

Notes:
Ce module propose une plongée pratique dans la personnalisation des outils de codage agentique pour une adoption de l'IA à l'échelle de l'équipe. Note (juillet 2026) : le parcours Gemini CLI est conservé à titre historique et comparatif uniquement — Gemini CLI a été retiré en mai 2026 (fin de l'accès grand public le 18 juin 2026) et remplacé par Antigravity CLI de Google. Présentez-le comme « son fonctionnement passé », pas comme un outil encore supporté.

##==##

<!-- .slide -->

# Prérequis

## Ce qu'il faut savoir

<br>

### Issu du module 3

- Compréhension des workflows de codage agentique
- Expérience des pratiques de développement assisté par IA
- Familiarité avec au moins un outil agentique (Claude Code, Copilot, Gemini CLI, Codex CLI ou OpenCode)

### Pour la pratique

<!-- .element: class="md-padding-top" -->

- Accès au CLI d'au moins un outil agentique
- Expérience du terminal / de la ligne de commande
- Git installé et configuré

Notes:
Ce module s'appuie sur les concepts de codage agentique du module 3 et approfondit les fonctionnalités de personnalisation des outils.
