<!-- .slide: class="transition" -->

# OpenCode Deep Dive

## CLI Features, Agents, Commands, Skills, Plugins, Modes & Configuration

##==##

<!-- .slide: -->

# **OpenCode: CLI Overview**

| Feature         | How            | Example                            |
| --------------- | -------------- | ---------------------------------- |
| Slash commands  | `/` prefix     | `/init`, `/help`, `/status`        |
| Command palette | `Ctrl+P`       | Search and execute all commands    |
| Switch agent    | `Tab`          | Toggle between `build` and `plan`  |
| Switch model    | `Ctrl+X M`     | Pick provider/model interactively  |
| Permissions     | Dialog or `-p` | Approve / deny / allow for session |

<br>

**Leader key**: `Ctrl+X` (customizable) — most multi-key actions use `Ctrl+X <key>`

**📚 Documentation**: https://opencode.ai/docs/

Notes:
OpenCode uses a terminal UI (TUI) built with Bubble Tea. The leader key pattern (Ctrl+X by default) avoids conflicts with terminal sequences. Ctrl+P opens the command palette to search all registered commands. The Tab key is the fastest way to switch between the two built-in primary agents.

##==##

<!-- .slide: -->

# **OpenCode: CLI Overview**

| Feature              | How                 | Example                         |
| -------------------- | ------------------- | ------------------------------- |
| Non-interactive mode | `opencode -p`       | `opencode -p "fix tests"`       |
| List models          | `opencode models`   | Shows all provider/model combos |
| Start server         | `opencode serve`    | Headless API for integrations   |
| Session management   | `opencode sessions` | List and export past sessions   |
| New session          | `Ctrl+X N`          | Start a fresh conversation      |

<br>

**📚 Documentation**: https://opencode.ai/docs/cli/

Notes:
The -p flag runs opencode in non-interactive mode — ideal for scripting, CI/CD, and automation. All permissions are auto-approved in this mode. Sessions are stored in SQLite and can be exported as JSON. The opencode serve command exposes a headless API that can be used to orchestrate multiple instances via external scripts.

##==##

<!-- .slide: class="with-code" -->

# OpenCode: AGENTS.md (Context File)

**Definition**: Persistent project instructions that OpenCode reads at the start of every session. Provides project-specific context, conventions, and guidelines.

| Level           | File                           | Scope                                |
| --------------- | ------------------------------ | ------------------------------------ |
| **Project**     | `./AGENTS.md`                  | Shared with team via git             |
| **User global** | `~/.config/opencode/AGENTS.md` | Personal, applies to all projects    |
| **Nested**      | `<subdir>/AGENTS.md`           | Subdirectory-specific (closest wins) |

<br>

**Create/Update**: `/init` analyzes the codebase and creates or updates AGENTS.md

**Extra instructions**: Point `opencode.json` at any `.md` file via the `instructions` config key

**📚 Documentation**: https://opencode.ai/docs/rules/

Notes:
AGENTS.md is the same standard used by Codex CLI — OpenCode's equivalent to Claude's CLAUDE.md. The /init command scans your project to auto-generate it with build steps, tests, and conventions. Nested AGENTS.md files let packages in a monorepo carry their own context. The instructions config option lets you reuse existing docs without duplicating content in AGENTS.md.

##==##

<!-- .slide: class="with-code" -->

# OpenCode: Built-in Modes (Agents)

**Definition**: OpenCode ships with two primary agents you can switch with `Tab`. Modes customize tools, prompts, and permissions for different use cases.

| Mode    | Description                   | Tools Enabled |
| ------- | ----------------------------- | ------------- |
| `build` | Default — full development    | All tools     |
| `plan`  | Read-only analysis & planning | No edit tools |

<br>

**Switch**: `Tab` to toggle · `Ctrl+X M` to pick any mode

**Custom modes**: Define in `opencode.json` under `$schema` modes section

**📚 Documentation**: https://opencode.ai/docs/modes/

Notes:
Build mode is the default — it gives the model full access to file operations and system commands. Plan mode disables editing tools, making it safe for code exploration, architecture review, or planning without any unintended changes. The Tab key is the fastest workflow: switch to plan, get the architecture decision, then Tab back to build to implement it.

##==##

<!-- .slide: class="with-code" -->

# OpenCode: Custom Agents

**Definition**: Specialized AI agents with custom system prompts, model settings, and tool access — defined as Markdown files

| Field         | Required | Description                                                 |
| ------------- | -------- | ----------------------------------------------------------- |
| `name`        | No       | Identifier (defaults to filename without extension)         |
| `description` | Yes      | When OpenCode should activate this agent                    |
| `model`       | No       | Provider/model override (e.g., `anthropic/claude-sonnet-5`) |

<br>

**Location**: `.opencode/agents/` (project) · `~/.config/opencode/agents/` (global)

**Format**: Markdown files (`.md`) with YAML frontmatter

**📚 Documentation**: https://opencode.ai/docs/agents/

Notes:
Custom agents in OpenCode follow the same Markdown + YAML frontmatter pattern as Claude Code. The description field is critical — OpenCode reads descriptions at startup to decide when to activate an agent contextually. Agents can override the model, giving different specialists access to different AI providers or model tiers.

##==##

<!-- .slide: class="exercice" -->

# Exercises: Opencode CLI Deep Dive

## Lab 41

<br>

### 👉 Follow **instructions** in

### <code data-markdown-preview="/labs/lab-41-agentic-tools-deep-dive/README.md">labs/lab-41-agentic-tools-deep-dive/README.md</code>

### 📚 Exercises 1 to 3, Section E (Opencode CLI)

Notes:

- Follow the instructions in the lab README.md for detailed steps.

##==##

<!-- .slide: class="exercice" -->

# Exercises: Opencode CLI Deep Dive

## Lab 41

<br>

### 💡 Read **solution** at

### <code data-markdown-preview="/labs/lab-41-agentic-tools-deep-dive-solution/README.md">labs/lab-41-agentic-tools-deep-dive-solution/README.md</code>

### 📚 Exercises 1 to 3, Section E (Opencode CLI)

Notes:

- Read the lab README.md for example of solutions.

##==##

<!-- .slide: class="with-code" -->

# OpenCode: Custom Commands

**Definition**: User-defined slash commands that send predefined prompts to the AI assistant — stored as Markdown files

| Feature          | Details                                                                   |
| ---------------- | ------------------------------------------------------------------------- |
| **Location**     | `.opencode/commands/` (project) · `~/.config/opencode/commands/` (global) |
| **Format**       | `.md` files — filename becomes the command ID                             |
| **Invocation**   | `/command-name` in the TUI prompt                                         |
| **Agent option** | Frontmatter `agent:` key to route to a specific agent                     |

<br>

**Example**: `.opencode/commands/code-reviewer.md` → invoked as `/code-reviewer`

**📚 Documentation**: https://opencode.ai/docs/commands/

Notes:
Custom commands are the equivalent of Claude's custom commands in .claude/commands/. They are Markdown files where the file name becomes the slash command. Use the agent frontmatter key to route the command to a specific custom agent. Commands are great for repetitive tasks: code review, architecture checks, documentation generation.

##==##

<!-- .slide: class="with-code" -->

# OpenCode: Agent Skills

**Definition**: Reusable prompt instructions following the SKILL.md standard — loaded on demand via the native skill tool

| Feature             | Details                                                                              |
| ------------------- | ------------------------------------------------------------------------------------ |
| **Location**        | `.opencode/skills/<name>/SKILL.md` (project) · `~/.config/opencode/skills/` (global) |
| **Loading**         | Progressive — only description loaded at startup; full content on activation         |
| **Auto-activation** | Agent sees available skills and loads the right one contextually                     |

<br>

**Public Registries**: [🔗 https://skills.sh](https://skills.sh) — [🔗 https://tessl.io/registry](https://tessl.io/registry)

**📚 Documentation**: https://opencode.ai/docs/skills

Notes:
OpenCode supports the same cross-platform SKILL.md format as Claude Code, Codex CLI, Gemini CLI, and GitHub Copilot. Skills can embed their own MCP server definitions in frontmatter (mcp.json), making them self-contained knowledge packages. The native skill tool means skills are loaded into context automatically when the agent decides they are relevant — no explicit $name invocation needed.

##==##

<!-- .slide: class="exercice" -->

# Exercises: Opencode CLI Deep Dive

## Lab 41

<br>

### 👉 Follow **instructions** in

### <code data-markdown-preview="/labs/lab-41-agentic-tools-deep-dive/README.md">labs/lab-41-agentic-tools-deep-dive/README.md</code>

### 📚 Exercises 4 to 7, Section E (Opencode CLI)

Notes:

- Follow the instructions in the lab README.md for detailed steps.

##==##

<!-- .slide: class="exercice" -->

# Exercises: Opencode CLI Deep Dive

## Lab 41

<br>

### 💡 Read **solution** at

### <code data-markdown-preview="/labs/lab-41-agentic-tools-deep-dive-solution/README.md">labs/lab-41-agentic-tools-deep-dive-solution/README.md</code>

### 📚 Exercises 4 to 7, Section E (Opencode CLI)

Notes:

- Read the lab README.md for example of solutions.

##==##

<!-- .slide: class="with-code" -->

# OpenCode: Plugins

**Definition**: Extend OpenCode with custom behavior via JavaScript/TypeScript plugins — hook into tool events and add custom tools

```js
// .opencode/plugins/pre-validate.js
export const PreValidatePlugin = async ({ $ }) => {
  return {
    'tool.execute.before': async (input, output) => {
      if (input.tool === 'bash') {
        await $`./scripts/validate.sh ${output.args.command}`;
      }
    },
  };
};
```

**Location**: `.opencode/plugins/` (project) · `~/.config/opencode/plugins/` (global)

**Key events**: `tool.execute.before` · `tool.execute.after` · `session.idle` · `shell.env`

**📚 Documentation**: https://opencode.ai/docs/plugins/

Notes:
OpenCode plugins are JavaScript or TypeScript files placed in `.opencode/plugins/`. Each plugin exports a function that returns a hooks object keyed by event names. The `tool.execute.before` event fires before every tool call — use it for pre-validation, blocking unsafe operations, or modifying arguments. Unlike Claude Code's JSON-configured hooks in settings.json, OpenCode plugins are full code with access to Bun's shell API ($), the opencode SDK client, and npm packages. Or configure via `opencode.json` under the `"plugin"` key to load from npm.

##==##

<!-- .slide: class="exercice" -->

# Exercises: Opencode CLI Deep Dive

## Lab 41

<br>

### 👉 Follow **instructions** in

### <code data-markdown-preview="/labs/lab-41-agentic-tools-deep-dive/README.md">labs/lab-41-agentic-tools-deep-dive/README.md</code>

### 📚 Exercise 8, Section E (Opencode CLI)

Notes:

- Follow the instructions in the lab README.md for detailed steps.

##==##

<!-- .slide: class="exercice" -->

# Exercises: Opencode CLI Deep Dive

## Lab 41

<br>

### 💡 Read **solution** at

### <code data-markdown-preview="/labs/lab-41-agentic-tools-deep-dive-solution/README.md">labs/lab-41-agentic-tools-deep-dive-solution/README.md</code>

### 📚 Exercise 8, Section E (Opencode CLI)

Notes:

- Read the lab README.md for example of solutions.

##==##

<!-- .slide: class="with-code" -->

# OpenCode: Configuration

**Definition**: Project and user-level settings in `opencode.json` (JSONC supported)

| Setting        | Purpose            | Example                              |
| -------------- | ------------------ | ------------------------------------ |
| `model`        | Default model      | `"anthropic/claude-sonnet-5"`        |
| `provider`     | Provider API keys  | `{ "anthropic": { "apiKey": "…" } }` |
| `instructions` | Extra context file | `"./team-conventions.md"`            |

<br>

**Project config**: `./opencode.json` (highest precedence)

**User config**: `~/.config/opencode/opencode.json`

**📚 Documentation**: https://opencode.ai/docs/config/

Notes:
OpenCode uses a "later wins" merge strategy: user config → project config → CLI flags. Store API keys in the user-level config and project conventions in project-level config. The instructions key lets you point to any markdown file (e.g., your existing README or a team conventions doc) without duplicating it into AGENTS.md.

##==##

<!-- .slide: class="with-code" -->

# OpenCode: Configuration

**Definition**: Project and user-level settings in `opencode.json` (JSONC supported)

| Setting              | Purpose                    | Example                                       |
| -------------------- | -------------------------- | --------------------------------------------- |
| `disabled_providers` | Skip auto-loaded providers | `["openai"]`                                  |
| `permission`         | Tool execution rules       | `{ "allow": ["read_file"], "ask": ["bash"] }` |
| `mcp`                | MCP server defs            | `{ "my-tool": { "type": "local", … } }`       |

<br>

**TUI config**: separate `tui.json` (or `tui.jsonc`) for UI preferences

**📚 Documentation**: https://opencode.ai/docs/config/

Notes:
The disabled_providers setting is useful when multiple provider credentials exist but you only want one active for a project. The permission config lets you pre-authorize specific tools (like read_file) without user prompts, keeping workflows smooth while still gating higher-risk operations like bash.

##==##

<!-- .slide: class="exercice" -->

# Exercises: Opencode CLI Deep Dive

## Lab 41

<br>

### 👉 Follow **instructions** in

### <code data-markdown-preview="/labs/lab-41-agentic-tools-deep-dive/README.md">labs/lab-41-agentic-tools-deep-dive/README.md</code>

### 📚 Exercise 9 (optional), Section E (Opencode CLI)

Notes:

- Follow the instructions in the lab README.md for detailed steps.

##==##

<!-- .slide: class="exercice" -->

# Exercises: Opencode CLI Deep Dive

## Lab 41

<br>

### 💡 Read **solution** at

### <code data-markdown-preview="/labs/lab-41-agentic-tools-deep-dive-solution/README.md">labs/lab-41-agentic-tools-deep-dive-solution/README.md</code>

### 📚 Exercise 9 (optional), Section E (Opencode CLI)

Notes:

- Read the lab README.md for example of solutions.

##==##

<!-- .slide: -->

# **OpenCode: Feature Summary**

| Feature   | Location                   | Invocation        | Key Trait                    |
| --------- | -------------------------- | ----------------- | ---------------------------- |
| AGENTS.md | `./AGENTS.md`              | Auto at startup   | Cross-platform context file  |
| Modes     | Built-in / `opencode.json` | `Tab` / `Ctrl+P`  | Build vs Plan out of the box |
| Agents    | `.opencode/agents/`        | Auto / contextual | Markdown, description-based  |
| Commands  | `.opencode/commands/`      | `/name`           | Slash commands, one-shot     |
| Skills    | `.opencode/skills/<name>/` | Auto / tool call  | SKILL.md, progressive load   |

Notes:
OpenCode plugins in `.opencode/plugins/` serve as both the hook and plugin system. Use the `tool.execute.before` event for pre-validation logic (equivalent to Claude Code's PreToolUse) and `tool.execute.after` for post-processing. The permission system provides declarative allow/ask/deny rules; plugins provide full programmatic control via JS/TS code. The built-in build/plan mode toggle is a standout feature not found in other tools. Multi-provider support and the MIT license make it unique in the ecosystem.

##==##

<!-- .slide: -->

# **OpenCode: Feature Summary**

| Feature     | Location                 | Invocation        | Key Trait                    |
| ----------- | ------------------------ | ----------------- | ---------------------------- |
| Plugins     | `.opencode/plugins/`     | Event-based hooks | JS/TS, `tool.execute.before` |
| Permissions | `opencode.json` / dialog | Per tool call     | Allow / Ask / Deny           |
| MCP Servers | `opencode.json` / skill  | Auto (tools)      | Local or remote, extensible  |
| Config      | `opencode.json`          | At startup        | Multi-level merge            |

Notes:
OpenCode plugins in `.opencode/plugins/` serve as both the hook and plugin system. Use the `tool.execute.before` event for pre-validation logic (equivalent to Claude Code's PreToolUse) and `tool.execute.after` for post-processing. The permission system provides declarative allow/ask/deny rules; plugins provide full programmatic control via JS/TS code. The built-in build/plan mode toggle is a standout feature not found in other tools. Multi-provider support and the MIT license make it unique in the ecosystem.

##==##

<!-- .slide: -->

# OpenCode: When to Use What

## Choosing the Right Feature

| Scenario                             | Use This           | Why                                                          |
| ------------------------------------ | ------------------ | ------------------------------------------------------------ |
| Need always-on project conventions   | **AGENTS.md**      | Auto-read at startup, same format as Codex CLI               |
| Need read-only analysis without risk | **Plan mode**      | Tab to switch — no edit tools, ideal for architecture review |
| Need domain-expert AI guidance       | **Custom Agent**   | Markdown persona in `.opencode/agents/`, description-based   |
| Need reusable prompt for a task      | **Custom Command** | `/command-name` in `.opencode/commands/` — one-shot          |

<br>

**AGENTS.md** = always-on project context | **Modes** = safe exploration vs active coding

Notes:
OpenCode's philosophy is simplicity: two built-in modes (build/plan) cover most workflow needs without defining custom agents. Add custom agents only when you need a persistent domain-expert persona. Skills handle the composable knowledge use case. The permission system replaces hooks for quality enforcement.

##==##

<!-- .slide: -->

# OpenCode: When to Use What

## Choosing the Right Feature

| Scenario                            | Use This            | Why                                                        |
| ----------------------------------- | ------------------- | ---------------------------------------------------------- |
| Need shared knowledge across agents | **Agent Skill**     | SKILL.md in `.opencode/skills/`, auto-loaded on demand     |
| Need tool execution control         | **Permissions**     | `permission` config in `opencode.json`, or session dialogs |
| Need custom tools / external APIs   | **MCP Servers**     | `mcp` key in `opencode.json` or skill-embedded MCP         |
| Need to switch AI providers freely  | **Provider config** | 75+ providers, bring your own API key                      |

<br>

**Skills** = composable knowledge | **Permissions** = execution control _(Hooks & Plugins: N/A)_

Notes:
OpenCode does not support hooks or plugins. Use permissions + modes for the hook use case (enforcement before/after actions). For the plugin use case, skills with embedded MCP servers are the recommended approach. The wide provider support (75+ providers including local Ollama) is OpenCode's standout differentiator for teams with varying AI provider agreements.
