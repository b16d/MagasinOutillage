<!-- .slide: class="transition" -->

# Codex CLI Deep Dive

## Fonctionnalités CLI, agents, skills, profils & configuration

##==##

<!-- .slide: -->

# **Codex CLI : vue d'ensemble CLI**

| Fonction         | Comment     | Exemple                          |
| ---------------- | ----------- | -------------------------------- |
| Inclure fichiers | symbole `@` | `@src/api/` recherche floue      |
| Invoquer skills  | préfixe `$` | `$skill-name "prompt"`           |
| Exécuter bash    | préfixe `!` | `!ls`, `!git status`             |
| Commandes slash  | préfixe `/` | `/init`, `/model`, `/plan`       |
| Approbation      | option `-a` | `untrusted / on-request / never` |

<br>

**📚 Documentation** : https://developers.openai.com/codex/cli/features

Notes:
Codex CLI partage les mêmes symboles @/!/$ que Claude Code. @ ouvre un sélecteur de fichiers flou sur la racine de votre workspace. ! exécute des commandes shell locales. $ invoque explicitement des skills. Les politiques d'approbation contrôlent ce que Codex exécute sans demander : untrusted (commandes de confiance uniquement), on-request (le modèle décide), never (totalement automatique).

##==##

<!-- .slide: -->

# **Codex CLI : vue d'ensemble CLI**

| Fonction             | Comment                     | Exemple                             |
| -------------------- | --------------------------- | ----------------------------------- |
| Éditer msg précédent | `Esc Esc`                   | Remonter dans le transcript         |
| Éditeur externe      | `Ctrl+G`                    | Rédiger longs prompts               |
| Reprise de session   | `/resume` \| `codex resume` | Restaurer une session               |
| Forker le thread     | `/fork`                     | Cloner le thread pour explorer      |
| Gestion du contexte  | `/compact`                  | Résumer le contexte, libérer tokens |
| Vider le contexte    | `/clear`                    | Repart à zéro, garde le terminal    |

<br>

**📚 Documentation** : https://developers.openai.com/codex/cli/slash-commands

Notes:
Codex CLI propose plus de 30 commandes slash intégrées. Esc Esc (depuis un composer vide) permet de remonter dans le transcript et de forker depuis n'importe quel point avec Entrée. Ctrl+G ouvre votre $VISUAL/$EDITOR pour rédiger des prompts plus longs. Les sessions sont stockées dans ~/.codex/sessions/ sous forme de fichiers JSONL.

##==##

<!-- .slide: class="with-code" -->

# Codex CLI : AGENTS.md (fichier de contexte)

**Définition** : instructions projet persistantes que Codex lit au début de chaque session. Fournit le contexte, les conventions et les règles propres au projet.

| Niveau            | Fichier              | Portée                                 |
| ----------------- | -------------------- | -------------------------------------- |
| **Projet**        | `./AGENTS.md`        | Partagé avec l'équipe via git          |
| **Global (user)** | `~/.codex/AGENTS.md` | Personnel, s'applique à tous projets   |
| **Imbriqué**      | `<subdir>/AGENTS.md` | Propre au répertoire (prend le dessus) |

**Créer/Mettre à jour** : `/init` analyse le code existant et génère AGENTS.md (stack, commandes de build, conventions)

**Lecture auto** : Codex le lit au début de session et l'applique comme consigne projet

**📚 Documentation** : https://developers.openai.com/codex/config-advanced

Notes:
AGENTS.md est l'équivalent Codex du CLAUDE.md de Claude et du GEMINI.md de Gemini. La commande /init le génère en analysant votre codebase. Les AGENTS.md imbriqués dans les sous-répertoires fournissent un contexte propre au répertoire (le plus proche du répertoire de travail prime). Codex utilise AGENTS.md pour le contexte projet général, tandis que .codex/agents/\*.toml gère les rôles d'agents spécialisés.

##==##

<!-- .slide: class="with-code" -->

# Codex CLI : agents personnalisés

**Définition** : agents spécialisés lancés en parallèle pour des tâches complexes comme l'exploration de codebase ou le traitement par lots

| Champ                    | Requis | Description                                |
| ------------------------ | ------ | ------------------------------------------ |
| `name`                   | Oui    | Identifiant de l'agent                     |
| `description`            | Oui    | Guide humain : quand l'utiliser            |
| `developer_instructions` | Oui    | Directives de comportement (system prompt) |
| `model`                  | Non    | Surcharge de modèle                        |
| `model_reasoning_effort` | Non    | Raisonnement                               |

Notes:
Codex CLI est la seule plateforme à utiliser TOML pour définir les agents. Les agents tournent en parallèle avec un max_threads configurable (6 par défaut). La méthode spawn_agents_on_csv permet le traitement par lots sur les lignes d'un CSV. Chaque agent peut avoir ses propres modes sandbox et modèles.

##==##

<!-- .slide: class="with-code" -->

# Codex CLI : agents personnalisés

**Définition** : agents spécialisés lancés en parallèle pour des tâches complexes comme l'exploration de codebase ou le traitement par lots

**Emplacement** : `.codex/agents/` (projet) · `~/.codex/agents/` (personnel)

**Invocation** : `/agent` pour changer de thread, délégation automatique, ou `spawn_agents_on_csv` pour le batch

**Format de fichier** : **TOML**

Notes:
Codex CLI est la seule plateforme à utiliser TOML pour définir les agents. Les agents tournent en parallèle avec un max_threads configurable (6 par défaut). La méthode spawn_agents_on_csv permet le traitement par lots sur les lignes d'un CSV. Chaque agent peut avoir ses propres modes sandbox et modèles.

##==##

<!-- .slide: class="with-code" -->

# Codex CLI : agents personnalisés

**Définition** : agents spécialisés lancés en parallèle pour des tâches complexes comme l'exploration de codebase ou le traitement par lots

| Champ                 | Requis | Description                           |
| --------------------- | ------ | ------------------------------------- |
| `sandbox_mode`        | Non    | `read-only` ou `workspace-write`      |
| `nickname_candidates` | Non    | Noms d'affichage UI                   |
| `mcp_servers`         | Non    | Connexions serveurs MCP               |
| `skills.config`       | Non    | Configuration des skills de cet agent |

<br>

**📚 Documentation** : https://developers.openai.com/codex/subagents

Notes:
Codex CLI est la seule plateforme à utiliser TOML pour définir les agents. Les agents tournent en parallèle avec un max_threads configurable (6 par défaut). La méthode spawn_agents_on_csv permet le traitement par lots sur les lignes d'un CSV. Chaque agent peut avoir ses propres modes sandbox et modèles.

##==##

<!-- .slide: class="exercice" -->

# Exercices : Codex CLI Deep Dive

## Lab 41

<br>

### 👉 Suivez les **instructions** dans

### <code data-markdown-preview="/labs/lab-41-agentic-tools-deep-dive/README.md">labs/lab-41-agentic-tools-deep-dive/README.md</code>

### 📚 Exercices 1 à 2, section D (Codex CLI)

Notes:

- Suivez les instructions du README.md du lab pour les étapes détaillées.

##==##

<!-- .slide: class="exercice" -->

# Exercices : Codex CLI Deep Dive

## Lab 41

<br>

### 💡 Lisez la **solution** dans

### <code data-markdown-preview="/labs/lab-41-agentic-tools-deep-dive-solution/README.md">labs/lab-41-agentic-tools-deep-dive-solution/README.md</code>

### 📚 Exercices 1 à 2, section D (Codex CLI)

Notes:

- Lisez le README.md du lab pour des exemples de solutions.

##==##

<!-- .slide: class="with-code" -->

# Codex CLI : Agent Skills

**Définition** : instructions de prompt réutilisables que Codex charge à la demande. Consignes détaillées, propres à une tâche, activées selon le contexte

| Fonction             | Détails                                                  |
| -------------------- | -------------------------------------------------------- |
| Invocation explicite | `$skill-name "prompt"`                                   |
| Skills intégrées     | `$skill-creator`, `$skill-installer`                     |
| Config               | `[[skills.config]]` dans `config.toml` pour (dés)activer |
| Références           | Les skills embarquent `references/` avec leurs docs      |

Notes:
Codex CLI est le seul à proposer le préfixe $ pour l'invocation explicite de skills et le chargement par divulgation progressive. La skill intégrée $skill-creator aide à créer de nouvelles skills interactivement. Les skills peuvent embarquer des fichiers de référence, ce qui en fait des paquets de connaissance autonomes. Le fichier agents/openai.yaml fournit des métadonnées étendues. Les registres publics permettent le partage entre équipes et plateformes sans repartir de zéro.

##==##

<!-- .slide: class="with-code" -->

# Codex CLI : Agent Skills

**Définition** : instructions de prompt réutilisables que Codex charge à la demande. Consignes détaillées, propres à une tâche, activées selon le contexte

**Fonctionnement** : divulgation progressive — seules les métadonnées sont chargées au départ ; le contenu complet du SKILL.md est chargé à l'activation via `$skill-name` ou auto-détection

**Quand l'utiliser** : connaissances/procédures réutilisables devant s'activer selon le contexte, pas des commandes liées à une tâche

**Registres publics** : [🔗 https://skills.sh](https://skills.sh) - [🔗 https://tessl.io/registry](https://tessl.io/registry)

Notes:
Codex CLI est le seul à proposer le préfixe $ pour l'invocation explicite de skills et le chargement par divulgation progressive. La skill intégrée $skill-creator aide à créer de nouvelles skills interactivement. Les skills peuvent embarquer des fichiers de référence, ce qui en fait des paquets de connaissance autonomes. Le fichier agents/openai.yaml fournit des métadonnées étendues. Les registres publics permettent le partage entre équipes et plateformes sans repartir de zéro.

##==##

<!-- .slide: class="with-code" -->

# Codex CLI : Agent Skills

**Définition** : instructions de prompt réutilisables que Codex charge à la demande. Consignes détaillées, propres à une tâche, activées selon le contexte

**Structure** :

```
my-skill/
├── SKILL.md           # Instructions (required)
├── agents/            # openai.yaml metadata
├── scripts/           # Executable scripts
├── references/        # Reference documentation
└── assets/            # Additional resources
```

<br>

**📚 Documentation** : https://developers.openai.com/codex/skills/create-skill

Notes:
Codex CLI est le seul à proposer le préfixe $ pour l'invocation explicite de skills et le chargement par divulgation progressive. La skill intégrée **$skill-creator** aide à créer de nouvelles skills interactivement. Les skills peuvent embarquer des fichiers de référence, ce qui en fait des paquets de connaissance autonomes. Le fichier agents/openai.yaml fournit des métadonnées étendues. Les registres publics permettent le partage entre équipes et plateformes sans repartir de zéro.

##==##

<!-- .slide: class="exercice" -->

# Exercices : Codex CLI Deep Dive

## Lab 41

<br>

### 👉 Suivez les **instructions** dans

### <code data-markdown-preview="/labs/lab-41-agentic-tools-deep-dive/README.md">labs/lab-41-agentic-tools-deep-dive/README.md</code>

### 📚 Exercices 3 à 5, section D (Codex CLI)

Notes:

- Suivez les instructions du README.md du lab pour les étapes détaillées.

##==##

<!-- .slide: class="exercice" -->

# Exercices : Codex CLI Deep Dive

## Lab 41

<br>

### 💡 Lisez la **solution** dans

### <code data-markdown-preview="/labs/lab-41-agentic-tools-deep-dive-solution/README.md">labs/lab-41-agentic-tools-deep-dive-solution/README.md</code>

### 📚 Exercices 3 à 5, section D (Codex CLI)

Notes:

- Lisez le README.md du lab pour des exemples de solutions.

##==##

<!-- .slide: class="with-code" -->

# Codex CLI : Rules (contrôle des commandes)

**Définition** : règles en Starlark contrôlant quelles commandes Codex peut exécuter hors de son sandbox — l'alternative Codex aux hooks

| Champ                 | Requis | Description                         |
| --------------------- | ------ | ----------------------------------- |
| `pattern`             | Oui    | Liste de littéraux/unions à matcher |
| `decision`            | Oui    | `allow`, `prompt` ou `forbidden`    |
| `justification`       | Non    | Pourquoi cette règle                |
| `match` / `not_match` | Non    | Cas de test                         |

Notes:
Codex CLI utilise des règles Starlark plutôt que des hooks pour contrôler les commandes. L'approche est fondamentalement différente : les règles définissent des politiques statiques, tandis que les hooks exécutent des scripts dynamiques. Les règles peuvent être testées avec codex execpolicy check avant déploiement. Le système de sandbox fournit la sécurité de base.

##==##

<!-- .slide: class="with-code" -->

# Codex CLI : Rules (contrôle des commandes)

**Définition** : règles en Starlark contrôlant quelles commandes Codex peut exécuter hors de son sandbox — l'alternative Codex aux hooks

**Emplacement** : `~/.codex/rules/default.rules` ou `.codex/rules/`

**Format de fichier** : fichiers `.rules` utilisant la fonction Starlark `prefix_rule()`

**Test** : `codex execpolicy check --pretty --rules <file> -- <command>`

**Quand l'utiliser** : politiques de sécurité, allowlist de commandes, règles d'exécution imposées à l'équipe

**📚 Documentation** : https://developers.openai.com/codex/rules#create-a-rules-file

Notes:
Codex CLI utilise des règles Starlark plutôt que des hooks pour contrôler les commandes. L'approche est fondamentalement différente : les règles définissent des politiques statiques, tandis que les hooks exécutent des scripts dynamiques. Les règles peuvent être testées avec codex execpolicy check avant déploiement. Le système de sandbox fournit la sécurité de base.

##==##

<!-- .slide: class="with-code" -->

# Codex CLI : configuration & profils

**Définition** : réglages projet et utilisateur contrôlant le comportement, les permissions et les intégrations de Codex

| Réglage                  | Rôle                 | Exemple                           |
| ------------------------ | -------------------- | --------------------------------- |
| `model`                  | Modèle défaut        | `gpt-5.6-sol`                     |
| `model_reasoning_effort` | Raisonnement         | `low/medium/high`                 |
| `approval_policy`        | Contrôle d'exécution | `untrusted/on-failure/on-request` |

<br>

**Emplacement** : `.codex/config.toml` (projet) · `~/.codex/config.toml` (utilisateur)

**Features** : activer/désactiver via `codex features` ou `[features]` dans la config

**📚 Documentation** : https://developers.openai.com/codex/cli/features

Notes:
En juillet 2026, Codex tourne sur la famille **GPT-5.6** d'OpenAI (GA le 9 juillet 2026) : **Sol** (flagship, le défaut de Codex — `gpt-5.6-sol`, aliasé par `gpt-5.6`), **Terra** (équilibré) et **Luna** (rapide/économique) ; les trois sont intégrés à la dernière version du Codex CLI et apparaissent dans `/model`. Les profils sont l'alternative de Codex CLI au changement de personas d'agents. Au lieu de charger un autre agent, vous changez de profil, ce qui ajuste le modèle, l'effort de raisonnement, le mode sandbox et la politique d'approbation. La config au niveau projet exige d'abord codex trust . Le système de sandbox avec writable_roots fournit les frontières de sécurité.

##==##

<!-- .slide: class="with-code" -->

# Codex CLI : configuration & profils

**Définition** : réglages projet et utilisateur contrôlant le comportement, les permissions et les intégrations de Codex

| Réglage             | Rôle                     | Exemple                     |
| ------------------- | ------------------------ | --------------------------- |
| `sandbox_mode`      | Frontière sécurité       | `read-only/workspace-write` |
| `writable_roots`    | Répertoires modifiables  | `["src/", "tests/"]`        |
| `profiles.<name>.*` | Presets de config nommés | `[profiles.review]`         |

<br>

**Emplacement** : `.codex/config.toml` (projet) · `~/.codex/config.toml` (utilisateur)

**Profils** : presets nommés dans les sections `[profiles.<name>]`, activés avec `codex --profile <name>`

**📚 Documentation** : https://developers.openai.com/codex/config-advanced#profiles

Notes:
Les profils sont l'alternative de Codex CLI au changement de personas d'agents. Au lieu de charger un autre agent, vous changez de profil, ce qui ajuste le modèle, l'effort de raisonnement, le mode sandbox et la politique d'approbation. La config au niveau projet exige d'abord codex trust . Le système de sandbox avec writable_roots fournit les frontières de sécurité.

##==##

<!-- .slide: class="exercice" -->

# Exercices : Codex CLI Deep Dive

## Lab 41

<br>

### 👉 Suivez les **instructions** dans

### <code data-markdown-preview="/labs/lab-41-agentic-tools-deep-dive/README.md">labs/lab-41-agentic-tools-deep-dive/README.md</code>

### 📚 Exercices 6 à 7, section D (Codex CLI)

Notes:

- Suivez les instructions du README.md du lab pour les étapes détaillées.

##==##

<!-- .slide: class="exercice" -->

# Exercices : Codex CLI Deep Dive

## Lab 41

<br>

### 💡 Lisez la **solution** dans

### <code data-markdown-preview="/labs/lab-41-agentic-tools-deep-dive-solution/README.md">labs/lab-41-agentic-tools-deep-dive-solution/README.md</code>

### 📚 Exercices 6 à 7, section D (Codex CLI)

Notes:

- Lisez le README.md du lab pour des exemples de solutions.

##==##

<!-- .slide: -->

# **Codex CLI : synthèse des features**

| Fonction  | Emplacement       | Invocation       | Trait clé                          |
| --------- | ----------------- | ---------------- | ---------------------------------- |
| Agents    | `.codex/agents/`  | `/agent`, auto   | Format TOML, exécution parallèle   |
| AGENTS.md | Racine projet     | Auto démarrage   | Squelette via `/init`              |
| Skills    | `.agents/skills/` | `$name`, auto    | Chargement progressif, préfixe `$` |
| Rules     | `.codex/rules/`   | Auto (politique) | Starlark, remplace les hooks       |
| Profils   | `config.toml`     | `--profile name` | Presets nommés                     |
| Config    | `config.toml`     | Au démarrage     | Sandbox + approbations             |

Notes:
Codex CLI adopte une approche fondamentalement différente sur plusieurs fonctionnalités : TOML pour les agents (vs markdown), rules pour le contrôle des commandes (vs hooks), profils pour changer de workflow (vs agents séparés), et sandbox pour la sécurité (vs validation par hooks). Pas de système de plugins — l'extensibilité passe par les serveurs MCP et les skills.

##==##

<!-- .slide: -->

# Codex CLI : quoi utiliser quand

## Choisir la bonne fonctionnalité

| Scénario                           | À utiliser        | Pourquoi                                          |
| ---------------------------------- | ----------------- | ------------------------------------------------- |
| Besoin d'un expert IA du domaine   | **Agent perso**   | Persona définie en TOML dans `.codex/agents/`     |
| Besoin de conventions projet       | **AGENTS.md**     | Lu au démarrage, généré par `/init`               |
| Piloter permissions & comportement | **Configuration** | `config.toml` : sandbox, approbations, politiques |

<br>

**Agents** = personas TOML | **AGENTS.md** = contexte projet global

Notes:
Codex CLI n'a pas de Hooks (il utilise les Rules Starlark à la place) ni de Plugins (utilisez les serveurs MCP pour l'extensibilité). Les commandes personnalisées sont dépréciées au profit des Agent Skills. Les profils sont propres à Codex — ils permettent de basculer entre des configurations de workflow nommées (modèle, sandbox, politique d'approbation) sans changer d'agent.

##==##

<!-- .slide: -->

# Codex CLI : quoi utiliser quand

## Choisir la bonne fonctionnalité

| Scénario                              | À utiliser      | Pourquoi                                              |
| ------------------------------------- | --------------- | ----------------------------------------------------- |
| Besoin de savoir partagé entre agents | **Agent Skill** | Composable, chargé via `$name` ou auto-découverte     |
| Besoin d'imposer des règles shell     | **Rules**       | Contrôle Starlark dans `.codex/rules/` (pas de Hooks) |
| Besoin de basculer entre workflows    | **Profil**      | Presets nommés dans `config.toml`, `--profile name`   |

<br>

**Skills** = savoir composable | **Rules** = application automatique _(Hooks & Plugins : N/A)_

Notes:
Codex CLI n'a pas de Hooks (il utilise les Rules Starlark à la place) ni de Plugins (utilisez les serveurs MCP pour l'extensibilité). Les commandes personnalisées sont dépréciées au profit des Agent Skills. Les profils sont propres à Codex — ils permettent de basculer entre des configurations de workflow nommées (modèle, sandbox, politique d'approbation) sans changer d'agent.
