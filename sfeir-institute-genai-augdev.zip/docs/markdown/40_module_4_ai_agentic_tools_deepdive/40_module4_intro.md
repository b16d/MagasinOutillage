<!-- .slide: class="transition" -->

# Module 4 Overview

## Agentic Tools Deep Dive: Strengths, Features, and When to Use What

##==##

<!-- .slide -->

# Learning Objectives

By the end of this module, you will be able to:

- **Master** the CLI main features, commands, and shortcuts of Claude Code, GitHub Copilot, Codex CLI, Gemini CLI, and OpenCode
- **Create** custom agents and custom commands tailored to your team's workflows
- **Configure** agent skills, hooks, plugins, and configuration files for automated quality enforcement
- **Choose** the right feature type (agent, command, skill, hook, plugin) for each use case

Notes:
This module provides a practical deep dive into customizing agentic coding tools for team-wide AI adoption. Note (July 2026): the Gemini CLI track is retained for historical and comparative reference only — Gemini CLI was retired in May 2026 (consumer access ended June 18, 2026) and superseded by Google's Antigravity CLI. Present it as "how it worked," not as a currently supported tool.

##==##

<!-- .slide -->

# Prerequisites

## What You Need to Know

<br>

### From Module 3

- Understanding of agentic coding workflows
- Experience with AI-assisted development patterns
- Familiarity with at least one agentic tool (Claude Code, Copilot, Gemini CLI, Codex CLI, or OpenCode)

### For Hands-on Practice

<!-- .element: class="md-padding-top" -->

- Access to at least one agentic tool CLI
- Terminal/command-line experience
- Git installed and configured

Notes:
This module builds on Module 3 agentic coding concepts and goes deeper into tool customization features.
