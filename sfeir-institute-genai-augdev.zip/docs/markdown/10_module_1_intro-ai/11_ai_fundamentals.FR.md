<!-- .slide: class="transition" -->

# Fondamentaux de l'IA

## Comprendre les briques de base

Notes:
Cette section couvre les concepts fondamentaux à maîtriser avant de se plonger dans les outils d'IA. Nous explorerons ce qu'est réellement l'IA, comment elle se rattache au machine learning et au deep learning, et retracerons les grandes étapes qui ont mené à la révolution actuelle de l'IA générative.

##==##

<!-- .slide: -->

# **Qu'est-ce que l'IA ?**

### **Définition**

L'**intelligence artificielle (IA)** est le domaine de l'informatique dédié à la création de systèmes capables d'accomplir des tâches qui exigent habituellement l'intelligence humaine.

<br>

### **Capacités clés**

- **Apprendre** à partir de données et d'expériences
- **Raisonner** pour résoudre des problèmes
- **Comprendre** le langage naturel
- **Percevoir** images et sons
- **Décider** dans des situations complexes

Notes:
L'IA est souvent réduite à tort à une technologie unique, alors qu'il s'agit en réalité d'un vaste domaine regroupant de nombreuses approches. Les systèmes que vous utiliserez pour l'assistance au code sont un type d'IA précis : les grands modèles de langage (LLM), que nous situerons dans cette hiérarchie.

Détaillons les capacités clés :

**Apprendre** : les systèmes d'IA s'améliorent au contact des données. Contrairement aux logiciels traditionnels où chaque comportement est programmé explicitement, l'IA sait identifier des motifs et s'adapter. Pour les développeurs, cela signifie des outils qui apprennent votre style de code, les conventions du projet et les motifs récurrents.

**Raisonner** : l'IA peut enchaîner des étapes logiques pour résoudre des problèmes, du débogage à la conception d'architecture. Les LLM modernes font preuve de raisonnement en chaîne de pensée, découpant les problèmes complexes en étapes traitables.

**Comprendre le langage naturel** : c'est ce qui rend l'IA conversationnelle possible. Vous décrivez ce que vous voulez en français courant, et l'IA le traduit en code, en documentation ou en explications techniques.

**Percevoir images et sons** : l'IA multimodale peut analyser des captures d'écran, des schémas, voire des commandes vocales. Utile pour convertir des maquettes d'UI en code ou interpréter des captures d'erreur.

**Décider** : l'IA pèse les options et choisit l'action adaptée au contexte. Dans les outils de code, cela se traduit par des suggestions pertinentes, de l'autocomplétion et des propositions de refactoring.

L'idée clé pour les développeurs : l'IA est un outil qui augmente vos capacités, pas un remplaçant. Comprendre ces fondations vous aide à en tirer parti efficacement tout en connaissant ses limites.

##==##

<img src="assets/images/10_module_1/ai-hierarchy-diagram.svg" alt="Hiérarchie des technologies d'IA montrant une relation imbriquée : l'IA contient le ML qui contient le Deep Learning qui contient l'IA générative qui contient les LLM" style="width:100%; height:auto; display:block;">

Notes:
Ce schéma montre comment les différentes technologies d'IA s'articulent en couches imbriquées. Parcourons chaque niveau de l'extérieur vers l'intérieur :

**Intelligence artificielle (couche externe)** : la catégorie la plus large, englobant tout système qui imite l'intelligence humaine. Inclut les systèmes à base de règles, les systèmes experts et toutes les approches de l'intelligence machine. Toute IA n'apprend pas : une partie relève de logique codée en dur.

**Machine Learning** : un sous-ensemble de l'IA où les systèmes apprennent des motifs à partir de données plutôt que de suivre des règles explicites. Inclut les arbres de décision, les machines à vecteurs de support et les réseaux de neurones. Le changement clé : au lieu de programmer des règles, vous fournissez des exemples et le système apprend les règles.

**Deep Learning** : une forme spécialisée de ML utilisant des réseaux de neurones à nombreuses couches (d'où « profond »). Chaque couche apprend des caractéristiques de plus en plus abstraites. Rendu possible par les GPU et le big data. Il alimente la reconnaissance d'images, le traitement de la parole et les modèles de langage modernes.

**IA générative** : un sous-ensemble spécialisé du Deep Learning centré sur la création de contenus nouveaux (texte, code, images, audio). ChatGPT, Claude et GitHub Copilot se situent ici. C'est ce que vous utiliserez quotidiennement en tant que développeurs augmentés.

**LLM (couche la plus interne)** : les grands modèles de langage sont la forme la plus spécialisée — des réseaux de neurones entraînés sur d'immenses corpus de texte pour comprendre et générer le langage humain. Exemples : GPT-5.6 d'OpenAI, Claude d'Anthropic (Fable 5, Opus 4.8, Sonnet 5), Gemini de Google et Mistral.

**Pourquoi cela compte pour les développeurs** : quand quelqu'un dit « IA », il peut désigner n'importe laquelle de ces couches. Comprendre la hiérarchie vous aide à :

- Choisir le bon outil (inutile d'un LLM pour de la simple correspondance de motifs)
- Avoir des attentes réalistes (chaque couche a ses capacités et ses limites)
- Communiquer avec précision avec vos collègues et vos interlocuteurs

##==##

<img src="assets/images/10_module_1/ai-timeline.svg" alt="Frise chronologique de l'évolution de l'IA montrant les grandes étapes, du test de Turing en 1950 à l'IA agentique en 2026" style="width:100%; height:auto; display:block;">

Notes:
Cette frise met en scène sept étapes décisives, différenciées par couleur selon l'époque. Voyons ce que chacune signifie :

**1950 - Test de Turing** : Alan Turing pose la question « Les machines peuvent-elles penser ? » et propose un test : si un humain ne peut distinguer les réponses d'une machine de celles d'un autre humain, la machine fait preuve d'intelligence. Cette question philosophique est devenue le socle de toute la recherche en IA.

**1956 - Naissance du terme « IA »** : à la conférence de Dartmouth, John McCarthy et ses collègues créent officiellement l'« intelligence artificielle » comme champ de recherche. Ils estimaient que les machines pouvaient simuler tout aspect de l'apprentissage et de l'intelligence humaine — lançant l'IA telle que nous la connaissons.

**1986 - Rétropropagation** : cet algorithme majeur apprend aux réseaux de neurones à apprendre, en propageant les erreurs à rebours dans les couches et en ajustant les poids. C'est la technique mathématique qui rend le deep learning possible — sans elle, l'IA moderne n'existerait pas.

**2012 - AlexNet** : ce réseau de neurones profond remporte une compétition de reconnaissance d'images avec une large avance, prouvant que le deep learning avec GPU et grands jeux de données surpasse nettement les méthodes traditionnelles. Il déclenche la révolution du deep learning et les investissements massifs en IA que l'on connaît.

**2017 - Transformers** : l'article « Attention Is All You Need » de Google introduit l'architecture Transformer, qui traite les séquences de texte en parallèle via des mécanismes d'attention pour saisir les relations entre les mots. C'est le socle de TOUS les LLM modernes — GPT, Claude et Gemini reposent tous sur des Transformers.

**2022 - ChatGPT** : OpenAI rend l'IA linguistique puissante accessible à tous via une simple interface de chat. Ce moment grand public démontre que les LLM comprennent le contexte, génèrent un texte proche de l'humain et assistent sur d'innombrables tâches — preuve que l'IA était prête pour un usage quotidien.

**2025 - IA agentique** : la frontière actuelle, où l'IA ne se contente plus de répondre mais planifie de façon autonome, utilise des outils, exécute des tâches en plusieurs étapes et écrit des applications complètes. L'IA passe du statut d'assistant à celui de collaborateur autonome dans le développement logiciel.

Remarquez l'accélération exponentielle : plus de progrès depuis 2017 que durant les 60 années précédentes réunies.

##==##

<img src="assets/images/10_module_1/tools-evolution.svg" alt="Frise chronologique de l'évolution de l'IA montrant les grandes étapes, du test de Turing en 1950 à l'IA agentique en 2026" style="width:100%; height:auto; display:block;">

Notes:
Ce schéma montre les 4 étapes d'évolution des outils de développement propulsés par l'IA, de la simple autocomplétion aux agents autonomes. Parcourons chaque étape :

**Étape 1 - Autocomplétion (2015-2018)** : les tout premiers outils de code par IA complétaient une seule ligne. Pensez à IntelliSense et TabNine v1 : ils prédisaient le token suivant ou finissaient une ligne à partir du contexte local. Utile mais limité, en substance de la correspondance de motifs sur le fichier courant.

**Étape 2 - Suggestions (2018-2021)** : les outils deviennent sensibles au contexte et génèrent des suggestions multi-lignes. GitHub Copilot et Kite incarnent ce saut : ils comprenaient un contexte de code plus large, savaient proposer des corps de fonction entiers et apprenaient des motifs open source. Toujours réactifs : vous tapez, ils suggèrent.

**Étape 3 - Chat (2022-2023)** : la révolution conversationnelle. ChatGPT et Copilot Chat permettent aux développeurs de dialoguer autour du code — demander des explications, réclamer des refactorings, déboguer des erreurs par la conversation. Le changement clé : vous pouviez désormais décrire une intention en langage naturel au lieu d'attendre des complétions.

**Étape 4 - Agents (2024 à aujourd'hui)** : là où nous en sommes AUJOURD'HUI. Des outils comme Cursor, Claude Code et Copilot Agents planifient et exécutent de façon autonome des tâches multi-fichiers. Ils lisent votre base de code, créent des fichiers, lancent les tests, corrigent les erreurs et itèrent — avec une intervention humaine minimale. C'est le paradigme agentique que nous explorerons tout au long de cette formation.

**Idée clé** : chaque étape s'appuie sur les précédentes. Les outils agentiques utilisent toujours l'autocomplétion, les suggestions et le chat en interne — mais y ajoutent la planification et l'exécution autonomes de tâches. Le comportement évolue de réactif (attendre votre saisie) à proactif (anticiper les besoins), puis interactif (converser) et enfin autonome (agir seul).

Remarquez la légende en bas : le code couleur reflète ce glissement comportemental — bleu pour réactif/proactif, orange pour interactif, vert pour autonome. Savoir à quelle étape opère un outil vous aide à ajuster vos attentes et à l'utiliser efficacement.
