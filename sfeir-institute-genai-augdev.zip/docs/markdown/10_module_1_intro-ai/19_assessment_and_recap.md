<!-- .slide: class="transition" -->

# Assessment and Recap

## Module 1 Summary

Notes:
Let's review what we've learned and check your understanding before moving on to Module 2, where we'll explore the difference between vibe coding and agentic coding.

##==##

<!-- .slide: -->

# **Learning Objectives Review**

<br>

### **You should now be able to:**

- **Explain** the AI > ML > Deep Learning > Generative AI > LLMs hierarchy
- **Categorize** AI models by tier (Frontier, Balanced, Fast) and type (Reasoning, Open-Weight)
- **Compare** GPT-5.6 Sol, Claude Fable 5, and Gemini 3.1 Pro on key benchmarks
- **Apply** 5 prompting techniques for code generation
- **Understand** tokens, context windows, and their practical constraints
- **Identify** which AI tool type (IDE Extension, CLI Agent, AI-Native IDE) to use for different tasks

<br>

**Key Takeaway**

Effective AI-augmented development is about **choosing the right tool** and **communicating clearly** through well-crafted prompts.

Notes:
If any of these objectives feel unclear, review the relevant section before continuing. Module 2 builds on this foundation to explore safe and effective ways to use these tools.

##==##

<!-- .slide: -->

# **Knowledge Check**

## **Question 1: Context Window**

<br>

### A developer has a model with a 128K token context window and sends a 100K token codebase for analysis. How many tokens remain for the model's response?

**A)** 128K tokens — the response window is always the full context size  
**B)** 28K tokens — input and output tokens share the same window  
**C)** 100K tokens — only input tokens count against the limit  
**D)** It depends on the model provider's pricing tier

<details>
<summary>Answer</summary>
<strong>B) 28K tokens</strong> — Input tokens + Output tokens must fit within the total context window. Sending 100K tokens of input leaves only 28K for the model's response. When a tool suddenly "forgets" earlier context, a saturated context window is the most common cause.
</details>

Notes:
Tests understanding of the context window constraint from the dedicated tokens/context slide. The key formula: Input + Output ≤ Total Window. Developers must be strategic about what they include in context.

##==##

<!-- .slide: -->

# **Knowledge Check**

## **Question 2: AI Hierarchy**

<br>

### In the AI technology hierarchy, which layer directly contains Large Language Models (LLMs)?

**A)** Machine Learning  
**B)** Generative AI  
**C)** Natural Language Processing (NLP)  
**D)** Deep Learning

<details>
<summary>Answer</summary>
<strong>B) Generative AI</strong> — LLMs are the innermost layer, nested inside Generative AI. The full nesting is: AI ⊃ Machine Learning ⊃ Deep Learning ⊃ Generative AI ⊃ LLMs. LLMs (GPT, Claude, Gemini, Mistral) are the most specialized subset — models that generate text and code.
</details>

Notes:
Tests the AI hierarchy from the fundamentals slide. A common mistake is adding NLP as a distinct layer — it does not appear in the diagram. The correct order is AI > ML > Deep Learning > Generative AI > LLMs, with LLMs as the innermost layer.

##==##

<!-- .slide: -->

# **Knowledge Check**

## **Question 3: Choosing the Right Tool**

<br>

### A developer needs to refactor authentication logic spanning 15 files across a monorepo. Which tool type is most appropriate?

**A)** CLI Agent (e.g. Claude Code, Gemini CLI)  
**B)** IDE Extension (e.g. GitHub Copilot)  
**C)** AI-Native IDE (e.g. Cursor, Windsurf)  
**D)** All three types are equally suited for this task

<details>
<summary>Answer</summary>
<strong>C) AI-Native IDE</strong> — For a developer working locally, AI-Native IDEs like Cursor or Windsurf are the most ergonomic choice: their native agent modes handle multi-file edits with inline diff previews per file, can run terminal commands and tests from within the editor, and require no context switching. CLI agents (A) like Claude Code or Gemini CLI are equally capable and shine in headless, CI, or remote server scenarios where no UI is available. IDE extensions (B) excel at inline completions and quick chat but are not designed for autonomous multi-file execution.
</details>

Notes:
Tests the tool selection framework from the tools panorama slide. AI-Native IDEs are the most ergonomic choice for local multi-file tasks thanks to native agent modes with inline diff previews. CLI agents are the go-to for headless or automated contexts. IDE extensions are best for single-file, quick-help scenarios.

##==##

<!-- .slide: -->

# **Resources**

<br>

### **Lab Solutions**

- <code data-markdown-preview="/labs/lab-11-prompt-engineering-solution/README.md">labs/lab-11-prompt-engineering-solution/README.md</code>

### **Further Reading**

<!-- .element: class="md-padding-top"-->

- [OpenAI Prompt Engineering Guide](https://platform.openai.com/docs/guides/prompt-engineering)
- [Anthropic's Claude Documentation](https://docs.anthropic.com/)
- [Google AI Prompting Guide](https://ai.google.dev/gemini-api/docs/prompting-intro)

Notes:
Module 2 is critical for understanding how to use AI tools responsibly and effectively. The prompting skills you learned here will be essential for the agentic approach we'll cover next.
