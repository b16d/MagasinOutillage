<!-- .slide: class="transition" -->

# Module 1 Glossary

## Key terms at a glance

Notes:
This section recaps all the vocabulary introduced in module 1. Use it as a reference card during the labs and to revise before the module 8 final exam.

##==##

<!-- .slide: -->

# **The AI hierarchy**

<br>

| Term                 | Short definition                                                  |
| -------------------- | ----------------------------------------------------------------- |
| **AI**               | Systems performing tasks that normally require human intelligence |
| **Machine Learning** | AI that learns patterns from data instead of hard-coded rules     |
| **Deep Learning**    | ML built on neural networks with many layers                      |
| **Generative AI**    | Deep Learning that creates new content: text, code, images, audio |
| **LLM**              | Large Language Model — the innermost layer                        |
| **Multimodal**       | A model that also handles images, diagrams, screenshots, audio    |

<br>

> **AI ⊃ Machine Learning ⊃ Deep Learning ⊃ Generative AI ⊃ LLM**

Notes:
The classic quiz trap is adding NLP as a layer of this hierarchy. It is not one. The exact nesting, outermost to innermost, is AI, Machine Learning, Deep Learning, Generative AI, LLM.

##==##

<!-- .slide: -->

# **Anatomy of a model**

<br>

| Term              | Short definition                                                    |
| ----------------- | ------------------------------------------------------------------- |
| **AI model**      | A neural network trained to recognize patterns and generate outputs |
| **Parameters**    | The weights learned during training — the model's "knowledge"       |
| **Transformer**   | The 2017 attention-based architecture behind EVERY modern LLM       |
| **Pre-training**  | Phase 1: predict the next token over huge corpora (self-supervised) |
| **RLHF**          | Phase 2: human-feedback tuning — turns the model into an assistant  |
| **Inference**     | Running the model: output is generated **one token at a time**      |
| **Hallucination** | A plausible but false output                                        |

Notes:
An important distinction: the model is the computational artifact, not the product built around it. Today's frontier models carry from hundreds of billions to several trillion parameters — Llama 4 Maverick is around 400 billion.

##==##

<!-- .slide: -->

# **Tokens and context**

<br>

| Term               | Short definition                                                  |
| ------------------ | ----------------------------------------------------------------- |
| **Token**          | Smallest unit of text a model processes — a word or word fragment |
| **Tokenizer**      | What splits text into tokens — it differs from model to model     |
| **Context window** | Max tokens per interaction — the model's working memory           |
| **Input tokens**   | What the model reads: system prompt, messages, history, files     |
| **Output tokens**  | What the model writes — a separate cap, typically 64K-128K        |
| **MTok**           | Million tokens — the pricing unit                                 |
| **RAG**            | Retrieve only the relevant excerpts instead of dumping everything |

<br>

> **Golden rule: Input tokens + Output tokens ≤ Context window**

Notes:
`function getUserName()` is 6 tokens. Rules of thumb: 1 English word is about 1.3 tokens, 1 line of code 5 to 10 tokens, 1000 lines 5000 to 8000 tokens. When a tool suddenly forgets context, a saturated window is almost always the cause: the start of the conversation gets truncated or compressed.

##==##

<!-- .slide: -->

# **Benchmarks**

<br>

| Benchmark               | What it measures                                               |
| ----------------------- | -------------------------------------------------------------- |
| **SWE-bench Verified**  | Fixing real GitHub issues — the coding reference               |
| **SWE-bench Pro**       | Same exercise on private codebases — harder                    |
| **LiveCodeBench**       | Competition-level code, refreshed prompts — no contamination   |
| **Aider Polyglot**      | **Editing** existing code in diff format, across 6 languages   |
| **Arena Elo (LMArena)** | Human preference, from anonymous pairwise votes                |
| **GPQA Diamond**        | PhD-level science questions                                    |
| **Scaffolding**         | The harness around the model — inflates vendor-reported scores |

Notes:
MMLU, HumanEval and GSM8K are now saturated: they no longer discriminate between frontier models. The 7 evaluation dimensions are Code, Reasoning, Agentic, Instruction following, Multimodal, Human preference and Safety. No model wins on all of them; for a developer the priority trio is Code, Agentic and Instruction following.

##==##

<!-- .slide: -->

# **Model categories**

<br>

| Category         | What it is for                                     |
| ---------------- | -------------------------------------------------- |
| **Frontier**     | The hardest problems — expensive and slow          |
| **Balanced**     | The everyday workhorse — the default tier          |
| **Fast / small** | High volume, latency and budget first              |
| **Reasoning**    | The model "thinks" before answering                |
| **Embedding**    | Text into semantic vectors — the engine behind RAG |
| **Open-weight**  | Public weights, run locally — private and offline  |

<br>

> **Match the tier to the task**: no frontier model for autocomplete, no fast model for architecture.

Notes:
Every vendor ships the same tiered structure. Frontier: Claude Fable 5, Claude Opus 4.8, GPT-5.6 Sol, Gemini 3.1 Pro. Balanced: Claude Sonnet 5, GPT-5.6 Terra, Gemini 3.5 Flash. Fast: Claude Haiku 4.5, GPT-5.6 Luna, Gemini 3.5 Flash-Lite. Open-weight: Llama 4, Qwen3, DeepSeek V3, Mistral, Phi-4, Gemma 3 — they reach 80 to 95 % of cloud frontier capability.

##==##

<!-- .slide: class="tc-multiple-columns" -->

##++## "class=with-code"

## **4 tooling eras**

<br>

| Era              | Behavior    |
| ---------------- | ----------- |
| **Autocomplete** | Reactive    |
| **Suggestions**  | Proactive   |
| **Chat**         | Interactive |
| **Agents**       | Autonomous  |

##++##

##++## "class=with-code"

## **3 tool types**

<br>

| Type              | Home turf                       |
| ----------------- | ------------------------------- |
| **IDE extension** | Completion and quick chat       |
| **CLI agent**     | Autonomous multi-file work      |
| **AI-Native IDE** | AI-augmented editing end to end |

##++##

Notes:
The 4 eras: autocomplete from 2015 to 2018 (IntelliSense, TabNine), suggestions from 2018 to 2021 (Copilot, Kite), chat from 2022 to 2023 (ChatGPT, Copilot Chat), agents since 2024 (Cursor, Claude Code, Copilot Agents). Each era builds on the previous ones. The 3 types are complementary, not competing: IDE extension for single-file work, CLI agent for headless and CI, AI-Native IDE for local multi-file work.

##==##

<!-- .slide: -->

# **Tooling vocabulary**

<br>

| Term                | Short definition                                          |
| ------------------- | --------------------------------------------------------- |
| **MCP**             | Protocol for extending an agent with external tools       |
| **"ide" mode**      | Connect a CLI agent to your IDE to preview its edits      |
| **Autonomy levels** | suggest → auto-edit → full-auto                           |
| **Sandbox**         | Isolated environment where the agent runs its commands    |
| **Grounding**       | Anchoring answers on a real-time source (e.g. web search) |
| **Antigravity CLI** | The replacement for Gemini CLI, retired in May 2026       |

Notes:
MCP, the Model Context Protocol, is covered in depth in modules 5 and 12. Gemini CLI was retired in May 2026 and consumer access ended on 18 June 2026; Antigravity CLI, written in Go and unveiled at Google I/O 2026, brings asynchronous multi-agent orchestration.

##==##

<!-- .slide: -->

# **Prompting**

<br>

| Technique               | What you add to the prompt         |
| ----------------------- | ---------------------------------- |
| **1. Role**             | Who the AI should be               |
| **2. Context**          | Tech stack, constraints, goals     |
| **3. Format**           | The expected output shape          |
| **4. Examples**         | A sample of the result you want    |
| **5. Chain-of-Thought** | The request to reason step by step |

<br>

> **Cumulative** techniques: Role + Context → + Format → + Examples → + Chain-of-Thought

Notes:
A reminder from the prompting slide: what separates junior from senior use of AI is prompt quality, not AI knowledge. The system prompt consumes context, so keep it concise.

##==##

<!-- .slide: -->

# **Numbers to remember**

<br>

### **Key figures**

- A **200K** window ≈ 150,000 words; **1M** ≈ 750,000 words (input + output)
- **10,000 lines** pasted ≈ 40K tokens; plus the answer ≈ 42K consumed
- Frontier models cap out at **64K-128K output tokens**
- **Input** tokens cost less than **output** tokens (e.g. $5 vs $25 per MTok)
- Most professional devs use **2 to 3 models** depending on the task

Notes:
These are the figures that come up most often during the labs. The rest of the module vocabulary is covered by the preceding slides in this section.
