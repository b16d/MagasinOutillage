<!-- .slide: class="transition" -->

# Module 1 : Introduction à l'IA pour les développeurs

## Comprendre les fondamentaux du développement augmenté par l'IA

Notes:
Bienvenue dans le Module 1 ! Ce module fournit les connaissances de base nécessaires pour exploiter efficacement les outils d'IA dans votre workflow de développement. Nous couvrirons l'histoire et l'évolution de l'IA, comparerons les principaux modèles du marché et pratiquerons les techniques de prompt engineering. Durée : 1h30 (60 min de cours + 30 min d'atelier).

##==##

<!-- .slide: -->

# **Objectifs pédagogiques**

<br>

### **À la fin de ce module, vous saurez :**

- **Expliquer** la hiérarchie IA, ML, Deep Learning et IA générative
- **Comparer** les différences clés entre les modèles GPT, Claude et Gemini
- **Appliquer** 5 techniques de prompting pour générer du code
- **Décrire** l'évolution de l'autocomplétion aux outils de codage agentique
- **Comprendre** l'impact des tokens et fenêtres de contexte sur les échanges avec l'IA
- **Identifier** les outils d'IA adaptés aux différentes tâches de développement

Notes:
Ces objectifs pédagogiques sont mesurables : vous démontrerez votre compréhension lors d'un atelier pratique où vous comparerez différentes approches de prompting sur une vraie tâche de code. Chaque objectif s'appuie sur le précédent, construisant une base complète pour le développement augmenté par l'IA.
