<!-- .slide: class="transition" -->

# Context and Tokens

## Understanding AI Constraints

Notes:
To use AI tools effectively, you need to understand their fundamental constraints: how they process text (tokens) and how much they can consider at once (context window). These concepts directly affect how you structure your prompts and what tasks are feasible.

##==##

<!-- .slide: -->

# **What Are Tokens?**

<br>

### **Definition**

A **token** is the smallest unit of text an LLM processes — typically **a word or part of a word**.

<br><br>

### **Example**

`function getUserName()` → 6 tokens: `function` | `get` | `User` | `Name` | `(` | `)`

Notes:
Tokens are the billing unit for AI APIs. Every character you send and receive is converted to tokens. Common words are usually 1 token, but longer or rare words get split into subwords. Punctuation and special characters are separate tokens.

##==##

<!-- .slide: -->

# **What Are Tokens?**

<br>

### **Rule of Thumb**

| Text Type          | Estimation           |
| ------------------ | -------------------- |
| English text       | 1 word ≈ 1.3 tokens  |
| Code               | 1 line ≈ 5-10 tokens |
| 1000 lines of code | ≈ 5,000-8,000 tokens |

<br>

> **Why it matters**: Tokens determine both **cost** and **context limits**

Notes:
Tokens are the billing unit for AI APIs. Every character you send and receive is converted to tokens. Common words are usually 1 token, but longer or rare words get split into subwords. Punctuation and special characters are separate tokens.
##==##

<!-- .slide: -->

# **What Is the Context Window?**

### **Definition**

The **context window** is the maximum number of tokens an LLM can process in a single interaction — it includes **everything**: system prompt, user input, conversation history, attached files, **and** the generated response.

<br>

### **The Golden Rule**

> **Input Tokens + Output Tokens ≤ Total Context Window**

<br>

| What counts as Input                 | What counts as Output      |
| ------------------------------------ | -------------------------- |
| System prompts & instructions        | Generated text & code      |
| Your messages & conversation history | Explanations & suggestions |
| Attached code files & documentation  | Analysis & summaries       |

Notes:
The context window is like the AI's working memory — everything the model "sees" at once must fit inside it. Unlike a human who can revisit old notes, an LLM has no memory beyond this window: once tokens fall outside the limit, they're effectively forgotten.

**Why this matters for developers:**

- **Context is finite**: If your codebase is 500K tokens but the window is 200K, the AI literally cannot see everything at once. You must be strategic about what you include.
- **Input competes with output**: The more context you send in, the less room remains for the model's response. A model with a 128K window that receives 120K of input can only generate ~8K of output.
- **Different models, different trade-offs**: Most frontier models now offer ~1M-token context — Gemini, GPT-5.6, and Claude (Fable 5 / Opus 4.8 / Sonnet 5) — so you can analyze large codebases in one shot. But output caps still differ (typically 64K-128K), larger inputs cost more, and packing the window too full can dilute the model's focus. Note tokenizers vary too: Sonnet 5's new tokenizer produces ~30% more tokens than Sonnet 4.6 for the same text.
- **Conversation history accumulates**: Each back-and-forth in a chat session adds tokens. Long conversations can silently exhaust the window, causing the model to "forget" earlier context or produce degraded responses.

**Practical implications:**

- Keep system prompts concise — every token there reduces your usable space.
- In agentic tools, context management is handled automatically (file indexing, RAG, summarization), but understanding the constraint helps you debug unexpected behavior.
- When a tool suddenly "forgets" something you told it earlier, a full context window is often the cause.
- Breaking large tasks into smaller, focused interactions is more effective than cramming everything into one prompt.

##==##

<!-- .slide: -->

<img src="assets/images/10_module_1/context-window-diagram.svg" alt="Context Window diagram showing how system prompt, input, and output must fit within the window" style="width:100%; height:auto; display:block;">

Notes:
The context window is like the AI's working memory - everything must fit: your system prompt, your input, AND the response it generates. This is why you can't just paste an entire codebase into a prompt. Strategic context selection becomes crucial for larger projects.
