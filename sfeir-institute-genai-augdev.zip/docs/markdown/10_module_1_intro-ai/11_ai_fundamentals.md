<!-- .slide: class="transition" -->

# AI Fundamentals

## Understanding the Building Blocks

Notes:
This section covers the foundational concepts you need to understand before diving into AI tools. We'll explore what AI really is, how it relates to machine learning and deep learning, and trace the key milestones that led to today's generative AI revolution.

##==##

<!-- .slide: -->

# **What is Artificial Intelligence?**

### **Definition**

**Artificial Intelligence (AI)** is the field of computer science focused on creating systems that can perform tasks that typically require human intelligence.

<br>

### **Key Capabilities**

- **Learning** from data and experience
- **Reasoning** to solve problems
- **Understanding** natural language
- **Perceiving** images and sounds
- **Making decisions** in complex situations

Notes:
AI is often misunderstood as a single technology, but it's actually a broad field encompassing many approaches. The systems you'll use for coding assistance are a specific type of AI called Large Language Models (LLMs), which we'll explore in this hierarchy.

Let's break down the key capabilities:

**Learning**: AI systems improve through exposure to data. Unlike traditional software where every behavior is explicitly programmed, AI can identify patterns and adapt. For developers, this means tools that learn your coding style, project conventions, and common patterns.

**Reasoning**: AI can apply logical steps to solve problems, from debugging code to architecting solutions. Modern LLMs demonstrate chain-of-thought reasoning, breaking complex problems into manageable steps.

**Understanding natural language**: This is what makes conversational AI possible. You can describe what you want in plain English, and the AI translates that into code, documentation, or technical explanations.

**Perceiving images and sounds**: Multimodal AI can analyze screenshots, diagrams, or even voice commands. Useful for converting UI mockups to code or understanding error screenshots.

**Making decisions**: AI weighs options and selects appropriate actions based on context. In coding tools, this appears as smart suggestions, auto-completions, and refactoring recommendations.

The key insight for developers: AI is a tool that augments your capabilities, not a replacement. Understanding these foundations helps you leverage AI effectively while knowing its limitations.

##==##

<img src="assets/images/10_module_1/ai-hierarchy-diagram.svg" alt="AI Technology Hierarchy showing nested relationship: AI contains ML contains Deep Learning contains Generative AI contains LLMs" style="width:100%; height:auto; display:block;">

Notes:
This diagram shows how different AI technologies relate to each other as nested layers. Let's walk through each level from the outside in:

**Artificial Intelligence (outermost layer)**: The broadest category encompassing any system that mimics human intelligence. Includes rule-based systems, expert systems, and all approaches to machine intelligence. Not all AI learns - some is hardcoded logic.

**Machine Learning**: A subset of AI where systems learn patterns from data rather than following explicit rules. Includes techniques like decision trees, support vector machines, and neural networks. The key shift: instead of programming rules, you provide examples and the system learns the rules.

**Deep Learning**: A specialized form of ML using neural networks with many layers (hence "deep"). Each layer learns increasingly abstract features. Enabled by GPUs and big data. Powers image recognition, speech processing, and modern language models.

**Generative AI**: A specialized subset of Deep Learning focused on creating new content (text, code, images, audio). ChatGPT, Claude, and GitHub Copilot live here. This is what you'll use daily as augmented developers.

**LLMs (innermost layer)**: Large Language Models are the most specialized form — neural networks trained on massive text datasets to understand and generate human language. Examples: OpenAI's GPT-5.6, Anthropic's Claude (Fable 5, Opus 4.8, Sonnet 5), Google's Gemini, and Mistral.

**Why this matters for developers**: When someone says "AI", they might mean any of these layers. Understanding the hierarchy helps you:

- Choose the right tool (you don't need an LLM for simple pattern matching)
- Set realistic expectations (each layer has different capabilities and limitations)
- Communicate precisely with colleagues and stakeholders

##==##

<img src="assets/images/10_module_1/ai-timeline.svg" alt="AI Evolution Timeline showing key milestones from 1950 Turing Test through 2026 Agentic AI" style="width:100%; height:auto; display:block;">

Notes:
This timeline visualizes seven transformative milestones, color-coded by era. Let's explore what each one means:

**1950 - Turing Test**: Alan Turing asked "Can machines think?" and proposed a test where if humans can't distinguish a machine's responses from another human's, the machine demonstrates intelligence. This philosophical question became the foundation for all AI research.

**1956 - "AI" Coined**: At the Dartmouth Conference, John McCarthy and colleagues officially created "Artificial Intelligence" as a research field. They believed machines could simulate any aspect of human learning and intelligence - launching AI as we know it today.

**1986 - Backpropagation**: This breakthrough algorithm taught neural networks to learn by propagating errors backward through layers and adjusting weights. It's the mathematical technique that makes deep learning possible - without it, modern AI couldn't exist.

**2012 - AlexNet**: This deep neural network won an image recognition competition by a huge margin, proving that deep learning with GPUs and large datasets vastly outperforms traditional methods. It triggered the deep learning revolution and massive AI investment we see today.

**2017 - Transformers**: Google's "Attention Is All You Need" paper introduced the Transformer architecture, which processes text sequences in parallel using attention mechanisms to understand word relationships. This is the foundation for ALL modern LLMs - GPT, Claude, and Gemini all use Transformers.

**2022 - ChatGPT**: OpenAI made powerful language AI accessible to everyone through a simple chat interface. This mainstream moment demonstrated that LLMs can understand context, generate human-like text, and assist with countless tasks - proving AI was ready for daily use.

**2025 - Agentic AI**: The current frontier where AI doesn't just respond but autonomously plans, uses tools, executes multi-step tasks, and writes complete applications. This represents AI evolving from assistant to autonomous collaborator in software development.

Notice the exponential acceleration: more progress since 2017 than the previous 60 years combined.

##==##

<img src="assets/images/10_module_1/tools-evolution.svg" alt="AI Evolution Timeline showing key milestones from 1950 Turing Test through 2026 Agentic AI" style="width:100%; height:auto; display:block;">

Notes:
This diagram shows the 4 stages of evolution of AI-powered developer tools, from simple autocomplete to autonomous agents. Let's walk through each stage:

**Stage 1 - Autocomplete (2015-2018)**: The earliest AI coding tools provided single-line completion. Think IntelliSense and TabNine v1 - they could predict the next token or finish a line based on local context. Useful but limited, essentially pattern matching on your current file.

**Stage 2 - Suggestions (2018-2021)**: Tools became context-aware and could generate multi-line suggestions. GitHub Copilot and Kite represented this leap - they understood broader code context, could suggest entire function bodies, and learned from open-source patterns. Still reactive: you type, they suggest.

**Stage 3 - Chat (2022-2023)**: The conversational revolution. ChatGPT and Copilot Chat allowed developers to have interactive dialogues about code - asking for explanations, requesting refactors, debugging errors through conversation. The key shift: you could now describe intent in natural language rather than just waiting for completions.

**Stage 4 - Agents (2024-present)**: Where we are NOW. Tools like Cursor, Claude Code, and Copilot Agents can autonomously plan and execute multi-file tasks. They read your codebase, create files, run tests, fix errors, and iterate - all with minimal human intervention. This is the agentic paradigm we'll explore throughout this training.

**Key insight**: Each stage builds on the previous ones. Agentic tools still use autocomplete, suggestions, and chat internally - but they add autonomous task planning and execution on top. The behavior evolves from reactive (waiting for your input) to proactive (anticipating needs) to interactive (conversing) to autonomous (acting independently).

Notice the legend at the bottom: the color coding reflects this behavioral shift - blue for reactive/proactive, orange for interactive, green for autonomous. Understanding which stage a tool operates at helps you set the right expectations and use it effectively.
