<!-- .slide: class="transition" -->

# Tools Panorama

## Types of AI Coding Tools

Notes:
Now let's look at the different categories of AI coding tools. They come in distinct flavors — each designed for a different workflow. Understanding these types helps you pick the right tool for the job.

##==##

<!-- .slide: -->

# **Types of AI Coding Tools**

| Type              | How It Works                                                            | Examples                |
| ----------------- | ----------------------------------------------------------------------- | ----------------------- |
| **IDE Extension** | Plugs into your existing editor (VS Code, JetBrains, Eclipse)           | GitHub Copilot, Codeium |
| **CLI Agent**     | Runs in your terminal, reads/writes files autonomously                  | Claude Code, Gemini CLI |
| **AI-Native IDE** | Fork of existing or brand new tool with AI built into every interaction | Cursor, Windsurf        |

<br>

### **💡Notes**

- Most developers combine **an IDE extension + a CLI agent** for maximum coverage.

- Most CLI-based agents have a **"ide mode"** that allows you to connect them to your IDE as well (to preview new or edited files for e.g).

Notes:
These three categories cover the vast majority of AI coding tools available today.

**IDE Extensions** are the most common entry point. They add AI features to an editor you already know, with zero workflow disruption. The AI lives in a sidebar or inline panel - you stay in your familiar environment.

**CLI Agents** are terminal-first tools that operate autonomously. They can read your entire codebase, run shell commands, execute tests, and make changes across many files in one session. They excel at tasks that span multiple files or require iteration (run tests → fix errors → re-run).

**AI-Native IDEs** (like Cursor or Windsurf) are forks of VS Code that deeply integrate AI into the editing experience — inline diffs, agent-mode tabs, and AI-aware navigation. The trade-off: you switch editors entirely.

The key insight is that these types are complementary, not competing. A CLI agent excels at autonomous refactoring that would be tedious in an IDE panel. An IDE extension excels at quick inline completions while you're typing. Many developers use both daily.

---

**GitHub Copilot** is the Swiss Army knife — it covers completions, chat, and now agent mode (Copilot Coding Agent) that can autonomously work on issues and open PRs. Its strength is ecosystem integration: it's embedded in your IDE and connected to your GitHub workflow (issues, PRs, code review). Available across VS Code, JetBrains, Xcode, and even the command line via GitHub CLI.

**Claude Code** runs entirely in your terminal. You point it at a codebase and describe what you want — it reads files, plans changes, writes code, runs commands, and iterates. It supports MCP for extending its capabilities with external tools. Particularly strong at large-scale refactoring, debugging across multiple files, and tasks requiring reasoning over complex codebases.

**Codex CLI** is OpenAI's open-source terminal agent. It runs commands in a sandboxed environment for safety, supports multiple autonomy levels (suggest, auto-edit, full-auto), and integrates with the OpenAI model ecosystem. It can also run as a VS Code extension or desktop app.

**Gemini CLI** _(retired May 2026; consumer access ended June 18, 2026 — succeeded by the Go-based **Antigravity CLI**, unveiled at Google I/O 2026 with async multi-agent orchestration)_ stood out with its 1M token context window — it could ingest entire codebases in a single prompt. It was open-source (Apache 2.0), included built-in Google Search grounding for real-time information, and supported MCP servers. Its generous free tier (60 req/min) made it accessible for experimentation.

##==##

<!-- .slide: -->

# **Choosing by Task Type**

<br>

| Task                      | Recommended Type          | Example Tool                    |
| ------------------------- | ------------------------- | ------------------------------- |
| Quick inline completion   | IDE Extension             | GitHub Copilot                  |
| Explaining code           | IDE Extension / CLI       | Copilot Chat, Gemini CLI        |
| Multi-file refactoring    | CLI Agent / AI-Native IDE | Claude Code, Codex CLI, Cursor  |
| Codebase-wide analysis    | CLI Agent / AI-Native IDE | Gemini CLI, Windsurf            |
| Scaffolding a new project | CLI Agent / AI-Native IDE | Claude Code, Gemini CLI, Cursor |
| PR review & collaboration | IDE Extension             | GitHub Copilot                  |

Notes:
The rule of thumb is simple: if you're editing a single file and need quick help, use your IDE extension. If the task spans multiple files, requires iteration, or involves running commands, reach out for a CLI agent.

In practice, most developers develop a workflow like this: Copilot handles completions and quick chats as you type. When you hit a bigger task (refactor this module, debug this failing test suite, scaffold a new service), you switch to a CLI agent like Claude Code or Gemini CLI.

In Module 3, you'll get hands-on practice with these tools and develop your own preferences.
