<!-- .slide: class="transition" -->

# Évaluation et synthèse

## Résumé du module 1

Notes:
Revoyons ce que nous avons appris et vérifions votre compréhension avant de passer au module 2, où nous explorerons la différence entre vibe coding et agentic coding.

##==##

<!-- .slide: -->

# **Revue des objectifs pédagogiques**

<br>

### **Vous devriez maintenant savoir :**

- **Expliquer** la hiérarchie IA > ML > Deep Learning > IA générative > LLM
- **Classer** les modèles d'IA par gamme (Frontier, Balanced, Fast) et par type (Reasoning, Open-Weight)
- **Comparer** GPT-5.6 Sol, Claude Fable 5 et Gemini 3.1 Pro sur les benchmarks clés
- **Appliquer** 5 techniques de prompting pour la génération de code
- **Comprendre** les tokens, les fenêtres de contexte et leurs contraintes pratiques
- **Identifier** quel type d'outil IA (extension IDE, agent CLI, IDE AI-Native) utiliser selon la tâche

<br>

**À retenir**

Le développement augmenté par l'IA repose sur le **choix du bon outil** et une **communication claire** via des prompts bien conçus.

Notes:
Si l'un de ces objectifs reste flou, relisez la section concernée avant de continuer. Le module 2 s'appuie sur ces bases pour explorer des usages sûrs et efficaces de ces outils.

##==##

<!-- .slide: -->

# **Quiz de validation**

## **Question 1 : fenêtre de contexte**

<br>

### Un développeur envoie une base de code de 100K tokens à un modèle doté d'une fenêtre de contexte de 128K tokens. Combien de tokens restent pour sa réponse ?

**A)** 128K tokens — la fenêtre de réponse vaut toujours la taille totale du contexte  
**B)** 28K tokens — les tokens d'entrée et de sortie partagent la même fenêtre  
**C)** 100K tokens — seuls les tokens d'entrée comptent dans la limite  
**D)** Cela dépend de la formule tarifaire du fournisseur du modèle

<details>
<summary>Réponse</summary>
<strong>B) 28K tokens</strong> — Les tokens d'entrée + les tokens de sortie doivent tenir dans la fenêtre de contexte totale. Envoyer 100K tokens en entrée ne laisse que 28K pour la réponse du modèle. Quand un outil « oublie » soudain le contexte précédent, une fenêtre de contexte saturée est la cause la plus fréquente.
</details>

Notes:
Teste la compréhension de la contrainte de fenêtre de contexte vue dans la slide dédiée aux tokens/contexte. La formule clé : Entrée + Sortie ≤ fenêtre totale. Les développeurs doivent être stratégiques sur ce qu'ils placent dans le contexte.

##==##

<!-- .slide: -->

# **Quiz de validation**

## **Question 2 : hiérarchie de l'IA**

<br>

### Dans la hiérarchie de l'IA, quelle couche contient directement les LLM (grands modèles de langage) ?

**A)** Machine Learning  
**B)** IA générative  
**C)** Traitement du langage naturel (NLP)  
**D)** Deep Learning

<details>
<summary>Réponse</summary>
<strong>B) IA générative</strong> — Les LLM sont la couche la plus interne, imbriquée dans l'IA générative. L'imbrication complète est : IA ⊃ Machine Learning ⊃ Deep Learning ⊃ IA générative ⊃ LLM. Les LLM (GPT, Claude, Gemini, Mistral) sont le sous-ensemble le plus spécialisé — des modèles qui génèrent du texte et du code.
</details>

Notes:
Teste la hiérarchie de l'IA vue dans la slide sur les fondamentaux. Une erreur fréquente consiste à ajouter le NLP comme couche distincte — il n'apparaît pas dans le schéma. L'ordre correct est IA > ML > Deep Learning > IA générative > LLM, les LLM étant la couche la plus interne.

##==##

<!-- .slide: -->

# **Quiz de validation**

## **Question 3 : choisir le bon outil**

<br>

### Un développeur doit refactorer la logique d'authentification répartie sur 15 fichiers dans un monorepo. Quel type d'outil est le plus adapté ?

**A)** Agent CLI (ex. Claude Code, Gemini CLI)  
**B)** Extension IDE (ex. GitHub Copilot)  
**C)** IDE AI-Native (ex. Cursor, Windsurf)  
**D)** Les trois types conviennent également à cette tâche

<details>
<summary>Réponse</summary>
<strong>C) IDE AI-Native</strong> — Pour un développeur travaillant en local, les IDE AI-Native comme Cursor ou Windsurf sont le choix le plus ergonomique : leurs modes agent natifs gèrent les éditions multi-fichiers avec un aperçu du diff en ligne par fichier, peuvent lancer des commandes terminal et des tests depuis l'éditeur, et évitent tout changement de contexte. Les agents CLI (A) comme Claude Code ou Gemini CLI sont tout aussi capables et brillent en mode headless, en CI ou sur un serveur distant, sans interface graphique. Les extensions IDE (B) excellent pour la complétion en ligne et le chat rapide, mais ne sont pas conçues pour l'exécution autonome multi-fichiers.
</details>

Notes:
Teste le cadre de choix d'outil vu dans la slide panorama des outils. Les IDE AI-Native sont le choix le plus ergonomique pour les tâches multi-fichiers en local, grâce aux modes agent natifs avec aperçu du diff en ligne. Les agents CLI sont la référence pour les contextes headless ou automatisés. Les extensions IDE conviennent mieux aux scénarios mono-fichier et d'aide rapide.

##==##

<!-- .slide: -->

# **Ressources**

<br>

### **Solutions du lab**

- <code data-markdown-preview="/labs/lab-11-prompt-engineering-solution/README.md">labs/lab-11-prompt-engineering-solution/README.md</code>

### **Pour aller plus loin**

<!-- .element: class="md-padding-top"-->

- [Guide de prompt engineering OpenAI](https://platform.openai.com/docs/guides/prompt-engineering)
- [Documentation Claude d'Anthropic](https://docs.anthropic.com/)
- [Guide de prompting Google AI](https://ai.google.dev/gemini-api/docs/prompting-intro)

Notes:
Le module 2 est essentiel pour comprendre comment utiliser les outils d'IA de façon responsable et efficace. Les compétences de prompting acquises ici seront indispensables pour l'approche agentique que nous aborderons ensuite.
