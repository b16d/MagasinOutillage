<!-- .slide: class="transition" -->

# Panorama des outils

## Types d'outils de code IA

Notes:
Voyons maintenant les différentes catégories d'outils de code IA. Elles se déclinent en familles distinctes — chacune pensée pour un workflow différent. Comprendre ces types aide à choisir le bon outil pour la bonne tâche.

##==##

<!-- .slide: -->

# **Types d'outils de code IA**

| Type              | Fonctionnement                                                           | Exemples                |
| ----------------- | ------------------------------------------------------------------------ | ----------------------- |
| **Extension IDE** | S'intègre à votre éditeur actuel (VS Code, JetBrains, Eclipse)           | GitHub Copilot, Codeium |
| **Agent CLI**     | Tourne dans le terminal, lit/écrit les fichiers en autonomie             | Claude Code, Gemini CLI |
| **IDE natif IA**  | Fork d'un outil existant ou outil neuf, IA intégrée à chaque interaction | Cursor, Windsurf        |

<br>

### **💡Notes**

- La plupart des devs combinent **une extension IDE + un agent CLI** pour une couverture maximale.

- La plupart des agents CLI ont un **« mode ide »** qui permet aussi de les relier à votre IDE (pour prévisualiser les fichiers créés ou modifiés, par ex.).

Notes:
Ces trois catégories couvrent la grande majorité des outils de code IA disponibles aujourd'hui.

**Les extensions IDE** sont le point d'entrée le plus courant. Elles ajoutent des fonctions IA à un éditeur que vous connaissez déjà, sans rupture de workflow. L'IA vit dans une barre latérale ou un panneau inline - vous restez dans votre environnement familier.

**Les agents CLI** sont des outils terminal-first qui opèrent en autonomie. Ils peuvent lire toute votre codebase, lancer des commandes shell, exécuter les tests et modifier de nombreux fichiers en une seule session. Ils excellent sur les tâches qui touchent plusieurs fichiers ou demandent de l'itération (lancer les tests → corriger les erreurs → relancer).

**Les IDE natifs IA** (comme Cursor ou Windsurf) sont des forks de VS Code qui intègrent l'IA en profondeur dans l'expérience d'édition — diffs inline, onglets en mode agent, navigation consciente de l'IA. La contrepartie : vous changez complètement d'éditeur.

L'idée clé : ces types sont complémentaires, pas concurrents. Un agent CLI excelle sur le refactoring autonome qui serait fastidieux dans un panneau d'IDE. Une extension IDE excelle sur les complétions inline rapides pendant que vous tapez. Beaucoup de devs utilisent les deux au quotidien.

---

**GitHub Copilot** est le couteau suisse — il couvre les complétions, le chat, et désormais le mode agent (Copilot Coding Agent) capable de traiter des issues et d'ouvrir des PR en autonomie. Sa force : l'intégration à l'écosystème : il est embarqué dans votre IDE et connecté à votre workflow GitHub (issues, PR, revue de code). Disponible sur VS Code, JetBrains, Xcode, et même en ligne de commande via GitHub CLI.

**Claude Code** tourne entièrement dans votre terminal. Vous le pointez sur une codebase et décrivez ce que vous voulez — il lit les fichiers, planifie les changements, écrit le code, lance des commandes et itère. Il supporte MCP pour étendre ses capacités avec des outils externes. Particulièrement fort sur le refactoring à grande échelle, le débogage multi-fichiers et les tâches demandant du raisonnement sur des codebases complexes.

**Codex CLI** est l'agent terminal open-source d'OpenAI. Il exécute les commandes dans un environnement sandboxé par sécurité, propose plusieurs niveaux d'autonomie (suggest, auto-edit, full-auto) et s'intègre à l'écosystème de modèles OpenAI. Il peut aussi tourner en extension VS Code ou en application desktop.

**Gemini CLI** _(retiré en mai 2026 ; accès grand public arrêté le 18 juin 2026 — remplacé par **Antigravity CLI**, en Go, dévoilé au Google I/O 2026 avec orchestration multi-agents asynchrone)_ se distinguait par sa fenêtre de contexte de 1M tokens — il pouvait ingérer des codebases entières en un seul prompt. Il était open-source (Apache 2.0), incluait le grounding Google Search intégré pour l'information en temps réel et supportait les serveurs MCP. Son free tier généreux (60 req/min) le rendait accessible pour l'expérimentation.

##==##

<!-- .slide: -->

# **Choisir selon le type de tâche**

<br>

| Tâche                        | Type recommandé          | Outil exemple                   |
| ---------------------------- | ------------------------ | ------------------------------- |
| Complétion inline rapide     | Extension IDE            | GitHub Copilot                  |
| Expliquer du code            | Extension IDE / CLI      | Copilot Chat, Gemini CLI        |
| Refactoring multi-fichiers   | Agent CLI / IDE natif IA | Claude Code, Codex CLI, Cursor  |
| Analyse de toute la codebase | Agent CLI / IDE natif IA | Gemini CLI, Windsurf            |
| Démarrer un nouveau projet   | Agent CLI / IDE natif IA | Claude Code, Gemini CLI, Cursor |
| Revue de PR & collaboration  | Extension IDE            | GitHub Copilot                  |

Notes:
La règle du pouce est simple : si vous éditez un seul fichier et voulez un coup de main rapide, utilisez votre extension IDE. Si la tâche touche plusieurs fichiers, demande de l'itération ou implique de lancer des commandes, prenez un agent CLI.

En pratique, la plupart des devs adoptent un workflow de ce type : Copilot gère les complétions et les chats rapides pendant que vous tapez. Quand arrive une tâche plus lourde (refactorer ce module, déboguer cette suite de tests en échec, démarrer un nouveau service), vous passez à un agent CLI comme Claude Code ou Gemini CLI.

Dans le module 3, vous pratiquerez ces outils et développerez vos propres préférences.
