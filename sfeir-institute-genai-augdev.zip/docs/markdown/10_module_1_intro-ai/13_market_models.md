<!-- .slide: class="transition" -->

# Market Models Comparison

## GPT, Claude, and Gemini

Notes:
Now that you understand what AI is, let's look at what AI models actually are, how they're evaluated, and the different categories you'll encounter. Then we'll compare the major models head-to-head.

##==##

<!-- .slide: -->

# **What is an AI Model?**

### **Definition**

An **AI model** is a mathematical system — typically a neural network with billions of **parameters** — trained on massive datasets to recognize patterns and generate outputs (text, code, images...).

<br>

### **Key Concepts**

- **Parameters**: The internal variables (weights) learned during training — the model's "knowledge"
- **Training**: Pre-training on data (self-supervised) + fine-tuning with human feedback (RLHF)
- **Inference**: Processing your prompt through the network to generate a response, token by token
- **Transformers**: The architecture (2017) powering ALL modern LLMs — GPT, Claude, Gemini

Notes:
An AI model is the core computational artifact — the trained neural network itself. It's important to understand this distinction because in daily conversation, people often conflate the model with the product or service built around it.

**Parameters** are the billions of numerical values (weights and biases) that the network has learned during training. Think of them as the model's accumulated knowledge. Frontier models today have hundreds of billions to trillions of parameters — for example, Meta's Llama 4 Maverick has ~400B parameters.

**Training happens in two phases:**

1. **Pre-training**: The model processes massive amounts of text, code, and other data, learning to predict the next token. This is self-supervised learning — no human labels needed. The model learns grammar, facts, coding patterns, reasoning, and more — all from predicting what comes next.

2. **Fine-tuning / RLHF (Reinforcement Learning from Human Feedback)**: After pre-training, humans rate the model's outputs, and the model is refined to be more helpful, harmless, and honest. This is what makes raw language models into useful assistants.

**Inference** is what happens when you use the model: your input (prompt) flows through the layers of the network, and the model generates output one token at a time, each time selecting the most probable next token given everything that came before.

**Transformers** (introduced in Google's "Attention Is All You Need" paper, 2017) are the foundational architecture. They process text in parallel using "attention mechanisms" that let the model understand relationships between any words in the input, regardless of distance. Every major LLM today — GPT, Claude, Gemini, Llama — is built on Transformers.

##==##

<!-- .slide: -->

<img src="assets/images/10_module_1/model-evaluation.svg" alt="How AI Models Are Evaluated showing key benchmarks with current scores and evaluation dimensions" style="width:100%; height:auto; display:block;">

Notes:
Understanding how models are evaluated helps you cut through marketing hype and make informed decisions. The benchmark landscape shifted decisively in early 2026 — older static tests (MMLU, HumanEval, GSM8K) are now saturated, replaced by harder, contamination-resistant, real-world evaluations.

**Key Benchmarks (left side) — with current top scores:**

- **SWE-bench Verified**: The gold standard for coding. Models must fix real GitHub issues by generating correct code patches across actual open-source repositories. Top scores (July 2026): Claude Fable 5 leads at ~95%, followed by Claude Opus 4.8 at ~88-89%, with GPT-5.6 Sol and Gemini 3.5 Flash in the top tier. Important caveat: scores vary with the scaffolding/harness used — independent runs (e.g., Simon Willison's analysis) show somewhat lower numbers, and vendors' headline figures often use their own scaffolding rather than a neutral harness. A harder variant, **SWE-bench Pro** (Scale AI), uses private codebases — Claude Fable 5 currently posts the top reported score (~80%).

- **LiveCodeBench**: Competition-level coding problems that are continuously refreshed with new problems, making memorization and data contamination impossible. Current leaders (July 2026): Gemini 3.5 Flash, GPT-5.6 Sol, and Claude Fable 5 sit at the top — exact rankings shift as new problems land. This benchmark is uniquely trustworthy because its dataset is always fresh.

- **Aider Polyglot**: 225 Exercism exercises across 6 languages (C++, Go, Java, JavaScript, Python, Rust) — measures a model's ability to edit existing code in a diff format, not just generate from scratch. As of July 2026, Claude Fable 5 and Opus 4.8 lead, followed by GPT-5.6 Sol and Gemini 3.5 Flash. This is the most practical benchmark for how well a model works inside an AI coding assistant.

- **Arena Elo (LMArena)**: Crowdsourced human preference rankings from millions of anonymous pairwise votes across 300+ models. As of July 2026, Claude Fable 5 leads, followed closely by Opus 4.8, GPT-5.6 Sol, Gemini 3.1 Pro, and Claude Sonnet 5 — exact Elo scores shift daily as votes accumulate. This is the best proxy for "which model feels best to actually use" — it captures quality dimensions that automated benchmarks miss.

- **GPQA Diamond**: PhD-level science questions created by domain experts. Top models now surpass human expert performance (~89.8%): as of July 2026, GPT-5.6 Sol and Gemini 3.1 Pro lead (both above ~90%), with Claude Fable 5 close behind. Tests deep multi-step reasoning — useful for evaluating how well a model handles complex technical analysis.

**Evaluation Dimensions (right side):**
Models are evaluated across seven key dimensions. No single model wins on all of them:

- **Coding**: The most important for developers. Measured by SWE-bench, LiveCodeBench, and Aider Polyglot.
- **Reasoning**: Deep multi-step problem solving. Measured by GPQA Diamond, Humanity's Last Exam (HLE, published in Nature — top scores still only ~25%), and FrontierMath.
- **Agentic**: Autonomous multi-step task completion. Measured by Terminal-Bench Hard (89 real terminal tasks), SWE-bench Pro, and tool-use evaluations. Increasingly important as AI shifts toward agentic coding workflows.
- **Instruction Following**: Does the model follow precise instructions? Measured by IFBench, IFEval, and edit format accuracy. Critical for reliable code generation.
- **Multimodal**: Understanding images, diagrams, screenshots alongside text. Measured by MMMU.
- **Human Preference**: Overall subjective quality via Arena Elo's crowdsourced rankings.
- **Safety**: Red-teaming results, alignment evaluations, and hallucination rates (measured by benchmarks like AA-Omniscience).

When choosing a model, focus on the dimensions that matter most for your use case. For most developers, Coding + Agentic + Instruction Following are the top three.

##==##

<!-- .slide: -->

<img src="assets/images/10_module_1/model-categories.svg" alt="AI Model Categories showing Frontier, Balanced, Fast, Reasoning, Embedding, and Open-Weight models with key model names" style="width:100%; height:auto; display:block;">

Notes:
This diagram maps the six categories of AI models you'll encounter, organized by how providers actually classify them. Every major provider (Anthropic, OpenAI, Google) offers a similar tiered lineup — understanding these tiers helps you pick the right model for each task.

**Row 1 — The three performance tiers (every provider has these):**

**Frontier / Flagship Models** are the most intelligent models each provider offers. Claude Fable 5 ($10/$50 per MTok, 1M context, 128K max output, always-on adaptive thinking — Anthropic's frontier "Mythos-class" model, released June 2026), GPT-5.6 Sol ($5/$30 per MTok, 1M context, 128K output, billed as OpenAI's "best coding model yet" — released July 9, 2026), and Gemini 3.1 Pro (1M token context, 2x reasoning vs 3 Pro — released Feb 19, 2026). Use these for the hardest problems: complex multi-step reasoning, large-scale refactoring, architectural decisions, and agentic workflows. They deliver the highest quality but cost more and respond slower. Alongside Fable 5, **Claude Opus 4.8** ($5/$25 per MTok, ~88-89% SWE-bench Verified) is the frontier coding/agentic workhorse — most teams run Opus-class or Sonnet 5 day-to-day and escalate to Fable 5 for the very hardest problems.

**Balanced Models** offer the best speed-to-intelligence tradeoff — the "everyday workhorse." Claude Sonnet 5 ($3/$15 per MTok, 1M context, adaptive thinking on by default — now the default model in Claude Code), GPT-5.6 Terra ($2.50/$15 per MTok, balanced everyday model), and Gemini 3.5 Flash (GA May 2026 — Google's strongest model for sustained agentic + coding work, ~4x faster than frontier models). These handle the vast majority of daily development tasks: code review, debugging, documentation, explanations, and general-purpose coding. For most developers, this is the default tier.

**Fast / Lightweight Models** prioritize speed and cost above all. Claude Haiku 4.5 ($1/$5 per MTok, fastest in the Claude family), GPT-5.6 Luna ($1/$6 per MTok, most economical in the GPT family), and Gemini 3.5 Flash-Lite (cost-efficient ultra-fast model for high-volume workloads). Use these for high-volume tasks: autocomplete suggestions, classification, summarization, quick answers, and anywhere latency or budget matters more than maximum intelligence. They scale affordably to millions of requests.

**Row 2 — Specialized model types:**

**Reasoning Models** are a distinct capability that now cuts across tiers rather than being a separate product line. Instead of responding immediately, they allocate extra compute to "think" first — generating internal chains of reasoning before answering. Claude uses adaptive thinking, on by default across Fable 5, Opus 4.8, and Sonnet 5, which decide how long to think per request (manual Extended Thinking is retired on these models). OpenAI no longer ships a separate o-series: reasoning is folded into the mainline model — GPT-5.6 exposes standard and "pro" reasoning modes plus a max-effort setting on Sol. Google provides configurable thinking budgets and Gemini Deep Think. Reasoning excels at complex debugging, algorithm design, math, security analysis, and architecture decisions. It's slower and costlier per token, but the quality improvement on hard problems is substantial.

**Embedding Models** convert text or code into semantic vectors (arrays of numbers) that capture meaning. They power search and retrieval — the backbone of RAG (Retrieval-Augmented Generation) systems. Key models: OpenAI's text-embedding-3-large, Cohere embed-v4 (multimodal — handles text and images), and Gemini Embeddings. You rarely interact with these directly, but they're essential infrastructure behind any system that needs to find relevant code, documentation, or data to feed into a chat model.

**Open-Weight / Local Models** are models whose weights are publicly available, meaning you can download and run them on your own hardware via tools like Ollama, vLLM, or llama.cpp. Meta's Llama 4 (~400B params, strongest open model), Alibaba's Qwen3, DeepSeek V3, Mistral, Microsoft's Phi-4 (~14B, punches above its weight), and Google's Gemma 3 (optimized for on-device). These are free after setup, offer full data privacy (nothing leaves your machine), and work offline. They're ideal for air-gapped environments, CI/CD pipelines, or anywhere you need predictable costs and low latency. Trade-off: they're typically 80-95% as capable as frontier cloud models.

**Row 3 — Specialized models (beyond text):**

These models handle specific modalities beyond text and code. They're not your daily drivers, but they unlock powerful capabilities when needed:

- **Image Generation**: OpenAI's GPT Image 1.5 (integrated into ChatGPT), Google's Nano Banana 2 (fast, low-cost) and Imagen 4, Stable Diffusion (open-source, run locally), and Midjourney. Useful for developers generating UI mockups, placeholder assets, diagrams, or marketing visuals.

- **Video Generation**: OpenAI's Sora 2 / Sora 2 Pro (text-to-video with synced audio), Google's Veo 3.1 (cinematic quality), and Kling. Still early-stage for most developer workflows, but increasingly useful for product demos, tutorials, and onboarding content.

- **Voice / Speech**: ElevenLabs (70+ languages, voice cloning, Eleven v3), OpenAI's Whisper (speech-to-text transcription), and Gemini TTS. Relevant for building voice interfaces, transcribing meetings, generating audio documentation, or adding accessibility features.

- **Deep Research**: OpenAI's deep research (now powered by the GPT-5.6 line) and Google's Gemini Deep Research. These are multi-step research agents that autonomously search, read, and synthesize information from multiple web sources. Useful for technology evaluation, competitive analysis, and gathering context before major architecture decisions.

**Key insight**: Every provider offers this same tiered structure — a frontier model, a balanced model, and a fast model — plus reasoning capabilities and specialized models. The skill is matching the tier to the task: don't use a frontier model for simple autocomplete (wasteful), and don't use a fast model for complex architecture decisions (insufficient).

##==##

<!-- .slide: -->

<img src="assets/images/10_module_1/models-comparison.svg" alt="The Big Three AI Models Comparison showing GPT-5.6 Sol, Claude Fable 5, and Gemini 3.1 Pro with Decision Framework" style="width:100%; height:auto; display:block;">

Notes:
**Understanding Context Windows**

Before comparing models, let's clarify a key concept: the **context window**. Think of it as the model's "working memory" - all the text it can reference when generating a response, including both your input and its output.

**Input tokens**: Everything you send to the model - your prompt, conversation history, code files, documentation, system instructions. This is what the model "reads."

**Output tokens**: Everything the model generates in response - code, explanations, answers. This is what the model "writes."

**Why it matters for developers**:

- A 200K context window means ~150,000 words of combined input + output; a 1M context window (Fable 5, Opus 4.8, Sonnet 5, GPT-5.6, Gemini) holds ~750K words
- Larger context = more code files, longer conversations, bigger codebases analyzed at once
- Input tokens are typically cheaper than output tokens (e.g., Claude Opus 4.8: $5/M input vs $25/M output)
- When you hit the limit, earlier conversation is either truncated or compressed

**Practical example**: If you paste a 10,000-line codebase (≈40K tokens) and ask for a refactoring (≈2K tokens output), you've used ~42K tokens of your context window. The remaining space can hold follow-up questions and responses.

---

These three represent different design philosophies as of July 2026:

**OpenAI GPT-5.6 Sol (July 9, 2026)**: OpenAI's flagship — billed as its "best coding model yet," with strong agentic and deep-reasoning capabilities (standard, "pro," and max-effort reasoning modes; the o-series is gone, reasoning is now a mode of the mainline model). Supports 1M input / 128K output context. Pricing: $5/$30 per million tokens. Codex CLI runs on Sol; the balanced **Terra** ($2.50/$15) and economical **Luna** ($1/$6) round out the family for everyday and high-volume work.

**Anthropic Claude Fable 5 (June 2026)**: Anthropic's most capable generally available model — the first of the frontier "Mythos-class" tier that now sits above Opus. Leads SWE-bench Verified at ~95%, with always-on adaptive thinking, 1M token context, and 128K max output. Pricing: $10/$50 per million tokens. Model ID: `claude-fable-5`. For most day-to-day coding, teams use **Claude Opus 4.8** ($5/$25, ~88-89% SWE-bench Verified) or **Sonnet 5** (the default model in Claude Code) and escalate to Fable 5 for the hardest work.

**Google Gemini 3.1 Pro (Feb 19, 2026)**: Google's top reasoning model — 2x the reasoning performance of Gemini 3 Pro, 1M token context window. Google's newer **Gemini 3.5 Flash** (GA May 2026) is its strongest model for sustained agentic + coding work and is ~4x faster, making the Flash tier surprisingly capable for its cost.

Don't get locked into one model - most professional developers use 2-3 models depending on the task. Each excels in different areas: GPT-5.6 Sol for autonomous coding and agentic reasoning, Claude Fable 5 / Opus 4.8 for the hardest agentic-coding workloads (and multi-agent workflows via Claude Code agent teams), Gemini 3.1 Pro / 3.5 Flash for massive context and multimodal tasks.
