# Glossaire — Module 1 : Introduction à l'IA pour les développeurs

> Référence des termes employés dans les slides du module 1 (`10_module1_intro` → `19_assessment_and_recap`).
> Fichier de référence, non inclus dans le deck (`docs/scripts/slides.js` liste les slides explicitement).

---

## 1. Fondamentaux de l'IA

| Terme                              | Définition                                                                                                                                                                                                               |
| ---------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| **Intelligence artificielle (IA)** | Domaine de l'informatique dédié aux systèmes capables de tâches exigeant habituellement l'intelligence humaine : apprendre, raisonner, comprendre le langage, percevoir, décider. Couche la plus large de la hiérarchie. |
| **Machine Learning (ML)**          | Sous-ensemble de l'IA où le système apprend des motifs à partir de données au lieu de suivre des règles codées. Arbres de décision, SVM, réseaux de neurones.                                                            |
| **Deep Learning**                  | ML à base de réseaux de neurones à nombreuses couches (« profond »). Chaque couche apprend des caractéristiques de plus en plus abstraites. Rendu viable par les GPU + big data.                                         |
| **IA générative**                  | Sous-ensemble du Deep Learning centré sur la création de contenu nouveau : texte, code, images, audio.                                                                                                                   |
| **LLM (Large Language Model)**     | Grand modèle de langage : couche la plus interne de la hiérarchie. Réseau entraîné sur d'immenses corpus de texte pour comprendre et générer du langage.                                                                 |
| **Hiérarchie IA**                  | IA ⊃ Machine Learning ⊃ Deep Learning ⊃ IA générative ⊃ LLM. _(Piège du quiz : le NLP n'est pas une couche de ce schéma.)_                                                                                               |
| **Multimodal**                     | Capacité d'un modèle à traiter plusieurs modalités : texte + images + schémas + captures d'écran + audio.                                                                                                                |

### Jalons historiques

| Jalon                         | Année | Ce qu'il apporte                                                                                                                          |
| ----------------------------- | ----- | ----------------------------------------------------------------------------------------------------------------------------------------- |
| **Test de Turing**            | 1950  | Alan Turing : « les machines peuvent-elles penser ? ». Si un humain ne distingue pas la machine d'un humain, la machine est intelligente. |
| **Naissance du terme « IA »** | 1956  | Conférence de Dartmouth, John McCarthy fonde le champ de recherche.                                                                       |
| **Rétropropagation**          | 1986  | Algorithme propageant l'erreur à rebours dans les couches pour ajuster les poids. Socle mathématique du deep learning.                    |
| **AlexNet**                   | 2012  | Réseau profond qui domine une compétition de reconnaissance d'images → déclenche la révolution deep learning.                             |
| **Transformers**              | 2017  | Article Google « Attention Is All You Need ». Architecture de TOUS les LLM modernes.                                                      |
| **ChatGPT**                   | 2022  | Moment grand public : l'IA linguistique devient accessible via une interface de chat.                                                     |
| **IA agentique**              | 2025+ | L'IA ne répond plus seulement : elle planifie, utilise des outils, exécute des tâches multi-étapes.                                       |

---

## 2. Anatomie d'un modèle

| Terme                                                   | Définition                                                                                                                                                                                                  |
| ------------------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| **Modèle d'IA**                                         | Système mathématique (réseau de neurones à plusieurs milliards de paramètres) entraîné sur d'immenses jeux de données pour reconnaître des motifs et générer des sorties.                                   |
| **Paramètres (poids)**                                  | Variables internes apprises pendant l'entraînement — la « connaissance » du modèle. Modèles frontier actuels : de centaines de milliards à plusieurs milliers de milliards (ex. Llama 4 Maverick ≈ 400 Md). |
| **Transformer**                                         | Architecture (2017) traitant le texte en parallèle via des **mécanismes d'attention**, qui saisissent les relations entre mots quelle que soit leur distance.                                               |
| **Pré-entraînement**                                    | Phase 1 : le modèle apprend à prédire le token suivant sur d'énormes volumes de texte/code. Auto-supervisé, sans annotation humaine.                                                                        |
| **Fine-tuning**                                         | Phase 2 : affinage du modèle pré-entraîné pour un comportement ou un domaine visé.                                                                                                                          |
| **RLHF** (_Reinforcement Learning from Human Feedback_) | Fine-tuning où des humains notent les sorties, rendant le modèle plus utile, inoffensif et honnête. Transforme un modèle de langage brut en assistant.                                                      |
| **Inférence**                                           | Exécution du modèle : votre prompt traverse le réseau, la sortie est générée **token par token**, chacun étant le plus probable au vu de ce qui précède.                                                    |
| **Hallucination**                                       | Sortie plausible mais fausse. Mesurée par des benchmarks dédiés (ex. AA-Omniscience).                                                                                                                       |
| **Red-teaming**                                         | Attaques délibérées sur un modèle pour tester sa sûreté et son alignement.                                                                                                                                  |

---

## 3. Tokens et contexte

| Terme                                      | Définition                                                                                                                                                                                                   |
| ------------------------------------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| **Token**                                  | Plus petite unité de texte traitée par un LLM — un mot ou un morceau de mot. `function getUserName()` → 6 tokens : `function` \| `get` \| `User` \| `Name` \| `(` \| `)`. Unité de facturation des API.      |
| **Tokenizer**                              | Composant qui découpe le texte en tokens. Varie selon le modèle : le tokenizer de Sonnet 5 produit ~30 % de tokens en plus que Sonnet 4.6 pour le même texte.                                                |
| **Ordres de grandeur**                     | Texte anglais : 1 mot ≈ 1,3 token. Code : 1 ligne ≈ 5-10 tokens. 1 000 lignes de code ≈ 5 000-8 000 tokens.                                                                                                  |
| **Fenêtre de contexte** (_context window_) | Nombre maximal de tokens traités en une seule interaction. Inclut **tout** : prompt système, saisie utilisateur, historique, fichiers joints **et** la réponse générée. La « mémoire de travail » du modèle. |
| **Règle d'or**                             | **Tokens d'entrée + Tokens de sortie ≤ Fenêtre de contexte totale.** Ex. 100K envoyés dans une fenêtre 128K → 28K restants pour la réponse.                                                                  |
| **Tokens d'entrée**                        | Ce que le modèle « lit » : prompts système, vos messages, historique, fichiers de code et documentation joints. Généralement moins chers que la sortie.                                                      |
| **Tokens de sortie**                       | Ce que le modèle « écrit » : code et texte générés, explications, analyses. Plafond distinct de la fenêtre (typiquement 64K-128K).                                                                           |
| **MTok**                                   | Million de tokens — unité de tarification (ex. « 5 $/25 $ par MTok » = entrée/sortie).                                                                                                                       |
| **Troncature / compression**               | À saturation de la fenêtre, le début de la conversation est coupé ou résumé → le modèle « oublie ». Cause n°1 des comportements incohérents en session longue.                                               |
| **RAG** (_Retrieval-Augmented Generation_) | Technique consistant à retrouver les documents/extraits pertinents et à les injecter dans le contexte, plutôt que de tout y entasser. Repose sur les embeddings.                                             |

---

## 4. Évaluation et benchmarks

| Benchmark                                                        | Ce qu'il mesure                                                                                                                                                                                                       |
| ---------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| **SWE-bench Verified**                                           | Référence code : corriger de vrais tickets GitHub sur des dépôts open source. Juillet 2026 : Claude Fable 5 ≈ 95 %, Claude Opus 4.8 ≈ 88-89 %.                                                                        |
| **SWE-bench Pro**                                                | Variante plus dure (Scale AI) sur des bases de code privées. Fable 5 ≈ 80 %.                                                                                                                                          |
| **LiveCodeBench**                                                | Problèmes de code niveau compétition, renouvelés en continu → mémorisation et contamination impossibles.                                                                                                              |
| **Aider Polyglot**                                               | 225 exercices Exercism en 6 langages (C++, Go, Java, JavaScript, Python, Rust). Mesure l'**édition** de code existant au format diff, pas la génération de zéro. Le plus proche de l'usage réel en assistant de code. |
| **Arena Elo (LMArena)**                                          | Classement de préférence humaine issu de millions de votes anonymes par paires sur 300+ modèles. Meilleur proxy du « plus agréable au quotidien ».                                                                    |
| **GPQA Diamond**                                                 | Questions scientifiques niveau doctorat créées par des experts. Les meilleurs modèles dépassent les experts humains (~89,8 %).                                                                                        |
| **HLE** (_Humanity's Last Exam_)                                 | Raisonnement extrême, publié dans Nature. Meilleurs scores encore ~25 %.                                                                                                                                              |
| **FrontierMath / Terminal-Bench Hard / IFBench / IFEval / MMMU** | Respectivement : maths avancées, 89 tâches terminal réelles (agentique), suivi d'instructions, compréhension multimodale.                                                                                             |
| **MMLU / HumanEval / GSM8K**                                     | Anciens benchmarks statiques, désormais **saturés** — peu discriminants.                                                                                                                                              |
| **Scaffolding / harness**                                        | Couche d'outillage autour du modèle pendant un benchmark. Les scores éditeurs reposent souvent sur leur propre scaffolding → chiffres plus hauts que les runs neutres.                                                |

**Les 7 dimensions d'évaluation** : Code · Raisonnement · Agentique · Suivi des instructions · Multimodal · Préférence humaine · Sûreté.
Aucun modèle ne gagne sur toutes. Trio prioritaire pour un développeur : **Code + Agentique + Suivi des instructions**.

---

## 5. Catégories de modèles

| Catégorie               | Rôle                                                                                                                                                       | Exemples (juillet 2026)                                                                                               |
| ----------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------- |
| **Frontier / flagship** | Problèmes les plus durs : raisonnement complexe, refactoring à grande échelle, architecture, agentique. Meilleure qualité, plus cher, plus lent.           | Claude Fable 5 (10 $/50 $ MTok, 1M ctx, 128K out), Claude Opus 4.8 (5 $/25 $), GPT-5.6 Sol (5 $/30 $), Gemini 3.1 Pro |
| **Équilibré**           | Cheval de trait du quotidien : revue de code, débogage, doc, explications. Palier par défaut.                                                              | Claude Sonnet 5 (3 $/15 $, défaut dans Claude Code), GPT-5.6 Terra (2,50 $/15 $), Gemini 3.5 Flash                    |
| **Rapide / léger**      | Fort volume, latence et budget prioritaires : autocomplétion, classification, résumé.                                                                      | Claude Haiku 4.5 (1 $/5 $), GPT-5.6 Luna (1 $/6 $), Gemini 3.5 Flash-Lite                                             |
| **Raisonnement**        | Capacité transversale (plus une gamme séparée) : le modèle alloue du calcul pour « réfléchir » avant de répondre.                                          | Thinking adaptatif Claude, modes standard/pro/max-effort de GPT-5.6, budgets de réflexion + Deep Think chez Google    |
| **Embedding**           | Convertit texte/code en vecteurs sémantiques pour la recherche et la récupération. Colonne vertébrale du RAG.                                              | text-embedding-3-large, Cohere embed-v4, Gemini Embeddings                                                            |
| **Open-weight / local** | Poids publics, exécutables sur votre matériel. Gratuit après installation, confidentialité totale, hors ligne. Atteint 80-95 % des modèles frontier cloud. | Llama 4 (~400 Md), Qwen3, DeepSeek V3, Mistral, Phi-4 (~14 Md), Gemma 3                                               |

| Terme                   | Définition                                                                                                                                                                                                                    |
| ----------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| **Thinking adaptatif**  | Le modèle décide lui-même du temps de réflexion par requête. Actif par défaut sur Fable 5, Opus 4.8 et Sonnet 5 — l'**Extended Thinking** manuel y est retiré.                                                                |
| **Runtime local**       | Outils d'exécution de modèles open-weight sur votre machine : **Ollama**, **vLLM**, **llama.cpp**.                                                                                                                            |
| **Modèles spécialisés** | Images (GPT Image 1.5, Nano Banana 2, Imagen 4, Stable Diffusion, Midjourney) · Vidéo (Sora 2, Veo 3.1, Kling) · Voix (ElevenLabs, Whisper, Gemini TTS) · Recherche approfondie (OpenAI deep research, Gemini Deep Research). |
| **Règle d'appariement** | Faire correspondre le palier à la tâche : pas de modèle frontier pour de l'autocomplétion (gaspillage), pas de modèle rapide pour de l'architecture (insuffisant).                                                            |

---

## 6. Outils de code IA

### Les 4 étapes d'évolution

| Étape                 | Période            | Comportement                                                                     | Exemples                            |
| --------------------- | ------------------ | -------------------------------------------------------------------------------- | ----------------------------------- |
| **1. Autocomplétion** | 2015-2018          | Réactif — complète une ligne depuis le contexte local                            | IntelliSense, TabNine v1            |
| **2. Suggestions**    | 2018-2021          | Proactif — suggestions multi-lignes, corps de fonction entiers                   | GitHub Copilot, Kite                |
| **3. Chat**           | 2022-2023          | Interactif — on décrit une intention en langage naturel                          | ChatGPT, Copilot Chat               |
| **4. Agents**         | 2024 → aujourd'hui | Autonome — planifie et exécute des tâches multi-fichiers, lance les tests, itère | Cursor, Claude Code, Copilot Agents |

> Chaque étape s'appuie sur les précédentes : les agents utilisent toujours autocomplétion, suggestions et chat en interne.

### Les 3 types d'outils

| Type                           | Fonctionnement                                                                                                                                         | Exemples                           |
| ------------------------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------ | ---------------------------------- |
| **Extension IDE**              | S'intègre à l'éditeur existant (VS Code, JetBrains, Eclipse). Sidebar ou panneau inline, pas de rupture de workflow.                                   | GitHub Copilot, Codeium            |
| **Agent CLI**                  | Terminal-first, lit/écrit les fichiers en autonomie, lance des commandes shell et les tests, itère sur une session.                                    | Claude Code, Codex CLI, Gemini CLI |
| **IDE natif IA** (_AI-Native_) | Fork de VS Code (ou outil neuf) avec IA intégrée à chaque interaction : diffs inline, onglets mode agent. Contrepartie : changement complet d'éditeur. | Cursor, Windsurf                   |

| Terme                              | Définition                                                                                                                                                                    |
| ---------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| **Mode « ide »**                   | Option de la plupart des agents CLI permettant de les relier à l'IDE (aperçu des fichiers créés/modifiés).                                                                    |
| **MCP** (_Model Context Protocol_) | Protocole d'extension des capacités d'un agent via des outils externes. Supporté par Claude Code, Codex CLI, Gemini CLI. Détaillé aux modules 5 et 12.                        |
| **Niveaux d'autonomie**            | Paliers de liberté d'un agent CLI, ex. Codex CLI : _suggest_ → _auto-edit_ → _full-auto_.                                                                                     |
| **Sandbox**                        | Environnement d'exécution isolé où l'agent lance ses commandes (Codex CLI).                                                                                                   |
| **Grounding**                      | Ancrage des réponses sur une source externe temps réel (ex. Google Search dans Gemini CLI).                                                                                   |
| **Antigravity CLI**                | Remplaçant de **Gemini CLI** (retiré en mai 2026, accès grand public arrêté le 18 juin 2026). Écrit en Go, dévoilé au Google I/O 2026, orchestration multi-agents asynchrone. |

### Choisir selon la tâche

| Tâche                        | Type recommandé                                                     |
| ---------------------------- | ------------------------------------------------------------------- |
| Complétion inline rapide     | Extension IDE                                                       |
| Expliquer du code            | Extension IDE / Agent CLI                                           |
| Refactoring multi-fichiers   | IDE natif IA (en local) / Agent CLI (headless, CI, serveur distant) |
| Analyse de toute la codebase | Agent CLI / IDE natif IA                                            |
| Démarrer un nouveau projet   | Agent CLI / IDE natif IA                                            |
| Revue de PR & collaboration  | Extension IDE                                                       |

---

## 7. Prompting

| Technique               | Définition                                                              | Exemple                                                      |
| ----------------------- | ----------------------------------------------------------------------- | ------------------------------------------------------------ |
| **1. Role**             | Dire à l'IA qui elle doit être — change son angle d'attaque.            | « Tu es un développeur backend senior »                      |
| **2. Context**          | Donner stack technique, contraintes et objectifs.                       | « API Node.js Express qui doit encaisser 10K req/s »         |
| **3. Format**           | Préciser la forme de sortie attendue.                                   | « Renvoie un objet JSON »                                    |
| **4. Examples**         | Montrer plutôt qu'expliquer — fournir un échantillon du résultat voulu. | « Voici comment nous structurons nos endpoints : [exemple] » |
| **5. Chain-of-Thought** | Demander les étapes de raisonnement avant la réponse.                   | « Réfléchis étape par étape avant de donner la solution »    |

> Techniques **cumulatives** : Role + Context pour le simple → + Format pour du structuré → + Examples pour des patterns précis → + Chain-of-Thought pour le raisonnement complexe.

| Terme                  | Définition                                                                                                                                                       |
| ---------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| **Prompt**             | Instruction envoyée au modèle. La qualité du prompt — pas la connaissance de l'IA — sépare le plus souvent un usage junior d'un usage senior.                    |
| **Prompt système**     | Instructions cadres posées avant l'échange. Consomme du contexte : à garder concis.                                                                              |
| **Prompt engineering** | Discipline de conception des prompts. Progression : prompt vague (incohérent) → structure de base (meilleure cohérence) → prompt soigné (haute qualité, fiable). |

---

## 8. Repères chiffrés du module

- Fenêtre de contexte 200K ≈ 150 000 mots (entrée + sortie) ; 1M ≈ 750 000 mots.
- 10 000 lignes collées ≈ 40K tokens ; + refactoring en sortie ≈ 2K tokens → ~42K consommés.
- La plupart des modèles frontier sont à ~1M tokens de contexte, avec 64K-128K de sortie max.
- La plupart des développeurs professionnels utilisent **2 à 3 modèles** selon la tâche.

---

## Liens

- [Guide de prompt engineering OpenAI](https://platform.openai.com/docs/guides/prompt-engineering)
- [Documentation Claude d'Anthropic](https://docs.anthropic.com/)
- [Guide de prompting Google AI](https://ai.google.dev/gemini-api/docs/prompting-intro)
- Lab associé : `labs/lab-11-prompt-engineering/README.md` — solution : `labs/lab-11-prompt-engineering-solution/README.md`
