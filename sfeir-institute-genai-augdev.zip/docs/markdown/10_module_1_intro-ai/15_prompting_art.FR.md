<!-- .slide: class="transition" -->

# L'art du prompting

## Communiquer efficacement avec l'IA

Notes:
C'est sans doute la compétence la plus importante du développement augmenté par l'IA. La façon dont vous communiquez avec l'IA détermine la qualité de ce que vous obtenez en retour. Nous couvrons 5 techniques clés qui améliorent progressivement vos résultats.

##==##

<!-- .slide: -->

# **Pourquoi le prompting compte**

<br>

### **Même tâche, résultats différents**

| Qualité prompt    | Résultat typique           |
| ----------------- | -------------------------- |
| Prompt vague      | Marche parfois, incohérent |
| Structure de base | Meilleure cohérence        |
| Prompt soigné     | Haute qualité, fiable      |

<br><br>

### **Idée clé**

La différence entre un développeur junior et un senior utilisant l'IA tient souvent à la **qualité du prompt**, pas à la connaissance de l'IA.

<br>

Notes:
Voyez le prompting comme une nouvelle forme de communication avec un assistant très capable mais littéral. L'IA fait exactement ce que vous demandez - le défi est de demander exactement ce que vous voulez. De petits changements dans la formulation d'une demande peuvent changer radicalement la qualité du résultat.

##==##

<!-- .slide: -->

<img src="assets/images/10_module_1/prompting-techniques.svg" alt="Schéma des 5 techniques de prompting montrant la progression du Rôle au Chain-of-Thought avec la combinaison des techniques" style="width:100%; height:auto; display:block;">

Notes:
Voici chacune des 5 techniques présentées sur le schéma :

**1. Role** : dites à l'IA qui elle doit être. « Tu es un développeur backend senior » change sa façon d'aborder les problèmes - plus d'attention à la scalabilité, à la sécurité et à la maintenabilité.

**2. Context** : donnez le contexte utile. Incluez votre stack technique, vos contraintes et vos objectifs. « C'est une API Node.js Express qui doit encaisser 10K requêtes/seconde. »

**3. Format** : précisez exactement la forme de sortie attendue. « Renvoie un objet JSON » ou « Fournis le code avec des commentaires en ligne expliquant chaque section. »

**4. Examples** : montrez plutôt que d'expliquer. Incluez un échantillon de ce que vous voulez : « Voici comment nous structurons nos endpoints d'API : [exemple] »

**5. Chain-of-Thought** : demandez les étapes de raisonnement. « Réfléchis étape par étape avant de donner la solution. » Améliore énormément la résolution de problèmes complexes.

Ces techniques se cumulent progressivement : commencez par Role + Context pour les tâches simples, ajoutez Format pour une sortie structurée, ajoutez Examples pour des patterns précis, et utilisez Chain-of-Thought pour les raisonnements complexes. Le Lab 11 permet aux participants de comparer ces approches en pratique.

##==##

<!-- .slide: class="exercice" -->

# Lab 11 : Atelier de prompt engineering

## Lab

Comparer 3 approches de prompting

<br>

### Suivez les **instructions** dans

### <code data-markdown-preview="/labs/lab-11-prompt-engineering/README.md">labs/lab-11-prompt-engineering/README.md</code>

Notes:
Il s'agit d'un atelier pratique de 30 minutes où vous écrirez des prompts pour la même tâche algorithmique selon trois approches différentes : basique, structurée et avancée. Vous comparerez les sorties de l'IA et documenterez les techniques ayant donné les meilleurs résultats.

##==##

<!-- .slide: class="exercice" -->

# Lab 11 : Atelier de prompt engineering

## Solution

Solutions et exemples

<br>

### Lisez les **solutions** ici

### <code data-markdown-preview="/labs/lab-11-prompt-engineering-solution/README.md">labs/lab-11-prompt-engineering-solution/README.md</code>

Notes:
Après l'atelier, consultez les solutions pour voir des exemples de prompts et de sorties pour chaque approche. La solution inclut une analyse expliquant pourquoi certaines techniques fonctionnent mieux pour ce type de tâche.
