<!-- .slide: class="transition" -->

# Comparaison des modèles du marché

## GPT, Claude et Gemini

Notes:
Maintenant que vous comprenez ce qu'est l'IA, voyons ce que sont réellement les modèles d'IA, comment ils sont évalués et les différentes catégories que vous rencontrerez. Nous comparerons ensuite les principaux modèles entre eux.

##==##

<!-- .slide: -->

# **Qu'est-ce qu'un modèle d'IA ?**

### **Définition**

Un **modèle d'IA** est un système mathématique — généralement un réseau de neurones à plusieurs milliards de **paramètres** — entraîné sur d'immenses jeux de données pour reconnaître des motifs et générer des sorties (texte, code, images...).

<br>

### **Concepts clés**

- **Paramètres** : les variables internes (poids) apprises pendant l'entraînement — la « connaissance » du modèle
- **Entraînement** : pré-entraînement sur des données (auto-supervisé) + fine-tuning avec retour humain (RLHF)
- **Inférence** : passage de votre prompt dans le réseau pour générer une réponse, token par token
- **Transformers** : l'architecture (2017) qui alimente TOUS les LLM modernes — GPT, Claude, Gemini

Notes:
Un modèle d'IA est l'artefact computationnel central — le réseau de neurones entraîné lui-même. Il est important de comprendre cette distinction car, dans les conversations quotidiennes, on confond souvent le modèle avec le produit ou le service construit autour de lui.

Les **paramètres** sont les milliards de valeurs numériques (poids et biais) que le réseau a apprises pendant l'entraînement. Voyez-les comme la connaissance accumulée du modèle. Les modèles frontier d'aujourd'hui comptent de plusieurs centaines de milliards à plusieurs milliers de milliards de paramètres — par exemple, Llama 4 Maverick de Meta compte ~400 Md de paramètres.

**L'entraînement se déroule en deux phases :**

1. **Pré-entraînement** : le modèle traite d'énormes volumes de texte, de code et d'autres données, en apprenant à prédire le token suivant. C'est de l'apprentissage auto-supervisé — aucune annotation humaine nécessaire. Le modèle apprend la grammaire, des faits, des motifs de code, le raisonnement, et bien plus — uniquement en prédisant ce qui vient ensuite.

2. **Fine-tuning / RLHF (Reinforcement Learning from Human Feedback)** : après le pré-entraînement, des humains notent les sorties du modèle, et le modèle est affiné pour être plus utile, inoffensif et honnête. C'est ce qui transforme des modèles de langage bruts en assistants utiles.

L'**inférence** est ce qui se produit lorsque vous utilisez le modèle : votre entrée (le prompt) traverse les couches du réseau, et le modèle génère la sortie un token à la fois, en sélectionnant chaque fois le token suivant le plus probable compte tenu de tout ce qui précède.

Les **Transformers** (introduits dans l'article de Google « Attention Is All You Need », 2017) constituent l'architecture fondatrice. Ils traitent le texte en parallèle grâce à des « mécanismes d'attention » qui permettent au modèle de comprendre les relations entre n'importe quels mots de l'entrée, quelle que soit la distance. Tous les grands LLM actuels — GPT, Claude, Gemini, Llama — reposent sur les Transformers.

##==##

<!-- .slide: -->

<img src="assets/images/10_module_1/model-evaluation.svg" alt="How AI Models Are Evaluated showing key benchmarks with current scores and evaluation dimensions" style="width:100%; height:auto; display:block;">

Notes:
Comprendre comment les modèles sont évalués vous aide à dépasser le discours marketing et à décider en connaissance de cause. Le paysage des benchmarks a basculé de façon décisive début 2026 — les anciens tests statiques (MMLU, HumanEval, GSM8K) sont désormais saturés, remplacés par des évaluations plus difficiles, résistantes à la contamination et ancrées dans le réel.

**Benchmarks clés (à gauche) — avec les meilleurs scores actuels :**

- **SWE-bench Verified** : la référence pour le code. Les modèles doivent corriger de vrais tickets GitHub en générant des patches corrects sur de véritables dépôts open source. Meilleurs scores (juillet 2026) : Claude Fable 5 mène avec ~95 %, suivi de Claude Opus 4.8 à ~88-89 %, avec GPT-5.6 Sol et Gemini 3.5 Flash dans le haut du classement. Réserve importante : les scores varient selon le scaffolding/harness utilisé — des runs indépendants (par ex. l'analyse de Simon Willison) donnent des chiffres un peu plus bas, et les chiffres mis en avant par les éditeurs reposent souvent sur leur propre scaffolding plutôt que sur un harness neutre. Une variante plus difficile, **SWE-bench Pro** (Scale AI), utilise des bases de code privées — Claude Fable 5 y affiche actuellement le meilleur score rapporté (~80 %).

- **LiveCodeBench** : problèmes de code de niveau compétition, renouvelés en continu avec de nouveaux énoncés, ce qui rend la mémorisation et la contamination des données impossibles. Leaders actuels (juillet 2026) : Gemini 3.5 Flash, GPT-5.6 Sol et Claude Fable 5 occupent le sommet — les classements exacts bougent au fil des nouveaux problèmes. Ce benchmark est particulièrement fiable car son jeu de données est toujours frais.

- **Aider Polyglot** : 225 exercices Exercism dans 6 langages (C++, Go, Java, JavaScript, Python, Rust) — mesure la capacité d'un modèle à éditer du code existant au format diff, et pas seulement à générer de zéro. En juillet 2026, Claude Fable 5 et Opus 4.8 mènent, suivis de GPT-5.6 Sol et Gemini 3.5 Flash. C'est le benchmark le plus pratique pour juger de l'efficacité d'un modèle dans un assistant de code IA.

- **Arena Elo (LMArena)** : classement des préférences humaines issu de millions de votes anonymes par paires sur plus de 300 modèles. En juillet 2026, Claude Fable 5 mène, suivi de près par Opus 4.8, GPT-5.6 Sol, Gemini 3.1 Pro et Claude Sonnet 5 — les scores Elo exacts bougent chaque jour au fil des votes. C'est le meilleur proxy pour « quel modèle est le plus agréable à utiliser au quotidien » — il capte des dimensions de qualité que les benchmarks automatisés manquent.

- **GPQA Diamond** : questions scientifiques de niveau doctorat créées par des experts du domaine. Les meilleurs modèles dépassent désormais la performance des experts humains (~89,8 %) : en juillet 2026, GPT-5.6 Sol et Gemini 3.1 Pro mènent (tous deux au-dessus de ~90 %), avec Claude Fable 5 juste derrière. Teste le raisonnement profond en plusieurs étapes — utile pour évaluer la capacité d'un modèle à mener une analyse technique complexe.

**Dimensions d'évaluation (à droite) :**
Les modèles sont évalués selon sept dimensions clés. Aucun modèle ne gagne sur toutes :

- **Code** : la plus importante pour les développeurs. Mesurée par SWE-bench, LiveCodeBench et Aider Polyglot.
- **Raisonnement** : résolution de problèmes profonde et multi-étapes. Mesurée par GPQA Diamond, Humanity's Last Exam (HLE, publié dans Nature — les meilleurs scores plafonnent encore à ~25 %) et FrontierMath.
- **Agentique** : accomplissement autonome de tâches multi-étapes. Mesuré par Terminal-Bench Hard (89 tâches terminal réelles), SWE-bench Pro et les évaluations d'usage d'outils. De plus en plus important à mesure que l'IA s'oriente vers des workflows de code agentiques.
- **Suivi des instructions** : le modèle respecte-t-il des instructions précises ? Mesuré par IFBench, IFEval et la précision du format d'édition. Critique pour une génération de code fiable.
- **Multimodal** : compréhension d'images, de schémas et de captures d'écran en plus du texte. Mesurée par MMMU.
- **Préférence humaine** : qualité subjective globale via le classement participatif Arena Elo.
- **Sûreté** : résultats de red-teaming, évaluations d'alignement et taux d'hallucination (mesurés par des benchmarks comme AA-Omniscience).

Pour choisir un modèle, concentrez-vous sur les dimensions qui comptent le plus pour votre cas d'usage. Pour la plupart des développeurs, Code + Agentique + Suivi des instructions forment le trio de tête.

##==##

<!-- .slide: -->

<img src="assets/images/10_module_1/model-categories.svg" alt="AI Model Categories showing Frontier, Balanced, Fast, Reasoning, Embedding, and Open-Weight models with key model names" style="width:100%; height:auto; display:block;">

Notes:
Ce schéma cartographie les six catégories de modèles d'IA que vous rencontrerez, organisées selon la classification réellement utilisée par les fournisseurs. Chaque grand fournisseur (Anthropic, OpenAI, Google) propose une gamme étagée similaire — comprendre ces paliers vous aide à choisir le bon modèle pour chaque tâche.

**Ligne 1 — les trois paliers de performance (présents chez chaque fournisseur) :**

Les **modèles frontier / flagship** sont les modèles les plus intelligents proposés par chaque fournisseur. Claude Fable 5 (10 $/50 $ par MTok, contexte de 1 M, 128 K de sortie max, thinking adaptatif toujours actif — le modèle frontier « Mythos-class » d'Anthropic, sorti en juin 2026), GPT-5.6 Sol (5 $/30 $ par MTok, contexte de 1 M, 128 K de sortie, présenté comme le « meilleur modèle de code à ce jour » d'OpenAI — sorti le 9 juillet 2026) et Gemini 3.1 Pro (contexte de 1 M de tokens, raisonnement 2x supérieur à 3 Pro — sorti le 19 février 2026). Utilisez-les pour les problèmes les plus difficiles : raisonnement complexe multi-étapes, refactoring à grande échelle, décisions d'architecture et workflows agentiques. Ils offrent la meilleure qualité mais coûtent plus cher et répondent plus lentement. À côté de Fable 5, **Claude Opus 4.8** (5 $/25 $ par MTok, ~88-89 % sur SWE-bench Verified) est le cheval de trait frontier du code et de l'agentique — la plupart des équipes utilisent Opus ou Sonnet 5 au quotidien et escaladent vers Fable 5 pour les problèmes les plus ardus.

Les **modèles équilibrés** offrent le meilleur compromis vitesse/intelligence — le « cheval de trait du quotidien ». Claude Sonnet 5 (3 $/15 $ par MTok, contexte de 1 M, thinking adaptatif actif par défaut — désormais le modèle par défaut dans Claude Code), GPT-5.6 Terra (2,50 $/15 $ par MTok, modèle équilibré du quotidien) et Gemini 3.5 Flash (GA en mai 2026 — le modèle le plus solide de Google pour le travail agentique + code soutenu, ~4x plus rapide que les modèles frontier). Ils couvrent la grande majorité des tâches de développement quotidiennes : revue de code, débogage, documentation, explications et code généraliste. Pour la plupart des développeurs, c'est le palier par défaut.

Les **modèles rapides / légers** privilégient la vitesse et le coût avant tout. Claude Haiku 4.5 (1 $/5 $ par MTok, le plus rapide de la famille Claude), GPT-5.6 Luna (1 $/6 $ par MTok, le plus économique de la famille GPT) et Gemini 3.5 Flash-Lite (modèle ultra-rapide et économique pour les charges à fort volume). Utilisez-les pour les tâches à fort volume : suggestions d'autocomplétion, classification, résumé, réponses rapides, et partout où la latence ou le budget compte plus que l'intelligence maximale. Ils montent en charge à des millions de requêtes à coût maîtrisé.

**Ligne 2 — types de modèles spécialisés :**

Les **modèles de raisonnement** constituent une capacité distincte qui traverse désormais les paliers au lieu de former une gamme séparée. Au lieu de répondre immédiatement, ils allouent du calcul supplémentaire pour « réfléchir » d'abord — en générant des chaînes de raisonnement internes avant de répondre. Claude utilise le thinking adaptatif, actif par défaut sur Fable 5, Opus 4.8 et Sonnet 5, qui décident du temps de réflexion par requête (l'Extended Thinking manuel est retiré sur ces modèles). OpenAI ne livre plus de série o distincte : le raisonnement est intégré au modèle principal — GPT-5.6 expose des modes de raisonnement standard et « pro », plus un réglage max-effort sur Sol. Google propose des budgets de réflexion configurables et Gemini Deep Think. Le raisonnement excelle sur le débogage complexe, la conception d'algorithmes, les maths, l'analyse de sécurité et les décisions d'architecture. Il est plus lent et plus coûteux par token, mais le gain de qualité sur les problèmes difficiles est substantiel.

Les **modèles d'embedding** convertissent du texte ou du code en vecteurs sémantiques (tableaux de nombres) qui capturent le sens. Ils alimentent la recherche et la récupération — la colonne vertébrale des systèmes RAG (Retrieval-Augmented Generation). Modèles clés : text-embedding-3-large d'OpenAI, Cohere embed-v4 (multimodal — gère texte et images) et Gemini Embeddings. Vous interagissez rarement avec eux directement, mais ils sont l'infrastructure essentielle de tout système devant retrouver du code, de la documentation ou des données à fournir à un modèle de chat.

Les **modèles open-weight / locaux** sont des modèles dont les poids sont publiquement disponibles, ce qui signifie que vous pouvez les télécharger et les exécuter sur votre propre matériel via des outils comme Ollama, vLLM ou llama.cpp. Llama 4 de Meta (~400 Md de paramètres, le modèle ouvert le plus solide), Qwen3 d'Alibaba, DeepSeek V3, Mistral, Phi-4 de Microsoft (~14 Md, très performant pour sa taille) et Gemma 3 de Google (optimisé pour l'on-device). Ils sont gratuits après installation, offrent une confidentialité totale des données (rien ne quitte votre machine) et fonctionnent hors ligne. Ils sont idéaux pour les environnements air-gapped, les pipelines CI/CD, ou partout où vous avez besoin de coûts prévisibles et d'une faible latence. Contrepartie : ils atteignent généralement 80-95 % des capacités des modèles frontier du cloud.

**Ligne 3 — modèles spécialisés (au-delà du texte) :**

Ces modèles traitent des modalités spécifiques au-delà du texte et du code. Ce ne sont pas vos outils du quotidien, mais ils débloquent des capacités puissantes au besoin :

- **Génération d'images** : GPT Image 1.5 d'OpenAI (intégré à ChatGPT), Nano Banana 2 de Google (rapide, peu coûteux) et Imagen 4, Stable Diffusion (open source, exécutable en local) et Midjourney. Utile aux développeurs pour générer des maquettes d'UI, des assets de remplacement, des schémas ou des visuels marketing.

- **Génération de vidéos** : Sora 2 / Sora 2 Pro d'OpenAI (texte vers vidéo avec audio synchronisé), Veo 3.1 de Google (qualité cinéma) et Kling. Encore à un stade précoce pour la plupart des workflows de développement, mais de plus en plus utile pour les démos produit, les tutoriels et les contenus d'onboarding.

- **Voix / parole** : ElevenLabs (plus de 70 langues, clonage de voix, Eleven v3), Whisper d'OpenAI (transcription parole vers texte) et Gemini TTS. Pertinent pour construire des interfaces vocales, transcrire des réunions, générer de la documentation audio ou ajouter des fonctions d'accessibilité.

- **Recherche approfondie** : deep research d'OpenAI (désormais propulsé par la gamme GPT-5.6) et Gemini Deep Research de Google. Ce sont des agents de recherche multi-étapes qui cherchent, lisent et synthétisent de façon autonome des informations issues de multiples sources web. Utiles pour l'évaluation de technologies, l'analyse concurrentielle et la collecte de contexte avant des décisions d'architecture majeures.

**Point clé** : chaque fournisseur propose cette même structure étagée — un modèle frontier, un modèle équilibré et un modèle rapide — plus des capacités de raisonnement et des modèles spécialisés. Tout l'art consiste à faire correspondre le palier à la tâche : n'utilisez pas un modèle frontier pour une simple autocomplétion (gaspillage), et n'utilisez pas un modèle rapide pour des décisions d'architecture complexes (insuffisant).

##==##

<!-- .slide: -->

<img src="assets/images/10_module_1/models-comparison.svg" alt="The Big Three AI Models Comparison showing GPT-5.6 Sol, Claude Fable 5, and Gemini 3.1 Pro with Decision Framework" style="width:100%; height:auto; display:block;">

Notes:
**Comprendre les fenêtres de contexte**

Avant de comparer les modèles, clarifions un concept clé : la **fenêtre de contexte** (context window). Voyez-la comme la « mémoire de travail » du modèle - tout le texte qu'il peut référencer en générant une réponse, y compris votre entrée et sa sortie.

**Tokens d'entrée** : tout ce que vous envoyez au modèle - votre prompt, l'historique de conversation, les fichiers de code, la documentation, les instructions système. C'est ce que le modèle « lit ».

**Tokens de sortie** : tout ce que le modèle génère en réponse - code, explications, réponses. C'est ce que le modèle « écrit ».

**Pourquoi c'est important pour les développeurs** :

- Une fenêtre de contexte de 200 K correspond à ~150 000 mots d'entrée + sortie combinés ; une fenêtre de 1 M (Fable 5, Opus 4.8, Sonnet 5, GPT-5.6, Gemini) contient ~750 K mots
- Plus de contexte = plus de fichiers de code, des conversations plus longues, des bases de code plus grosses analysées d'un coup
- Les tokens d'entrée sont généralement moins chers que les tokens de sortie (par ex. Claude Opus 4.8 : 5 $/M en entrée contre 25 $/M en sortie)
- Quand vous atteignez la limite, le début de la conversation est soit tronqué, soit compressé

**Exemple pratique** : si vous collez une base de code de 10 000 lignes (≈40 K tokens) et demandez un refactoring (≈2 K tokens en sortie), vous avez consommé ~42 K tokens de votre fenêtre de contexte. L'espace restant peut accueillir les questions de suivi et les réponses.

---

Ces trois modèles incarnent des philosophies de conception différentes en juillet 2026 :

**OpenAI GPT-5.6 Sol (9 juillet 2026)** : le flagship d'OpenAI — présenté comme son « meilleur modèle de code à ce jour », avec de solides capacités agentiques et de raisonnement profond (modes de raisonnement standard, « pro » et max-effort ; la série o a disparu, le raisonnement est désormais un mode du modèle principal). Prend en charge un contexte de 1 M en entrée / 128 K en sortie. Tarif : 5 $/30 $ par million de tokens. Codex CLI tourne sur Sol ; **Terra**, l'équilibré (2,50 $/15 $), et **Luna**, l'économique (1 $/6 $), complètent la famille pour le quotidien et les gros volumes.

**Anthropic Claude Fable 5 (juin 2026)** : le modèle le plus capable généralement disponible d'Anthropic — le premier du palier frontier « Mythos-class » qui se situe désormais au-dessus d'Opus. Mène sur SWE-bench Verified avec ~95 %, avec un thinking adaptatif toujours actif, un contexte de 1 M de tokens et 128 K de sortie max. Tarif : 10 $/50 $ par million de tokens. ID du modèle : `claude-fable-5`. Pour le code au quotidien, les équipes utilisent **Claude Opus 4.8** (5 $/25 $, ~88-89 % sur SWE-bench Verified) ou **Sonnet 5** (le modèle par défaut dans Claude Code) et escaladent vers Fable 5 pour les travaux les plus difficiles.

**Google Gemini 3.1 Pro (19 février 2026)** : le meilleur modèle de raisonnement de Google — 2x la performance de raisonnement de Gemini 3 Pro, fenêtre de contexte de 1 M de tokens. Le plus récent **Gemini 3.5 Flash** de Google (GA en mai 2026) est son modèle le plus solide pour le travail agentique + code soutenu et est ~4x plus rapide, ce qui rend le palier Flash étonnamment capable pour son coût.

Ne vous enfermez pas dans un seul modèle - la plupart des développeurs professionnels utilisent 2 à 3 modèles selon la tâche. Chacun excelle dans des domaines différents : GPT-5.6 Sol pour le code autonome et le raisonnement agentique, Claude Fable 5 / Opus 4.8 pour les charges de code agentique les plus difficiles (et les workflows multi-agents via les agent teams de Claude Code), Gemini 3.1 Pro / 3.5 Flash pour le contexte massif et les tâches multimodales.
