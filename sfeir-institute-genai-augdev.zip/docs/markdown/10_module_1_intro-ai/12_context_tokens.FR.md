<!-- .slide: class="transition" -->

# Contexte et Tokens

## Comprendre les contraintes de l'IA

Notes:
Pour utiliser efficacement les outils d'IA, il faut comprendre leurs contraintes fondamentales : comment ils traitent le texte (tokens) et quelle quantité ils peuvent considérer à la fois (fenêtre de contexte). Ces notions influencent directement la façon de structurer vos prompts et les tâches réalisables.

##==##

<!-- .slide: -->

# **Qu'est-ce qu'un token ?**

<br>

### **Définition**

Un **token** est la plus petite unité de texte traitée par un LLM — généralement **un mot ou une partie de mot**.

<br><br>

### **Exemple**

`function getUserName()` → 6 tokens : `function` | `get` | `User` | `Name` | `(` | `)`

Notes:
Les tokens sont l'unité de facturation des API d'IA. Chaque caractère envoyé et reçu est converti en tokens. Les mots courants font généralement 1 token, mais les mots longs ou rares sont découpés en sous-mots. La ponctuation et les caractères spéciaux sont des tokens distincts.

##==##

<!-- .slide: -->

# **Qu'est-ce qu'un token ?**

<br>

### **Ordres de grandeur**

| Type de texte       | Estimation            |
| ------------------- | --------------------- |
| Texte anglais       | 1 mot ≈ 1,3 tokens    |
| Code                | 1 ligne ≈ 5-10 tokens |
| 1000 lignes de code | ≈ 5 000-8 000 tokens  |

<br>

> **Pourquoi c'est important** : les tokens déterminent le **coût** et les **limites de contexte**

Notes:
Les tokens sont l'unité de facturation des API d'IA. Chaque caractère envoyé et reçu est converti en tokens. Les mots courants font généralement 1 token, mais les mots longs ou rares sont découpés en sous-mots. La ponctuation et les caractères spéciaux sont des tokens distincts.
##==##

<!-- .slide: -->

# **Qu'est-ce que la fenêtre de contexte ?**

### **Définition**

La **fenêtre de contexte** est le nombre maximal de tokens qu'un LLM peut traiter en une seule interaction — elle inclut **tout** : prompt système, saisie utilisateur, historique de conversation, fichiers joints **et** la réponse générée.

<br>

### **La règle d'or**

> **Tokens d'entrée + Tokens de sortie ≤ Fenêtre de contexte totale**

<br>

| Compté en entrée                         | Compté en sortie            |
| ---------------------------------------- | --------------------------- |
| Prompts système et instructions          | Texte et code générés       |
| Vos messages et l'historique             | Explications et suggestions |
| Fichiers de code et documentation joints | Analyses et synthèses       |

Notes:
La fenêtre de contexte est la mémoire de travail de l'IA — tout ce que le modèle « voit » d'un coup doit y tenir. Contrairement à un humain qui peut relire d'anciennes notes, un LLM n'a aucune mémoire au-delà de cette fenêtre : dès que des tokens en sortent, ils sont oubliés.

**Pourquoi c'est important pour les développeurs :**

- **Le contexte est fini** : si votre base de code fait 500K tokens et la fenêtre 200K, l'IA ne peut littéralement pas tout voir en même temps. Il faut être stratégique sur ce que vous incluez.
- **L'entrée concurrence la sortie** : plus vous envoyez de contexte, moins il reste de place pour la réponse. Un modèle à fenêtre de 128K qui reçoit 120K d'entrée ne peut générer que ~8K de sortie.
- **Autres modèles, autres compromis** : la plupart des modèles frontière offrent aujourd'hui ~1M tokens de contexte — Gemini, GPT-5.6 et Claude (Fable 5 / Opus 4.8 / Sonnet 5) — vous pouvez donc analyser de grandes bases de code d'un seul coup. Mais les plafonds de sortie diffèrent encore (typiquement 64K-128K), les entrées volumineuses coûtent plus cher, et trop remplir la fenêtre dilue la concentration du modèle. Les tokenizers varient aussi : le nouveau tokenizer de Sonnet 5 produit ~30 % de tokens en plus que Sonnet 4.6 pour le même texte.
- **L'historique de conversation s'accumule** : chaque échange dans une session ajoute des tokens. Les longues conversations peuvent épuiser la fenêtre sans bruit, amenant le modèle à « oublier » le contexte antérieur ou à produire des réponses dégradées.

**Implications pratiques :**

- Gardez les prompts système concis — chaque token y réduit votre espace utilisable.
- Dans les outils agentiques, la gestion du contexte est automatique (indexation de fichiers, RAG, résumé), mais comprendre la contrainte aide à déboguer les comportements inattendus.
- Quand un outil « oublie » soudain ce que vous lui avez dit, une fenêtre de contexte pleine en est souvent la cause.
- Découper les grandes tâches en interactions plus petites et ciblées est plus efficace que de tout entasser dans un seul prompt.

##==##

<!-- .slide: -->

<img src="assets/images/10_module_1/context-window-diagram.svg" alt="Schéma de la fenêtre de contexte montrant comment le prompt système, l'entrée et la sortie doivent tenir dans la fenêtre" style="width:100%; height:auto; display:block;">

Notes:
La fenêtre de contexte est la mémoire de travail de l'IA - tout doit y tenir : votre prompt système, votre saisie, ET la réponse générée. C'est pourquoi on ne peut pas simplement coller une base de code entière dans un prompt. La sélection stratégique du contexte devient cruciale sur les projets plus gros.
