<!-- .slide: class="transition" -->

# Module 1: Introduction to AI for Developers

## Understanding the Foundations of AI-Augmented Development

Notes:
Welcome to Module 1! This module provides the foundational knowledge you need to effectively leverage AI tools in your development workflow. We'll cover the history and evolution of AI, compare major market models, and practice prompt engineering techniques. Duration: 1h30 (60 min lecture + 30 min workshop).

##==##

<!-- .slide: -->

# **Learning Objectives**

<br>

### **By the end of this module, you will be able to:**

- **Explain** the hierarchy of AI, ML, Deep Learning, and Generative AI
- **Compare** key differences between GPT, Claude, and Gemini models
- **Apply** 5 prompting techniques for effective code generation
- **Describe** the evolution from autocomplete to agentic coding tools
- **Understand** how tokens and context windows affect AI interactions
- **Identify** appropriate AI tools for different development tasks

Notes:
These learning objectives are measurable - you'll demonstrate your understanding through a hands-on workshop where you'll compare different prompting approaches on a real coding task. Each objective builds on the previous one, creating a complete foundation for AI-augmented development.
