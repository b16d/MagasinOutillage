<!-- .slide: class="transition" -->

# The Art of Prompting

## Communicating Effectively with AI

Notes:
This is arguably the most important skill in AI-augmented development. How you communicate with AI determines the quality of output you receive. We'll cover 5 key techniques that progressively improve your results.

##==##

<!-- .slide: -->

# **Why Prompting Matters**

<br>

### **The Same Task, Different Results**

| Prompt Quality  | Typical Output                |
| --------------- | ----------------------------- |
| Vague prompt    | Works sometimes, inconsistent |
| Basic structure | Better consistency            |
| Well-crafted    | High quality, reliable        |

<br><br>

### **Key Insight**

The difference between a junior and senior developer using AI often comes down to **prompt quality**, not AI knowledge.

<br>

Notes:
Think of prompting as a new form of communication with a very capable but literal assistant. The AI will do exactly what you ask - the challenge is asking for exactly what you want. Small changes in how you frame a request can dramatically change the output quality.

##==##

<!-- .slide: -->

<img src="assets/images/10_module_1/prompting-techniques.svg" alt="5 Prompting Techniques diagram showing progression from Role through Chain-of-Thought with Combining Techniques" style="width:100%; height:auto; display:block;">

Notes:
Let me explain each of the 5 techniques shown in the diagram:

**1. Role**: Tell the AI who to be. "You are a senior backend developer" changes how it approaches problems - more consideration for scalability, security, and maintainability.

**2. Context**: Provide relevant background. Include your tech stack, constraints, and goals. "This is a Node.js Express API that needs to handle 10K requests/second."

**3. Format**: Specify exactly how you want the output. "Return a JSON object" or "Provide the code with inline comments explaining each section."

**4. Examples**: Show don't tell. Include a sample of what you want: "Here's how we structure our API endpoints: [example]"

**5. Chain-of-Thought**: Ask for reasoning steps. "Think through this step by step before providing the solution." Dramatically improves complex problem-solving.

These build progressively: start with Role + Context for simple tasks, add Format for structured output, include Examples for specific patterns, and use Chain-of-Thought for complex reasoning. Lab 11 lets trainees compare these approaches hands-on.

##==##

<!-- .slide: class="exercice" -->

# Lab 11: Prompt Engineering Workshop

## Lab

Compare 3 Prompting Approaches

<br>

### Follow **instructions** in

### <code data-markdown-preview="/labs/lab-11-prompt-engineering/README.md">labs/lab-11-prompt-engineering/README.md</code>

Notes:
This is a 30-minute hands-on workshop where you'll write prompts for the same algorithm task using three different approaches: basic, structured, and advanced. You'll compare the AI outputs and document which techniques produced the best results.

##==##

<!-- .slide: class="exercice" -->

# Lab 11: Prompt Engineering Workshop

## Solution

Solutions and Examples

<br>

### Read **solutions** at

### <code data-markdown-preview="/labs/lab-11-prompt-engineering-solution/README.md">labs/lab-11-prompt-engineering-solution/README.md</code>

Notes:
After completing the workshop, review the solutions to see example prompts and outputs for each approach. The solution includes analysis of why certain techniques work better for this type of task.
