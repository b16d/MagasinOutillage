<!-- .slide: class="transition" -->

# Glossaire du module 1

## Les termes clés en un coup d'œil

Notes:
Cette section récapitule tout le vocabulaire introduit dans le module 1. À utiliser comme fiche de référence pendant les labs et pour réviser avant l'examen final du module 8.

##==##

<!-- .slide: -->

# **Hiérarchie de l'IA**

<br>

| Terme                | Définition courte                                                     |
| -------------------- | --------------------------------------------------------------------- |
| **IA**               | Systèmes capables de tâches exigeant l'intelligence humaine           |
| **Machine Learning** | L'IA qui apprend des motifs à partir de données, sans règles codées   |
| **Deep Learning**    | Le ML à base de réseaux de neurones à nombreuses couches              |
| **IA générative**    | Le Deep Learning qui crée du contenu neuf : texte, code, image, audio |
| **LLM**              | Grand modèle de langage — la couche la plus interne                   |
| **Multimodal**       | Modèle traitant aussi images, schémas, captures d'écran, audio        |

<br>

> **IA ⊃ Machine Learning ⊃ Deep Learning ⊃ IA générative ⊃ LLM**

Notes:
Le piège classique du quiz : ajouter le NLP comme couche de cette hiérarchie. Il n'y figure pas. L'ordre exact, de l'extérieur vers l'intérieur, est IA, Machine Learning, Deep Learning, IA générative, LLM.

##==##

<!-- .slide: -->

# **Anatomie d'un modèle**

<br>

| Terme                  | Définition courte                                                           |
| ---------------------- | --------------------------------------------------------------------------- |
| **Modèle d'IA**        | Réseau de neurones entraîné à reconnaître des motifs et générer des sorties |
| **Paramètres (poids)** | Les variables apprises à l'entraînement — la « connaissance » du modèle     |
| **Transformer**        | L'architecture de 2017 à mécanismes d'attention, socle de TOUS les LLM      |
| **Pré-entraînement**   | Phase 1 : prédire le token suivant sur d'énormes corpus (auto-supervisé)    |
| **RLHF**               | Phase 2 : affinage par retour humain — transforme le modèle en assistant    |
| **Inférence**          | L'exécution : la sortie est générée **token par token**                     |
| **Hallucination**      | Sortie plausible mais fausse                                                |

Notes:
Distinction importante : le modèle est l'artefact computationnel, pas le produit construit autour. Les modèles frontier actuels comptent de centaines de milliards à plusieurs milliers de milliards de paramètres — Llama 4 Maverick en affiche environ 400 milliards.

##==##

<!-- .slide: -->

# **Tokens et contexte**

<br>

| Terme                   | Définition courte                                                      |
| ----------------------- | ---------------------------------------------------------------------- |
| **Token**               | Plus petite unité de texte traitée — un mot ou un morceau de mot       |
| **Tokenizer**           | Le découpeur de texte en tokens — varie d'un modèle à l'autre          |
| **Fenêtre de contexte** | Le maximum de tokens par interaction — la mémoire de travail du modèle |
| **Tokens d'entrée**     | Ce que le modèle lit : prompt système, messages, historique, fichiers  |
| **Tokens de sortie**    | Ce que le modèle écrit — plafond distinct, typiquement 64K-128K        |
| **MTok**                | Million de tokens — l'unité de tarification                            |
| **RAG**                 | Ne charger que les extraits pertinents au lieu de tout entasser        |

<br>

> **Règle d'or : Tokens d'entrée + Tokens de sortie ≤ Fenêtre de contexte**

Notes:
`function getUserName()` vaut 6 tokens. Ordres de grandeur : 1 mot anglais vaut environ 1,3 token, 1 ligne de code 5 à 10 tokens, 1000 lignes de 5000 à 8000 tokens. Quand un outil oublie brutalement le contexte, la fenêtre saturée en est presque toujours la cause : le début de conversation est tronqué ou compressé.

##==##

<!-- .slide: -->

# **Benchmarks**

<br>

| Benchmark               | Ce qu'il mesure                                                         |
| ----------------------- | ----------------------------------------------------------------------- |
| **SWE-bench Verified**  | Corriger de vrais tickets GitHub — la référence code                    |
| **SWE-bench Pro**       | Même exercice sur des bases de code privées — plus dur                  |
| **LiveCodeBench**       | Code niveau compétition, énoncés renouvelés — pas de contamination      |
| **Aider Polyglot**      | **Éditer** du code existant au format diff, dans 6 langages             |
| **Arena Elo (LMArena)** | Préférence humaine, par votes anonymes deux à deux                      |
| **GPQA Diamond**        | Questions scientifiques niveau doctorat                                 |
| **Scaffolding**         | L'outillage autour du modèle — gonfle les scores annoncés par l'éditeur |

Notes:
MMLU, HumanEval et GSM8K sont désormais saturés : ils ne discriminent plus les modèles frontier. Les 7 dimensions d'évaluation sont Code, Raisonnement, Agentique, Suivi des instructions, Multimodal, Préférence humaine et Sûreté. Aucun modèle ne gagne sur toutes ; pour un développeur, le trio prioritaire est Code, Agentique et Suivi des instructions.

##==##

<!-- .slide: -->

# **Catégories de modèles**

<br>

| Catégorie          | À quoi ça sert                                                   |
| ------------------ | ---------------------------------------------------------------- |
| **Frontier**       | Les problèmes les plus durs — cher et lent                       |
| **Équilibré**      | Le cheval de trait du quotidien — le palier par défaut           |
| **Rapide / léger** | Fort volume, latence et budget prioritaires                      |
| **Raisonnement**   | Le modèle « réfléchit » avant de répondre                        |
| **Embedding**      | Texte vers vecteurs sémantiques — le moteur du RAG               |
| **Open-weight**    | Poids publics, exécutables en local — confidentiel et hors ligne |

<br>

> **Apparier le palier à la tâche** : pas de frontier pour de l'autocomplétion, pas de modèle rapide pour de l'architecture.

Notes:
Chaque fournisseur propose la même structure étagée. Frontier : Claude Fable 5, Claude Opus 4.8, GPT-5.6 Sol, Gemini 3.1 Pro. Équilibré : Claude Sonnet 5, GPT-5.6 Terra, Gemini 3.5 Flash. Rapide : Claude Haiku 4.5, GPT-5.6 Luna, Gemini 3.5 Flash-Lite. Open-weight : Llama 4, Qwen3, DeepSeek V3, Mistral, Phi-4, Gemma 3 — ils atteignent 80 à 95 % des capacités des modèles frontier cloud.

##==##

<!-- .slide: class="tc-multiple-columns" -->

##++## "class=with-code"

## **Les 4 étapes de l'outillage**

<br>

| Étape              | Comportement |
| ------------------ | ------------ |
| **Autocomplétion** | Réactif      |
| **Suggestions**    | Proactif     |
| **Chat**           | Interactif   |
| **Agents**         | Autonome     |

##++##

##++## "class=with-code"

## **Les 3 types d'outils**

<br>

| Type              | Terrain de jeu                    |
| ----------------- | --------------------------------- |
| **Extension IDE** | Complétion et chat rapide         |
| **Agent CLI**     | Autonomie multi-fichiers          |
| **IDE natif IA**  | Édition augmentée de bout en bout |

##++##

Notes:
Les 4 étapes : autocomplétion de 2015 à 2018 (IntelliSense, TabNine), suggestions de 2018 à 2021 (Copilot, Kite), chat de 2022 à 2023 (ChatGPT, Copilot Chat), agents depuis 2024 (Cursor, Claude Code, Copilot Agents). Chaque étape s'appuie sur les précédentes. Les 3 types sont complémentaires, pas concurrents : extension IDE pour le mono-fichier, agent CLI pour le headless et la CI, IDE natif IA pour le multi-fichiers en local.

##==##

<!-- .slide: -->

# **Vocabulaire des outils**

<br>

| Terme                   | Définition courte                                                 |
| ----------------------- | ----------------------------------------------------------------- |
| **MCP**                 | Protocole d'extension d'un agent par des outils externes          |
| **Mode « ide »**        | Relier un agent CLI à l'IDE pour prévisualiser les modifications  |
| **Niveaux d'autonomie** | suggest → auto-edit → full-auto                                   |
| **Sandbox**             | Environnement isolé où l'agent exécute ses commandes              |
| **Grounding**           | Ancrer les réponses sur une source temps réel (ex. recherche web) |
| **Antigravity CLI**     | Le remplaçant de Gemini CLI, retiré en mai 2026                   |

Notes:
MCP, le Model Context Protocol, est détaillé aux modules 5 et 12. Gemini CLI a été retiré en mai 2026, son accès grand public s'est arrêté le 18 juin 2026 ; Antigravity CLI, écrit en Go et dévoilé au Google I/O 2026, apporte l'orchestration multi-agents asynchrone.

##==##

<!-- .slide: -->

# **Prompting**

<br>

| Technique               | Ce que vous ajoutez au prompt           |
| ----------------------- | --------------------------------------- |
| **1. Role**             | Qui l'IA doit être                      |
| **2. Context**          | Stack technique, contraintes, objectifs |
| **3. Format**           | La forme de sortie attendue             |
| **4. Examples**         | Un échantillon du résultat voulu        |
| **5. Chain-of-Thought** | La demande de raisonner étape par étape |

<br>

> Techniques **cumulatives** : Role + Context → + Format → + Examples → + Chain-of-Thought

Notes:
Rappel de la slide sur l'art du prompting : la différence entre un usage junior et senior de l'IA tient à la qualité du prompt, pas à la connaissance de l'IA. Le prompt système consomme du contexte : à garder concis.

##==##

<!-- .slide: -->

# **Repères chiffrés**

<br>

### **À retenir**

- Fenêtre de **200K** ≈ 150 000 mots ; **1M** ≈ 750 000 mots (entrée + sortie)
- **10 000 lignes** collées ≈ 40K tokens ; + la réponse ≈ 42K consommés
- Les modèles frontier plafonnent à **64K-128K tokens de sortie**
- Les tokens d'**entrée** coûtent moins cher que ceux de **sortie** (ex. 5 $ contre 25 $ par MTok)
- La plupart des devs pros utilisent **2 à 3 modèles** selon la tâche

Notes:
Ces repères sont ceux qui reviennent le plus souvent en atelier. Le reste du vocabulaire du module est repris dans les slides précédentes de cette section.
