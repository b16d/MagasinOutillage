<!-- .slide -->

# **Parcours de formation**

<br>

## **Au programme**

- **Fondamentaux de l'IA** : concepts clés et prompt engineering
- **Agentic Coding** : du vibe coding au développement structuré piloté par l'IA
- **Augmentation d'équipe** : workflows collaboratifs, contextes partagés et standards d'équipe
- **Orchestration multi-agents** : agents spécialisés, délégation de tâches complexes et création de serveurs MCP (**Jour 3**)
- **Création de serveur MCP** : votre propre serveur Model Context Protocol pour des interactions IA sur mesure (**Jour 3**)
- **Spec-Driven Development** : des spécifications à l'implémentation automatisée (**Jour 3**)

##==##

<!-- .slide-->

# **Parcours de formation**

<br>

## **Prérequis**

- **Expérience en programmation** d'au moins un langage (TypeScript, Java, Python, C#, Go, etc.)
- **Maîtrise de Git** et **expérience d'un IDE moderne** (VS Code, IntelliJ, WebStorm, etc.)
- **Aisance en ligne de commande** et expérience du travail collaboratif
- **Accès à un assistant IA**

Notes:
Ce programme complet de 3 jours (21 heures) transforme les développeurs en professionnels augmentés par l'IA. Chaque journée développe des compétences pratiques et mène à la certification SFEIR Certified AI-Augmented Developer.
