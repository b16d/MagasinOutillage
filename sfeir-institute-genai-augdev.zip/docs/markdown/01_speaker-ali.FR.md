<!-- .slide: class="speaker-slide" -->
<div class="speaker-slide">

# Bonjour ! @SFEIR

## Angélo **Lima**

### AI Champion & Software Engineer chez SFEIR

### lima.a@sfeir.com

### @lingelo

![](./assets/images/logo-sfeir-blanc.png 'company')

![](./assets/images/speaker-ali.png 'speaker')

</div>

Notes:
Angélo Lima est AI Champion et Software Engineer chez SFEIR, spécialisé dans le développement augmenté par l'IA et les outils agentiques.
