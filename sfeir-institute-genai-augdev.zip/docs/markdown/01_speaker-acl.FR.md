<!-- .slide: class="speaker-slide" -->
<div class="speaker-slide">

# Bonjour ! @SFEIR

## Alban **Clevy**

### AI Champion & Engineering Manager chez SFEIR

### clevy.a@sfeir.com

![](./assets/images/logo-sfeir-blanc.png 'company')

![](./assets/images/speaker-acl.jpg 'speaker')

</div>

Notes:
No Note
