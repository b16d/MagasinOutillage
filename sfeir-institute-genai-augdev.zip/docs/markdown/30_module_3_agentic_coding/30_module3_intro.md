<!-- .slide: class="transition" -->

# Module 3 Overview

## Discovery and Practice of Agentic Coding

##==##

<!-- .slide -->

# Learning Objectives

By the end of this module, you will be able to:

- **Understand** what Agentic Coding is and how it differs from traditional and Vibe Coding approaches
- **Apply** the 5-phase agentic workflow (Specify → Plan → Tasks → Implement → Validate)
- **Create** effective context files that enable accurate AI collaboration
- **Refactor** legacy codebases using agentic practices with AI assistance
- **Build** new features from scratch following the complete agentic workflow
- **Structure** effective AI requests and iterate to achieve high-quality results

Notes:
You'll demonstrate these skills through two hands-on labs with working deliverables.

##==##

<!-- .slide -->

# Prerequisites

## What You Need to Know

<br><br>

### From Module 1 & 2

- Understanding of AI coding assistants and their capabilities
- Knowledge of the spectrum from traditional to Vibe Coding
- Awareness of AI's role in modern software development
