<!-- .slide: class="transition" -->

# Vue d'ensemble du Module 3

## Découverte et pratique de l'Agentic Coding

##==##

<!-- .slide -->

# Objectifs pédagogiques

À la fin de ce module, vous saurez :

- **Comprendre** ce qu'est l'Agentic Coding et en quoi il diffère des approches traditionnelles et du Vibe Coding
- **Appliquer** le workflow agentique en 5 phases (Specify → Plan → Tasks → Implement → Validate)
- **Créer** des fichiers de contexte efficaces pour une collaboration IA précise
- **Refactorer** du code legacy avec les pratiques agentiques et l'aide de l'IA
- **Construire** de nouvelles fonctionnalités from scratch en suivant le workflow agentique complet
- **Structurer** des requêtes IA efficaces et itérer pour obtenir des résultats de qualité

Notes:
Vous démontrerez ces compétences via deux labs pratiques avec des livrables fonctionnels.

##==##

<!-- .slide -->

# Prérequis

## Ce qu'il faut savoir

<br><br>

### Issu des Modules 1 & 2

- Compréhension des assistants de code IA et de leurs capacités
- Connaissance du spectre allant du développement traditionnel au Vibe Coding
- Conscience du rôle de l'IA dans le développement logiciel moderne
