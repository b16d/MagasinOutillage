<!-- .slide: class="transition" -->

# Module 3 : Gestion du contexte

## Faire de l'IA un collaborateur efficace

##==##

<!-- .slide -->

## Gestion du contexte : définition

La **gestion du contexte** consiste à fournir aux agents de code IA les informations propres au projet pour guider leurs générations de code et leurs suggestions.

### **Pourquoi c'est clé ?**

<!-- .element: class="md-padding-top"-->

**Sans contexte**, les agents IA :

- ❌ Génèrent du code qui ne respecte pas vos conventions de projet
- ❌ Suggèrent des dépendances obsolètes ou incompatibles
- ❌ Ignorent les contraintes et patterns propres au projet
- ❌ Produisent des styles d'implémentation incohérents

**✅ Avec un contexte adapté**, l'IA devient un membre d'équipe averti qui comprend l'**architecture**, les **conventions** et les **objectifs** de votre projet.

<!-- .element: class="sm-padding-top"-->

##==##

<!-- .slide -->

## Les fichiers de contexte

Les **fichiers de contexte** sont des fichiers de documentation spécifiques que les agents de code IA lisent pour comprendre votre projet.

### 🎯 Objectif :

- 📄 **Vue d'ensemble** : ce que fait l'application, sa raison d'être et ses objectifs
- 🛠️ **Stack technique** : langages, frameworks, bibliothèques et versions
- 🏗️ **Architecture** : structure, patterns et décisions de conception
- 📏 **Conventions** : nommage, formatage et standards de code
- 🚧 **Contraintes** : exigences de performance, politiques de sécurité, limitations

<br>
<br>

### 📍 Emplacement :

Les fichiers de contexte se placent généralement à la **racine du dépôt** ou dans des répertoires de configuration dédiés (`.github/`, `.windsurf/`, etc.) ou dans n'importe quel **sous-répertoire** (par ex. dans les monorepos).

##==##

<!-- .slide -->

## Fichiers de contexte par agent

Chaque agent de code IA utilise son propre format natif de fichier de contexte :

| Agent              | Fichier(s) de contexte natif(s)   | Emplacement           |
| ------------------ | --------------------------------- | --------------------- |
| **GitHub Copilot** | `.github/copilot-instructions.md` | Répertoire `.github/` |
| **Claude Code**    | `CLAUDE.md`                       | Racine du dépôt       |
| **Gemini**         | `GEMINI.md`                       | Racine du dépôt       |
| **Codex (OpenAI)** | `AGENTS.md`                       | Racine du dépôt       |
| **OpenCode**       | `AGENTS.md`                       | Racine du dépôt       |
| **Mistral Vibe**   | `AGENTS.md`                       | Racine du dépôt       |

<!--TODO: add new agentic tool native context file above-->

<br>

**🤯 Défi** : gérer plusieurs fichiers de contexte pour différents agents crée une charge de maintenance.

##==##

<!-- .slide -->

## AGENTS.md : un standard universel

<cite>le `README.md` des 🤖 agents IA !</cite>

**[AGENTS.md](https://agents.md/)** est un **standard ouvert émergent** initié par **OpenAI**, qui vise à fournir contexte et instructions pour aider les agents de code IA à travailler efficacement sur votre projet.

Au fond, ce n'est qu'un **fichier markdown**, semblable à un `README.md`, mais destiné, lui, à nous 🗣️ les humains

### Objectifs

- **Source unique de vérité** : un seul fichier de contexte au lieu de plusieurs fichiers par agent
- **Interopérabilité** : fonctionne avec les différents outils de code IA
- **Standard ouvert** : spécification communautaire et indépendante des éditeurs
- **Maintenable** : une mise à jour, un bénéfice partout

##==##

<!-- .slide -->

## Prise en charge d'AGENTS.md

<br>

| Agent              | Prise en charge AGENTS.md         | Alternative native                |
| ------------------ | --------------------------------- | --------------------------------- |
| **GitHub Copilot** | ✅ Totale (août 2025)             | `.github/copilot-instructions.md` |
| **Claude Code**    | ⚠️ Partielle (import `CLAUDE.md`) | `CLAUDE.md`                       |
| **Gemini CLI**     | ⚠️ Partielle (configurable)       | `GEMINI.md`                       |
| **Codex (OpenAI)** | ✅ Totale (créateur)              | `AGENTS.md` (natif)               |
| **OpenCode**       | ✅ Totale (natif)                 | `AGENTS.md` (natif)               |
| **Mistral Vibe**   | ✅ Totale (natif)                 | `AGENTS.md` (natif)               |

<!--TODO: add new agentic tool's AGENTS.md support above-->

<br>

**💡 Recommandation** : utilisez `AGENTS.md` comme fichier de contexte principal, complété au besoin par des fichiers spécifiques à chaque agent.

Notes:

- **Claude Code :** ⚠️ Partielle (via import CLAUDE.md) — Claude Code lit CLAUDE.md, pas AGENTS.md. Le contournement demande un CLAUDE.md qui importe @AGENTS.md - https://code.claude.com/docs/en/memory#agents-md

- **Gemini CLI :** ⚠️ Partielle (configurable) — Gemini CLI peut être configuré pour lire AGENTS.md au lieu de GEMINI.md ; ce n'est pas le comportement par défaut, une configuration manuelle est nécessaire - https://geminicli.com/docs/cli/gemini-md#customize-the-context-file-name — Note (en juillet 2026) : Gemini CLI a été retiré (mai 2026) et remplacé par Antigravity CLI ; la distinction AGENTS.md/GEMINI.md est conservée ici pour référence.

##==##

<!-- .slide -->

<img src="assets/images/30_module_3/context-file-example.svg" alt="Context File Example" style="width:100%; height:auto; display:block;">

Notes:
Cet exemple montre un fichier AGENTS.md bien structuré, avec toutes les sections essentielles. **Points clés à souligner** : (1) la **Vue d'ensemble** donne à l'IA le « quoi et pourquoi » - raison d'être, périmètre et contraintes ; (2) l'**Architecture** explique la structure et les flux de données pour que l'IA génère du code cohérent ; (3) la **Stack technique** avec des versions précises évite les suggestions obsolètes (par ex. Angular 21 standalone vs NgModules) ; (4) les **Conventions** garantissent la cohérence - patterns de nommage, approche DI, gestion d'état ; (5) les **Objectifs actuels** focalisent l'IA sur le travail immédiat. **Erreurs fréquentes** : rester trop vague (« suivre les bonnes pratiques »), omettre les versions, oublier la mise à jour quand l'architecture change. **Astuce** : traitez AGENTS.md comme un README pour l'IA - si un nouvel arrivant aurait besoin de l'information, incluez-la.

##==##

<!-- .slide: class="exercice" -->

# Lab 31 : Refactoring de code legacy

## Lab 31

<br>

### 👉 Suivez les **instructions** dans

### <code data-markdown-preview="/labs/lab-31-legacy-refactoring/README.md">labs/lab-31-legacy-refactoring/README.md</code>

Notes:

- Suivez les instructions du README.md du lab pour le détail des étapes.

##==##

<!-- .slide: class="exercice" -->

# Lab 31 : Refactoring de code legacy

## Lab 31

<br>

### 💡 Lisez la **solution** dans

### <code data-markdown-preview="/labs/lab-31-legacy-refactoring-solution/README.md">labs/lab-31-legacy-refactoring-solution/README.md</code>

Notes:

- Lisez le README.md du lab pour des exemples de solutions.

##==##

<!-- .slide: class="exercice" -->

# Lab 32 : Implémentation from scratch

## Lab 32

<br>

### 👉 Suivez les **instructions** dans

### <code data-markdown-preview="/labs/lab-32-from-scratch/README.md">labs/lab-32-from-scratch/README.md</code>

Notes:

- Suivez les instructions du README.md du lab pour le détail des étapes.

##==##

<!-- .slide: class="exercice" -->

# Lab 32 : Implémentation from scratch

## Lab 32

<br>

### 💡 Lisez la **solution** dans

### <code data-markdown-preview="/labs/lab-32-from-scratch-solution/README.md">labs/lab-32-from-scratch-solution/README.md</code>

Notes:

- Lisez le README.md du lab pour des exemples de solutions.
