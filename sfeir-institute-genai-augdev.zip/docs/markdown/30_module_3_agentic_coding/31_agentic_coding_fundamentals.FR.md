<!-- .slide: class="transition" -->

# Module 3 : fondamentaux de l'Agentic Coding

## Comprendre le développement IA axé sur la qualité

##==##

<!-- .slide -->

# L'IA améliore la qualité du code

### Application automatique des conventions

- **Nommage & structure** : des motifs cohérents entre les fichiers
- **Bonnes pratiques** : principes SOLID, design patterns, sécurité
- **Documentation** : JSDoc, commentaires, mises à jour du README

### Couverture & gestion des erreurs

<!-- .element: class="sm-padding-top"-->

- **Tests automatisés** : unitaires, intégration, cas limites
- **Validation** : contrôle des entrées, gestion des erreurs
- **Solutions complètes** : toutes les exigences couvertes

### Exemple concret : upload de photo

<!-- .element: class="sm-padding-top"-->

**❌ Sans IA** : validation, gestion des erreurs, indicateurs de progression souvent oubliés

**✅ Avec l'Agentic Coding** : solution complète avec validation, tests, docs, cas limites

##==##

<!-- .slide -->

## Le workflow agentique en 5 phases

<img src="assets/images/30_module_3/agentic-workflow-diagram.svg" alt="Diagramme du workflow agentique" style="width:100%; height:auto; display:block;">

Notes:

1. Specify (QUOI) → 2. Plan (COMMENT) → 3. Tasks → 4. Implement → 5. Validate. Itérer autant que nécessaire - le processus n'est pas strictement linéaire. Les labs mettent ce workflow en pratique.
