<!-- .slide: class="transition" -->

# Module 3 : Bilan et récapitulatif

##==##

<!-- .slide -->

# Objectifs pédagogiques

### Au programme

À l'issue du Module 3, vous devriez être capable de :

- ✅ **Expliquer l'Agentic Coding** : comprendre ce que c'est et en quoi il diffère du développement traditionnel et du Vibe Coding
- ✅ **Appliquer le workflow en 5 phases** : dérouler Specify → Plan → Tasks → Implement → Validate de façon systématique
- ✅ **Créer un contexte efficace** : écrire des fichiers de contexte qui permettent une assistance IA de qualité
- ✅ **Analyser du code legacy** : utiliser l'IA pour identifier la dette technique et planifier un refactoring
- ✅ **Construire avec qualité** : implémenter des fonctionnalités avec documentation, tests et bonnes pratiques
- ✅ **Structurer vos requêtes IA** : formuler des prompts clairs et actionnables produisant des résultats de qualité

### Compétences pratiquées

<!-- .element: class="md-padding-top" -->

- **Lab 31** : analyse de legacy, création de contexte, planification du refactoring
- **Lab 32** : exécution complète du workflow, implémentation en collaboration avec l'IA

##==##

<!-- .slide -->

# **Quiz de validation**

## **Question 1 : phases du workflow**

<br>

### Quelle phase du workflow agentique définit **ce qui** doit être construit (exigences et critères d'acceptation) ?

**A)** Plan

**B)** Tasks

**C)** Validate

**D)** Specify

<details>
<summary>Réponse</summary>
<strong>D) Specify</strong> - Cette phase définit <strong>quoi</strong> construire (exigences et critères d'acceptation), tandis que Plan définit <strong>comment</strong> (architecture et approche).
</details>

Notes:
Comprendre la distinction entre le « quoi » (Specify) et le « comment » (Plan) est essentiel pour dérouler efficacement un workflow agentique.

##==##

<!-- .slide -->

# **Quiz de validation**

## **Question 2 : le contexte**

<br>

### Quelles sections essentielles doit contenir un fichier de contexte AGENTS.md efficace ?

**A)** Vue d'ensemble du projet, architecture, stack technique, conventions de code, objectifs actuels

**B)** Seulement la vue d'ensemble du projet et la stack technique

**C)** Une simple liste de chemins de fichiers

**D)** Des extraits de code et des signatures de fonctions

<details>
<summary>Réponse</summary>
<strong>A) Vue d'ensemble du projet, architecture, stack technique, conventions de code, objectifs actuels</strong> - Ces cinq sections donnent à l'IA un contexte projet complet. Plus de détail permet une meilleure assistance.
</details>

Notes:
Les fichiers de contexte sont le socle d'un Agentic Coding efficace : ils permettent à l'IA de fournir une assistance pertinente et spécifique au projet.

##==##

<!-- .slide -->

# **Quiz de validation**

## **Question 3 : requêtes IA efficaces**

<br>

### Laquelle de ces requêtes est la plus efficace pour l'IA ?

**A)** « Corrige le bug d'upload »

**B)** « Il y a un souci avec l'upload de photos, tu peux regarder ? »

**C)** « Dans PhotoUploadComponent, ajoute une validation rejetant les fichiers de plus de 5 Mo et affiche un message d'erreur à l'utilisateur. Suis le pattern de gestion d'erreur utilisé dans TagInputComponent. »

**D)** « Corrige le bug du composant d'upload et assure-toi qu'il gère les gros fichiers »

<details>
<summary>Réponse</summary>
<strong>C)</strong> - La requête C donne une localisation précise, une exigence claire, le comportement attendu et référence les patterns du projet. Les requêtes A, B et D sont trop vagues. Une requête efficace a besoin de contexte, de précision et d'exemples.
</details>

Notes:
Des requêtes IA structurées, avec un contexte et des contraintes clairs, produisent des résultats de meilleure qualité que des requêtes vagues. Les options A, B et D manquent de précision à des titres différents : A et B ne précisent pas le problème, D précise le problème mais ni le comportement attendu ni les patterns à suivre.

##==##

<!-- .slide -->

# **Quiz de validation**

## **Question 4 : gains de qualité**

<br>

### Comment l'Agentic Coding améliore-t-il la qualité face au développement traditionnel ?

**A)** Il ne l'améliore pas - la qualité dépend du développeur

**B)** Uniquement par une génération de code plus rapide

**C)** Par une application systématique de la qualité : conventions, tests, documentation et validation

**D)** En supprimant le besoin de revue de code

<details>
<summary>Réponse</summary>
<strong>C) Application systématique de la qualité</strong> - L'Agentic Coding intègre la qualité au processus : application automatique des conventions, tests complets, documentation exhaustive et phases de validation obligatoires. Le développement traditionnel repose sur la discipline individuelle.
</details>

Notes:
Le workflow structuré et la collaboration avec l'IA créent une application systématique de la qualité, au lieu de reposer uniquement sur la discipline du développeur.

##==##

<!-- .slide -->

# **Quiz de validation**

## **Question 5 : Vibe Coding vs Agentic Coding**

<br>

### Quelle est la différence fondamentale entre Vibe Coding et Agentic Coding ?

**A)** La vitesse de génération du code

**B)** Le développeur garde le contrôle stratégique et valide les résultats, vs acceptation passive de l'IA

**C)** Le langage de programmation ou le framework utilisé

**D)** Le modèle ou l'outil d'IA choisi

<details>
<summary>Réponse</summary>
<strong>B) Le développeur garde le contrôle stratégique et valide les résultats, vs acceptation passive de l'IA</strong> - Le Vibe Coding accepte les résultats de l'IA sans revue, alors que l'Agentic Coding garde le développeur aux commandes via un workflow structuré, la validation et une collaboration intentionnelle. La vitesse (A), le langage (C) et le choix de l'outil (D) ne sont pas les facteurs distinctifs.
</details>

Notes:
Cette question renforce la distinction clé du Module 2 et vérifie la compréhension de pourquoi l'Agentic Coding produit de meilleurs résultats que l'acceptation passive de l'IA.

##==##

<!-- .slide -->

# **Ressources**

## **Pour aller plus loin**

<br>

### **Documentation**

- [Claude Docs](https://docs.anthropic.com) - La documentation IA d'Anthropic
- [GitHub Copilot Best Practices](https://docs.github.com/en/copilot/using-github-copilot) - Développement assisté par IA
- [OpenAI API Documentation](https://platform.openai.com/docs/) - Référence et guides officiels de l'API
- [How to write a great AGENTS.md](https://github.blog/ai-and-ml/github-copilot/how-to-write-a-great-agents-md-lessons-from-over-2500-repositories/) - Bonnes pratiques issues de plus de 2 500 dépôts

Notes:
Utilisez les solutions des labs pour voir des implémentations complètes du workflow agentique, aussi bien en refactoring qu'en développement greenfield.
