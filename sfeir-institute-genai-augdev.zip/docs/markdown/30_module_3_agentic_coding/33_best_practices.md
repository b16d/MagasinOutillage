<!-- .slide: class="transition" -->

# Module 3: Best Practices

## Effective AI Collaboration Techniques

##==##

<!-- .slide: class="tc-multiple-columns" -->

##++## "class=with-code"

## ❌ Poor Request

<br>

**Prompt**:

```
Create a photo component.
```

**Problems**:

<!-- .element: class="md-padding-top"-->

- No context
- Unclear requirements
- No constraints
- No format guidance

##++##

##++## "class=with-code"

## ✅ Effective Request

<br>

**Prompt**:

```
In our Angular photo gallery
(standalone components, signals):

Create PhotoDetailComponent:
1. Accepts photo ID input
2. Displays filename, date, tags
3. Uses existing PhotoService
4. Error handling for missing photos
5. inject() DI + signal state

Include JSDoc + Vitest tests
```

**Why it works**: Context + Clear requirements + Patterns specified

<!-- .element: class="md-padding-top"-->

##++##

##==##

<!-- .slide -->

## Iteration: The Secret to Quality

### `First Pass` → `Review` → `Refine` → `Repeat`

| Iteration | Request                                                                         | Result                           |
| --------- | ------------------------------------------------------------------------------- | -------------------------------- |
| **1st**   | "Create photo upload validation"                                                | Basic checks, missing edge cases |
| **2nd**   | "Add: file type check (jpeg/png/gif/webp), 5MB limit, min 100x100px dimensions" | Better, but no error messages    |
| **3rd**   | "Add user-friendly error messages + unit tests for each rule"                   | ✅ Production-ready              |

##==##

<!-- .slide -->

## Iteration: The Secret to Quality

### `First Pass` → `Review` → `Refine` → `Repeat`

### Common Refinements

<!-- .element: class="sm-padding-top"-->

- **Error Handling**: "Add try-catch for network failures"
- **Performance**: "Optimize for 10,000+ items using virtualization"
- **Testing**: "Add edge case tests for boundary conditions"
- **Conventions**: "Match pattern in UserService.ts"

**Tip**: Be specific - instead of "make it better", say "add input validation and error messages"

##==##

<!-- .slide -->

## Documentation Best Practices

<br>

### Documentation Levels

| Level         | What             | Example                                                                                   |
| ------------- | ---------------- | ----------------------------------------------------------------------------------------- |
| **Code**      | JSDoc/docstrings | `/** Uploads photo with validation @param file @returns Photo @throws ValidationError */` |
| **Component** | README in folder | Features, dependencies, usage examples                                                    |
| **Project**   | AGENTS.md        | Context file for AI - keep updated!                                                       |

##==##

<!-- .slide: class="with-code" -->

## Testing Best Practices

<br>

### AI-Assisted Testing

**Request Pattern**:

```markdown
Generate unit tests for [Component] covering:

1. Happy path scenarios
2. Edge cases (empty inputs, boundaries)
3. Error conditions
4. Integration with dependencies (mocked)
   Use Vitest syntax. Descriptive test names.
```

**TDD with AI**:

<!-- .element: class="sm-padding-top"-->

`Specify` → `Generate tests` → `Verify fail` → `Implement` → `Verify pass` → `Refactor`

##==##

<!-- .slide -->

## Common Pitfalls and Solutions

<br>

| Pitfall             | ❌ Problem                                    | ✅ Solution                                               |
| ------------------- | --------------------------------------------- | --------------------------------------------------------- |
| **Vague specs**     | "Build a photo app" → generic code            | Be specific - define exact features, user flows, criteria |
| **Skip validation** | Accept without review → bugs, security issues | Always run tests, review code, verify requirements        |
| **Stale context**   | Outdated AGENTS.md → wrong suggestions        | Update context when architecture/conventions change       |
| **AI-driven**       | AI makes all decisions → poor architecture    | YOU lead strategy, AI assists implementation              |

##==##

<!-- .slide -->

## Common Pitfalls and Solutions

<br>

| Pitfall               | ❌ Problem                                       | ✅ Solution                               |
| --------------------- | ------------------------------------------------ | ----------------------------------------- |
| **No iteration**      | Use first output → incomplete solution           | Refine requests until quality achieved    |
| **No tests**          | Skip testing → unreliable code                   | Request tests alongside implementation    |
| **Context switching** | New feature without context update → AI confused | Update "Current Goals" before new work    |
| **Old patterns**      | AI suggests NgModules in Angular 21 → debt       | Specify modern approaches in context file |
