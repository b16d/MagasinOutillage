<!-- .slide: class="transition" -->

# Module 3: Assessment and Recap

##==##

<!-- .slide -->

# Learning Objectives Review

### What We Covered

By completing Module 3, you should now be able to:

- ✅ **Explain Agentic Coding**: Understand what it is and how it differs from traditional development and Vibe Coding
- ✅ **Apply the 5-Phase Workflow**: Execute Specify → Plan → Tasks → Implement → Validate systematically
- ✅ **Create Effective Context**: Write context files that enable high-quality AI assistance
- ✅ **Analyze Legacy Code**: Use AI to identify technical debt and plan refactoring
- ✅ **Build with Quality**: Implement features with documentation, tests, and best practices
- ✅ **Structure AI Requests**: Formulate clear, actionable prompts that produce quality outputs

### Skills You've Practiced

<!-- .element: class="md-padding-top" -->

- **Lab 31**: Legacy analysis, context creation, refactoring planning
- **Lab 32**: Complete workflow execution, implementation with AI collaboration

##==##

<!-- .slide -->

# **Knowledge Check**

## **Question 1: Workflow Phases**

<br>

### Which phase of the agentic workflow defines **what** needs to be built (requirements and acceptance criteria)?

**A)** Plan

**B)** Tasks

**C)** Validate

**D)** Specify

<details>
<summary>Answer</summary>
<strong>D) Specify</strong> - This phase defines <strong>what</strong> to build (requirements and acceptance criteria), while Plan defines <strong>how</strong> (architecture and approach).
</details>

Notes:
Understanding the distinction between "what" (Specify) and "how" (Plan) is critical for effective agentic workflow execution.

##==##

<!-- .slide -->

# **Knowledge Check**

## **Question 2: Context Files**

<br>

### What are the essential sections that should be included in an effective AGENTS.md context file?

**A)** Project overview, architecture, tech stack, coding conventions, current goals

**B)** Only project overview and tech stack

**C)** Just a list of file paths

**D)** Code snippets and function signatures

<details>
<summary>Answer</summary>
<strong>A) Project overview, architecture, tech stack, coding conventions, current goals</strong> - These five sections provide AI with comprehensive project context. More detail enables better assistance.
</details>

Notes:
Context files are the foundation of effective agentic coding - they enable AI to provide project-specific, relevant assistance.

##==##

<!-- .slide -->

# **Knowledge Check**

## **Question 3: Effective AI Requests**

<br>

### Which of these requests is more effective for AI assistance?

**A)** "Fix the upload bug"

**B)** "There's something wrong with photo uploads, can you look into it?"

**C)** "In PhotoUploadComponent, add validation to reject files larger than 5MB and display an error message to the user. Follow the error handling pattern used in TagInputComponent."

**D)** "Fix the bug in the upload component and make sure it handles large files"

<details>
<summary>Answer</summary>
<strong>C)</strong> - Request C provides specific location, clear requirement, expected behavior, and references project patterns. Requests A, B, and D are too vague. Effective requests need context, specificity, and examples.
</details>

Notes:
Structured AI requests with clear context and constraints produce higher quality outputs than vague requests. Options A, B, and D lack specificity in different ways — A and B don't specify the issue, D specifies the problem but not the expected behavior or patterns to follow.

##==##

<!-- .slide -->

# **Knowledge Check**

## **Question 4: Quality Improvements**

<br>

### How does Agentic Coding improve code quality compared to traditional development?

**A)** It doesn't - quality depends on the developer

**B)** Only through faster code generation

**C)** Systematic quality enforcement through conventions, testing, documentation, and validation

**D)** By eliminating the need for code review

<details>
<summary>Answer</summary>
<strong>C) Systematic quality enforcement</strong> - Agentic Coding builds quality into the process through automatic convention enforcement, comprehensive testing, complete documentation, and required validation phases. Traditional development relies on individual discipline.
</details>

Notes:
The structured workflow and AI collaboration create systematic quality enforcement rather than relying solely on developer discipline.

##==##

<!-- .slide -->

# **Knowledge Check**

## **Question 5: Vibe Coding vs Agentic Coding**

<br>

### What is the fundamental difference between Vibe Coding and Agentic Coding?

**A)** The speed of code generation

**B)** Developer maintains strategic control and validates outputs vs passive AI acceptance

**C)** The programming language or framework used

**D)** The specific AI model or tool chosen

<details>
<summary>Answer</summary>
<strong>B) Developer maintains strategic control and validates outputs vs passive AI acceptance</strong> - Vibe Coding accepts AI outputs without review, while Agentic Coding keeps the developer in control through structured workflow, validation, and intentional collaboration. Speed (A), language (C), and tool choice (D) are not the distinguishing factors.
</details>

Notes:
This question reinforces the core distinction from Module 2 and ensures understanding of why Agentic Coding produces better outcomes than passive AI acceptance.

##==##

<!-- .slide -->

# **Resources**

## **Further Learning**

<br>

### **Documentation**

- [Claude Docs](https://docs.anthropic.com) - Anthropic's AI documentation
- [GitHub Copilot Best Practices](https://docs.github.com/en/copilot/using-github-copilot) - AI-assisted development
- [OpenAI API Documentation](https://platform.openai.com/docs/) - Official API reference and guides
- [How to write a great AGENTS.md](https://github.blog/ai-and-ml/github-copilot/how-to-write-a-great-agents-md-lessons-from-over-2500-repositories/) - Best practices from 2,500+ repositories

Notes:
Use the lab solutions to see complete implementations of the agentic workflow for both refactoring and greenfield development scenarios.
