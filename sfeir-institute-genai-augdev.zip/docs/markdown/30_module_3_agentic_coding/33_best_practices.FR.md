<!-- .slide: class="transition" -->

# Module 3 : Bonnes pratiques

## Techniques de collaboration IA

##==##

<!-- .slide: class="tc-multiple-columns" -->

##++## "class=with-code"

## ❌ Mauvaise requête

<br>

**Prompt** :

```
Create a photo component.
```

**Problèmes** :

<!-- .element: class="md-padding-top"-->

- Aucun contexte
- Besoins flous
- Aucune contrainte
- Aucun format indiqué

##++##

##++## "class=with-code"

## ✅ Requête efficace

<br>

**Prompt** :

```
In our Angular photo gallery
(standalone components, signals):

Create PhotoDetailComponent:
1. Accepts photo ID input
2. Displays filename, date, tags
3. Uses existing PhotoService
4. Error handling for missing photos
5. inject() DI + signal state

Include JSDoc + Vitest tests
```

**Pourquoi ça marche** : contexte + besoins clairs + patterns précisés

<!-- .element: class="md-padding-top"-->

##++##

##==##

<!-- .slide -->

## Itération : le secret de la qualité

### `First Pass` → `Review` → `Refine` → `Repeat`

| Itération | Requête                                                                                 | Résultat                              |
| --------- | --------------------------------------------------------------------------------------- | ------------------------------------- |
| **1re**   | "Créer la validation d'upload de photo"                                                 | Vérifs de base, cas limites manquants |
| **2e**    | "Ajouter : contrôle du type (jpeg/png/gif/webp), limite 5 Mo, dimensions min 100x100px" | Mieux, mais sans messages d'erreur    |
| **3e**    | "Ajouter des messages d'erreur clairs + tests unitaires par règle"                      | ✅ Prêt pour la production            |

##==##

<!-- .slide -->

## Itération : le secret de la qualité

### `First Pass` → `Review` → `Refine` → `Repeat`

### Affinages courants

<!-- .element: class="sm-padding-top"-->

- **Gestion d'erreur** : "Ajouter un try-catch pour les pannes réseau"
- **Performance** : "Optimiser pour 10 000+ éléments via virtualisation"
- **Tests** : "Ajouter des tests de cas limites"
- **Conventions** : "Suivre le pattern de UserService.ts"

**Astuce** : soyez précis - au lieu de "améliore ça", dites "ajoute la validation des entrées et des messages d'erreur"

##==##

<!-- .slide -->

## Bonnes pratiques de documentation

<br>

### Niveaux de documentation

| Niveau        | Quoi              | Exemple                                                                                   |
| ------------- | ----------------- | ----------------------------------------------------------------------------------------- |
| **Code**      | JSDoc/docstrings  | `/** Uploads photo with validation @param file @returns Photo @throws ValidationError */` |
| **Composant** | README du dossier | Fonctionnalités, dépendances, exemples d'usage                                            |
| **Projet**    | AGENTS.md         | Fichier de contexte pour l'IA - à tenir à jour !                                          |

##==##

<!-- .slide: class="with-code" -->

## Bonnes pratiques de test

<br>

### Tests assistés par IA

**Modèle de requête** :

```markdown
Generate unit tests for [Component] covering:

1. Happy path scenarios
2. Edge cases (empty inputs, boundaries)
3. Error conditions
4. Integration with dependencies (mocked)
   Use Vitest syntax. Descriptive test names.
```

**TDD avec l'IA** :

<!-- .element: class="sm-padding-top"-->

`Specify` → `Generate tests` → `Verify fail` → `Implement` → `Verify pass` → `Refactor`

##==##

<!-- .slide -->

## Pièges courants et solutions

<br>

| Piège                 | ❌ Problème                               | ✅ Solution                                                   |
| --------------------- | ----------------------------------------- | ------------------------------------------------------------- |
| **Specs floues**      | "Faire une app photo" → code générique    | Soyez précis - définissez fonctionnalités, parcours, critères |
| **Validation zappée** | Accepter sans relire → bugs, failles      | Toujours tester, relire le code, vérifier les besoins         |
| **Contexte obsolète** | AGENTS.md périmé → mauvaises suggestions  | Mettre à jour à chaque changement d'archi/conventions         |
| **Piloté par l'IA**   | L'IA décide de tout → architecture faible | VOUS pilotez la stratégie, l'IA assiste                       |

##==##

<!-- .slide -->

## Pièges courants et solutions

<br>

| Piège                      | ❌ Problème                                       | ✅ Solution                                      |
| -------------------------- | ------------------------------------------------- | ------------------------------------------------ |
| **Zéro itération**         | Garder la 1re sortie → solution incomplète        | Affiner les requêtes jusqu'à la qualité visée    |
| **Zéro test**              | Pas de tests → code peu fiable                    | Demander les tests avec l'implémentation         |
| **Changement de contexte** | Nouvelle feature sans MAJ du contexte → IA perdue | Mettre à jour "Current Goals" avant de démarrer  |
| **Patterns obsolètes**     | L'IA propose des NgModules en Angular 21 → dette  | Préciser les approches modernes dans le contexte |
