<!-- .slide: class="transition" -->

# Module 3: Context Management

## Making AI Your Effective Collaborator

##==##

<!-- .slide -->

## What is Context Management?

**Context Management** is the practice of providing AI coding agents with project-specific information to guide their code generation and suggestions.

### **Why It Matters?**

<!-- .element: class="md-padding-top"-->

**Without context**, AI agents:

- ❌ Generate code that doesn't match your project conventions
- ❌ Suggest outdated or incompatible dependencies
- ❌ Miss project-specific constraints and patterns
- ❌ Create inconsistent implementation styles

**✅ With proper context**, AI becomes a knowledgeable team member that understands your project's **architecture**, **conventions**, and **goals**.

<!-- .element: class="sm-padding-top"-->

##==##

<!-- .slide -->

## What Are Context Files?

**Context files** are special documentation files that AI coding agents read to understand your project.

### 🎯 Purpose:

- 📄 **Project Overview**: What the application does, its purpose, and goals
- 🛠️ **Technical Stack**: Languages, frameworks, libraries, and versions
- 🏗️ **Architecture**: Structure, patterns, and design decisions
- 📏 **Conventions**: Naming, formatting, and coding standards
- 🚧 **Constraints**: Performance requirements, security policies, limitations

<br>
<br>

### 📍 Location:

Context files are typically placed at the **repository root** or in specific configuration directories (`.github/`, `.windsurf/`, etc.) or any **sub-directories** (for e.g in monorepos).

##==##

<!-- .slide -->

## Coding Agent Context Files

Different AI coding agents use different native context file formats:

| Agent              | Native Context File(s)            | Location             |
| ------------------ | --------------------------------- | -------------------- |
| **GitHub Copilot** | `.github/copilot-instructions.md` | `.github/` directory |
| **Claude Code**    | `CLAUDE.md`                       | Repository root      |
| **Gemini**         | `GEMINI.md`                       | Repository root      |
| **Codex (OpenAI)** | `AGENTS.md`                       | Repository root      |
| **OpenCode**       | `AGENTS.md`                       | Repository root      |
| **Mistral Vibe**   | `AGENTS.md`                       | Repository root      |

<!--TODO: add new agentic tool native context file above-->

<br>

**🤯 Challenge**: Managing multiple context files for different agents creates maintenance overhead.

##==##

<!-- .slide -->

## AGENTS.md: A Universal Standard

<cite>the `README.md` for 🤖 AI agents!</cite>

**[AGENTS.md](https://agents.md/)** is an **emerging open standard** pionered by **OpenAI**, aiming to provide context and instructions to help AI coding agents work effectively on your project.

At heart, it is just a **markdown file** , similar to a `README.md`, which is instead, for us 🗣️ Humans

### Goals

- **Single Source of Truth**: One context file instead of many agent-specific files
- **Interoperability**: Works across different AI coding tools
- **Open Standard**: Community-driven, vendor-neutral specification
- **Maintainable**: Update once, benefit everywhere

##==##

<!-- .slide -->

## AGENTS.md Support Across Agents

<br>

| Agent              | AGENTS.md Support                   | Native Alternative                |
| ------------------ | ----------------------------------- | --------------------------------- |
| **GitHub Copilot** | ✅ Full (Aug 2025)                  | `.github/copilot-instructions.md` |
| **Claude Code**    | ⚠️ Partial (via `CLAUDE.md` import) | `CLAUDE.md`                       |
| **Gemini CLI**     | ⚠️ Partial (configurable)           | `GEMINI.md`                       |
| **Codex (OpenAI)** | ✅ Full (Creator)                   | `AGENTS.md` (native)              |
| **OpenCode**       | ✅ Full (native)                    | `AGENTS.md` (native)              |
| **Mistral Vibe**   | ✅ Full (native)                    | `AGENTS.md` (native)              |

<!--TODO: add new agentic tool's AGENTS.md support above-->

<br>

**💡 Recommendation**: Use `AGENTS.md` as primary context file, supplemented with agent-specific files when needed.

Notes:

- **Claude Code:** ⚠️ Partial (via CLAUDE.md import) — Claude Code reads CLAUDE.md, not AGENTS.md. A workaround requires a CLAUDE.md that import @AGENTS.md - https://code.claude.com/docs/en/memory#agents-md

- **Gemini CLI:** ⚠️ Partial (configurable) — Gemini CLI can be configured to read AGENTS.md instead of GEMINI.md, it is not default behavior, requires manual configuration - https://geminicli.com/docs/cli/gemini-md#customize-the-context-file-name — Note (as of July 2026): Gemini CLI was retired (May 2026) and succeeded by Antigravity CLI; the AGENTS.md/GEMINI.md distinction is retained here for reference.

##==##

<!-- .slide -->

<img src="assets/images/30_module_3/context-file-example.svg" alt="Context File Example" style="width:100%; height:auto; display:block;">

Notes:
This example demonstrates a well-structured AGENTS.md file with all essential sections. **Key points to highlight**: (1) **Project Overview** gives AI the "what and why" - purpose, scope, and constraints; (2) **Architecture** explains structure and data flow so AI generates code that fits; (3) **Tech Stack** with specific versions prevents outdated suggestions (e.g., Angular 21 standalone vs NgModules); (4) **Conventions** ensure consistency - naming patterns, DI approach, state management; (5) **Current Goals** focuses AI on immediate work. **Common mistakes**: Being too vague ("use best practices"), omitting versions, forgetting to update when architecture changes. **Tip**: Treat AGENTS.md like a README for AI - if a new team member would need to know it, include it.

##==##

<!-- .slide: class="exercice" -->

# Lab 31: Legacy Code Refactoring

## Lab 31

<br>

### 👉 Follow **instructions** in

### <code data-markdown-preview="/labs/lab-31-legacy-refactoring/README.md">labs/lab-31-legacy-refactoring/README.md</code>

Notes:

- Follow the instructions in the lab README.md for detailed steps.

##==##

<!-- .slide: class="exercice" -->

# Lab 31: Legacy Code Refactoring

## Lab 31

<br>

### 💡 Read **solution** at

### <code data-markdown-preview="/labs/lab-31-legacy-refactoring-solution/README.md">labs/lab-31-legacy-refactoring-solution/README.md</code>

Notes:

- Read the lab README.md for example of solutions.

##==##

<!-- .slide: class="exercice" -->

# Lab 32: From-Scratch Implementation

## Lab 32

<br>

### 👉 Follow **instructions** in

### <code data-markdown-preview="/labs/lab-32-from-scratch/README.md">labs/lab-32-from-scratch/README.md</code>

Notes:

- Follow the instructions in the lab README.md for detailed steps.

##==##

<!-- .slide: class="exercice" -->

# Lab 32: From-Scratch Implementation

## Lab 32

<br>

### 💡 Read **solution** at

### <code data-markdown-preview="/labs/lab-32-from-scratch-solution/README.md">labs/lab-32-from-scratch-solution/README.md</code>

Notes:

- Read the lab README.md for example of solutions.
