<!-- .slide: class="transition" -->

# Module 3: Agentic Coding Fundamentals

## Understanding Quality-Focused AI Development

##==##

<!-- .slide -->

# How AI Improves Code Quality

### Automatic Convention Enforcement

- **Naming & Structure**: Consistent patterns across files
- **Best Practices**: SOLID principles, design patterns, security
- **Documentation**: JSDoc, comments, README updates

### Test Coverage & Error Handling

<!-- .element: class="sm-padding-top"-->

- **Automated Tests**: Unit, integration, edge cases
- **Validation**: Input checking, error handling
- **Complete Solutions**: All requirements covered

### Real Example: Photo Upload

<!-- .element: class="sm-padding-top"-->

**❌ Without AI**: May miss validation, error handling, progress indicators

**✅ With Agentic Coding**: Complete solution with validation, tests, docs, edge cases

##==##

<!-- .slide -->

## The 5-Phase Agentic Workflow

<img src="assets/images/30_module_3/agentic-workflow-diagram.svg" alt="Agentic Workflow Diagram" style="width:100%; height:auto; display:block;">

Notes:

1. Specify (WHAT) → 2. Plan (HOW) → 3. Tasks → 4. Implement → 5. Validate. Iterate as needed - not strictly linear. Labs demonstrate this workflow in practice.
