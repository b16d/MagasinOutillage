<!-- .slide: class="transition" -->

# Aperçu du module 2

## Vibe Coding vs Agentic Coding

Notes:
Ce module explore la distinction essentielle entre le vibe coding (acceptation passive des suggestions de l'IA) et l'agentic coding (développeur augmenté en collaboration continue). Comprendre cette différence est indispensable pour un développement augmenté par l'IA sûr et efficace en environnement de production.

##==##

<!-- .slide: -->

# **Objectifs pédagogiques**

À la fin de ce module, vous saurez :

- **Comprendre** la différence fondamentale entre vibe coding et agentic coding
- **Identifier** les limites et dangers majeurs de l'acceptation passive du code IA
- **Distinguer** les cas d'usage adaptés et inadaptés au vibe coding
- **Expliquer** comment le modèle du développeur augmenté préserve qualité et contrôle du code
- **Appliquer** les principes de collaboration continue dans les workflows d'agentic coding

Notes:
Ces objectifs s'alignent sur le but du cours : développer la conscience des pratiques sûres de développement augmenté par l'IA. Chaque objectif est vérifiable par la discussion, des exercices de réflexion et la pratique lors de l'atelier photo gallery.

##==##

<!-- .slide: -->

# **Prérequis**

## **Ce qu'il faut connaître**

<br>

### **Issu du module 1**

- Compréhension de base des outils de développement augmenté par l'IA
- Familiarité avec les workflows de développement et les pratiques de revue de code

<br><br>

### **Prérequis techniques**

- Connaissances de base en programmation (tout langage)
- Un navigateur Web (pour tester l'application web du lab)

Notes:
Vérifiez que tous les participants ont terminé le module 1 et maîtrisent les concepts fondamentaux du développement avec l'IA. Pour le lab pratique, assurez-vous qu'ils peuvent installer des logiciels sur leur machine. Les prérequis techniques sont volontairement légers pour rester accessibles à tous les niveaux.
