<!-- .slide: class="transition" -->

# Module 2: Agentic Coding Paradigm

## The Augmented Developer Model

Notes:
This section introduces the agentic coding approach and explores how continuous human-AI collaboration maintains code quality and control.

##==##

<!-- .slide: -->

# **The Augmented Developer**

## **A New Vision for AI-Assisted Development**

<br><br>

### **The Augmented Developer Model**

Human intelligence + AI capabilities = **Enhanced productivity** with maintained control

The developer remains the **architect, decision-maker, and quality guardian**. AI serves as a **powerful assistant, not a replacement**.

Notes:
The augmented developer model represents a fundamental shift in how we think about AI tools. Instead of replacing human developers or having humans passively accept AI output, we create a partnership where each party contributes their strengths. Humans provide judgment, experience, domain knowledge, and quality standards. AI provides speed, pattern recognition, and tireless assistance with routine tasks. This is the foundation of agentic coding.

##==##

<!-- .slide: -->

# **What is Agentic Coding?**

## **Definition**

<br><br>

### **Agentic Coding**

A systematic, quality-focused approach to AI-augmented development where developers maintain strategic control, review all suggestions, and take responsibility for code quality while leveraging AI as an intelligent collaborator.

The developer is an **active agent** who directs, evaluates, and refines AI assistance.

Notes:
The term "agentic" emphasizes developer agency - the developer has power, control, and responsibility. Unlike vibe coding's passive observation, agentic coding requires continuous engagement. You review every suggestion, understand every line of code, test thoroughly, and iterate when needed. This is more work than vibe coding, but it's the only approach that produces production-quality code. Module 3 will expand on this definition with a structured 5-phase workflow (Specify → Plan → Tasks → Implement → Validate) that makes agentic coding repeatable and scalable.

##==##

<!-- .slide: -->

<img src="assets/images/20_module_2/agentic-coding-workflow.svg" alt="Agentic Coding Workflow showing iterative cycle of suggest, review, test, refine with developer at center maintaining control" style="width:100%; height:auto; display:block;">

Notes:
This diagram illustrates the continuous **collaboration cycle of agentic coding**.

The developer sits at the **center**, maintaining control throughout the entire process.

The workflow follows an iterative loop:

1. The AI Tool suggests code
2. The developer performs a Code Review, examining logic, checking edge cases, and verifying quality
3. Testing validates the behavior
4. If issues are found, the developer performs Refinement by iterating prompts and adjusting the approach, which cycles back to the AI Tool.

When testing passes and quality is verified, code moves to Production. Notice the dashed circle around the entire process - this represents the **safety boundary** created by **human oversight**. The developer never blindly accepts AI suggestions; instead, they maintain an active review-test-refine loop until the code meets all requirements.

##==##

<!-- .slide: -->

# **Impact on Code Quality**

## **How Review Catches Issues**

<br>

### **Before Deployment**

Code review identifies bugs, edge cases, and quality issues **before** they reach production

<br><br>

### **Key Benefits**

- Catch logic errors during review, not in production
- Identify edge cases AI might miss
- Ensure code meets team quality standards
- Verify security and performance requirements

Notes:
This is the primary value proposition of agentic coding - quality assurance through human review. When you review AI-generated code, you're applying your experience and judgment to catch issues the AI can't see. You understand the business context, security requirements, performance constraints, and team coding standards. The AI doesn't. Your review is the quality gate that prevents production failures.

##==##

<!-- .slide: -->

# **Impact on Maintainability**

## **How Review Ensures Understandable Code**

<br><br>

### **Code Understanding**

If you review code, you understand how it works. This enables:

- **Debugging**: Fix issues when they arise
- **Extension**: Add features without breaking existing functionality
- **Refactoring**: Improve code quality over time
- **Knowledge Transfer**: Explain code to teammates

Notes:
Maintainability is the long-term benefit of agentic coding. When you review code before accepting it, you build understanding. That understanding becomes invaluable when you need to modify or debug the code months later. Contrast this with vibe coding where the original developer can't explain how the code works. Maintainability debt accumulates quickly with unreviewed code and becomes very expensive to pay down.

##==##

<!-- .slide: -->

# **Impact on Documentation**

## **How Humans Ensure Documentation Matches Implementation**

<br>

### **The Documentation Gap**

AI can generate documentation, but only humans can verify it matches actual behavior

<br><br>

### **Human Responsibility**

- Verify documentation accuracy against implementation
- Add context about business requirements and edge cases
- Document non-obvious decisions and tradeoffs
- Keep docs synchronized with code changes

Notes:
Documentation is a critical area where human review is irreplaceable. AI can generate plausible-sounding documentation, but it might not accurately describe what the code actually does (especially if the code has bugs). Only a human who understands both the code and the business requirements can ensure documentation is accurate, complete, and useful. This is part of the developer's responsibility in agentic coding.

##==##

<!-- .slide -->

## Three Approaches To Software Development in 2026

<img src="assets/images/20_module_2/traditional-vs-agentic.svg" alt="Traditional vs Agentic Comparison" style="width:100%; height:auto; display:block;">

Notes:

- **Traditional**: manual, slow, variable quality.
- **Vibe**: fast but chaotic, technical debt. Agentic: structured workflow, fast + consistent, best of both worlds.
- **Agentic**: structured workflow, fast + consistent, best of both worlds.
