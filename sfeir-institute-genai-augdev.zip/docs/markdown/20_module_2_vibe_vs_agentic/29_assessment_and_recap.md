<!-- .slide: class="transition" -->

# Module 2: Assessment and Recap

## Validating Your Understanding

Notes:
This assessment validates your understanding of vibe coding vs agentic coding concepts through knowledge checks and reflection. It reinforces key learnings and ensures you can apply these principles to real development scenarios.

##==##

<!-- .slide: -->

# **Learning Objectives Review**

## **What You've Learned**

<br>

### **Key Competencies Developed**

- **Understand** the fundamental difference between vibe coding (passive AI acceptance) and agentic coding (active human control)
- **Identify** the key limitations and dangers of passive AI code acceptance through production failure examples
- **Distinguish** between appropriate scenarios (prototyping, hackathons) and inappropriate scenarios (production systems, security-sensitive code) for vibe coding
- **Explain** how the augmented developer model maintains code quality through continuous collaboration and review
- **Apply** continuous collaboration principles to real development scenarios through hands-on experience

Notes:
You've completed a comprehensive module covering both theoretical concepts and hands-on practice. You're now equipped to make informed decisions about when and how to use AI coding assistants safely. The hands-on photo gallery workshop provided practical experience to ground these abstract concepts in reality. Note that this module focused on two core sections: vibe coding fundamentals (definition, dangers, appropriate use cases) and the agentic coding paradigm (augmented developer model, quality impacts).

##==##

<!-- .slide: -->

# **Knowledge Check**

## **Question 1:**

<br>

### A developer accepts all AI-generated code suggestions without reviewing them or understanding the logic. This is an example of:

**A)** Vibe coding (passive acceptance approach)

**B)** Agentic coding where the developer remains in control

**C)** Augmented developer model with continuous collaboration

**D)** Traditional coding without AI assistance

<br>

<details>
<summary>Answer</summary>
<strong>A</strong> - Vibe coding is defined as passive acceptance of AI suggestions without code review or understanding. The key characteristic is the developer acting as an observer rather than an active participant.
</details>

Notes:
This question tests the fundamental definition of vibe coding and its distinction from safer approaches. Understanding this definition is critical because it underpins all other concepts in the module.

- Option B is incorrect because agentic coding requires the developer to remain in control through active review.
- Option C is incorrect because the augmented developer model requires active human engagement and review.
- Option D is incorrect because this scenario explicitly involves AI-generated suggestions.

##==##

<!-- .slide: -->

# **Knowledge Check**

## **Question 2: Risk Assessment**

<br>

### Your team is building a user authentication system for a production web application. A developer wants to use AI to generate authentication code without reviewing it. What is the appropriate response?

_(Hint 💡: Remember the production failure with inverted authentication logic)_

**A)** Allow it - AI is good at generating authentication code

**B)** Allow it only if the developer has experience with authentication

**C)** Allow it for the prototype but not for production

**D)** Prevent it - authentication is security-sensitive and requires thorough review

<br>

<details>
<summary>Answer</summary>
<strong>D</strong> - Authentication code is security-sensitive and should NEVER be generated without thorough review, regardless of experience level or context.
</details>

Notes:
This question tests the ability to apply vibe coding concepts to real scenarios and make risk-based decisions. Security-sensitive code represents one of the clearest "never use vibe coding" cases.

- Option A is dangerous because even if AI can generate plausible authentication code, security vulnerabilities (like the inverted logic example from production failures) can be subtle and catastrophic.
- Option B is incorrect because even experienced developers need to review security-sensitive code.
- Option C is partially correct but misleading - even prototypes with real user data require security review. Remember the production failure where inverted authentication logic (`if (!isAuthenticated)`) granted access to unauthorized users.

##==##

<!-- .slide: -->

# **Knowledge Check**

## **Question 3: Production Failure Patterns**

<br>

### Based on the production failures discussed, what do all three failures (performance collapse, authentication bug, maintainability crisis) have in common?

**A)** All were caused by AI hallucinations

**B)** All were discovered immediately upon deployment

**C)** All worked in initial testing but failed under production conditions

**D)** All could have been prevented by using a different AI tool

<br>

<details>
<summary>Answer</summary>
<strong>C</strong> - All three production failures shared the pattern of working in initial testing but failing under production conditions. The performance collapse worked with small datasets but failed at scale. The authentication bug passed basic tests but had inverted logic. The maintainability crisis produced code that "worked" but was impossible to debug or extend. This is the insidious danger of vibe coding: code appears to work in limited testing scenarios, giving false confidence, but production exposes hidden issues.
</details>

Notes:
This question reinforces the critical insight that vibe coding's danger lies in false confidence from limited testing. It connects the three failure examples to demonstrate a common pattern that participants should watch for.

- Option A is incorrect because these weren't AI hallucinations - the AI generated plausible code with subtle problems.
- Option B is incorrect because some issues took time to surface (like maintainability problems).
- Option D is incorrect because the root cause was lack of code review, not the AI tool choice.

##==##

<!-- .slide: -->

# **Resources**

## **Further Learning**

<br>

### **Documentation**

- [Vibe Coding Article](https://addyo.substack.com/p/vibe-coding-is-not-the-same-as-ai) - Original analysis of vibe coding vs agentic coding with production failure examples

<br><br>

### **Lab Solutions**

- Review `labs/lab-21-photo-gallery-workshop-solution/` for complete photo gallery implementation with architectural notes

Notes:
The vibe coding article provides deeper context for the production failures discussed. The lab solution offers a reference photo gallery implementation to compare against what participants generated during the workshop.
