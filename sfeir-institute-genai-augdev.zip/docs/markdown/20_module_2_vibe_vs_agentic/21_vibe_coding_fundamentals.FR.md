<!-- .slide: class="transition" -->

# Module 2 : fondamentaux du vibe coding

## Comprendre l'acceptation passive du code IA

Notes:
Cette section explore ce qu'est le vibe coding, ses limites, et les cas où il peut être approprié de l'utiliser.

##==##

<!-- .slide: -->

# **Le vibe coding**

## **Définition**

<br>

### **Vibe Coding**

Acceptation passive des suggestions de code générées par l'IA, sans revue ni compréhension du code.

Le développeur agit en **observateur**, et non en participant actif du processus de développement.

Notes:
Le vibe coding est un terme apparu pour décrire une façon spécifique (et risquée) de travailler avec les assistants de code IA. La caractéristique clé est la passivité : le développeur génère du code avec l'IA mais ne relit pas, ne comprend pas et ne valide pas ce que l'IA produit. C'est fondamentalement différent de l'agentic coding, que nous verrons ensuite.

##==##

<!-- .slide: -->

<img src="assets/images/20_module_2/vibe-coding-workflow.svg" alt="Vibe Coding Workflow showing linear flow from developer prompt to AI generation to production without review" style="width:100%; height:auto; display:block;">

Notes:
Ce schéma illustre le **flux linéaire dangereux** du vibe coding. Remarquez comment le code avance en ligne droite du prompt du développeur jusqu'à la production, sans aucune boucle de retour ni point de contrôle.

**Le workflow montre** : le développeur écrit un prompt → l'IA génère du code → le code part directement en production. Aucune étape de revue, aucune phase de test, aucun point de validation. Le développeur agit comme un simple relais passif, pas comme un participant actif.

**Danger clé** : ce workflow crée un faux sentiment de productivité. Le code apparaît vite, mais sans revue, les bugs, les failles de sécurité et les problèmes de maintenabilité passent inaperçus. À comparer avec le workflow de l'agentic coding vu juste après, qui inclut des cycles de revue itératifs.

##==##

<!-- .slide: -->

# **Limites clés du vibe coding**

## **Ce que vous perdez**

<br><br>

### **1. Manque de visibilité**

Vous ne comprenez pas comment le code fonctionne ni pourquoi les décisions ont été prises

### **2. Débogage difficile**

Quand un bug survient, vous ne pouvez pas le corriger car vous ne comprenez pas l'implémentation

### **3. Perte de contrôle**

Vous subissez les suggestions de l'IA sans pouvoir évaluer leur qualité ni leur exactitude

Notes:
Ces limites s'accumulent avec le temps. Plus vous acceptez de code sans le relire, moins vous comprenez votre propre base de code. Cela crée une dette technique coûteuse à rembourser plus tard. Les développeurs juniors sont particulièrement exposés, car ils n'ont pas encore l'expérience nécessaire pour repérer ces problèmes.

##==##

<img src="assets/images/20_module_2/production-failures-diagram.svg" alt="Three production failures from vibe coding: performance collapse, security bug, and maintainability crisis with impacts and common patterns" style="width:100%; height:auto; display:block;">

Notes:
Ces trois incidents de production proviennent de cas réels documentés dans l'industrie. Ils partagent le même schéma : le code semblait fonctionner aux premiers tests, le développeur ne l'a pas relu, les problèmes ont surgi en production, et la correction a coûté cher parce que personne ne comprenait le code. Source : https://addyo.substack.com/p/vibe-coding-is-not-the-same-as-ai

##==##

<!-- .slide: -->

# **Quand NE PAS faire de vibe coding**

## **Contextes à haut risque**

<br>

### **❌ Systèmes en production**

Code qui sert de vrais utilisateurs ou traite de vraies données

### **❌ Code sensible pour la sécurité**

<!-- .element: class="sm-padding-top"-->

Authentification, autorisation, chiffrement, protection des données

### **❌ Applications financières**

<!-- .element: class="sm-padding-top"-->

Paiement, comptabilité, calculs financiers

### **❌ Systèmes médicaux ou critiques**

<!-- .element: class="sm-padding-top"-->

Tout domaine où un bug peut nuire à des personnes ou enfreindre une réglementation

Notes:
Ces contextes ont un point commun : le coût de l'échec est élevé. Un bug en production impacte les utilisateurs. Une faille de sécurité expose les données. Une erreur financière fait perdre de l'argent. Un bug dans un système critique met des vies en danger. Dans ces contextes, le vibe coding n'est jamais approprié, quel que soit le niveau d'expérience. Même les développeurs seniors doivent appliquer des processus d'agentic coding formels, avec revue de code, tests et quality gates. Le temps investi en revue est une assurance contre les défaillances catastrophiques.

##==##

<!-- .slide: -->

# **Quand le vibe coding est-il approprié ?**

## **Cas d'usage légitimes**

<br>

### **✓ Prototypage et exploration**

Preuve de concept rapide où la qualité du code importe peu

### **✓ Hackathons et démos**

Événements limités dans le temps, centrés sur les idées, pas sur le code de production

### **✓ Scripts jetables et changements ciblés**

Automatisation jetable qui ne sera pas maintenue, ou refactoring précis dont vous maîtrisez pleinement le contexte et l'impact

### **✓ Outils internes (avec supervision)**

Utilitaires internes à faible risque dont les pannes n'impactent pas les clients

Notes:
Le vibe coding n'est pas toujours une erreur : le contexte compte. Ces scénarios partagent les mêmes caractéristiques : risque faible, durée de vie courte, aucune charge de maintenance et périmètre limité. L'essentiel est de savoir si vous êtes dans un contexte sûr ou dans un contexte de production. Nous approfondirons ce point en abordant les niveaux d'expérience.

##==##

<!-- .slide: class="exercice" -->

# Exercice 1 : atelier Photo Gallery

## Lab 21

<br>

### 👉 Suivez les **instructions** dans

### <code data-markdown-preview="/labs/lab-21-photo-gallery-workshop/README.md">labs/lab-21-photo-gallery-workshop/README.md</code>

Notes:
**Durée** : 30 à 40 minutes pour l'atelier complet.

**Mise en place** (2 min) : vérifier que les participants ont installé Cursor IDE et accèdent au dossier du lab. En cas de problème d'installation, ils peuvent se mettre en binôme avec un voisin.

**Points clés à souligner** :

- Ce lab met en pratique le vibe coding dans un cadre contrôlé : les participants vont volontairement accepter les suggestions de l'IA sans revue approfondie
- Demander aux participants de noter ce que l'IA génère et s'ils comprennent chaque ligne
- Leur rappeler qu'il s'agit d'un contexte d'apprentissage sûr : l'objectif est de vivre le workflow du vibe coding de l'intérieur

**Dépannage** : si Cursor ne fonctionne pas, les participants peuvent utiliser n'importe quel assistant de code IA (GitHub Copilot, Claude) pour faire l'exercice.

##==##

<!-- .slide: class="exercice" -->

# Exercice 1 : atelier Photo Gallery

## Lab 21

<br>

### 💡 Lisez la **solution** dans

### <code data-markdown-preview="/labs/lab-21-photo-gallery-workshop-solution/README.md">labs/lab-21-photo-gallery-workshop-solution/README.md</code>

Notes:
**Durée** : 5 à 10 minutes pour la revue de la solution et la discussion.

**Questions de discussion** :

- Demander : « Quelle part du code généré aviez-vous vraiment comprise avant de l'accepter ? »
- Demander : « Certains ont-ils repéré des problèmes potentiels qu'ils ont acceptés quand même ? »
- Demander : « Seriez-vous à l'aise de déployer ça en production tel quel ? »

**À retenir** : le dossier solution montre à quoi ressemble une implémentation complète et relue. Comparez-la à la version vibe-codée pour mettre en évidence les manques en gestion d'erreurs, cas limites ou documentation que les participants ont pu laisser passer.

**Transition** : utilisez cette discussion pour enchaîner sur la section suivante consacrée à l'agentic coding : « Voyons maintenant comment l'approche agentique répond à ces préoccupations. »
