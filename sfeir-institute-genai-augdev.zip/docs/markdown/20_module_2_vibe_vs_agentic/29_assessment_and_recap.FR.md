<!-- .slide: class="transition" -->

# Module 2 : évaluation et bilan

## Valider vos acquis

Notes:
Cette évaluation valide votre compréhension des concepts vibe coding vs agentic coding via des questions de contrôle et une réflexion. Elle consolide les apprentissages clés et vérifie que vous pouvez appliquer ces principes à des situations réelles de développement.

##==##

<!-- .slide: -->

# **Retour sur les objectifs**

## **Ce que vous avez appris**

<br>

### **Compétences clés acquises**

- **Comprendre** la différence fondamentale entre vibe coding (acceptation passive de l'IA) et agentic coding (contrôle humain actif)
- **Identifier** les limites et dangers majeurs de l'acceptation passive du code IA via des exemples d'incidents en production
- **Distinguer** les cas adaptés (prototypage, hackathons) des cas inadaptés (systèmes de production, code sensible en sécurité) au vibe coding
- **Expliquer** comment le modèle du développeur augmenté préserve la qualité du code par la collaboration et la revue continues
- **Appliquer** les principes de collaboration continue à des situations réelles grâce à la pratique

Notes:
Vous avez terminé un module complet couvrant à la fois les concepts théoriques et la pratique. Vous êtes désormais en mesure de décider en connaissance de cause quand et comment utiliser les assistants de code IA en sécurité. L'atelier pratique photo gallery a fourni l'expérience concrète qui ancre ces concepts abstraits dans la réalité. Notez que ce module s'est concentré sur deux sections centrales : les fondamentaux du vibe coding (définition, dangers, cas d'usage adaptés) et le paradigme agentic coding (modèle du développeur augmenté, impacts sur la qualité).

##==##

<!-- .slide: -->

# **Quiz de contrôle**

## **Question 1 :**

<br>

### Un développeur accepte toutes les suggestions de code générées par l'IA sans les relire ni comprendre la logique. C'est un exemple de :

**A)** Vibe coding (approche par acceptation passive)

**B)** Agentic coding où le développeur garde le contrôle

**C)** Modèle du développeur augmenté en collaboration continue

**D)** Développement traditionnel sans assistance IA

<br>

<details>
<summary>Réponse</summary>
<strong>A</strong> - Le vibe coding se définit comme l'acceptation passive des suggestions de l'IA, sans revue ni compréhension du code. La caractéristique clé : le développeur agit en observateur plutôt qu'en participant actif.
</details>

Notes:
Cette question teste la définition fondamentale du vibe coding et sa distinction avec les approches plus sûres. Comprendre cette définition est essentiel car elle sous-tend tous les autres concepts du module.

- L'option B est incorrecte car l'agentic coding exige que le développeur garde le contrôle par une revue active.
- L'option C est incorrecte car le modèle du développeur augmenté exige un engagement et une revue humains actifs.
- L'option D est incorrecte car ce scénario implique explicitement des suggestions générées par l'IA.

##==##

<!-- .slide: -->

# **Quiz de contrôle**

## **Question 2 : analyse du risque**

<br>

### Votre équipe construit un système d'authentification pour une application web en production. Un développeur veut générer le code d'authentification avec l'IA sans le relire. Quelle est la bonne réponse ?

_(Indice 💡 : rappelez-vous l'incident en production avec la logique d'authentification inversée)_

**A)** Autoriser - l'IA génère bien le code d'authentification

**B)** Autoriser seulement si le développeur maîtrise l'authentification

**C)** Autoriser pour le prototype, mais pas pour la production

**D)** Refuser - l'authentification est sensible en sécurité et exige une revue approfondie

<br>

<details>
<summary>Réponse</summary>
<strong>D</strong> - Le code d'authentification est sensible en sécurité et ne doit JAMAIS être généré sans revue approfondie, quel que soit le niveau d'expérience ou le contexte.
</details>

Notes:
Cette question teste la capacité à appliquer les concepts du vibe coding à des situations réelles et à décider en fonction du risque. Le code sensible en sécurité est l'un des cas les plus nets de « jamais de vibe coding ».

- L'option A est dangereuse car même si l'IA peut générer du code d'authentification plausible, les failles de sécurité (comme la logique inversée vue dans les incidents en production) peuvent être subtiles et catastrophiques.
- L'option B est incorrecte car même les développeurs expérimentés doivent relire le code sensible en sécurité.
- L'option C est partiellement correcte mais trompeuse : même un prototype manipulant de vraies données utilisateur exige une revue de sécurité. Rappelez-vous l'incident en production où une logique d'authentification inversée (`if (!isAuthenticated)`) donnait accès à des utilisateurs non autorisés.

##==##

<!-- .slide: -->

# **Quiz de contrôle**

## **Question 3 : schémas de défaillance**

<br>

### D'après les incidents en production étudiés, qu'ont en commun les trois défaillances (effondrement des performances, bug d'authentification, crise de maintenabilité) ?

**A)** Toutes étaient dues à des hallucinations de l'IA

**B)** Toutes ont été détectées dès la mise en production

**C)** Toutes fonctionnaient aux tests initiaux mais ont échoué en conditions de production

**D)** Toutes auraient pu être évitées avec un autre outil d'IA

<br>

<details>
<summary>Réponse</summary>
<strong>C</strong> - Les trois incidents partagent le même schéma : ça marchait aux tests initiaux, puis ça a échoué en conditions de production. L'effondrement des performances marchait sur de petits jeux de données mais pas à l'échelle. Le bug d'authentification passait les tests de base mais la logique était inversée. La crise de maintenabilité a produit du code qui « marchait » mais impossible à déboguer ou à faire évoluer. C'est là le danger insidieux du vibe coding : le code semble fonctionner sur des tests limités, ce qui donne une fausse confiance, mais la production révèle les problèmes cachés.
</details>

Notes:
Cette question renforce l'enseignement essentiel : le danger du vibe coding réside dans la fausse confiance née de tests limités. Elle relie les trois exemples de défaillance pour mettre en évidence un schéma commun que les participants doivent savoir repérer.

- L'option A est incorrecte car il ne s'agissait pas d'hallucinations : l'IA a généré du code plausible avec des problèmes subtils.
- L'option B est incorrecte car certains problèmes ont mis du temps à apparaître (comme ceux de maintenabilité).
- L'option D est incorrecte car la cause racine était l'absence de revue de code, pas le choix de l'outil d'IA.

##==##

<!-- .slide: -->

# **Ressources**

## **Pour aller plus loin**

<br>

### **Documentation**

- [Article sur le vibe coding](https://addyo.substack.com/p/vibe-coding-is-not-the-same-as-ai) - Analyse d'origine du vibe coding vs agentic coding, avec exemples d'incidents en production

<br><br>

### **Corrigés des labs**

- Consultez `labs/lab-21-photo-gallery-workshop-solution/` pour l'implémentation complète de la photo gallery, avec notes d'architecture

Notes:
L'article sur le vibe coding apporte un contexte plus approfondi sur les incidents en production étudiés. Le corrigé du lab offre une implémentation de référence de la photo gallery, à comparer avec ce que les participants ont généré pendant l'atelier.
