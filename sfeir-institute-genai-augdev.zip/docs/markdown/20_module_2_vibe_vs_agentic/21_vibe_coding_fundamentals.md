<!-- .slide: class="transition" -->

# Module 2: Vibe Coding Fundamentals

## Understanding Passive AI Code Acceptance

Notes:
This section explores what vibe coding is, its limitations, and when it might be appropriate to use.

##==##

<!-- .slide: -->

# **What is Vibe Coding?**

## **Definition**

<br>

### **Vibe Coding**

Passive acceptance of AI-generated code suggestions without code review or understanding.

The developer acts as an **observer**, not an active participant in the development process.

Notes:
Vibe coding is a term that has emerged to describe a specific (and risky) way of working with AI coding assistants. The key characteristic is passivity - the developer generates code with AI but doesn't review, understand, or validate what the AI produces. This is fundamentally different from agentic coding, which we'll explore next.

##==##

<!-- .slide: -->

<img src="assets/images/20_module_2/vibe-coding-workflow.svg" alt="Vibe Coding Workflow showing linear flow from developer prompt to AI generation to production without review" style="width:100%; height:auto; display:block;">

Notes:
This diagram illustrates the **dangerous linear flow** of vibe coding. Notice how code moves in a straight line from the developer's prompt directly to production with no feedback loops or checkpoints.

**The workflow shows**: Developer writes a prompt → AI generates code → Code goes straight to production. There's no review step, no testing phase, no validation checkpoint. The developer acts as a passive conduit, not an active participant.

**Key danger**: This workflow creates a false sense of productivity. Code appears quickly, but without review, bugs, security vulnerabilities, and maintainability issues slip through undetected. Compare this to the agentic coding workflow we'll see next, which includes iterative review cycles.

##==##

<!-- .slide: -->

# **Key Limitations of Vibe Coding**

## **What You Lose**

<br><br>

### **1. Lack of Visibility**

You don't understand how the code works or why decisions were made

### **2. Difficulty Debugging**

When bugs occur, you can't fix them because you don't understand the implementation

### **3. Loss of Control**

You're at the mercy of AI suggestions without ability to evaluate quality or correctness

Notes:
These limitations compound over time. The more code you accept without review, the less you understand your own codebase. This creates technical debt that becomes expensive to fix later. Junior developers are particularly vulnerable because they don't yet have the experience to recognize these problems.

##==##

<img src="assets/images/20_module_2/production-failures-diagram.svg" alt="Three production failures from vibe coding: performance collapse, security bug, and maintainability crisis with impacts and common patterns" style="width:100%; height:auto; display:block;">

Notes:
These three production failures come from real incidents documented in the industry. They share a common pattern: code appeared to work in initial testing, the developer didn't review it, issues surfaced in production, and the fix was costly because no one understood the code. Source: https://addyo.substack.com/p/vibe-coding-is-not-the-same-as-ai

##==##

<!-- .slide: -->

# **When NOT to Use Vibe Coding**

## **High-Risk Contexts**

<br>

### **❌ Production Systems**

Code that serves real users or processes real data

### **❌ Security-Sensitive Code**

<!-- .element: class="sm-padding-top"-->

Authentication, authorization, encryption, data protection

### **❌ Financial Applications**

<!-- .element: class="sm-padding-top"-->

Payment processing, accounting, financial calculations

### **❌ Medical/Safety-Critical Systems**

<!-- .element: class="sm-padding-top"-->

Anything where bugs could harm people or violate regulations

Notes:
These contexts have one thing in common: the cost of failure is high. Production bugs impact users. Security vulnerabilities expose data. Financial errors lose money. Safety-critical bugs endanger lives. In these contexts, vibe coding is never appropriate regardless of experience level. Even senior developers should use formal agentic coding processes with code review, testing, and quality gates. The time invested in review is insurance against catastrophic failures.

##==##

<!-- .slide: -->

# **When is Vibe Coding Appropriate?**

## **Legitimate Use Cases**

<br>

### **✓ Prototyping and Exploration**

Quick proof-of-concept work where code quality doesn't matter

### **✓ Hackathons and Demos**

Time-limited events focused on ideas, not production code

### **✓ One-Off Scripts and Targeted Changes**

Throwaway automation that won't be maintained, or specific refactoring where you fully understand the context and impact

### **✓ Internal Tools (with supervision)**

Low-risk internal utilities where failures don't impact customers

Notes:
Vibe coding isn't always wrong - context matters. These scenarios share common characteristics: low risk, short lifespan, no maintenance burden, and limited scope. The key is knowing when you're in a safe context vs. a production context. We'll explore this further when discussing experience levels.

##==##

<!-- .slide: class="exercice" -->

# Exercise 1: Photo Gallery Workshop

## Lab 21

<br>

### 👉 Follow **instructions** in

### <code data-markdown-preview="/labs/lab-21-photo-gallery-workshop/README.md">labs/lab-21-photo-gallery-workshop/README.md</code>

Notes:
**Duration**: 30-40 minutes for the full workshop.

**Setup** (2 min): Ensure participants have Cursor IDE installed and can access the lab folder. If anyone has installation issues, they can pair with a neighbor.

**Key points to emphasize**:

- This lab demonstrates vibe coding in a controlled environment - participants will intentionally accept AI suggestions without thorough review
- Ask participants to note what the AI generates and whether they understand every line
- Remind them this is a safe learning context - the goal is to experience vibe coding's workflow firsthand

**Troubleshooting**: If Cursor isn't working, participants can use any AI coding assistant (GitHub Copilot, Claude) to complete the exercise.

##==##

<!-- .slide: class="exercice" -->

# Exercise 1: Photo Gallery Workshop

## Lab 21

<br>

### 💡 Read **solution** at

### <code data-markdown-preview="/labs/lab-21-photo-gallery-workshop-solution/README.md">labs/lab-21-photo-gallery-workshop-solution/README.md</code>

Notes:
**Duration**: 5-10 minutes for solution review and discussion.

**Discussion prompts**:

- Ask: "How much of the generated code did you fully understand before accepting it?"
- Ask: "Did anyone notice potential issues that they accepted anyway?"
- Ask: "How would you feel deploying this to production as-is?"

**Key takeaway**: The solution folder shows what a complete, reviewed implementation looks like. Compare the vibe-coded version to highlight gaps in error handling, edge cases, or documentation that participants may have missed.

**Transition**: Use this discussion to bridge into the next section on agentic coding - "Now let's see how the agentic approach addresses these concerns."
