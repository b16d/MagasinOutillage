<!-- .slide: class="transition" -->

# Module 2 Overview

## Vibe Coding vs Agentic Coding

Notes:
This module explores the critical distinction between vibe coding (passive acceptance of AI suggestions) and agentic coding (augmented developer with continuous collaboration). Understanding this difference is essential for safe and effective AI-augmented development in production environments.

##==##

<!-- .slide: -->

# **Learning Objectives**

By the end of this module, you will be able to:

- **Understand** the fundamental difference between vibe coding and agentic coding
- **Identify** the key limitations and dangers of passive AI code acceptance
- **Distinguish** between appropriate and inappropriate use cases for vibe coding
- **Explain** how the augmented developer model maintains code quality and control
- **Apply** continuous collaboration principles in agentic coding workflows

Notes:
These objectives align with the course goal of building awareness about safe AI-augmented development practices. Each objective is testable through discussion, reflection exercises, and hands-on practice in the photo gallery workshop.

##==##

<!-- .slide: -->

# **Prerequisites**

## **What You Need to Know**

<br>

### **From Module 1**

- Basic understanding of AI-augmented development tools
- Familiarity with development workflows and code review practices

<br><br>

### **Technical Requirements**

- Basic programming knowledge (any language)
- A Web browser (for testing the lab's web application)

Notes:
Verify that all participants have completed Module 1 and understand foundational AI development concepts. For the hands-on lab, ensure participants can install software on their machines. Technical requirements are intentionally lightweight to maximize accessibility across experience levels.
