<!-- .slide: class="transition" -->

# Module 2 : Paradigme Agentic Coding

## Le modèle du développeur augmenté

Notes:
Cette section présente l'approche agentic coding et explore comment la collaboration continue humain-IA préserve la qualité du code et le contrôle.

##==##

<!-- .slide: -->

# **Le développeur augmenté**

## **Nouvelle vision du développement avec l'IA**

<br><br>

### **Le modèle du développeur augmenté**

Intelligence humaine + capacités IA = **Productivité accrue** avec contrôle maintenu

Le développeur reste **architecte, décideur et garant de la qualité**. L'IA est un **assistant puissant, pas un remplaçant**.

Notes:
Le modèle du développeur augmenté représente un changement fondamental dans notre façon de penser les outils d'IA. Plutôt que de remplacer les développeurs humains ou de leur faire accepter passivement la sortie de l'IA, on crée un partenariat où chaque partie apporte ses forces. L'humain apporte le jugement, l'expérience, la connaissance du domaine et les standards de qualité. L'IA apporte la vitesse, la reconnaissance de motifs et une assistance infatigable sur les tâches répétitives. C'est le socle de l'agentic coding.

##==##

<!-- .slide: -->

# **L'Agentic Coding, c'est quoi ?**

## **Définition**

<br><br>

### **Agentic Coding**

Une approche systématique et centrée sur la qualité du développement augmenté par l'IA, où le développeur garde le contrôle stratégique, relit toutes les suggestions et assume la qualité du code, tout en utilisant l'IA comme collaborateur intelligent.

Le développeur est un **agent actif** qui dirige, évalue et affine l'assistance de l'IA.

Notes:
Le terme « agentic » met l'accent sur l'agentivité du développeur : il détient le pouvoir, le contrôle et la responsabilité. Contrairement à l'observation passive du vibe coding, l'agentic coding exige un engagement continu. Vous relisez chaque suggestion, comprenez chaque ligne de code, testez en profondeur et itérez si besoin. C'est plus de travail que le vibe coding, mais c'est la seule approche qui produit du code de qualité production. Le module 3 étendra cette définition avec un workflow structuré en 5 phases (Specify → Plan → Tasks → Implement → Validate) qui rend l'agentic coding reproductible et scalable.

##==##

<!-- .slide: -->

<img src="assets/images/20_module_2/agentic-coding-workflow.svg" alt="Workflow Agentic Coding montrant le cycle itératif proposer, relire, tester, affiner avec le développeur au centre qui garde le contrôle" style="width:100%; height:auto; display:block;">

Notes:
Ce diagramme illustre le **cycle de collaboration continu de l'agentic coding**.

Le développeur est au **centre** et garde le contrôle tout au long du processus.

Le workflow suit une boucle itérative :

1. L'outil d'IA propose du code
2. Le développeur fait une Code Review : il examine la logique, vérifie les cas limites et contrôle la qualité
3. Les tests valident le comportement
4. Si des problèmes apparaissent, le développeur passe au Raffinement en itérant sur les prompts et en ajustant l'approche, ce qui renvoie vers l'outil d'IA.

Quand les tests passent et que la qualité est vérifiée, le code part en Production. Remarquez le cercle en pointillés autour de tout le processus : il représente la **frontière de sécurité** créée par la **supervision humaine**. Le développeur n'accepte jamais aveuglément les suggestions de l'IA ; il maintient au contraire une boucle active relire-tester-affiner jusqu'à ce que le code réponde à toutes les exigences.

##==##

<!-- .slide: -->

# **Impact sur la qualité du code**

## **Ce que la relecture détecte**

<br>

### **Avant le déploiement**

La relecture détecte bugs, cas limites et problèmes de qualité **avant** la production

<br><br>

### **Bénéfices clés**

- Détecter les erreurs de logique en relecture, pas en prod
- Repérer les cas limites que l'IA manque
- Respecter les standards qualité de l'équipe
- Valider les exigences sécurité et performance

Notes:
C'est la proposition de valeur première de l'agentic coding : l'assurance qualité par la relecture humaine. Quand vous relisez du code généré par l'IA, vous appliquez votre expérience et votre jugement pour attraper ce que l'IA ne peut pas voir. Vous comprenez le contexte métier, les exigences de sécurité, les contraintes de performance et les standards de code de l'équipe. L'IA, non. Votre relecture est la porte qualité qui évite les incidents en production.

##==##

<!-- .slide: -->

# **Impact sur la maintenabilité**

## **La relecture rend le code compréhensible**

<br><br>

### **Compréhension du code**

Relire le code, c'est comprendre son fonctionnement. Cela permet :

- **Débogage** : corriger les bugs rencontrés
- **Extension** : ajouter des fonctionnalités sans casser l'existant
- **Refactoring** : améliorer la qualité au fil du temps
- **Transfert de savoir** : expliquer le code à l'équipe

Notes:
La maintenabilité est le bénéfice de long terme de l'agentic coding. Quand vous relisez le code avant de l'accepter, vous construisez votre compréhension. Cette compréhension devient inestimable quand il faut modifier ou déboguer ce code des mois plus tard. À l'inverse, en vibe coding, le développeur d'origine est incapable d'expliquer comment le code fonctionne. La dette de maintenabilité s'accumule vite avec du code non relu et devient très coûteuse à rembourser.

##==##

<!-- .slide: -->

# **Impact sur la documentation**

## **Comment l'humain garantit que la doc suit le code**

<br>

### **L'écart de documentation**

L'IA génère de la documentation, mais seul l'humain vérifie qu'elle correspond au comportement réel

<br><br>

### **Responsabilité humaine**

- Vérifier l'exactitude de la doc face à l'implémentation
- Ajouter le contexte métier et les cas limites
- Documenter les choix non évidents et les compromis
- Garder la doc synchronisée avec le code

Notes:
La documentation est un domaine critique où la relecture humaine est irremplaçable. L'IA peut générer une documentation plausible, mais qui ne décrit pas forcément ce que le code fait réellement (surtout si le code a des bugs). Seul un humain qui comprend à la fois le code et les exigences métier peut garantir une documentation exacte, complète et utile. Cela fait partie de la responsabilité du développeur en agentic coding.

##==##

<!-- .slide -->

## Trois approches du développement logiciel en 2026

<img src="assets/images/20_module_2/traditional-vs-agentic.svg" alt="Comparaison traditionnel vs agentic" style="width:100%; height:auto; display:block;">

Notes:

- **Traditionnel** : manuel, lent, qualité variable.
- **Vibe** : rapide mais chaotique, dette technique. Agentic : workflow structuré, rapide + constant, le meilleur des deux mondes.
- **Agentic** : workflow structuré, rapide + constant, le meilleur des deux mondes.
