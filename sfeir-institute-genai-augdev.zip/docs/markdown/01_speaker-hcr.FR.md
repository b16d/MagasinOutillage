<!-- .slide: class="speaker-slide" -->
<div class="speaker-slide">

# Bonjour ! @SFEIR

## Hoani **Cross**

### IA Champion, Senior Architect & Engineering Manager

### cross.h@sfeir.com

![](./assets/images/logo-sfeir-blanc.png 'company')

![](./assets/images/speaker-hcr.jpeg 'speaker')

</div>

Notes:
Hoani Cross est IA Champion, Senior Architect & Engineering Manager chez SFEIR, spécialisé dans l'architecture backend, le développement augmenté par l'IA et les pratiques d'ingénierie avancées.
