<!-- .slide: class="first-slide" sfeir-level="2" sfeir-techno="AI" -->

# **Bienvenue à SFEIR Institute**

## **GenAI Augmented Developer**

Notes:
Bienvenue à la formation complète de SFEIR Institute sur le développement augmenté par la GenAI.
