<!-- .slide: class="speaker-slide" -->
<div class="speaker-slide">

# Bonjour ! @SFEIR

## Tine **Kondo**

### Senior Staff Engineer chez SFEIR Luxembourg

### kondo.t@sfeir.com

### @tinesoft

![](./assets/images/logo-sfeir-blanc.png 'company')

![](./assets/images/speaker-tko.jpg 'speaker')

</div>

Notes:
Tine Kondo apporte à cette formation plus de 14 ans d'expertise en ingénierie logicielle et en IA.
Senior Staff Engineer chez SFEIR Luxembourg, Nx champion et mainteneur OSS, il est spécialisé dans les workflows de développement augmentés par l'IA et travaille depuis le début à l'intégration des outils IA dans le développement logiciel professionnel.
