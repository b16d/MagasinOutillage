<!-- .slide: class="speaker-slide" -->
<div class="speaker-slide">

# Hello ! @SFEIR

## Guillaume **Homberg**

### Engineering Director & AI Champion at SFEIR Luxembourg

### homberg.g@sfeir.com

![](./assets/images/logo-sfeir-blanc.png 'company')

![](./assets/images/speaker-gho.jpg 'speaker')

</div>

Notes:
Guillaume Homberg is Engineering Director and AI Champion at SFEIR Luxembourg, specialized in AI-augmented development and engineering leadership.
