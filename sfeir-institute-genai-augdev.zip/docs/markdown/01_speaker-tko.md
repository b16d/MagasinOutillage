<!-- .slide: class="speaker-slide" -->
<div class="speaker-slide">

# Hello ! @SFEIR

## Tine **Kondo**

### Senior Staff Engineer at SFEIR Luxembourg

### kondo.t@sfeir.com

### @tinesoft

![](./assets/images/logo-sfeir-blanc.png 'company')

![](./assets/images/speaker-tko.jpg 'speaker')

</div>

Notes:
Tine Kondo brings 14+ years of software engineering and AI expertise to this training.
As a Senior Staff Engineer at SFEIR Luxembourg, Nx champion, OSS maintainer, he specializes in AI-enhanced development workflows and has been at the forefront of integrating AI tools into professional software development.
