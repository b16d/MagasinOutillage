<!-- .slide: class="transition" -->

# Model Context Protocol

## Comprendre l'architecture MCP

##==##

<!-- .slide: -->

# **Qu'est-ce que MCP ?**

<br>

### **Model Context Protocol (MCP)**

Un **protocole ouvert** qui standardise la connexion des applications d'IA aux sources de données et outils externes.

<br>

### **Bénéfices clés**

- 🔌 **Connectivité universelle** : un protocole, de multiples intégrations
- 🔄 **Communication bidirectionnelle** : l'IA peut lire et agir
- 🛡️ **Sécurisé par conception** : permissions de capacités explicites
- 🧩 **Composable** : combinez les serveurs selon votre workflow

Notes:
MCP a été développé par Anthropic et publié comme standard ouvert. Voyez-le comme l'USB des assistants IA : une interface universelle qui permet à n'importe quel host compatible de se connecter à n'importe quel serveur compatible, sans code d'intégration spécifique.

##==##

<!-- .slide: -->

<img src="assets/images/50_module_5/mcp-architecture.svg" alt="Schéma d'architecture MCP montrant un Host contenant plusieurs Clients, chacun connecté à un Server (Playwright, Filesystem, GitHub) qui fournit des Tools, Resources et Prompts" style="width:100%; height:auto; display:block;">

Notes:
L'architecture suit un modèle client-serveur. Chaque client se connecte à exactement un serveur. Les serveurs exposent trois types de capacités : les **Tools** (fonctions appelables qui réalisent des actions comme « prendre une capture d'écran » ou « exécuter une requête »), les **Resources** (données en lecture seule accessibles à l'IA, comme des fichiers ou des enregistrements de base de données) et les **Prompts** (modèles d'instructions prêts à l'emploi pour les tâches courantes). Les serveurs MCP peuvent être locaux (exécutés sur votre machine avec accès aux ressources locales) ou distants (hébergés dans le cloud). Le protocole prend en charge deux modes de transport : **stdio** (par défaut, pour les serveurs locaux) et **Streamable HTTP** (recommandé pour les serveurs distants) ; l'ancien transport **HTTP+SSE** est désormais legacy/déprécié. La spécification MCP ratifiée actuelle est la **2025-11-25** ; la révision suivante, **2026-07-28**, est une release candidate (finalisation le 28 juillet 2026) qui introduit un cœur de protocole sans état, le framework **Extensions**, les **Tasks**, les **MCP Apps** et un durcissement de l'autorisation. Point clé : un Host (comme VS Code ou Claude) peut gérer plusieurs Clients, mais chaque Client se connecte à exactement un Server — cette relation 1:1 simplifie la gestion des connexions et des permissions.
