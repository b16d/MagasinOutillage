<!-- .slide: class="transition" -->

# Module 5: Assessment and Recap

##==##

<!-- .slide: -->

# **Learning Objectives Review**

<br>

### **What We Covered**

- ✅ **Explain MCP Architecture**: Hosts, clients, servers, and capabilities
- ✅ **Identify Use Cases**: Where MCP improves development workflows
- ✅ **Install MCP Servers**: Configure Playwright MCP for AI Agents
- ✅ **Use AI Agents with MCP**: Agent Mode with MCP tools
- ✅ **Apply Playwright MCP**: Visual testing and accessibility auditing

**Skills Practiced**: Lab 51 - MCP configuration, visual regression, A11y auditing

<!-- .element: class="sm-padding-top" -->

##==##

<!-- .slide: -->

# **Knowledge Check**

## **Question 1: MCP Architecture**

<br>

### What is the relationship between Host, Client, and Server in MCP?

**A)** Host contains Clients, each Client connects to one Server  
**B)** Host connects directly to multiple Servers  
**C)** Server manages Clients and Host  
**D)** Client contains multiple Hosts and Servers

<details>
<summary>Answer</summary>
<strong>A) Host contains Clients, each Client connects to one Server</strong> - The Host application (VS Code, Claude) manages multiple Clients, and each Client maintains a 1:1 connection with a specific Server.
</details>

Notes:
Understanding this hierarchy is essential for troubleshooting MCP connections and configuring multiple servers.

##==##

<!-- .slide: -->

# **Knowledge Check**

## **Question 2: MCP Capabilities**

<br>

### Which MCP capability allows AI to execute actions like "take a screenshot"?

**A)** Resources  
**B)** Prompts  
**C)** Transports  
**D)** Tools

<details>
<summary>Answer</summary>
<strong>D) Tools</strong> - Tools are executable functions that AI can invoke to perform actions. Resources are read-only data, Prompts are instruction templates, and Transports handle communication protocols.
</details>

Notes:
Distinguishing between Tools (actions), Resources (data), and Prompts (templates) helps developers choose the right capability when building or using MCP servers.

##==##

<!-- .slide: -->

# **Knowledge Check**

## **Question 3: MCP Server Deployment**

<br>

### Which type of MCP server deployment is most appropriate when the server needs to be shared across multiple developers on different machines?

**A)** Local server via stdio  
**B)** Remote server via HTTP  
**C)** Local server via SSE  
**D)** Remote server via gRPC

<details>
<summary>Answer</summary>
<strong>B) Remote server via HTTP</strong> - Remote MCP servers exposed over HTTP are accessible over the network and can be shared across multiple clients and machines. Local stdio servers run as a subprocess on the developer's own machine and are not network-accessible.
</details>

Notes:
MCP supports two main deployment models: local servers (launched via a CLI command, communicating over stdio — simple, secure, no network exposure) and remote servers (hosted on a URL, communicating over HTTP — shareable across teams and accessible from any machine). SSE is a deprecated transport and gRPC is not part of the MCP specification.

##==##

<!-- .slide: -->

# **Knowledge Check**

## **Question 4: MCP Transport Protocols**

<br>

### Which MCP transport is typically used when running a local MCP server started via a CLI command like `npx @playwright/mcp`?

**A)** HTTP + SSE (Server-Sent Events)  
**B)** WebSocket  
**C)** stdio (Standard Input/Output)  
**D)** gRPC

<details>
<summary>Answer</summary>
<strong>C) stdio (Standard Input/Output)</strong> - Local MCP servers launched via CLI commands communicate over stdio, where the MCP client spawns the server process and communicates through standard input/output streams. Streamable HTTP is used for remote or long-running servers accessible via URL (HTTP+SSE is the legacy transport).
</details>

Notes:
stdio is the most common transport for local development tools — it's simple, secure (no network exposure), and works out of the box with CLI-based servers. Streamable HTTP is preferred when the server needs to be shared across multiple clients or accessed remotely (HTTP+SSE is the legacy transport).

##==##

<!-- .slide: -->

# **Resources**

<br>

### **Documentation**

- **MCP**: [Spec](https://modelcontextprotocol.io/specification) | [Server Registry](https://github.com/modelcontextprotocol/servers) | [Playwright MCP](https://github.com/microsoft/playwright-mcp)

<br><br>

### **Lab Solution**

- `labs/lab-51-mcp-playground-solution/`

Notes:
Use the lab solution for complete MCP configuration examples, accessibility audit outputs, and generated E2E tests.
