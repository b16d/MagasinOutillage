<!-- .slide: class="transition" -->

# Module 5 : Serveurs MCP

## Étendre les assistants IA avec MCP

Notes:
Bienvenue dans le Module 5 ! Ce module explore le Model Context Protocol (MCP) et l'usage des serveurs MCP pour étendre les assistants de code IA au-delà de leurs capacités par défaut. Nous verrons les concepts MCP, l'architecture, des cas d'usage concrets, l'installation pour plusieurs clients IA, et un lab pratique avec Playwright MCP. Durée : 1h30 (45 min de slides + 45 min de lab).

##==##

<!-- .slide: -->

# **Objectifs pédagogiques**

<br>

### **À la fin de ce module, vous saurez :**

- **Expliquer** l'architecture du Model Context Protocol et ses composants
- **Installer** et configurer des serveurs MCP pour des agents IA
- **Appliquer** Playwright MCP aux tests de régression visuelle et à l'audit d'accessibilité

Notes:
Ces objectifs pédagogiques sont mesurables : vous démontrerez votre compréhension par la pratique, avec l'installation de MCP et un lab utilisant Playwright MCP pour les tests visuels et les audits d'accessibilité.

##==##

<!-- .slide: -->

# **Prérequis**

<br>

### **Des modules précédents**

- Compréhension des assistants de code IA et de leurs capacités
- Expérience des workflows de codage agentique
- Maîtrise des bases de Claude Code (Module 4)

<br><br>

### **Prérequis techniques**

- **Assistant de code IA** : avec support MCP
- **IDE** : VS Code ou l'IDE de votre choix
- **Runtime** : Node.js v22+ installé en local
- **Paquet MCP** : @playwright/mcp (installé pendant le lab)

Notes:
Ce module s'appuie sur les fondamentaux de Claude Code du Module 4. Vous étendrez vos connaissances avec les commandes personnalisées, les subagents et les intégrations MCP.
