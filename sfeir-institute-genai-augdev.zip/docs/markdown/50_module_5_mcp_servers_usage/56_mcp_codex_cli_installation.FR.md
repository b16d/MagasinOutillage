<!-- .slide: class="with-code" -->

# **Installer un serveur MCP**

```bash
codex mcp add [OPTIONS] <NAME> (--url <URL> | -- <COMMAND>...)
```

| Commande                  | Description                       |
| ------------------------- | --------------------------------- |
| `codex mcp --help`        | Afficher l'aide MCP               |
| `codex mcp list`          | Lister les serveurs               |
| `codex mcp remove <name>` | Supprimer un serveur              |
| `/mcp`                    | Dans le TUI : serveurs MCP actifs |

Notes:
Codex CLI stocke la configuration MCP dans `~/.codex/config.toml` par défaut, ou `.codex/config.toml` pour une portée projet.
Le Codex CLI et l'extension IDE partagent cette config : une seule installation suffit pour les deux.
