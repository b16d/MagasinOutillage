<!-- .slide: class="with-code" -->

# **Installing a MCP Server**

1. Enter copilot, by running `copilot` in your terminal
2. Type `/mcp add` then <kbd>ENTER</kbd>
3. Fill in the details to add the MCP server you want
   - **Server Name:** Enter a name , e.g. `playwright`
   - **Server Type:** `stdio`, `http`, or `sse`
   - **Command:** `npx [package]`, `pipx [package]`, `docker [args]`, etc.

> The MCP configuration will be stored in `~/.copilot/mcp-config.json` folder.

![](https://docs.github.com/en/copilot/how-tos/provide-context/use-mcp/extend-copilot-chat-with-mcp 'tc-qrcode h-200')

<!-- .element: class="center" -->

<br>

Notes:
GitHub Copilot supports MCP in both CLI and IDE modes. **CLI method**: Interactive wizard via `/mcp add` - configuration stored in `~/.copilot/mcp-config.json`. **IDE method (VS Code)**: Use Command Palette (Ctrl+Shift+P) → "MCP: Add Server". Key difference from Claude Code: Copilot uses `global` (all projects), `remote` (cloud-hosted), or `workspace` (project-specific) scopes. The QR code links to official GitHub docs with detailed setup instructions and troubleshooting tips.

##==##

<!-- .slide: class="with-code" -->

# **Installing a MCP Server**

Installation depends on your IDE. For example, for **GitHub Copilot for VS Code**:

<!-- .element: class="sm-padding-top" -->

1. Press <kbd>CTRL-SHIFT-P</kbd>
2. Type "mcp" to filter and select `MCP: Add Server`
3. Follow the guide to add the MCP server you want
   _ **Server Type:** `stdio`, `http`, or `sse`
   _ **Command:** `npx [package]`, `pipx [package]`, `docker [image]`, etc.
   _ **Server Name:** Enter a name , e.g. `playwright`
   _ **MCP Location/Availability:** `global`, `remote`, or `workspace`

Notes:
GitHub Copilot supports MCP in both CLI and IDE modes. **CLI method**: Interactive wizard via `/mcp add` - configuration stored in `~/.copilot/mcp-config.json`. **IDE method (VS Code)**: Use Command Palette (Ctrl+Shift+P) → "MCP: Add Server". Key difference from Claude Code: Copilot uses `global` (all projects), `remote` (cloud-hosted), or `workspace` (project-specific) scopes. The QR code links to official GitHub docs with detailed setup instructions and troubleshooting tips.
