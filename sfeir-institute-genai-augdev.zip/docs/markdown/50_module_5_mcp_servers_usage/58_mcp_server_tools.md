<!-- .slide: -->

# **MCP Server Tools**

Once you have installed a MCP server, you can access the **tools** it provides in your prompts.
You can invoke them either by name or let the AI choose the appropriate tool based on your request.

Here are some of the available tools in the **Playwright MCP server**:

| Category        | Tools                                                                            |
| --------------- | -------------------------------------------------------------------------------- |
| **Navigation**  | `browser_navigate`, `browser_navigate_back`, `browser_wait_for`                  |
| **Capture**     | `browser_screenshot`, `browser_snapshot`, `browser_console_messages`             |
| **Interaction** | `browser_click`, `browser_type`, `browser_fill`, `browser_hover`, `browser_drag` |
| **Forms**       | `browser_select_option`, `browser_file_upload`, `browser_handle_dialog`          |

<!-- .element: class="sm-padding-top" -->

<!-- | **Verification** | `browser_verify_text_visible`, `browser_verify_element_visible`, `browser_verify_value` | -->
<!-- | **Debug** | `browser_evaluate`, `browser_network_requests`, `browser_generate_locator` | -->

<br>

📖 **Documentation**: [github.com/microsoft/playwright-mcp](https://github.com/microsoft/playwright-mcp)

Notes:
Playwright MCP uses accessibility snapshots instead of screenshots for element identification. This makes interactions more reliable and accessible. Works with both Claude Code and GitHub Copilot.

##==##

<!-- .slide: class="exercice" -->

# Exercise: MCP Playground

## Lab 51

<br>

### 👉 Follow **instructions** in

### <code data-markdown-preview="/labs/lab-51-mcp-playground/README.md">labs/lab-51-mcp-playground/README.md</code>

Notes:

- Configure Playwright MCP for your AI Agent
- Use MCP tools for visual regression testing
- Perform accessibility audits with AI assistance
- Expected time: 40-45 minutes

##==##

<!-- .slide: class="exercice" -->

# Exercise: MCP Playground

## Lab 51

<br>

### 💡 Read **solution** at

### <code data-markdown-preview="/labs/lab-51-mcp-playground-solution/README.md">labs/lab-51-mcp-playground-solution/README.md</code>

Notes:

- Read the lab README.md for MCP configuration examples and accessibility audit outputs
