<!-- .slide: class="with-code" -->

# **Installing a MCP Server**

```json
// opencode.json
{
  "$schema": "https://opencode.ai/config.json",
  "mcp": {
    "my-tool": {
      "type": "local",
      "command": ["node", "tools/my-mcp-server.js"]
    }
  }
}
```

<br>

| Setting   | Description                             |
| --------- | --------------------------------------- |
| `type`    | `local` (subprocess) or `remote` (HTTP) |
| `command` | Command array for local servers         |
| `url`     | URL for remote HTTP servers             |

Notes:
OpenCode configures MCP servers in `opencode.json` (JSONC supported) under the `mcp` key — no CLI add command.

It supports two **transport types**:

- `local` (subprocess via `command` array) — for local MCP servers with access to local resources
- `remote` (HTTP via `url`) — for remote MCP servers

**Scope**: `opencode.json` at project root (shared with team) or `~/.config/opencode/opencode.json` (user-level).

Skill-embedded MCP: Skills can declare their own MCP servers inline in frontmatter — zero manual config required.

Once configured, MCP tools are automatically available to the model alongside built-in tools.

📚 **Documentation**: https://opencode.ai/docs/mcp-servers/
