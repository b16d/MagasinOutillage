<!-- .slide: class="with-code" -->

# **Installer un serveur MCP**

1. Lancez copilot en exécutant `copilot` dans votre terminal
2. Tapez `/mcp add` puis <kbd>ENTER</kbd>
3. Renseignez les informations du serveur MCP à ajouter
   - **Nom du serveur :** saisissez un nom, ex. `playwright`
   - **Type de serveur :** `stdio`, `http` ou `sse`
   - **Commande :** `npx [package]`, `pipx [package]`, `docker [args]`, etc.

> La configuration MCP sera stockée dans `~/.copilot/mcp-config.json`.

![](https://docs.github.com/en/copilot/how-tos/provide-context/use-mcp/extend-copilot-chat-with-mcp 'tc-qrcode h-200')

<!-- .element: class="center" -->

<br>

Notes:
GitHub Copilot prend en charge MCP en mode CLI comme en mode IDE. **Méthode CLI** : assistant interactif via `/mcp add` — configuration stockée dans `~/.copilot/mcp-config.json`. **Méthode IDE (VS Code)** : utiliser la palette de commandes (Ctrl+Shift+P) → « MCP: Add Server ». Différence clé avec Claude Code : Copilot utilise les portées `global` (tous les projets), `remote` (hébergé dans le cloud) ou `workspace` (propre au projet). Le QR code renvoie à la documentation officielle GitHub, avec les instructions détaillées d'installation et des conseils de dépannage.

##==##

<!-- .slide: class="with-code" -->

# **Installer un serveur MCP**

L'installation dépend de votre IDE. Par exemple, pour **GitHub Copilot pour VS Code** :

<!-- .element: class="sm-padding-top" -->

1. Appuyez sur <kbd>CTRL-SHIFT-P</kbd>
2. Tapez « mcp » pour filtrer et sélectionnez `MCP: Add Server`
3. Suivez le guide pour ajouter le serveur MCP souhaité
   _ **Type de serveur :** `stdio`, `http` ou `sse`
   _ **Commande :** `npx [package]`, `pipx [package]`, `docker [image]`, etc.
   _ **Nom du serveur :** saisissez un nom, ex. `playwright`
   _ **Emplacement/Disponibilité MCP :** `global`, `remote` ou `workspace`

Notes:
GitHub Copilot prend en charge MCP en mode CLI comme en mode IDE. **Méthode CLI** : assistant interactif via `/mcp add` — configuration stockée dans `~/.copilot/mcp-config.json`. **Méthode IDE (VS Code)** : utiliser la palette de commandes (Ctrl+Shift+P) → « MCP: Add Server ». Différence clé avec Claude Code : Copilot utilise les portées `global` (tous les projets), `remote` (hébergé dans le cloud) ou `workspace` (propre au projet). Le QR code renvoie à la documentation officielle GitHub, avec les instructions détaillées d'installation et des conseils de dépannage.
