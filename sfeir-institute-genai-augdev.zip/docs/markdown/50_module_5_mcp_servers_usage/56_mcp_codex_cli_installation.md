<!-- .slide: class="with-code" -->

# **Installing a MCP Server**

```bash
codex mcp add [OPTIONS] <NAME> (--url <URL> | -- <COMMAND>...)
```

| Command                   | Description                     |
| ------------------------- | ------------------------------- |
| `codex mcp --help`        | Show MCP command help           |
| `codex mcp list`          | List servers                    |
| `codex mcp remove <name>` | Remove a server                 |
| `/mcp`                    | In TUI: View active MCP servers |

Notes:
Codex CLI stores MCP configuration in `~/.codex/config.toml` by default, or `.codex/config.toml` for project scope.
The Codex CLI and IDE extension share this config, so one setup works in both.
