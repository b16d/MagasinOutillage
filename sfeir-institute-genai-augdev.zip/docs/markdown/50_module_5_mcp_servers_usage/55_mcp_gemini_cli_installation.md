<!-- .slide: class="with-code" -->

# **Installing a MCP Server**

> ⚠️ **Gemini CLI was retired (May 2026)** — consumer access ended **June 18, 2026**. Its successor is the Go-based **Antigravity CLI** (unveiled at Google I/O 2026). The commands below are kept for reference; migrate MCP configs to Antigravity CLI.

<!-- .element: class="bbquote" -->

```bash
gemini mcp add [options] <name> <commandOrUrl> [args...]
```

| Command                    | Description                     |
| -------------------------- | ------------------------------- |
| `gemini mcp --help`        | Show MCP command help           |
| `gemini mcp list`          | List servers                    |
| `gemini mcp remove <name>` | Remove a server                 |
| `/mcp`                     | In TUI: View active MCP servers |

Notes:
Gemini CLI provides built-in MCP support with simple command syntax.
MCP configuration is stored in `settings.json`:

It supports **scopes**: `project` (default), `user` (global).

- **Project scope**(default): `.gemini/settings.json` - shared with team, project-specific
- **User scope** : `~/.gemini/settings.json` - applies to all projects

It supports **transport**:

- `stdio`, default, for local mcp servers with access to local resources
- `http`, Streamable HTTP — recommended transport type for remote mcp servers
- `sse`, HTTP+SSE — legacy/deprecated transport type for remote mcp servers

OAuth tokens for remote servers are stored in `~/.gemini/mcp-oauth-tokens.json`.
Server enablement state is tracked in `~/.gemini/mcp-server-enablement.json`.
Use `/mcp` within the Gemini CLI interactive mode to view and manage active servers.
