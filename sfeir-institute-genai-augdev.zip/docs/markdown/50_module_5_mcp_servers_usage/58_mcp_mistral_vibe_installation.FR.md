<!-- .slide: class="with-code" -->

# **Installer un serveur MCP**

```toml
# .vibe/config.toml
[mcp_servers.playwright]
command = "npx"
args = ["@playwright/mcp", "--browser=firefox", "--isolated"]

[mcp_servers.docs]
url = "https://example.com/mcp"
```

<br>

| Paramètre | Description                                     |
| --------- | ----------------------------------------------- |
| `command` | Exécutable d'un serveur MCP local (stdio)       |
| `args`    | Arguments passés à la commande du serveur local |
| `url`     | Endpoint d'un serveur MCP distant (HTTP)        |
| `env`     | Variables d'environnement optionnelles          |

Notes:
Mistral Vibe stocke sa configuration dans un fichier TOML `.vibe/config.toml`. Les serveurs MCP sont déclarés sous des tables `[mcp_servers.<name>]` — pas de commande add, on édite la config directement.

Il supporte deux **types de transport** :

- **Local (stdio)** — déclaré avec `command` + `args`, pour les serveurs MCP lancés en sous-processus avec accès aux ressources locales
- **Distant (HTTP)** — déclaré avec `url`, pour les serveurs MCP hébergés

**Portée** : `.vibe/config.toml` à la racine du projet (partagé avec l'équipe) ou la config niveau utilisateur pour les outils voulus partout.

Lancez `vibe --setup` pour une configuration interactive guidée. Au premier lancement dans un répertoire, Vibe affiche une demande de **confiance du dossier** avant de charger la config projet et les serveurs MCP.

Utilisez `vibe-acp` pour lancer Vibe en **mode ACP**, pilotable par un éditeur compatible ACP. Reprenez le travail avec `vibe --continue` (dernière session) ou `vibe --resume` (choix de session).

Une fois configurés, les outils MCP sont disponibles pour le modèle, aux côtés des outils natifs de Vibe.

📚 **Documentation** : https://docs.mistral.ai/vibe/
