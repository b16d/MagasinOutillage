<!-- .slide: class="transition" -->

# Cas d'usage MCP

## Applications pratiques pour le développement

##==##

<!-- .slide: -->

# **MCP en action**

<br>

### **Cas d'usage concrets**

| Cas d'usage                           | Serveur MCP               |
| ------------------------------------- | ------------------------- |
| 🎨 **Régression visuelle & captures** | @playwright/mcp           |
| ♿ **Audit d'accessibilité**          | @playwright/mcp           |
| 🧪 **Génération de tests E2E**        | @playwright/mcp           |
| 📁 **Accès fichiers (sandbox)**       | @anthropic/mcp-filesystem |
| 🔗 **Repos & PRs GitHub**             | @github/mcp-server        |
| 📋 **Jira & Confluence**              | @anthropic/mcp-atlassian  |
| 📚 **Docs à jour**                    | @upstash/context7-mcp     |

<br>

**Pour aller plus loin** : [Registre MCP](https://github.com/modelcontextprotocol/servers) | [Awesome MCP](https://github.com/punkpeye/awesome-mcp-servers) | [MCP Hub](https://mcp.so)

Notes:
Dans notre lab, nous utiliserons Playwright MCP pour les tests de régression visuelle, l'audit d'accessibilité et la génération de tests E2E. L'écosystème MCP grandit vite : consultez les registres pour les bases de données, les API et plus encore.
