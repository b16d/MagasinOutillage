<!-- .slide: class="transition" -->

# Installer des serveurs MCP

## Configuration pour votre IDE / agent IA

##==##

<!-- .slide: class="with-code" -->

# **Installer un serveur MCP**

```bash
claude mcp add [options] <name> <commandOrUrl> [args...]
```

<!-- .element: class="big-code"-->

<br>

| Commande                           | Description                                              |
| ---------------------------------- | -------------------------------------------------------- |
| `claude mcp [sub-command] [help]`  | Afficher l'aide                                          |
| `claude mcp list`                  | Lister les serveurs                                      |
| `claude mcp remove <name>`         | Supprimer un serveur                                     |
| `claude mcp reset-project-choices` | Redemander l'approbation des serveurs MCP                |
| `/mcp`                             | En session : statut, authentification, réinit. auth, etc |

Notes:
Claude Code fournit une CLI pour la gestion MCP (`claude mcp add`).

Elle gère les **scopes** : `local` (défaut), `project` (partagé), `user` (global).

- `local` (défaut) | vous seul, ce projet, pour le dev perso et les essais
- `user` | vous seul, tous les projets, pour vos outils perso partout
- `project` | l'équipe via `.mcp.json` à la racine du projet, pour l'outillage partagé

Elle gère les **transports** :

- `stdio`, par défaut, pour les serveurs MCP locaux avec accès aux ressources locales
- `http`, Streamable HTTP — transport recommandé pour les serveurs MCP distants
- `sse`, HTTP+SSE — transport legacy/déprécié pour les serveurs MCP distants
