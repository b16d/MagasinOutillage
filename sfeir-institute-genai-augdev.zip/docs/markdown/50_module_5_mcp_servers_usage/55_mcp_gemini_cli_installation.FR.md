<!-- .slide: class="with-code" -->

# **Installer un serveur MCP**

> ⚠️ **Gemini CLI a été retiré (mai 2026)** — l'accès grand public a pris fin le **18 juin 2026**. Son successeur est l'**Antigravity CLI**, écrit en Go (dévoilé à Google I/O 2026). Les commandes ci-dessous sont conservées à titre de référence ; migrez les configs MCP vers Antigravity CLI.

<!-- .element: class="bbquote" -->

```bash
gemini mcp add [options] <name> <commandOrUrl> [args...]
```

| Commande                   | Description                                |
| -------------------------- | ------------------------------------------ |
| `gemini mcp --help`        | Afficher l'aide des commandes MCP          |
| `gemini mcp list`          | Lister les serveurs                        |
| `gemini mcp remove <name>` | Supprimer un serveur                       |
| `/mcp`                     | Dans le TUI : voir les serveurs MCP actifs |

Notes:
Gemini CLI offre un support MCP intégré avec une syntaxe de commande simple.
La configuration MCP est stockée dans `settings.json` :

Il gère des **portées** : `project` (par défaut), `user` (globale).

- **Portée projet** (par défaut) : `.gemini/settings.json` - partagée avec l'équipe, spécifique au projet
- **Portée utilisateur** : `~/.gemini/settings.json` - s'applique à tous les projets

Il gère des **transports** :

- `stdio`, par défaut, pour les serveurs mcp locaux avec accès aux ressources locales
- `http`, Streamable HTTP — transport recommandé pour les serveurs mcp distants
- `sse`, HTTP+SSE — transport legacy/déprécié pour les serveurs mcp distants

Les tokens OAuth des serveurs distants sont stockés dans `~/.gemini/mcp-oauth-tokens.json`.
L'état d'activation des serveurs est suivi dans `~/.gemini/mcp-server-enablement.json`.
Utilisez `/mcp` dans le mode interactif de Gemini CLI pour voir et gérer les serveurs actifs.
