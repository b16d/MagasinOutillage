<!-- .slide: class="transition" -->

# Installing MCP Servers

## Configuration for your IDE/AI Agent

##==##

<!-- .slide: class="with-code" -->

# **Installing a MCP Server**

```bash
claude mcp add [options] <name> <commandOrUrl> [args...]
```

<!-- .element: class="big-code"-->

<br>

| Command                            | Description                                            |
| ---------------------------------- | ------------------------------------------------------ |
| `claude mcp [sub-command] [help]`  | Show help                                              |
| `claude mcp list`                  | List servers                                           |
| `claude mcp remove <name>`         | Remove a server                                        |
| `claude mcp reset-project-choices` | Re-prompt approval for mcp servers                     |
| `/mcp`                             | In-session: View status, authenticate, clear auth, etc |

Notes:
Claude Code provides a CLI for MCP management (`claude mcp add`).

It supports **scopes**: `local` (default), `project` (shared), `user` (global).

- `local` (default) | You only, this project, intended for Personal dev, experiments
- `user` | You only, all projects, intended for Personal tools everywhere
- `project` | Team via `.mcp.json` at project root, intended for Shared team tooling

It supports **transport**:

- `stdio`, default, for local mcp servers with access to local resources
- `http`, Streamable HTTP — recommended transport type for remote mcp servers
- `sse`, HTTP+SSE — legacy/deprecated transport type for remote mcp servers
