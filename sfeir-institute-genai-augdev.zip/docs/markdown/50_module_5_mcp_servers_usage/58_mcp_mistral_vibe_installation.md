<!-- .slide: class="with-code" -->

# **Installing a MCP Server**

```toml
# .vibe/config.toml
[mcp_servers.playwright]
command = "npx"
args = ["@playwright/mcp", "--browser=firefox", "--isolated"]

[mcp_servers.docs]
url = "https://example.com/mcp"
```

<br>

| Setting   | Description                                     |
| --------- | ----------------------------------------------- |
| `command` | Executable for a local (stdio) MCP server       |
| `args`    | Arguments passed to the local server command    |
| `url`     | Endpoint for a remote (HTTP) MCP server         |
| `env`     | Optional environment variables for the server   |

Notes:
Mistral Vibe stores its configuration in a TOML file at `.vibe/config.toml`. MCP servers are declared under `[mcp_servers.<name>]` tables — no separate add command is required, you edit the config directly.

It supports two **transport types**:

- **Local (stdio)** — declared with `command` + `args`, for MCP servers that run as a subprocess with access to local resources
- **Remote (HTTP)** — declared with `url`, for hosted MCP servers

**Scope**: `.vibe/config.toml` at the project root (shared with the team) or the user-level config for tools you want available everywhere.

Run `vibe --setup` for an interactive configuration walkthrough. On first launch inside a directory, Vibe shows a **folder-trust** prompt before loading project config and MCP servers.

Use `vibe-acp` to run Vibe in **ACP mode** so it can be driven by an ACP-compatible editor. Resume prior work with `vibe --continue` (last session) or `vibe --resume` (pick a session).

Once configured, MCP tools are available to the model alongside Vibe's built-in tools.

📚 **Documentation**: https://docs.mistral.ai/vibe/
