<!-- .slide: class="transition" -->

# Module 5 : Évaluation et récapitulatif

##==##

<!-- .slide: -->

# **Revue des objectifs pédagogiques**

<br>

### **Ce que nous avons vu**

- ✅ **Expliquer l'architecture MCP** : hosts, clients, serveurs et capacités
- ✅ **Identifier les cas d'usage** : là où MCP améliore les workflows de dev
- ✅ **Installer des serveurs MCP** : configurer Playwright MCP pour les agents IA
- ✅ **Utiliser des agents IA avec MCP** : mode Agent avec des outils MCP
- ✅ **Appliquer Playwright MCP** : tests visuels et audit d'accessibilité

**Compétences pratiquées** : Lab 51 - configuration MCP, régression visuelle, audit A11y

<!-- .element: class="sm-padding-top" -->

##==##

<!-- .slide: -->

# **Test de connaissances**

## **Question 1 : architecture MCP**

<br>

### Quelle est la relation entre Host, Client et Serveur dans MCP ?

**A)** Le Host contient des Clients, chaque Client se connecte à un Serveur  
**B)** Le Host se connecte directement à plusieurs Serveurs  
**C)** Le Serveur gère les Clients et le Host  
**D)** Le Client contient plusieurs Hosts et Serveurs

<details>
<summary>Réponse</summary>
<strong>A) Le Host contient des Clients, chaque Client se connecte à un Serveur</strong> - L'application Host (VS Code, Claude) gère plusieurs Clients, et chaque Client maintient une connexion 1:1 avec un Serveur donné.
</details>

Notes:
Comprendre cette hiérarchie est essentiel pour diagnostiquer les connexions MCP et configurer plusieurs serveurs.

##==##

<!-- .slide: -->

# **Test de connaissances**

## **Question 2 : capacités MCP**

<br>

### Quelle capacité MCP permet à l'IA d'exécuter des actions comme « prendre une capture d'écran » ?

**A)** Resources  
**B)** Prompts  
**C)** Transports  
**D)** Tools

<details>
<summary>Réponse</summary>
<strong>D) Tools</strong> - Les Tools sont des fonctions exécutables que l'IA peut invoquer pour réaliser des actions. Les Resources sont des données en lecture seule, les Prompts des modèles d'instructions, et les Transports gèrent les protocoles de communication.
</details>

Notes:
Distinguer Tools (actions), Resources (données) et Prompts (modèles) aide les développeurs à choisir la bonne capacité pour construire ou utiliser des serveurs MCP.

##==##

<!-- .slide: -->

# **Test de connaissances**

## **Question 3 : déploiement de serveur MCP**

<br>

### Quel type de déploiement de serveur MCP convient le mieux quand le serveur doit être partagé entre plusieurs développeurs sur des machines différentes ?

**A)** Serveur local via stdio  
**B)** Serveur distant via HTTP  
**C)** Serveur local via SSE  
**D)** Serveur distant via gRPC

<details>
<summary>Réponse</summary>
<strong>B) Serveur distant via HTTP</strong> - Les serveurs MCP distants exposés en HTTP sont accessibles sur le réseau et partageables entre plusieurs clients et machines. Les serveurs stdio locaux tournent comme sous-processus sur la machine du développeur et ne sont pas accessibles par le réseau.
</details>

Notes:
MCP propose deux modèles de déploiement : les serveurs locaux (lancés par une commande CLI, communiquant via stdio — simple, sûr, sans exposition réseau) et les serveurs distants (hébergés sur une URL, communiquant en HTTP — partageables entre équipes et accessibles depuis n'importe quelle machine). SSE est un transport déprécié et gRPC ne fait pas partie de la spécification MCP.

##==##

<!-- .slide: -->

# **Test de connaissances**

## **Question 4 : protocoles de transport MCP**

<br>

### Quel transport MCP est généralement utilisé pour un serveur MCP local lancé par une commande CLI comme `npx @playwright/mcp` ?

**A)** HTTP + SSE (Server-Sent Events)  
**B)** WebSocket  
**C)** stdio (entrée/sortie standard)  
**D)** gRPC

<details>
<summary>Réponse</summary>
<strong>C) stdio (entrée/sortie standard)</strong> - Les serveurs MCP locaux lancés par commande CLI communiquent via stdio : le client MCP démarre le processus serveur et échange par les flux d'entrée/sortie standard. Streamable HTTP sert aux serveurs distants ou longue durée accessibles par URL (HTTP+SSE est le transport historique).
</details>

Notes:
stdio est le transport le plus courant pour les outils de développement locaux — simple, sûr (aucune exposition réseau) et fonctionnel d'emblée avec les serveurs en CLI. Streamable HTTP est préférable quand le serveur doit être partagé entre plusieurs clients ou accessible à distance (HTTP+SSE est le transport historique).

##==##

<!-- .slide: -->

# **Ressources**

<br>

### **Documentation**

- **MCP** : [Spec](https://modelcontextprotocol.io/specification) | [Registre de serveurs](https://github.com/modelcontextprotocol/servers) | [Playwright MCP](https://github.com/microsoft/playwright-mcp)

<br><br>

### **Solution du lab**

- `labs/lab-51-mcp-playground-solution/`

Notes:
Utilisez la solution du lab pour des exemples complets de configuration MCP, des sorties d'audit d'accessibilité et des tests E2E générés.
