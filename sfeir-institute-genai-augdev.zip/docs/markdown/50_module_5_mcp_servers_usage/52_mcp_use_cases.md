<!-- .slide: class="transition" -->

# MCP Use Cases

## Practical Applications for Development

##==##

<!-- .slide: -->

# **MCP in Action**

<br>

### **Concrete Use Cases**

| Use Case                               | MCP Server                |
| -------------------------------------- | ------------------------- |
| 🎨 **Visual Regression & Screenshots** | @playwright/mcp           |
| ♿ **Accessibility Auditing**          | @playwright/mcp           |
| 🧪 **E2E Test Generation**             | @playwright/mcp           |
| 📁 **File Access (sandbox)**           | @anthropic/mcp-filesystem |
| 🔗 **GitHub Repos & PRs**              | @github/mcp-server        |
| 📋 **Jira & Confluence**               | @anthropic/mcp-atlassian  |
| 📚 **Up-to-date Docs**                 | @upstash/context7-mcp     |

<br>

**Discover More**: [MCP Registry](https://github.com/modelcontextprotocol/servers) | [Awesome MCP](https://github.com/punkpeye/awesome-mcp-servers) | [MCP Hub](https://mcp.so)

Notes:
In our lab, we'll use Playwright MCP for visual regression testing, accessibility auditing, and E2E test generation. The MCP ecosystem is growing rapidly - check the registries for databases, APIs, and more.
