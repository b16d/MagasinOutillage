<!-- .slide: class="transition" -->

# Model Context Protocol

## Understanding MCP Architecture

##==##

<!-- .slide: -->

# **What is MCP?**

<br>

### **Model Context Protocol (MCP)**

An **open protocol** that standardizes how AI applications connect to external data sources and tools.

<br>

### **Key Benefits**

- 🔌 **Universal Connectivity**: One protocol, many integrations
- 🔄 **Bidirectional Communication**: AI can both read and act
- 🛡️ **Secure by Design**: Explicit capability permissions
- 🧩 **Composable**: Mix and match servers for your workflow

Notes:
MCP was developed by Anthropic and released as an open standard. Think of it like USB for AI assistants - a universal interface that allows any compatible host to connect to any compatible server without custom integration code.

##==##

<!-- .slide: -->

<img src="assets/images/50_module_5/mcp-architecture.svg" alt="MCP Architecture diagram showing Host containing multiple Clients, each connected to a Server (Playwright, Filesystem, GitHub) that provides Tools, Resources, and Prompts" style="width:100%; height:auto; display:block;">

Notes:
The architecture follows a client-server model. Each client connects to exactly one server. Servers expose three types of capabilities: **Tools** (callable functions that perform actions like "take screenshot" or "run query"), **Resources** (read-only data the AI can access like files or database records), and **Prompts** (pre-built instruction templates for common tasks). MCP servers can be local (running on your machine with access to local resources) or remote (hosted in the cloud). The protocol supports two transport methods: **stdio** (default, for local servers) and **Streamable HTTP** (recommended for remote servers); the older **HTTP+SSE** transport is now legacy/deprecated. The current ratified MCP specification is **2025-11-25**; the next revision, **2026-07-28**, is a release candidate (finalizes July 28, 2026) that introduces a stateless protocol core, the **Extensions** framework, **Tasks**, **MCP Apps**, and authorization hardening. Key insight: one Host (like VS Code or Claude) can manage multiple Clients, but each Client connects to exactly one Server - this 1:1 relationship simplifies connection management and permissions.
