<!-- .slide: class="transition" -->

# Module 5: MCP Servers Usage

## Using MCP Servers to Extend AI Assistants

Notes:
Welcome to Module 5! This module explores the Model Context Protocol (MCP) and how to use MCP servers to extend AI coding assistants beyond their default capabilities. We'll cover MCP concepts, architecture, concrete use cases, installation for multiple AI clients, and a hands-on lab with Playwright MCP. Duration: 1h30 (45 min slides + 45 min lab).

##==##

<!-- .slide: -->

# **Learning Objectives**

<br>

### **By the end of this module, you will be able to:**

- **Explain** the Model Context Protocol architecture and its components
- **Install** and configure MCP servers for AI Agents
- **Apply** Playwright MCP for visual regression testing and accessibility auditing

Notes:
These learning objectives are measurable - you'll demonstrate your understanding through hands-on practice with MCP installation and a lab using Playwright MCP for visual testing and accessibility audits.

##==##

<!-- .slide: -->

# **Prerequisites**

<br>

### **From Previous Modules**

- Understanding of AI coding assistants and their capabilities
- Experience with agentic coding workflows
- Familiarity with Claude Code basics (Module 4)

<br><br>

### **Technical Requirements**

- **AI Coding Assistant**: with MCP support
- **IDE**: VS Code or your IDE of choice
- **Runtime**: Node.js v22+ installed locally
- **MCP Package**: @playwright/mcp (installed during lab)

Notes:
This module builds on Module 4's Claude Code foundations. You'll extend your knowledge with custom commands, subagents, and MCP integrations.
