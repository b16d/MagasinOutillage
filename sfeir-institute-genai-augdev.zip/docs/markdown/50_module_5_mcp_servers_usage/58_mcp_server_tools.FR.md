<!-- .slide: -->

# **Outils des serveurs MCP**

Une fois un serveur MCP installé, vous accédez aux **outils** qu'il fournit dans vos prompts.
Vous pouvez les invoquer par leur nom ou laisser l'IA choisir l'outil adapté à votre demande.

Voici quelques outils disponibles dans le **serveur MCP Playwright** :

| Catégorie       | Outils                                                                           |
| --------------- | -------------------------------------------------------------------------------- |
| **Navigation**  | `browser_navigate`, `browser_navigate_back`, `browser_wait_for`                  |
| **Capture**     | `browser_screenshot`, `browser_snapshot`, `browser_console_messages`             |
| **Interaction** | `browser_click`, `browser_type`, `browser_fill`, `browser_hover`, `browser_drag` |
| **Formulaires** | `browser_select_option`, `browser_file_upload`, `browser_handle_dialog`          |

<!-- .element: class="sm-padding-top" -->

<!-- | **Vérification** | `browser_verify_text_visible`, `browser_verify_element_visible`, `browser_verify_value` | -->
<!-- | **Debug** | `browser_evaluate`, `browser_network_requests`, `browser_generate_locator` | -->

<br>

📖 **Documentation** : [github.com/microsoft/playwright-mcp](https://github.com/microsoft/playwright-mcp)

Notes:
Playwright MCP utilise des snapshots d'accessibilité plutôt que des captures d'écran pour identifier les éléments. Les interactions sont ainsi plus fiables et plus accessibles. Fonctionne avec Claude Code comme avec GitHub Copilot.

##==##

<!-- .slide: class="exercice" -->

# Exercice : MCP Playground

## Lab 51

<br>

### 👉 Suivez les **instructions** dans

### <code data-markdown-preview="/labs/lab-51-mcp-playground/README.md">labs/lab-51-mcp-playground/README.md</code>

Notes:

- Configurer Playwright MCP pour votre agent IA
- Utiliser les outils MCP pour des tests de régression visuelle
- Réaliser des audits d'accessibilité assistés par IA
- Durée estimée : 40-45 minutes

##==##

<!-- .slide: class="exercice" -->

# Exercice : MCP Playground

## Lab 51

<br>

### 💡 Consultez la **solution** dans

### <code data-markdown-preview="/labs/lab-51-mcp-playground-solution/README.md">labs/lab-51-mcp-playground-solution/README.md</code>

Notes:

- Lire le README.md du lab pour les exemples de configuration MCP et les résultats d'audit d'accessibilité
