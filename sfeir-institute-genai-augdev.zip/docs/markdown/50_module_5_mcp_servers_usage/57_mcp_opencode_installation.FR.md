<!-- .slide: class="with-code" -->

# **Installer un serveur MCP**

```json
// opencode.json
{
  "$schema": "https://opencode.ai/config.json",
  "mcp": {
    "my-tool": {
      "type": "local",
      "command": ["node", "tools/my-mcp-server.js"]
    }
  }
}
```

<br>

| Paramètre | Description                                 |
| --------- | ------------------------------------------- |
| `type`    | `local` (sous-processus) ou `remote` (HTTP) |
| `command` | Tableau de commande pour serveurs locaux    |
| `url`     | URL des serveurs HTTP distants              |

Notes:
OpenCode configure les serveurs MCP dans `opencode.json` (JSONC supporté) sous la clé `mcp` — pas de commande CLI add.

Il supporte deux **types de transport** :

- `local` (sous-processus via le tableau `command`) — pour les serveurs MCP locaux avec accès aux ressources locales
- `remote` (HTTP via `url`) — pour les serveurs MCP distants

**Portée** : `opencode.json` à la racine du projet (partagé avec l'équipe) ou `~/.config/opencode/opencode.json` (niveau utilisateur).

MCP embarqué dans les Skills : les Skills peuvent déclarer leurs propres serveurs MCP en frontmatter — aucune config manuelle.

Une fois configurés, les outils MCP sont automatiquement disponibles pour le modèle, aux côtés des outils natifs.

📚 **Documentation** : https://opencode.ai/docs/mcp-servers/
