import { Plugin } from 'vite';
import {
  existsSync,
  statSync,
  createReadStream,
  mkdirSync,
  cpSync,
} from 'node:fs';
import { resolve, normalize, sep, extname, join, dirname } from 'node:path';
import { globSync } from 'glob';

interface LabsServerConfig {
  /** Absolute path to the labs directory on disk. */
  labsDir: string;
  /** URL prefix to serve labs under. Default: `/labs`. */
  urlPrefix?: string;
  /** Glob (relative to labsDir) of files to copy into the dist output during build.
   *  Default: `'*\/README.md'` — top-level README.md of each lab directory only. */
  copyGlob?: string;
}

const MIME: Record<string, string> = {
  '.md': 'text/markdown; charset=utf-8',
  '.txt': 'text/plain; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.gif': 'image/gif',
  '.svg': 'image/svg+xml',
  '.webp': 'image/webp',
};

/**
 * Vite plugin that serves the workspace `labs/` directory at a URL prefix.
 *
 * Vite's dev root is `docs/`, but lab READMEs live in `../labs/`. This bridges the gap so
 * the RevealMarkdownPreview plugin can `fetch('/labs/<lab>/README.md')` from a slide.
 * Only files (not directory listings) are served. Path traversal is blocked.
 *
 * - Dev: middleware intercepts requests and streams files directly from disk (no copying).
 * - Build: copies labs into the output dir so the path resolves in production.
 */
export default function LabsServer(config: LabsServerConfig): Plugin {
  const { labsDir, urlPrefix = '/labs', copyGlob = '*/README.md' } = config;
  const labsRoot = resolve(labsDir);
  let outDir: string;

  function labsMiddleware(
    req: import('node:http').IncomingMessage,
    res: import('node:http').ServerResponse,
    next: () => void
  ) {
    if (!req.url) return next();
    const [pathname] = req.url.split('?');
    if (!pathname.startsWith(`${urlPrefix}/`)) return next();

    const decoded = decodeURIComponent(pathname.slice(urlPrefix.length + 1));
    const target = normalize(resolve(labsRoot, decoded));
    if (target !== labsRoot && !target.startsWith(labsRoot + sep)) {
      res.statusCode = 403;
      res.end('Forbidden');
      return;
    }

    if (!existsSync(target) || !statSync(target).isFile()) {
      return next();
    }

    const ext = extname(target).toLowerCase();
    if (MIME[ext]) res.setHeader('Content-Type', MIME[ext]);
    res.setHeader('Cache-Control', 'no-cache');
    createReadStream(target).pipe(res);
  }

  return {
    name: 'labs-server',
    configResolved(cfg) {
      outDir = resolve(cfg.root, cfg.build.outDir);
    },
    configureServer(server) {
      server.middlewares.use(labsMiddleware);
    },
    configurePreviewServer(server) {
      server.middlewares.use(labsMiddleware);
    },
    closeBundle() {
      const destRoot = join(outDir, urlPrefix.replace(/^\//, ''));
      for (const file of globSync(copyGlob, { cwd: labsRoot })) {
        const dst = join(destRoot, file);
        mkdirSync(dirname(dst), { recursive: true });
        cpSync(join(labsRoot, file), dst);
      }
    },
  };
}
