import { Plugin } from 'vite';

/**
 * Configuration options for the Markdown HMR plugin.
 */
interface MarkdownHMRConfig {
  /**
   * Time in milliseconds to debounce reload events.
   * @default 300
   */
  debounceTimeInMs?: number;
  /**
   * How to reload when a markdown file changes.
   * - 'selective': sends a custom `markdown-update` event with the file path so the
   *   client can reload only the affected slide (requires `extrasRenderAttr: 'data-markdown-path'`
   *   in the SfeirThemeInitializer config).
   * - 'full': triggers a full page reload (legacy behaviour).
   * @default 'selective'
   */
  reloadType?: 'selective' | 'full';
}

/**
 * Vite plugin that enables Hot Module Replacement for Markdown files.
 * Triggers a selective slide reload (or full page reload) when .md files are modified,
 * with optional debouncing.
 *
 * @param config - Configuration options for the plugin
 * @returns A Vite plugin instance
 *
 * @example
 * ```ts
 * // Selective reload with default debounce (300ms)
 * MarkdownHMR()
 *
 * // Full page reload (legacy)
 * MarkdownHMR({ reloadType: 'full' })
 * ```
 */
export default function MarkdownHMR(config: MarkdownHMRConfig = {}): Plugin {
  const { debounceTimeInMs = 300, reloadType = 'selective' } = config;
  let debounceTimeout: NodeJS.Timeout | null = null;

  return {
    name: 'markdown-hmr',
    handleHotUpdate({ file, server }) {
      if (file.endsWith('.md')) {
        if (debounceTimeout) {
          clearTimeout(debounceTimeout);
        }

        debounceTimeout = setTimeout(() => {
          if (reloadType === 'full') {
            console.info('[hmr] full reload');
            server.ws.send({ type: 'full-reload', path: '*' });
          } else {
            console.info(
              `[hmr] selective reload of ${file.split('/').pop()}...`
            );
            server.ws.send({
              type: 'custom',
              event: 'markdown-update',
              data: { file },
            });
          }
          debounceTimeout = null;
        }, debounceTimeInMs);

        // Return empty array to suppress Vite's default handling (full page
        // reload) for files not in the module graph — we manage reloading ourselves.
        return [];
      }
    },
  };
}
