/// <reference types="vite/client" />
import { Reveal } from 'sfeir-school-theme';
import RevealMarkdown from 'reveal.js/plugin/markdown/markdown.esm.js';

// data-hmr-src is stamped by sfeir-school-theme via extrasRenderAttr: 'data-hmr-src'
// in SfeirThemeInitializer.init(). Reveal's getForwardedAttributes() propagates it
// to all ##==##-split sections automatically — no MutationObserver needed.

if (import.meta.hot) {
  import.meta.hot.on('markdown-update', async ({ file }: { file: string }) => {
    console.log(`[hmr] selective reload of ${file.split('/').pop()}...`);

    const relativePath = file.split('/markdown/').pop();
    if (!relativePath) {
      await Reveal.sync();
      return;
    }

    const markdownUrl = `./markdown/${relativePath}`;
    const allSections = Array.from(
      document.querySelectorAll(`section[data-hmr-src="${markdownUrl}"]`)
    );

    if (allSections.length === 0) {
      console.warn(
        '[hmr] no sections found for',
        markdownUrl,
        '— falling back to sync'
      );
      await Reveal.sync();
      return;
    }

    const savedIndices = Reveal.getIndices();

    // Keep the first section as the re-processing anchor; remove the rest.
    // All sections from this file carry data-hmr-src (propagated by n() on each reload).
    const anchor = allSections[0];
    allSections.slice(1).forEach((s) => s.remove());

    // Reset the anchor so RevealMarkdown re-fetches it.
    anchor.setAttribute('data-markdown', `${markdownUrl}?_t=${Date.now()}`);
    anchor.removeAttribute('data-markdown-parsed');
    anchor.innerHTML = '';
    // Restore the separators that Reveal's n() strips from split sections.
    anchor.setAttribute('data-separator', '##==##');
    anchor.setAttribute('data-separator-vertical', '##--##');
    anchor.setAttribute('data-separator-notes', '^Notes:');

    // RevealMarkdown is a factory — call it to get a fresh plugin instance.
    // The talk-control theme bundles markdown processing internally and does not
    // register it via Reveal.getPlugin(), so we use the standalone plugin directly.
    try {
      await RevealMarkdown().init(Reveal);
    } catch (err) {
      console.error('[hmr] RevealMarkdown.init failed:', err);
    }

    await Reveal.sync();
    Reveal.slide(savedIndices.h, savedIndices.v, savedIndices.f);
  });
}
