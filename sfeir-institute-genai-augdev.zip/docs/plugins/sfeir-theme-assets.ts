import { Plugin } from 'vite';
import { resolve, join } from 'path';
import { createReadStream, existsSync, mkdirSync, cpSync } from 'fs';

const MIME: Record<string, string> = {
  webp: 'image/webp',
  png: 'image/png',
  jpg: 'image/jpeg',
  jpeg: 'image/jpeg',
  ico: 'image/x-icon',
};

const URL_PREFIX = '/web_modules/sfeir-school-theme/dist/images/';

/**
 * Vite plugin that serves sfeir-school-theme background images at the path the theme hardcodes:
 * `./web_modules/sfeir-school-theme/dist/images/`. This path is baked into SfeirThemeInitializer
 * (tcCustomBackgroundOptions.basePath) and cannot be configured externally.
 *
 * - Dev: middleware intercepts requests to that URL and streams files from node_modules.
 * - Build: copies the images into the output dir so the path resolves in production.
 */
export default function SfeirThemeAssetsPlugin(): Plugin {
  let themeImagesDir: string;
  let outDir: string;

  return {
    name: 'sfeir-theme-assets',

    configResolved(config) {
      themeImagesDir = resolve(
        config.root,
        '../node_modules/sfeir-school-theme/dist/images'
      );
      outDir = resolve(config.root, config.build.outDir);
    },

    configureServer(server) {
      server.middlewares.use((req, res, next) => {
        if (!req.url?.startsWith(URL_PREFIX)) return next();
        const fileName = req.url.slice(URL_PREFIX.length).split('?')[0];
        const filePath = join(themeImagesDir, fileName);
        if (!existsSync(filePath)) return next();
        const ext = fileName.split('.').pop() ?? '';
        res.setHeader('Content-Type', MIME[ext] ?? 'application/octet-stream');
        createReadStream(filePath).pipe(res);
      });
    },

    closeBundle() {
      const destDir = join(
        outDir,
        'web_modules/sfeir-school-theme/dist/images'
      );
      mkdirSync(destDir, { recursive: true });
      cpSync(themeImagesDir, destDir, { recursive: true });
    },
  };
}
