interface RevealLike {
  getRevealElement?(): HTMLElement;
}

type ClickTargetSpace = 'slides' | 'viewport';

interface SpeakerClickMessage {
  namespace: 'reveal-speaker-click';
  x: number;
  y: number;
  targetSpace: ClickTargetSpace;
}

interface SpeakerScrollMessage {
  namespace: 'reveal-speaker-scroll';
  path: number[];
  scrollTop: number;
  scrollLeft: number;
  anchorPath: number[] | null;
  anchorOffsetTop: number | null;
}

interface RevealNotesMessage {
  namespace: 'reveal-notes';
  type: string;
}

interface RectLike {
  left: number;
  top: number;
  width: number;
  height: number;
}

interface SpeakerWindowBinding {
  iframe: HTMLIFrameElement | null;
  cleanup: (() => void) | null;
  pollId: number;
}

const speakerBindings = new WeakMap<Window, SpeakerWindowBinding>();

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null;
}

function isWindowLike(value: MessageEventSource | null): value is Window {
  return (
    isRecord(value) &&
    'document' in value &&
    'closed' in value &&
    typeof value.closed === 'boolean'
  );
}

function isRevealNotesMessage(data: unknown): data is RevealNotesMessage {
  return (
    isRecord(data) &&
    data.namespace === 'reveal-notes' &&
    data.type === 'connected'
  );
}

function isSpeakerClickMessage(data: unknown): data is SpeakerClickMessage {
  return (
    isRecord(data) &&
    data.namespace === 'reveal-speaker-click' &&
    typeof data.x === 'number' &&
    Number.isFinite(data.x) &&
    typeof data.y === 'number' &&
    Number.isFinite(data.y) &&
    (data.targetSpace === 'slides' || data.targetSpace === 'viewport')
  );
}

function isElementPath(value: unknown): value is number[] {
  return (
    Array.isArray(value) &&
    value.every(
      (segment) =>
        typeof segment === 'number' && Number.isInteger(segment) && segment >= 0
    )
  );
}

function isSpeakerScrollMessage(data: unknown): data is SpeakerScrollMessage {
  return (
    isRecord(data) &&
    data.namespace === 'reveal-speaker-scroll' &&
    isElementPath(data.path) &&
    typeof data.scrollTop === 'number' &&
    Number.isFinite(data.scrollTop) &&
    typeof data.scrollLeft === 'number' &&
    Number.isFinite(data.scrollLeft) &&
    (data.anchorPath === null || isElementPath(data.anchorPath)) &&
    (data.anchorOffsetTop === null ||
      (typeof data.anchorOffsetTop === 'number' &&
        Number.isFinite(data.anchorOffsetTop)))
  );
}

function isScrollableElement(value: unknown): value is HTMLElement {
  return (
    isRecord(value) &&
    typeof value.scrollTop === 'number' &&
    typeof value.scrollLeft === 'number' &&
    typeof value.children === 'object'
  );
}

function isPointInsideRect(
  x: number,
  y: number,
  rect: RectLike | null
): boolean {
  if (!rect || !rect.width || !rect.height) return false;
  return (
    x >= rect.left &&
    x <= rect.left + rect.width &&
    y >= rect.top &&
    y <= rect.top + rect.height
  );
}

function normalizeSpeakerClick(
  event: MouseEvent,
  iframeWin: Window,
  iframeDoc: Document
): SpeakerClickMessage | null {
  const slidesEl = iframeDoc.querySelector(
    '.reveal .slides'
  ) as HTMLElement | null;
  const slidesRect = slidesEl?.getBoundingClientRect() ?? null;
  const targetSpace: ClickTargetSpace = isPointInsideRect(
    event.clientX,
    event.clientY,
    slidesRect
  )
    ? 'slides'
    : 'viewport';

  const base: RectLike =
    targetSpace === 'slides' && slidesRect
      ? slidesRect
      : {
          left: 0,
          top: 0,
          width: iframeWin.innerWidth,
          height: iframeWin.innerHeight,
        };

  if (!base.width || !base.height) return null;

  return {
    namespace: 'reveal-speaker-click',
    x: (event.clientX - base.left) / base.width,
    y: (event.clientY - base.top) / base.height,
    targetSpace,
  };
}

function getElementPath(target: Element, root: Element): number[] | null {
  if (target === root) return [];

  const path: number[] = [];
  let current: Element | null = target;

  while (current && current !== root) {
    const parent: HTMLElement | null = current.parentElement;
    if (!parent) return null;

    const index = Array.from(parent.children).indexOf(current);
    if (index === -1) return null;

    path.unshift(index);
    current = parent;
  }

  return current === root ? path : null;
}

function findElementByPath(path: number[], root: Element): Element | null {
  let current: Element | null = root;

  for (const index of path) {
    current = current.children.item(index);
    if (!current) return null;
  }

  return current;
}

function getScrollAnchor(
  target: HTMLElement
): { path: number[]; offsetTop: number } | null {
  const rect = target.getBoundingClientRect();
  const view = target.ownerDocument.defaultView;
  if (!view) return null;

  const isStickyOrFixed = (el: Element): boolean => {
    const pos = view.getComputedStyle(el).position;
    return pos === 'sticky' || pos === 'fixed';
  };

  // Descend through single-child wrappers (skipping sticky/fixed siblings
  // like a sticky close button) to reach the layer whose children are
  // individual content blocks — that's the layer that re-flows when the
  // viewport resizes, so its children are stable anchors.
  let scope: Element = target;
  while (true) {
    let only: Element | null = null;
    let multiple = false;
    for (const child of Array.from(scope.children)) {
      if (isStickyOrFixed(child)) continue;
      if (only) {
        multiple = true;
        break;
      }
      only = child;
    }
    if (!only || multiple) break;
    scope = only;
  }

  // Within the content layer, pick the first visible child as the anchor.
  for (const child of Array.from(scope.children)) {
    if (isStickyOrFixed(child)) continue;
    const r = child.getBoundingClientRect();
    if (r.height <= 0 || r.bottom <= rect.top + 1) continue;
    const path = getElementPath(child, target);
    if (!path) continue;
    return { path, offsetTop: r.top - rect.top };
  }

  return null;
}

function getScrollTarget(
  target: EventTarget | null,
  doc: Document
): HTMLElement | null {
  if (isScrollableElement(target)) {
    return target;
  }

  return isScrollableElement(doc.scrollingElement)
    ? doc.scrollingElement
    : null;
}

function attachIframeForwarders(
  speakerWindow: Window,
  iframe: HTMLIFrameElement
): (() => void) | null {
  const iframeWin = iframe.contentWindow;
  const iframeDoc = iframe.contentDocument;
  if (!iframeWin || !iframeDoc) return null;

  let pendingScrollMessage: SpeakerScrollMessage | null = null;
  let scrollFrameId: number | null = null;

  const forwardClick = (event: MouseEvent): void => {
    const message = normalizeSpeakerClick(event, iframeWin, iframeDoc);
    if (!message) return;

    speakerWindow.opener?.postMessage(JSON.stringify(message), '*');
  };

  const flushScroll = (): void => {
    scrollFrameId = null;
    if (!pendingScrollMessage) return;

    speakerWindow.opener?.postMessage(
      JSON.stringify(pendingScrollMessage),
      '*'
    );
    pendingScrollMessage = null;
  };

  const forwardScroll = (event: Event): void => {
    const target = getScrollTarget(event.target, iframeDoc);
    if (!target) return;

    const path = getElementPath(target, iframeDoc.documentElement);
    if (!path) return;
    const anchor = getScrollAnchor(target);

    pendingScrollMessage = {
      namespace: 'reveal-speaker-scroll',
      path,
      scrollTop: target.scrollTop,
      scrollLeft: target.scrollLeft,
      anchorPath: anchor?.path ?? null,
      anchorOffsetTop: anchor?.offsetTop ?? null,
    };

    if (scrollFrameId === null) {
      scrollFrameId = iframeWin.requestAnimationFrame(flushScroll);
    }
  };

  iframeDoc.addEventListener('click', forwardClick, true);
  iframeDoc.addEventListener('scroll', forwardScroll, true);

  return (): void => {
    if (scrollFrameId !== null) {
      iframeWin.cancelAnimationFrame(scrollFrameId);
    }
    iframeDoc.removeEventListener('click', forwardClick, true);
    iframeDoc.removeEventListener('scroll', forwardScroll, true);
  };
}

function bindSpeakerIframeClicks(speakerWindow: Window): void {
  if (speakerBindings.has(speakerWindow)) return;

  const binding: SpeakerWindowBinding = {
    iframe: null,
    cleanup: null,
    pollId: 0,
  };

  const syncBinding = (): void => {
    if (speakerWindow.closed) {
      if (binding.cleanup) {
        binding.cleanup();
      }
      window.clearInterval(binding.pollId);
      speakerBindings.delete(speakerWindow);
      return;
    }

    const iframe = speakerWindow.document.querySelector(
      '#current-slide iframe'
    ) as HTMLIFrameElement | null;

    if (iframe !== binding.iframe) {
      if (binding.cleanup) {
        binding.cleanup();
      }
      binding.iframe = iframe;
      binding.cleanup = null;
    }

    if (!iframe || binding.cleanup) return;

    binding.cleanup = attachIframeForwarders(speakerWindow, iframe);
  };

  binding.pollId = window.setInterval(syncBinding, 100);
  speakerBindings.set(speakerWindow, binding);
  syncBinding();
}

function handleForwardedClick(
  data: SpeakerClickMessage,
  reveal: RevealLike
): void {
  const revealEl = reveal.getRevealElement?.();
  if (!revealEl) return;

  const rect =
    data.targetSpace === 'viewport'
      ? {
          left: 0,
          top: 0,
          width: window.innerWidth,
          height: window.innerHeight,
        }
      : (
          (revealEl.querySelector('.slides') as HTMLElement | null) ?? revealEl
        ).getBoundingClientRect();

  if (!rect.width || !rect.height) return;

  const px = rect.left + data.x * rect.width;
  const py = rect.top + data.y * rect.height;

  (document.elementFromPoint(px, py) as HTMLElement | null)?.click();
}

function handleForwardedScroll(data: SpeakerScrollMessage): void {
  const target = findElementByPath(data.path, document.documentElement);
  if (!isScrollableElement(target)) return;

  if (data.anchorPath && data.anchorOffsetTop !== null) {
    const anchor = findElementByPath(data.anchorPath, target);
    if (anchor) {
      const targetTop = target.getBoundingClientRect().top;
      const anchorTop = anchor.getBoundingClientRect().top;
      target.scrollTop += anchorTop - targetTop - data.anchorOffsetTop;
      target.scrollLeft = data.scrollLeft;
      return;
    }
  }

  target.scrollTop = data.scrollTop;
  target.scrollLeft = data.scrollLeft;
}

const RevealSpeakerEventForward = {
  id: 'speaker-event-forward',

  init(reveal: RevealLike): void {
    window.addEventListener('message', (event: MessageEvent) => {
      if (typeof event.data !== 'string') return;

      try {
        const data = JSON.parse(event.data) as unknown;
        if (isRevealNotesMessage(data) && isWindowLike(event.source)) {
          bindSpeakerIframeClicks(event.source);
        }
        if (isSpeakerClickMessage(data)) {
          handleForwardedClick(data, reveal);
        }
        if (isSpeakerScrollMessage(data)) {
          handleForwardedScroll(data);
        }
      } catch {
        // ignore malformed messages
      }
    });
  },
};

export default RevealSpeakerEventForward;
