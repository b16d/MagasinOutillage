import { readFileSync } from 'fs';
import { resolve } from 'path';

/**
 * Vite plugin that seeds `sessionStorage` with data from a JSON file during development.
 *
 * Reads the specified JSON file and injects an inline `<script>` into `<head>`
 * that populates `sessionStorage` with the file's key/value pairs before the
 * page loads.
 *
 * @param filePath - Absolute or relative path to the JSON seed file. If the file is not found, a warning is logged and no script is injected.
 * @returns A Vite plugin object applied only in `serve` (dev) mode.
 *
 * @example
 * // vite.config.ts
 * import SessionStorageSeederPlugin from './plugins/session-storage-seeder';
 *
 * export default defineConfig({
 *   plugins: [SessionStorageSeederPlugin('./session.json')],
 * });
 */
export default function SessionStorageSeederPlugin(filePath: string) {
  return {
    name: 'session-storage-seeder',
    apply: 'serve', // dev only
    transformIndexHtml() {
      const absolutePath = resolve(__dirname, filePath);
      let parsed: Record<string, unknown>;
      try {
        const data = readFileSync(absolutePath, 'utf-8');
        parsed = JSON.parse(data);

        console.info(
          `[session-storage-seeder] Session will be seeded from "${filePath}"`
        );
      } catch (err) {
        if ((err as NodeJS.ErrnoException).code !== 'ENOENT') {
          // if the error is not "file not found", log a warning (otherwise, just skip seeding without spamming the console)
          console.warn(
            `[session-storage-seeder] Could not read seed file "${filePath}":`,
            (err as NodeJS.ErrnoException).message
          );
        }
        return [];
      }
      return [
        {
          tag: 'script',
          attrs: { type: 'text/javascript' },
          injectTo: 'head-prepend',
          children: `
            (function() {
              const seed = ${JSON.stringify(parsed)};
              Object.entries(seed).forEach(([key, value]) => {
                sessionStorage.setItem(key, typeof value === 'string' ? value : JSON.stringify(value));
              });
            })();
          `,
        },
      ];
    },
  };
}
