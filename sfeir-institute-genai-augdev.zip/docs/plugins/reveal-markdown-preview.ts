/// <reference types="vite/client" />
import { marked } from 'marked';
import { markedHighlight } from 'marked-highlight';
import hljs from 'highlight.js';
import css from './reveal-markdown-preview.css?raw';
import hljsCss from 'highlight.js/styles/github.css?raw';

type TriggerPosition = 'left' | 'right' | 'top' | 'bottom';

interface CssClassMap {
  trigger: string;
  overlay: string;
  container: string;
  closeBtn: string;
  loading: string;
}

interface MarkdownPreviewConfig {
  triggerButton: string;
  triggerButtonPosition: TriggerPosition;
  triggerButtonOffset: string;
  overlayBackground: string;
  closeButton: string;
  closeButtonText: string;
  contentMaxWidth: string;
  contentPadding: string;
  syntaxHighlight: boolean;
  closeOnBackdropClick: boolean;
  showLoadingIndicator: boolean;
  markedOptions: Record<string, unknown>;
  cssClasses: CssClassMap;
}

type DeepPartial<T> = {
  [K in keyof T]?: T[K] extends object ? DeepPartial<T[K]> : T[K];
};

interface MarkdownPreviewApi {
  open(element: Element): void;
  close(): void;
  refresh(): void;
  getConfig(): MarkdownPreviewConfig;
}

interface RevealLike {
  on?(event: string, handler: (...args: unknown[]) => void): void;
  getConfig?(): {
    markdownPreview?: DeepPartial<MarkdownPreviewConfig>;
  } & Record<string, unknown>;
  getPlugin?(id: string): Record<string, unknown> | undefined;
}

interface RevealPlugin {
  id: string;
  init(reveal: RevealLike): MarkdownPreviewApi;
}

const DEFAULTS: MarkdownPreviewConfig = {
  triggerButton: '🔍',
  triggerButtonPosition: 'right',
  triggerButtonOffset: '5px',
  overlayBackground: 'rgba(0, 0, 0, 0.95)',
  closeButton: '✕',
  closeButtonText: 'Close',
  contentMaxWidth: '80%',
  contentPadding: '40px',
  syntaxHighlight: true,
  closeOnBackdropClick: true,
  showLoadingIndicator: true,
  markedOptions: { breaks: true, gfm: true },
  cssClasses: {
    trigger: 'markdown-preview-trigger',
    overlay: 'markdown-preview-overlay',
    container: 'markdown-preview-container',
    closeBtn: 'markdown-preview-close',
    loading: 'markdown-preview-loading',
  },
};

const STYLE_ID = 'reveal-markdown-preview-styles';
const BOUND_ATTR = 'data-markdown-preview-bound';

function deepMerge<T>(target: T, source: DeepPartial<T> | undefined): T {
  if (!source) return { ...(target as object) } as T;
  const out: Record<string, unknown> = {
    ...(target as Record<string, unknown>),
  };
  for (const key of Object.keys(source) as Array<keyof T>) {
    const tv = (target as Record<string, unknown>)[key as string];
    const sv = (source as Record<string, unknown>)[key as string];
    if (
      sv &&
      typeof sv === 'object' &&
      !Array.isArray(sv) &&
      tv &&
      typeof tv === 'object' &&
      !Array.isArray(tv)
    ) {
      out[key as string] = deepMerge(tv, sv as DeepPartial<typeof tv>);
    } else if (sv !== undefined) {
      out[key as string] = sv;
    }
  }
  return out as T;
}

/**
 * Prefix every selector in a stylesheet with `scope` so its rules can't escape
 * a given DOM subtree. Used to keep the third-party highlight.js theme from
 * styling slide-level `<code>` blocks outside our preview overlay.
 *
 * Skips at-rules (@keyframes, @media, etc.). Adequate for highlight.js themes,
 * which are flat selector lists with no nested at-rules.
 */
function scopeCss(rawCss: string, scope: string): string {
  const noComments = rawCss.replace(/\/\*[\s\S]*?\*\//g, '');
  return noComments.replace(
    /(^|\})([^{}]+)(\{)/g,
    (match, before, selectors, brace) => {
      const trimmed = selectors.trim();
      if (!trimmed || trimmed.startsWith('@')) return match;
      const scoped = trimmed
        .split(',')
        .map((s: string) => `${scope} ${s.trim()}`)
        .join(', ');
      return `${before}${scoped}${brace}`;
    }
  );
}

function injectStyles(withSyntaxHighlight: boolean): void {
  if (document.getElementById(STYLE_ID)) return;
  const style = document.createElement('style');
  style.id = STYLE_ID;
  const scopedHljs = withSyntaxHighlight
    ? scopeCss(hljsCss, '.markdown-preview-content')
    : '';
  style.textContent = withSyntaxHighlight ? `${scopedHljs}\n${css}` : css;
  document.head.appendChild(style);
}

function applyOverlayVars(
  overlay: HTMLElement,
  config: MarkdownPreviewConfig
): void {
  overlay.style.setProperty('--rmp-overlay-bg', config.overlayBackground);
  overlay.style.setProperty('--rmp-max-width', config.contentMaxWidth);
  overlay.style.setProperty('--rmp-padding', config.contentPadding);
}

function ensurePositioned(el: HTMLElement): void {
  if (getComputedStyle(el).position === 'static') {
    el.style.position = 'relative';
  }
}

function placeTrigger(
  el: HTMLElement,
  button: HTMLElement,
  position: TriggerPosition,
  offset: string
): void {
  button.style.position =
    button.style.top =
    button.style.right =
    button.style.bottom =
    button.style.left =
    button.style.transform =
    button.style.margin =
      '';
  if (position === 'top' || position === 'bottom') {
    // Block-relative placement — only sensible for block-level marked elements.
    ensurePositioned(el);
    button.style.position = 'absolute';
    button.style.left = '50%';
    button.style.transform = 'translateX(-50%)';
    if (position === 'top') {
      button.style.bottom = `calc(100% + ${offset})`;
    } else {
      button.style.top = `calc(100% + ${offset})`;
    }
    el.appendChild(button);
    return;
  }
  // Inline flow for left/right: the button rides along with the text, so it
  // ends up next to the visible last/first line even when content wraps.
  if (position === 'left') {
    button.style.marginRight = offset;
    el.insertBefore(button, el.firstChild);
  } else {
    button.style.marginLeft = offset;
    el.appendChild(button);
  }
}

function rewriteRelativeUrls(container: HTMLElement, baseHref: string): void {
  if (!baseHref) return;
  const isAbsolute = (v: string): boolean =>
    /^([a-z][a-z0-9+.-]*:|\/\/|\/|#|mailto:|tel:|data:)/i.test(v);
  for (const img of Array.from(
    container.querySelectorAll<HTMLImageElement>('img[src]')
  )) {
    const src = img.getAttribute('src');
    if (src && !isAbsolute(src)) {
      try {
        img.setAttribute('src', new URL(src, baseHref).pathname);
      } catch {
        /* ignore */
      }
    }
  }
  for (const a of Array.from(
    container.querySelectorAll<HTMLAnchorElement>('a[href]')
  )) {
    const href = a.getAttribute('href');
    if (href && !isAbsolute(href)) {
      try {
        const resolved = new URL(href, baseHref);
        a.setAttribute(
          'href',
          resolved.pathname + resolved.search + resolved.hash
        );
        a.setAttribute('target', '_blank');
        a.setAttribute('rel', 'noopener');
      } catch {
        /* ignore */
      }
    }
  }
}

function renderError(message: string, detail?: string): HTMLDivElement {
  const div = document.createElement('div');
  div.className = 'markdown-preview-error';
  const strong = document.createElement('strong');
  strong.textContent = message;
  div.appendChild(strong);
  if (detail) {
    const small = document.createElement('div');
    small.textContent = detail;
    div.appendChild(small);
  }
  return div;
}

const RevealMarkdownPreview: RevealPlugin = {
  id: 'markdown-preview',
  init(reveal: RevealLike): MarkdownPreviewApi {
    const userOptions = (reveal.getConfig?.().markdownPreview ??
      {}) as DeepPartial<MarkdownPreviewConfig>;
    const config = deepMerge(DEFAULTS, userOptions);
    const c = config.cssClasses;

    if (config.syntaxHighlight) {
      marked.use(
        markedHighlight({
          langPrefix: 'hljs language-',
          highlight(code: string, lang: string): string {
            const language =
              lang && hljs.getLanguage(lang) ? lang : 'plaintext';
            return hljs.highlight(code, { language, ignoreIllegals: true })
              .value;
          },
        })
      );
    }
    marked.setOptions({ ...config.markedOptions });
    injectStyles(config.syntaxHighlight);

    let activeOverlay: HTMLElement | null = null;
    let escListener: ((e: KeyboardEvent) => void) | null = null;
    let savedBodyOverflow = '';

    function close(): void {
      if (!activeOverlay) return;
      const overlay = activeOverlay;
      activeOverlay = null;
      overlay.classList.remove('is-visible');
      if (escListener) {
        document.removeEventListener('keydown', escListener);
        escListener = null;
      }
      document.body.style.overflow = savedBodyOverflow;
      const cleanup = (): void => {
        overlay.parentNode?.removeChild(overlay);
      };
      const fallback = window.setTimeout(cleanup, 400);
      overlay.addEventListener(
        'transitionend',
        () => {
          window.clearTimeout(fallback);
          cleanup();
        },
        { once: true }
      );
    }

    function open(el: Element): void {
      if (!el) return;
      if (activeOverlay) close();

      const overlay = document.createElement('div');
      overlay.className = c.overlay;
      applyOverlayVars(overlay, config);

      const container = document.createElement('div');
      container.className = c.container;

      const closeBtn = document.createElement('button');
      closeBtn.className = c.closeBtn;
      closeBtn.type = 'button';
      closeBtn.appendChild(
        document.createTextNode(
          `${config.closeButton} ${config.closeButtonText}`
        )
      );
      closeBtn.setAttribute('aria-label', config.closeButtonText);

      const content = document.createElement('div');
      content.className = 'markdown-preview-content';

      container.appendChild(closeBtn);
      container.appendChild(content);
      overlay.appendChild(container);
      document.body.appendChild(overlay);

      savedBodyOverflow = document.body.style.overflow;
      document.body.style.overflow = 'hidden';
      activeOverlay = overlay;

      requestAnimationFrame(() => overlay.classList.add('is-visible'));
      closeBtn.focus();

      closeBtn.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        close();
      });
      container.addEventListener('click', (e) => e.stopPropagation());
      if (config.closeOnBackdropClick) {
        overlay.addEventListener('click', (e) => {
          if (e.target === overlay) close();
        });
      }
      escListener = (e: KeyboardEvent) => {
        if (e.key === 'Escape') {
          e.preventDefault();
          close();
        }
      };
      document.addEventListener('keydown', escListener);

      const src = el.getAttribute('data-markdown-preview');
      const inline = el.getAttribute('data-markdown-preview-content');

      const renderMarkdown = (md: string, baseHref: string): void => {
        try {
          const html = marked.parse(md) as string;
          content.innerHTML = html;
          rewriteRelativeUrls(content, baseHref);
        } catch (err) {
          content.replaceChildren(
            renderError(
              'Failed to render markdown',
              err instanceof Error ? err.message : String(err)
            )
          );
        }
      };

      if (src) {
        if (config.showLoadingIndicator) {
          const loading = document.createElement('div');
          loading.className = c.loading;
          loading.textContent = 'Loading…';
          content.appendChild(loading);
        }
        const base = import.meta.env.BASE_URL;
        const adjustedSrc = src.startsWith('/') ? base.slice(0, -1) + src : src;
        const url = new URL(adjustedSrc, window.location.href);
        fetch(url.toString())
          .then((res) => {
            if (!res.ok) throw new Error(`${res.status} ${res.statusText}`);
            return res.text();
          })
          .then((text) => renderMarkdown(text, url.href))
          .catch((err: unknown) => {
            content.replaceChildren(
              renderError(
                `Could not load ${src}`,
                err instanceof Error ? err.message : String(err)
              )
            );
          });
      } else if (inline) {
        renderMarkdown(inline, window.location.href);
      } else {
        renderMarkdown(el.textContent ?? '', window.location.href);
      }
    }

    function bindElement(el: Element): void {
      if (!(el instanceof HTMLElement)) return;
      if (el.getAttribute(BOUND_ATTR) === 'true') return;
      el.setAttribute(BOUND_ATTR, 'true');

      const button = document.createElement('button');
      button.type = 'button';
      button.className = c.trigger;
      button.textContent = config.triggerButton;
      button.setAttribute('aria-label', 'Preview markdown');

      const handler = (e: Event): void => {
        e.preventDefault();
        e.stopPropagation();
        open(el);
      };
      button.addEventListener('click', handler);
      el.addEventListener('click', handler);

      placeTrigger(
        el,
        button,
        config.triggerButtonPosition,
        config.triggerButtonOffset
      );
    }

    function scan(root?: ParentNode | null): void {
      const scope: ParentNode = root ?? document;
      const els = scope.querySelectorAll(
        '[data-markdown-preview], [data-markdown-preview-content]'
      );
      els.forEach(bindElement);
    }

    if (typeof reveal.on === 'function') {
      reveal.on('ready', () => scan());
      reveal.on('slidechanged', (...args: unknown[]) => {
        const ev = args[0] as { currentSlide?: ParentNode } | undefined;
        scan(ev?.currentSlide ?? null);
      });
    }
    scan();

    const api: MarkdownPreviewApi = {
      open,
      close,
      refresh: () => scan(),
      getConfig: () => deepMerge(config, {}),
    };
    const plugin = reveal.getPlugin?.('markdown-preview');
    if (plugin) Object.assign(plugin, api);
    return api;
  },
};

export default RevealMarkdownPreview;
export type { MarkdownPreviewConfig, MarkdownPreviewApi, TriggerPosition };
