import { defineConfig } from 'vite';
import { resolve } from 'path';
import { nxViteTsPaths } from '@nx/vite/plugins/nx-tsconfig-paths.plugin';
import { nxCopyAssetsPlugin } from '@nx/vite/plugins/nx-copy-assets.plugin';
import { ViteImageOptimizer } from 'vite-plugin-image-optimizer';

import MarkdownHMR from './plugins/hmr-markdown';
import SessionStorageSeederPlugin from './plugins/session-storage-seeder';
import LabsServer from './plugins/labs-server';
import SfeirThemeAssetsPlugin from './plugins/sfeir-theme-assets';

export default defineConfig(() => ({
  root: __dirname,
  cacheDir: '../node_modules/.vite/docs',
  server: {
    port: 4200,
    host: '0.0.0.0', //needed because we want to access the server from outside the devcontainer
  },
  preview: {
    port: 4300,
    host: '0.0.0.0', //needed because we want to access the server from outside the devcontainer
  },
  plugins: [
    nxViteTsPaths(),
    SfeirThemeAssetsPlugin(),
    nxCopyAssetsPlugin([
      '**/*.md',
      '**/*.png',
      '**/*.jpg',
      '**/*.jpeg',
      '**/*.svg',
      '**/*.gif',
      '**/*.webp',
    ]),
    ViteImageOptimizer({
      includePublic: true,
      cache: true,
      cacheLocation: '../node_modules/.cache/vite-plugin-image-optimizer',
    }),
    MarkdownHMR(),
    SessionStorageSeederPlugin(resolve(__dirname, './session.json')),
    LabsServer({ labsDir: resolve(__dirname, '../labs') }),
  ],
  // Uncomment this if you are using workers.
  // worker: {
  //  plugins: [ nxViteTsPaths() ],
  // },
  build: {
    outDir: '../dist/docs',
    emptyOutDir: true,
    reportCompressedSize: true,
    commonjsOptions: {
      transformMixedEsModules: true,
    },
  },
  // Use relative base for all CI deployments so assets resolve correctly
  // regardless of the GitLab Pages namespace prefix in the URL
  base: process.env.CI ? './' : '/',
}));
