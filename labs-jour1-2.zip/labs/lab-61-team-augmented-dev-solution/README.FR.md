# Lab 61 : Développement augmenté en équipe - Solutions

> **Public : stagiaires.** À lire après avoir tenté le lab. Ce document déroule le résultat
> attendu et le raisonnement qui y mène.

Ce document fournit les solutions et exemples de référence pour les exercices du lab Développement augmenté en équipe. Le projet d'exemple complet et fonctionnel se trouve dans `resources/photo-gallery-fullstack-solution/`.

## Livrables de la solution

Le répertoire `resources/` contient le projet de solution complet :

```
resources/
└── photo-gallery-fullstack-solution/   # Complete Nx workspace with all AI configurations
    ├── .claude/                         # Claude Code agents, commands, skills, plugins
    ├── .codex/                          # Codex CLI config, skills, profiles
    ├── .github/                         # GitHub Copilot agents, prompts, hooks, workflows
    ├── .gemini/                         # Gemini CLI commands, hooks, references
    ├── .opencode/                       # OpenCode agents, commands, skills
    ├── .vibe/                           # Mistral Vibe agents, skills system, references, TOML config/hooks
    ├── apps/
    │   ├── frontend/                    # Angular 20 app
    │   ├── backend-nestjs/              # NestJS 11 backend (reference)
    │   ├── backend-spring/              # Spring Boot 4 backend (Java 17)
    │   ├── backend-fastapi/             # FastAPI backend (Python 3.12)
    │   ├── backend-dotnet/              # .NET backend (C# 12)
    │   └── backend-gin/                 # Gin backend (Go 1.23)
    ├── docs/
    │   ├── openapi.yaml                 # Canonical API contract (regen: npm run openapi:export)
    │   └── backends/                    # Per-stack implementation guides
    ├── AGENTS.md                        # Cross-platform reference + Codex project instructions
    ├── CLAUDE.md                        # Claude Code setup guide
    └── GEMINI.md                        # Gemini CLI setup guide
```

### Lancer le projet de solution

```bash
cd resources/photo-gallery-fullstack-solution
npm ci
npm run start
```

La solution tourne sur des ports différents pour éviter les conflits avec le projet du lab :

- **Frontend** : http://localhost:42620
- **Backend** : port 42621

---

## Vue d'ensemble de la solution

Le workspace Nx `photo-gallery-fullstack-solution/` démontre des configurations IA d'équipe prêtes pour la production sur six plateformes :

- **Claude Code** (répertoire `.claude/`)
- **Codex CLI** (répertoire `.codex/`)
- **GitHub Copilot** (répertoire `.github/`)
- **Gemini CLI** (répertoire `.gemini/`)
- **OpenCode** (répertoire `.opencode/`)
- **Mistral Vibe** (répertoire `.vibe/`)

Chaque dossier de plateforme contient des implémentations équivalentes des agents, commandes/prompts, skills, hooks et références.

---

## Section A : solutions Claude Code

### Exercice A1 : découverte des agents

**Emplacement de la solution** : `resources/photo-gallery-fullstack-solution/.claude/agents/`

Fichiers d'agents clés :

- `architecture-guardian.md` - Valide les décisions d'architecture selon `references/architecture.md`
- `api-contract-agent.md` - Garantit la rétrocompatibilité de l'API
- `legacy-modernizer.md` - Guide le refactoring callback → async
- `test-strategist.md` - Planifie les stratégies de test d'après `references/testing-guidelines.md`
- `release-safety.md` - Valide la préparation au déploiement

**Comportement attendu** : à l'invocation de `@architecture-guardian`, l'agent lit `references/architecture.md` et fournit des recommandations adaptées à la couche concernée.

### Exercice A2 : exploration des commandes

**Emplacement de la solution** : `resources/photo-gallery-fullstack-solution/.claude/commands/`

Fichiers de commandes clés :

- `trace-flow.md` - Traçage de flux de bout en bout avec chemins de fichiers
- `prepare-pr.md` - Génération de description de PR avec checklist
- `add-tests.md` - Génération de tests conforme aux guidelines de test
- `migration-plan.md` - Planification de refactoring incrémental
- `explain-oncall.md` - Guide de réponse aux incidents
- `code-reviewer.md` - Analyse de diff et revue de code

**Comportement attendu** : `/trace-flow POST /api/photos/upload` produit le flux controller → service → repository avec les numéros de ligne.

### Exercices A3-A5 : API, tests et modernisation du legacy

**Patterns clés** :

- L'API Contract Agent se réfère à `references/coding-standards.md` pour les règles de validation
- Le Test Strategist utilise `references/testing-guidelines.md` pour les patterns de test
- Le Legacy Modernizer applique la skill incremental-refactoring de `.claude/skills/`

### Exercice A6 : mise en œuvre des skills

**Emplacement de la solution** : `resources/photo-gallery-fullstack-solution/.claude/skills/`

Fichiers de skills :

- `topology-awareness/SKILL.md` - Compréhension du graphe de dépendances
- `change-impact-analysis/SKILL.md` - Évaluation du risque des changements
- `incremental-refactoring/SKILL.md` - Refactoring sûr, étape par étape
- `framework-conventions/SKILL.md` - Application des patterns NestJS/Angular
- `debug-correlation/SKILL.md` - Analyse de cause racine

**Comportement attendu** : les skills sont invoquées automatiquement selon le contexte ; poser une question sur un changement d'interface déclenche `change-impact-analysis`.

### Exercices A7-A8 : release et astreinte

**Références de la solution** :

- Release Safety utilise `references/oncall.md` pour les checklists de déploiement
- Les scénarios d'astreinte s'appuient sur les problèmes courants documentés dans `references/oncall.md`

### Exercice A9 : hook de pre-commit

**Emplacement de la solution** : `resources/photo-gallery-fullstack-solution/.claude/settings.json`

```json
"hooks": {
  "PreToolUse": [{
    "matcher": "Bash",
    "hooks": [{
      "type": "prompt",
      "prompt": "Run code-reviewer on staged files..."
    }]
  }],
  "PostToolUse": [{
    "matcher": "Write|Edit",
    "hooks": [{
      "type": "prompt",
      "prompt": "Validate against coding-standards.md..."
    }]
  }]
}
```

### Exercice A10 : utilisation d'un plugin d'équipe

**Emplacement de la solution** : `resources/photo-gallery-fullstack-solution/.claude/plugins/team-workflows/`

Structure du plugin :

- `.claude-plugin/plugin.json` - Manifeste du plugin
- `commands/` - Slash commands (analyze-dependencies, generate-changelog)
- `agents/` - Sous-agents (security-auditor, performance-optimizer)
- `skills/` - Capacités réutilisables
- `hooks/` - Gestionnaires d'événements

**Chargement** : `claude --plugin-dir .claude/plugins/team-workflows`

---

## Section B : solutions GitHub Copilot

### Exercice B1 : découverte des agents

**Emplacement de la solution** : `resources/photo-gallery-fullstack-solution/.github/agents/`

Les fichiers d'agents utilisent le suffixe `.agent.md` :

- `architecture-guardian.agent.md`
- `api-contract-agent.agent.md`
- `legacy-modernizer.agent.md`
- `test-strategist.agent.md`
- `release-safety.agent.md`

### Exercice B2 : exploration des prompts

**Emplacement de la solution** : `resources/photo-gallery-fullstack-solution/.github/prompts/`

Les fichiers de prompts utilisent le suffixe `.prompt.md` :

- `trace-flow.prompt.md`
- `prepare-pr.prompt.md`
- `add-tests.prompt.md`
- `migration-plan.prompt.md`
- `explain-oncall.prompt.md`
- `code-reviewer.prompt.md`
- `analyze-diff.prompt.md`
- `safe-refactor.prompt.md`
- `test-plan.prompt.md`
- `release-checklist.prompt.md`

**Invocation** : `#trace-flow POST /api/photos/upload`

### Exercices B3-B5 : contrat d'API, génération de tests et refactoring sûr

**Emplacement de la solution** : `resources/photo-gallery-fullstack-solution/.github/agents/` et `.github/prompts/`

Copilot n'a pas de syntaxe `@mention` pour les agents. Un agent se choisit dans le sélecteur, ou bien
son fichier `.agent.md` est attaché au contexte de la conversation. Les trois exercices associent
donc un agent et un fichier de prompt :

| Exercice | Agent                         | Fichier de prompt                                                 |
| -------- | ----------------------------- | ----------------------------------------------------------------- |
| B3       | `api-contract-agent.agent.md` | `.github/prompts/analyze-diff.prompt.md`                          |
| B4       | `test-strategist.agent.md`    | `.github/prompts/test-plan.prompt.md`, puis `add-tests.prompt.md` |
| B5       | `legacy-modernizer.agent.md`  | `.github/prompts/safe-refactor.prompt.md`                         |

**Points clés** :

- L'API Contract Agent lit `.github/instructions/architecture-<backend>.instructions.md` pour les
  règles de couches du backend choisi : la réponse est donc spécifique à la stack, pas générique
- Ajouter un paramètre **optionnel** est rétrocompatible ; l'agent doit le dire _puis_ demander la
  mise à jour du schéma OpenAPI — s'il se contente d'un « oui », relancez-le sur le schéma
- Le Test Strategist lit `.github/instructions/testing-guidelines-<backend>.instructions.md`. C'est
  le seul endroit où le découpage par backend compte vraiment : le fichier FastAPI recommande
  `pytest.mark.parametrize`, celui de Spring recommande `@ParameterizedTest`
- Le Legacy Modernizer applique le skill `incremental-refactoring` : une étape préservant le
  comportement à la fois, suite de tests verte entre chaque

**Résultat attendu** : un verdict de rétrocompatibilité assorti d'un diff OpenAPI, un plan de test
adapté à la stack, et une séquence de refactoring qui ne laisse jamais la suite au rouge.

### Exercice B6 : instructions ciblées par chemin

**Emplacement de la solution** : `resources/photo-gallery-fullstack-solution/.github/instructions/`

Instructions avec frontmatter `applyTo` :

- `architecture.instructions.md` - Patterns de la couche domaine (toutes les couches domaine des backends — `apps/backend-nestjs/src/domain/**`, `apps/backend-spring/.../domain/**`, `apps/backend-fastapi/app/domain/**`, `apps/backend-dotnet/Domain/**`, `apps/backend-gin/internal/domain/**`)
- `testing-guidelines.instructions.md` - Patterns de fichiers de test (`**/*.spec.ts`)

### Exercice B7 : exécution des hooks

**Emplacement de la solution** : `resources/photo-gallery-fullstack-solution/.github/hooks/`

Fichiers de configuration des hooks :

- `code-reviewer.json` - Hook pre-tool pour la validation des commits git
- `coding-standards.json` - Hook post-tool pour la validation des standards

Scripts de hooks dans `.github/hooks/scripts/` :

- `validate-commit.sh` / `.ps1`
- `validate-coding-standards.sh` / `.ps1`

### Exercice B8 : intégration dans le workflow CI

**Emplacement de la solution** : `resources/photo-gallery-fullstack-solution/.github/workflows/`

Fichiers de workflow :

- `ci.yml` - Pipeline lint, test, build
- `pr-review.yml` - Revue de PR assistée par IA
- `deploy.yml` - Déploiement en production

---

### Exercices B9-B10 : checklist de release et guidage d'astreinte

**Emplacement de la solution** : `resources/photo-gallery-fullstack-solution/.github/prompts/release-checklist.prompt.md` et `explain-oncall.prompt.md`

```
/release-checklist
/explain-oncall High error rate on photo uploads
```

**Points clés** :

- `release-checklist` va de pair avec `release-safety.agent.md` ; la sortie doit nommer les risques
  de déploiement, un plan de rollback et ce qu'il faut surveiller — pas seulement cocher des cases
- `/explain-oncall` lit `.github/instructions/oncall.instructions.md`, qui porte le chemin
  d'escalade et les modes de défaillance connus par backend
- Copilot applique automatiquement les fichiers `instructions/` selon leur glob `applyTo` : le
  contexte d'astreinte est donc déjà chargé, le stagiaire n'a rien à attacher

**Résultat attendu** : une évaluation de release ancrée dans les procédures d'escalade du dépôt,
plutôt que des conseils génériques.

## Section C : solutions Gemini CLI

### Exercice C1 : revue de la configuration

**Emplacement de la solution** : `resources/photo-gallery-fullstack-solution/.gemini/settings.json`

Sections de configuration :

- `mcpServers` - Configuration des serveurs MCP
- `tools` - Définitions des tools
- `hooks` - Gestionnaires BeforeTool/AfterTool
- `skills` - Références de skills
- `commands` - Références de commandes

### Exercice C2 : découverte des commandes

**Emplacement de la solution** : `resources/photo-gallery-fullstack-solution/.gemini/commands/`

Fichiers de commandes TOML :

- `trace-flow.toml`
- `prepare-pr.toml`
- `add-tests.toml`
- `migration-plan.toml`
- `explain-oncall.toml`
- `code-reviewer.toml`

### Exercice C3 : exécution des hooks

**Solution dans** `settings.json` :

```json
"hooks": {
  "BeforeTool": [{
    "matcher": "terminal|shell|bash",
    "hooks": [{ "command": ".gemini/hooks/validate-commit.sh" }]
  }],
  "AfterTool": [{
    "matcher": "write_file|replace",
    "hooks": [{ "command": ".gemini/hooks/validate-coding-standards.sh" }]
  }]
}
```

**Scripts de hooks** : `.gemini/hooks/`

- `validate-commit.sh`
- `validate-writes.sh`
- `validate-coding-standards.sh`

### Exercices C4-C9 : contrat d'API, tests, migration, skills, astreinte et préparation de PR

**Emplacement de la solution** : `resources/photo-gallery-fullstack-solution/.gemini/commands/` et `.gemini/skills/`

> **Gemini CLI n'a aucun fichier d'agent dans ce projet.** Le support des agents est expérimental :
> le parcours Gemini passe donc entièrement par les commandes et les skills. C'est la différence
> structurelle à souligner au débriefing — les mêmes six capacités, sans l'abstraction `@agent`.

| Exercice | Comment on procède                                                                                      |
| -------- | ------------------------------------------------------------------------------------------------------- |
| C4       | `/code-reviewer` sur le contrôleur modifié                                                              |
| C5       | `/add-tests <chemin de votre PhotoService>`                                                             |
| C6       | `/migration-plan` — invoque le skill `incremental-refactoring`                                          |
| C7       | Poser une question sur un changement d'interface ; `change-impact-analysis` s'active depuis le contexte |
| C8       | `/explain-oncall "High error rate on photo uploads"`                                                    |
| C9       | `/prepare-pr`                                                                                           |

**Points clés** :

- Les commandes sont en TOML (`.gemini/commands/*.toml`), pas en Markdown — le prompt vit dans une
  clé `prompt`
- Chaque commande référence `.gemini/references/*.md` : c'est par là que la connaissance propre à la
  stack atteint le modèle, faute d'agent pour la porter
- Les skills utilisent le même format `SKILL.md` multi-plateforme que Claude, Copilot, OpenCode et
  Vibe ; seul le répertoire change
- `.gemini/settings.json` câble les trois hooks de `.gemini/hooks/`

**Résultat attendu** : les six mêmes sorties que sur les autres parcours. Si un stagiaire trouve ses
réponses plus maigres que celles de son voisin sous Claude, la cause est en général la persona
d'agent manquante, pas le modèle — demandez-lui d'attacher explicitement le fichier `references/`
pertinent.

### Exercice C10 : utilisation des références

**Emplacement de la solution** : `resources/photo-gallery-fullstack-solution/.gemini/references/`

Fichiers de références :

- `architecture.md` - Topologie du système
- `domain-glossary.md` - Termes métier
- `testing-guidelines.md` - Patterns de test
- `coding-standards.md` - Conventions de code
- `oncall.md` - Réponse aux incidents

---

## Section D : solutions Codex CLI

### Exercice D1 : confiance projet et configuration

**Emplacement de la solution** : `resources/photo-gallery-fullstack-solution/.codex/config.toml`

Configuration clé :

```toml
model = "gpt-5-codex"
approval_policy = "on-request"
sandbox_mode = "workspace-write"
model_reasoning_effort = "medium"
```

### Exercice D2 : découverte d'AGENTS.md

**Emplacement de la solution** : `resources/photo-gallery-fullstack-solution/AGENTS.md`

Le fichier `AGENTS.md` à la racine du projet est lu automatiquement par Codex et fournit :

- Vue d'ensemble de l'architecture du système
- Agents disponibles et leurs correspondances entre plateformes
- Table de référence des commandes et prompts
- Instructions de setup spécifiques à chaque plateforme

### Exercice D3 : exploration des skills

**Emplacement de la solution** : `resources/photo-gallery-fullstack-solution/.codex/skills/`

Répertoires de skills :

- `topology-awareness/SKILL.md` - Cartographie des dépendances
- `change-impact-analysis/SKILL.md` - Évaluation du risque
- `incremental-refactoring/SKILL.md` - Étapes de refactoring sûr
- `framework-conventions/SKILL.md` - Patterns NestJS/Angular
- `debug-correlation/SKILL.md` - Analyse de cause racine

**Invocation** : `$topology-awareness` ou implicite selon la description de la tâche

### Exercice D4 : changement de profil

**Emplacement de la solution** : `resources/photo-gallery-fullstack-solution/.codex/config.toml`

Profils disponibles :

```toml
[profiles.deep-review]
model = "gpt-5-pro"
model_reasoning_effort = "high"

[profiles.lightweight]
model = "gpt-4.1"
approval_policy = "on-failure"

[profiles.architecture]
model_reasoning_effort = "high"

[profiles.testing]
model_reasoning_effort = "medium"

[profiles.code-review]
model_reasoning_effort = "high"
```

**Usage** : `codex --profile deep-review`

### Exercices D5-D7 : analyse d'API, modernisation du legacy, stratégie de test

**Patterns clés** :

- Changements d'API → skill `$change-impact-analysis`
- Refactoring de legacy → skill `$incremental-refactoring` avec plan étape par étape
- Tests → `--profile testing` + skill `$framework-conventions`

### Exercice D8 : revue de code intégrée

**Solution** : utiliser la commande `/review` ou demander « Review the changes in my working tree »

Codex fournit une revue de code intégrée, sans configuration de commande personnalisée.

### Exercice D9 : debug en astreinte

**Solution** : utiliser la skill `$debug-correlation`

```
$debug-correlation "High error rate on photo uploads"
```

La skill se réfère à `references/oncall.md` via le répertoire references de la skill.

### Exercice D10 : règles personnalisées

**Référence de la solution** : `~/.codex/rules/default.rules`

Exemples de règles (syntaxe Starlark) :

```starlark
prefix_rule(pattern=["npm", "run"], decision="allow")
prefix_rule(pattern=["git", "push"], decision="prompt")
prefix_rule(
  pattern=["rm", "-rf"],
  decision="forbidden",
  justification="Use git clean instead"
)
```

---

## Section E : solutions OpenCode

### Exercice E1 : découverte des agents

**Emplacement de la solution** : `resources/photo-gallery-fullstack-solution/.opencode/agents/`

Cinq fichiers d'agents, en Markdown avec frontmatter, mêmes cinq rôles que sur tous les autres
parcours :

- `architecture-guardian.md` - Valide les décisions d'architecture face à `references/architecture.md`
- `api-contract-agent.md` - Garantit la rétrocompatibilité de l'API
- `legacy-modernizer.md` - Guide le refactoring
- `test-strategist.md` - Planifie les stratégies de test depuis `references/testing-guidelines.md`
- `release-safety.md` - Valide l'état de préparation au déploiement

**Invocation** : `@architecture-guardian I need to add a photo filter feature...`

Identique à Claude Code. Appuyez sur `Tab` pour passer en mode Plan si vous voulez que l'agent
planifie avant de toucher aux fichiers.

### Exercice E2 : exploration des commandes

**Emplacement de la solution** : `resources/photo-gallery-fullstack-solution/.opencode/command/`

> **Attention au répertoire au singulier** : `.opencode/command/`, pas `commands/`. C'est un piège
> classique, et le symptôme est silencieux — la commande slash n'apparaît tout simplement pas.

Six commandes : `trace-flow`, `prepare-pr`, `add-tests`, `migration-plan`, `explain-oncall`,
`code-reviewer`.

**Invocation** : `/trace-flow POST /api/photos/upload`

**Résultat attendu** : le chemin complet depuis la requête HTTP jusqu'au dépôt en passant par le
contrôleur et le service, avec chemins de fichiers et numéros de ligne pour le backend choisi.

### Exercices E3-E5 : contrat d'API, stratégie de test et modernisation du legacy

**Points clés** :

- `@api-contract-agent` lit `.opencode/references/architecture.md`. Ajouter un paramètre `tags`
  **optionnel** est rétrocompatible — l'agent doit le dire _et_ proposer la mise à jour du schéma
  OpenAPI
- `@test-strategist` lit `.opencode/references/testing-guidelines.md`, puis `/add-tests <chemin>`
  génère la suite. Le chemin change selon le backend ; l'agent ne le devine pas à votre place
- `@legacy-modernizer` applique le skill `incremental-refactoring` : une étape préservant le
  comportement à la fois, suite verte entre chaque. Passez d'abord en mode Plan (`Tab`) sur
  l'exercice de refactoring

### Exercice E6 : mise en œuvre des skills

**Emplacement de la solution** : `resources/photo-gallery-fullstack-solution/.opencode/skills/`

Cinq skills au format multi-plateforme `SKILL.md` : `topology-awareness`,
`change-impact-analysis`, `incremental-refactoring`, `framework-conventions`, `debug-correlation`.

> **Correctif à l'énoncé** : l'exercice E6 demande d'examiner `.claude/skills/`. Les skills sont en
> réalité livrés dans `.opencode/skills/` sur ce projet, pour qu'OpenCode les trouve sans dépendre
> d'une installation de Claude. Les deux emplacements fonctionnent — OpenCode lit les skills
> compatibles Claude — mais orientez les stagiaires vers `.opencode/skills/`.

Poser la question _« If I change the PhotoRepository interface, what else will break? »_ active
`change-impact-analysis` depuis le contexte, sans invocation explicite.

### Exercices E7-E8 : préparation au déploiement et astreinte

```
@release-safety Are we ready to deploy these changes to production?
/prepare-pr
/explain-oncall "High error rate on photo uploads"
```

**Points clés** :

- `release-safety` lit le diff indexé : faites `git add apps/` avant de demander — un index vide
  produit une évaluation vide, énoncée avec aplomb
- `/explain-oncall` lit `.opencode/references/oncall.md` pour le chemin d'escalade et les modes de
  défaillance connus

### Exercice E9 : plugin TypeScript — hook de cycle de vie

**Emplacement de la solution** : `resources/photo-gallery-fullstack-solution/.opencode/plugins/coding-standards.ts`

C'est l'exercice propre à OpenCode. Là où Claude Code configure ses hooks en JSON dans
`settings.json` et où Vibe utilise du TOML, OpenCode exporte une **fonction de plugin asynchrone qui
renvoie des handlers de cycle de vie** :

- `tool.execute.before` — inspecte la charge utile d'`edit`/`write` en attente et lève une exception
  pour la bloquer
- `file.edited` — se déclenche après l'écriture, utilisé ici pour journaliser un rappel

Demander à OpenCode _« Add a temporary variable of type any to photo.service.ts »_ fait lever le
plugin avant que l'édition n'aboutisse.

**Pourquoi cela dépasse OpenCode** : le plugin lit `.opencode/references/coding-standards.md` au
chargement et dérive sa règle du document. La convention et son application ne peuvent pas diverger,
puisqu'il n'y a qu'une seule source. Ce motif se transpose à toutes les autres plateformes.

### Exercice E10 : partage de session et mode headless

Deux capacités sans équivalent sous cette forme chez Claude Code :

**Partage de session** — `/share` (ou `ctrl+x s`) publie la conversation à une URL publique, pour
qu'un collègue relise l'analyse en asynchrone sans avoir à la rejouer.

> ⚠️ **À dire à voix haute dans la salle** : `/share` rend la session **publique**. Tout ce qui se
> trouve dans la fenêtre de contexte part avec — contenus de fichiers, chemins, et tout ce que
> l'agent a lu en chemin. Excellent outil sur un dépôt open source, mauvais outil sur du code client.

**Mode headless** — `opencode run "<prompt>"` renvoie l'analyse sur stdout sans ouvrir le TUI, ce qui
le rend utilisable en CI :

```bash
opencode run "Check if staged files follow team coding standards and fail if violations are found"
```

L'équivalent Claude Code est `claude -p`. La différence à noter est qu'`opencode run` est le chemin
principal documenté pour la CI, plutôt qu'un drapeau d'impression sur un outil interactif.

## Section F : solutions Mistral Vibe

### Exercice F1 : confiance du dossier et configuration

**Emplacement de la solution** : `resources/photo-gallery-fullstack-solution/.vibe/config.toml`

La configuration TOML est chargée une fois le dossier approuvé (prompt de folder-trust au premier lancement ; `vibe --setup` pour une configuration interactive) :

```toml
[project]
trust = true

[agent]
permission_mode = "default"
agents_dir = ".vibe/agents"

[skills]
skills_dir = ".vibe/skills"
```

### Exercice F2 : découverte des agents

**Emplacement de la solution** : `resources/photo-gallery-fullstack-solution/.vibe/agents/`

Fichiers d'agents (Markdown avec frontmatter `name`/`description`/`tools` optionnel) :

- `architecture-guardian.md` - Valide les décisions d'architecture selon `references/architecture.md`
- `api-contract-agent.md` - Garantit la rétrocompatibilité de l'API
- `legacy-modernizer.md` - Guide le refactoring callback → async
- `test-strategist.md` - Planifie les stratégies de test d'après `references/testing-guidelines.md`
- `release-safety.md` - Valide la préparation au déploiement

**Invocation** : `@architecture-guardian I need to add a photo filter feature...`

### Exercice F3 : slash commands via le système de skills

**Emplacement de la solution** : `resources/photo-gallery-fullstack-solution/.vibe/skills/`

Le système de skills unifié héberge à la fois les skills réutilisables (invoquées par le modèle) et les slash commands (invoquées par l'utilisateur avec `/`) :

- Skills réutilisables : `topology-awareness`, `change-impact-analysis`, `incremental-refactoring`, `framework-conventions`, `debug-correlation`
- Slash commands : `trace-flow`, `prepare-pr`, `add-tests`, `migration-plan`, `explain-oncall`, `code-reviewer`

**Invocation** : `/trace-flow POST /api/photos/upload`

### Exercices F4-F7 : API, tests, modernisation du legacy et skills

**Patterns clés** :

- L'API Contract Agent se réfère à `.vibe/references/coding-standards.md` pour les règles de validation
- Le Test Strategist utilise `.vibe/references/testing-guidelines.md` pour les patterns de test
- Le Legacy Modernizer applique la skill `incremental-refactoring` ; utiliser le permission mode `plan` pour revoir les changements d'abord
- Poser une question sur un changement d'interface active automatiquement la skill `change-impact-analysis`

### Exercice F8 : hooks TOML

**Emplacement de la solution** : `resources/photo-gallery-fullstack-solution/.vibe/hooks.toml`

```toml
[[hooks.pre_tool_use]]
matcher = "shell"
command = "bash .vibe/hooks/validate-commit.sh"

[[hooks.pre_tool_use]]
matcher = "write"
command = "bash .vibe/hooks/validate-writes.sh"

[[hooks.post_tool_use]]
matcher = "write|edit"
command = "bash .vibe/hooks/validate-coding-standards.sh"
```

**Scripts de hooks** : `.vibe/hooks/`

- `validate-commit.sh`
- `validate-writes.sh`
- `validate-coding-standards.sh`

Un hook qui sort avec un code non nul bloque l'action associée.

### Exercice F9 : utilisation des références

**Emplacement de la solution** : `resources/photo-gallery-fullstack-solution/.vibe/references/`

Fichiers de références :

- `architecture.md` - Topologie du système
- `domain-glossary.md` - Termes métier
- `testing-guidelines.md` - Patterns de test
- `coding-standards.md` - Conventions de code
- `oncall.md` - Réponse aux incidents

### Exercice F10 : mode ACP et reprise de session

**Références de la solution** :

- Reprise de session : `vibe --continue` (reprend la plus récente) ou `vibe --resume` (choisir une session précédente)
- Mode ACP : `vibe-acp` sert les requêtes via l'Agent Client Protocol pour les éditeurs/clients compatibles ACP

---

## Patterns multi-plateformes

| Capacité            | Claude Code                 | Codex CLI                       | GitHub Copilot                | Gemini CLI                  | Mistral Vibe              |
| ------------------- | --------------------------- | ------------------------------- | ----------------------------- | --------------------------- | ------------------------- |
| Agents              | `.claude/agents/*.md`       | Via les skills                  | `.github/agents/*.agent.md`   | N/A (via les skills)        | `.vibe/agents/*.md`       |
| Commandes/Prompts   | `.claude/commands/*.md`     | `~/.codex/prompts/`             | `.github/prompts/*.prompt.md` | `.gemini/commands/*.toml`   | via le système de skills  |
| Skills              | `.claude/skills/*/SKILL.md` | `.codex/skills/*/SKILL.md`      | N/A (intégré)                 | `.gemini/skills/*/SKILL.md` | `.vibe/skills/*/SKILL.md` |
| Références          | `.claude/references/`       | Dans `references/` des skills   | `.github/references/`         | `.gemini/references/`       | `.vibe/references/`       |
| Hooks/Règles        | `.claude/settings.json`     | `~/.codex/rules/*.rules`        | `.github/hooks/*.json`        | `.gemini/settings.json`     | `.vibe/hooks.toml`        |
| Réglages            | `.claude/settings.json`     | `.codex/config.toml`            | Réglages VS Code              | `.gemini/settings.json`     | `.vibe/config.toml`       |
| Profils             | N/A                         | `[profiles.*]` dans config.toml | N/A                           | N/A                         | N/A                       |
| Plugins             | `.claude/plugins/`          | N/A                             | Extensions VS Code            | N/A                         | N/A                       |
| Instructions projet | `CLAUDE.md`                 | `AGENTS.md` (lu auto.)          | `copilot-instructions.md`     | `GEMINI.md`                 | `AGENTS.md` (lu auto.)    |

## Points clés à retenir

1. **Maîtrise des agents/commandes** : chaque plateforme offre des capacités équivalentes avec une syntaxe différente
2. **Conscience des skills** : les skills sont invoquées automatiquement selon le contexte de la requête
3. **Exploitation des références** : la connaissance partagée dans les dossiers `references/` guide le comportement des agents
4. **Conventions de plateforme** : extensions de fichiers et structures de répertoires diffèrent d'une plateforme à l'autre
5. **Collaboration d'équipe** : les fichiers de configuration sont versionnés et partageables

## Ressources complémentaires

- [AGENTS.md](resources/photo-gallery-fullstack-solution/AGENTS.md) - Référence multi-plateformes + instructions projet Codex
- [CLAUDE.md](resources/photo-gallery-fullstack-solution/CLAUDE.md) - Guide de setup Claude Code
- [GEMINI.md](resources/photo-gallery-fullstack-solution/GEMINI.md) - Guide de setup Gemini CLI
