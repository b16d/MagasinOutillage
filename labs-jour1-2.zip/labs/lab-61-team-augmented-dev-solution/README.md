# Lab 61: Team-Augmented Development - Solutions

> **Audience: trainees.** Read this after attempting the lab. It walks through the expected
> result and the reasoning behind it.

This document provides reference solutions and examples for the Team-Augmented Development lab exercises. The complete working example project is located in `resources/photo-gallery-fullstack-solution/`.

## Solution Deliverables

The `resources/` directory contains the complete solution project:

```
resources/
└── photo-gallery-fullstack-solution/   # Complete Nx workspace with all AI configurations
    ├── .claude/                         # Claude Code agents, commands, skills, plugins
    ├── .codex/                          # Codex CLI config, skills, profiles
    ├── .github/                         # GitHub Copilot agents, prompts, hooks, workflows
    ├── .gemini/                         # Gemini CLI commands, hooks, references
    ├── .opencode/                       # OpenCode agents, commands, skills
    ├── .vibe/                           # Mistral Vibe agents, skills system, references, TOML config/hooks
    ├── apps/
    │   ├── frontend/                    # Angular 20 app
    │   ├── backend-nestjs/              # NestJS 11 backend (reference)
    │   ├── backend-spring/              # Spring Boot 4 backend (Java 17)
    │   ├── backend-fastapi/             # FastAPI backend (Python 3.12)
    │   ├── backend-dotnet/              # .NET backend (C# 12)
    │   └── backend-gin/                 # Gin backend (Go 1.23)
    ├── docs/
    │   ├── openapi.yaml                 # Canonical API contract (regen: npm run openapi:export)
    │   └── backends/                    # Per-stack implementation guides
    ├── AGENTS.md                        # Cross-platform reference + Codex project instructions
    ├── CLAUDE.md                        # Claude Code setup guide
    └── GEMINI.md                        # Gemini CLI setup guide
```

### Running the Solution Project

```bash
cd resources/photo-gallery-fullstack-solution
npm ci
npm run start
```

The solution runs on different ports to avoid conflicts with the lab project:

- **Frontend**: http://localhost:42620
- **Backend**: port 42621

---

## Solution Overview

The `photo-gallery-fullstack-solution/` Nx workspace demonstrates production-ready team AI configurations across six platforms:

- **Claude Code** (`.claude/` directory)
- **Codex CLI** (`.codex/` directory)
- **GitHub Copilot** (`.github/` directory)
- **Gemini CLI** (`.gemini/` directory)
- **OpenCode** (`.opencode/` directory)
- **Mistral Vibe** (`.vibe/` directory)

Each platform folder contains equivalent implementations of agents, commands/prompts, skills, hooks, and references.

---

## Section A: Claude Code Solutions

### Exercise A1: Agent Discovery

**Solution Location**: `resources/photo-gallery-fullstack-solution/.claude/agents/`

Key agent files:

- `architecture-guardian.md` - Validates architectural decisions against `references/architecture.md`
- `api-contract-agent.md` - Ensures API backward compatibility
- `legacy-modernizer.md` - Guides callback-to-async refactoring
- `test-strategist.md` - Plans test strategies based on `references/testing-guidelines.md`
- `release-safety.md` - Validates deployment readiness

**Expected Behavior**: When invoking `@architecture-guardian`, the agent reads `references/architecture.md` and provides layer-appropriate recommendations.

### Exercise A2: Command Exploration

**Solution Location**: `resources/photo-gallery-fullstack-solution/.claude/commands/`

Key command files:

- `trace-flow.md` - End-to-end flow tracing with file paths
- `prepare-pr.md` - PR description generation with checklist
- `add-tests.md` - Test generation following testing guidelines
- `migration-plan.md` - Incremental refactoring planning
- `explain-oncall.md` - Incident response guidance
- `code-reviewer.md` - Diff analysis and code review

**Expected Behavior**: `/trace-flow POST /api/photos/upload` produces controller → service → repository flow with line numbers.

### Exercise A3-A5: API, Testing, and Legacy Modernization

**Key Patterns**:

- API Contract Agent references `references/coding-standards.md` for validation rules
- Test Strategist uses `references/testing-guidelines.md` for test patterns
- Legacy Modernizer applies incremental-refactoring skill from `.claude/skills/`

### Exercise A6: Skills Application

**Solution Location**: `resources/photo-gallery-fullstack-solution/.claude/skills/`

Skill files:

- `topology-awareness/SKILL.md` - Dependency graph understanding
- `change-impact-analysis/SKILL.md` - Risk assessment for changes
- `incremental-refactoring/SKILL.md` - Safe step-by-step refactoring
- `framework-conventions/SKILL.md` - NestJS/Angular pattern enforcement
- `debug-correlation/SKILL.md` - Root cause analysis

**Expected Behavior**: Skills are auto-invoked based on context; asking about interface changes triggers `change-impact-analysis`.

### Exercise A7-A8: Release and On-Call

**Solution References**:

- Release Safety uses `references/oncall.md` for deployment checklists
- On-call scenarios reference common issues documented in `references/oncall.md`

### Exercise A9: Pre-Commit Hook

**Solution Location**: `resources/photo-gallery-fullstack-solution/.claude/settings.json`

```json
"hooks": {
  "PreToolUse": [{
    "matcher": "Bash",
    "hooks": [{
      "type": "prompt",
      "prompt": "Run code-reviewer on staged files..."
    }]
  }],
  "PostToolUse": [{
    "matcher": "Write|Edit",
    "hooks": [{
      "type": "prompt",
      "prompt": "Validate against coding-standards.md..."
    }]
  }]
}
```

### Exercise A10: Team Plugin Usage

**Solution Location**: `resources/photo-gallery-fullstack-solution/.claude/plugins/team-workflows/`

Plugin structure:

- `.claude-plugin/plugin.json` - Plugin manifest
- `commands/` - Slash commands (analyze-dependencies, generate-changelog)
- `agents/` - Sub-agents (security-auditor, performance-optimizer)
- `skills/` - Reusable capabilities
- `hooks/` - Event handlers

**Loading**: `claude --plugin-dir .claude/plugins/team-workflows`

---

## Section B: GitHub Copilot Solutions

### Exercise B1: Agent Discovery

**Solution Location**: `resources/photo-gallery-fullstack-solution/.github/agents/`

Agent files use `.agent.md` suffix:

- `architecture-guardian.agent.md`
- `api-contract-agent.agent.md`
- `legacy-modernizer.agent.md`
- `test-strategist.agent.md`
- `release-safety.agent.md`

### Exercise B2: Prompt Exploration

**Solution Location**: `resources/photo-gallery-fullstack-solution/.github/prompts/`

Prompt files use `.prompt.md` suffix:

- `trace-flow.prompt.md`
- `prepare-pr.prompt.md`
- `add-tests.prompt.md`
- `migration-plan.prompt.md`
- `explain-oncall.prompt.md`
- `code-reviewer.prompt.md`
- `analyze-diff.prompt.md`
- `safe-refactor.prompt.md`
- `test-plan.prompt.md`
- `release-checklist.prompt.md`

**Invocation**: `#trace-flow POST /api/photos/upload`

### Exercise B3-B5: API Contract, Test Generation, and Safe Refactoring

**Solution Location**: `resources/photo-gallery-fullstack-solution/.github/agents/` and `.github/prompts/`

Copilot has no `@mention` syntax for agents. An agent is selected from the agent picker, or its
`.agent.md` file is attached to the chat context. The three exercises therefore pair an agent with a
prompt file:

| Exercise | Agent                         | Prompt file                                                       |
| -------- | ----------------------------- | ----------------------------------------------------------------- |
| B3       | `api-contract-agent.agent.md` | `.github/prompts/analyze-diff.prompt.md`                          |
| B4       | `test-strategist.agent.md`    | `.github/prompts/test-plan.prompt.md`, then `add-tests.prompt.md` |
| B5       | `legacy-modernizer.agent.md`  | `.github/prompts/safe-refactor.prompt.md`                         |

**Key Patterns**:

- The API Contract Agent reads `.github/instructions/architecture-<backend>.instructions.md` for the
  layer rules of the backend you picked, so the answer is stack-specific rather than generic
- Adding an **optional** parameter is backward compatible; the agent should say so and then ask for
  the OpenAPI schema to be updated — if it only says "yes", press it for the schema change
- The Test Strategist reads `.github/instructions/testing-guidelines-<backend>.instructions.md`.
  This is the one place where the per-backend split matters: the FastAPI file recommends
  `pytest.mark.parametrize`, the Spring one recommends `@ParameterizedTest`
- The Legacy Modernizer applies the `incremental-refactoring` skill: one behaviour-preserving step at
  a time, tests green between each

**Expected Outcome**: a backward-compatibility verdict with an OpenAPI diff, a stack-appropriate test
plan, and a refactoring sequence that never leaves the suite red.

### Exercise B6: Path-Specific Instructions

**Solution Location**: `resources/photo-gallery-fullstack-solution/.github/instructions/`

Instructions with `applyTo` frontmatter:

- `architecture.instructions.md` - Domain layer patterns (all backend domain layers — `apps/backend-nestjs/src/domain/**`, `apps/backend-spring/.../domain/**`, `apps/backend-fastapi/app/domain/**`, `apps/backend-dotnet/Domain/**`, `apps/backend-gin/internal/domain/**`)
- `testing-guidelines.instructions.md` - Test file patterns (`**/*.spec.ts`)

### Exercise B7: Hook Execution

**Solution Location**: `resources/photo-gallery-fullstack-solution/.github/hooks/`

Hook configuration files:

- `code-reviewer.json` - Pre-tool hook for git commit validation
- `coding-standards.json` - Post-tool hook for standards validation

Hook scripts in `.github/hooks/scripts/`:

- `validate-commit.sh` / `.ps1`
- `validate-coding-standards.sh` / `.ps1`

### Exercise B8: CI Workflow Integration

**Solution Location**: `resources/photo-gallery-fullstack-solution/.github/workflows/`

Workflow files:

- `ci.yml` - Lint, test, build pipeline
- `pr-review.yml` - AI-assisted PR review
- `deploy.yml` - Production deployment

---

### Exercise B9-B10: Release Checklist and On-Call Guidance

**Solution Location**: `resources/photo-gallery-fullstack-solution/.github/prompts/release-checklist.prompt.md` and `explain-oncall.prompt.md`

```
/release-checklist
/explain-oncall High error rate on photo uploads
```

**Key Patterns**:

- `release-checklist` pairs with `release-safety.agent.md`; the output should name deployment risks,
  a rollback plan and what to monitor, not just a tick list
- `explain-oncall` reads `.github/instructions/oncall.instructions.md`, which carries the escalation
  path and the known failure modes per backend
- Copilot applies `instructions/` files automatically by `applyTo` glob, so the on-call context is
  already in scope — the trainee does not attach it manually

**Expected Outcome**: a release assessment grounded in the repository's own escalation procedures
rather than generic advice.

## Section C: Gemini CLI Solutions

### Exercise C1: Configuration Review

**Solution Location**: `resources/photo-gallery-fullstack-solution/.gemini/settings.json`

Configuration sections:

- `mcpServers` - MCP server configuration
- `tools` - Tool definitions
- `hooks` - BeforeTool/AfterTool handlers
- `skills` - Skill references
- `commands` - Command references

### Exercise C2: Command Discovery

**Solution Location**: `resources/photo-gallery-fullstack-solution/.gemini/commands/`

TOML command files:

- `trace-flow.toml`
- `prepare-pr.toml`
- `add-tests.toml`
- `migration-plan.toml`
- `explain-oncall.toml`
- `code-reviewer.toml`

### Exercise C3: Hook Execution

**Solution in** `settings.json`:

```json
"hooks": {
  "BeforeTool": [{
    "matcher": "terminal|shell|bash",
    "hooks": [{ "command": ".gemini/hooks/validate-commit.sh" }]
  }],
  "AfterTool": [{
    "matcher": "write_file|replace",
    "hooks": [{ "command": ".gemini/hooks/validate-coding-standards.sh" }]
  }]
}
```

**Hook Scripts**: `.gemini/hooks/`

- `validate-commit.sh`
- `validate-writes.sh`
- `validate-coding-standards.sh`

### Exercise C4-C9: API Contract, Tests, Migration, Skills, On-Call, and PR Preparation

**Solution Location**: `resources/photo-gallery-fullstack-solution/.gemini/commands/` and `.gemini/skills/`

> **Gemini CLI has no agent files in this project.** Agent support is experimental, so the Gemini
> track drives everything through commands and skills instead. That is the structural difference to
> point out at the debrief: the same six capabilities, delivered without the `@agent` abstraction.

| Exercise | How it is done                                                                            |
| -------- | ----------------------------------------------------------------------------------------- |
| C4       | `/code-reviewer` on the modified controller                                               |
| C5       | `/add-tests <path to your PhotoService>`                                                  |
| C6       | `/migration-plan` — invokes the `incremental-refactoring` skill                           |
| C7       | Ask a question about an interface change; `change-impact-analysis` activates from context |
| C8       | `/explain-oncall "High error rate on photo uploads"`                                      |
| C9       | `/prepare-pr`                                                                             |

**Key Patterns**:

- Commands are TOML (`.gemini/commands/*.toml`), not Markdown — the prompt lives in a `prompt` key
- Every command references `.gemini/references/*.md`, which is how the stack-specific knowledge
  reaches the model without an agent to carry it
- Skills use the same cross-platform `SKILL.md` format as Claude, Copilot, OpenCode and Vibe; only
  the directory differs
- `.gemini/settings.json` wires the three hooks in `.gemini/hooks/`

**Expected Outcome**: the same six outputs as the other tracks. If a trainee reports thinner answers
than their Claude-using neighbour, the cause is usually the missing agent persona, not the model —
ask them to attach the relevant `references/` file explicitly.

### Exercise C10: Reference Usage

**Solution Location**: `resources/photo-gallery-fullstack-solution/.gemini/references/`

Reference files:

- `architecture.md` - System topology
- `domain-glossary.md` - Business terms
- `testing-guidelines.md` - Test patterns
- `coding-standards.md` - Code conventions
- `oncall.md` - Incident response

---

## Section D: Codex CLI Solutions

### Exercise D1: Project Trust & Configuration

**Solution Location**: `resources/photo-gallery-fullstack-solution/.codex/config.toml`

Key configuration:

```toml
model = "gpt-5-codex"
approval_policy = "on-request"
sandbox_mode = "workspace-write"
model_reasoning_effort = "medium"
```

### Exercise D2: AGENTS.md Discovery

**Solution Location**: `resources/photo-gallery-fullstack-solution/AGENTS.md`

The `AGENTS.md` file at project root is automatically read by Codex and provides:

- System architecture overview
- Available agents and their mappings across platforms
- Commands & prompts reference table
- Platform-specific setup instructions

### Exercise D3: Skills Exploration

**Solution Location**: `resources/photo-gallery-fullstack-solution/.codex/skills/`

Skill directories:

- `topology-awareness/SKILL.md` - Dependency mapping
- `change-impact-analysis/SKILL.md` - Risk assessment
- `incremental-refactoring/SKILL.md` - Safe refactoring steps
- `framework-conventions/SKILL.md` - NestJS/Angular patterns
- `debug-correlation/SKILL.md` - Root cause analysis

**Invocation**: `$topology-awareness` or implicit based on task description

### Exercise D4: Profile Switching

**Solution Location**: `resources/photo-gallery-fullstack-solution/.codex/config.toml`

Available profiles:

```toml
[profiles.deep-review]
model = "gpt-5-pro"
model_reasoning_effort = "high"

[profiles.lightweight]
model = "gpt-4.1"
approval_policy = "on-failure"

[profiles.architecture]
model_reasoning_effort = "high"

[profiles.testing]
model_reasoning_effort = "medium"

[profiles.code-review]
model_reasoning_effort = "high"
```

**Usage**: `codex --profile deep-review`

### Exercise D5-D7: API Analysis, Legacy Modernization, Test Strategy

**Key Patterns**:

- API changes → `$change-impact-analysis` skill
- Legacy refactoring → `$incremental-refactoring` skill with step-by-step plan
- Testing → `--profile testing` + `$framework-conventions` skill

### Exercise D8: Built-in Code Review

**Solution**: Use `/review` command or ask "Review the changes in my working tree"

Codex provides built-in code review without custom command configuration.

### Exercise D9: On-Call Debugging

**Solution**: Use `$debug-correlation` skill

```
$debug-correlation "High error rate on photo uploads"
```

Skill references `references/oncall.md` via the skill's references directory.

### Exercise D10: Custom Rules

**Solution Reference**: `~/.codex/rules/default.rules`

Example rules (Starlark syntax):

```starlark
prefix_rule(pattern=["npm", "run"], decision="allow")
prefix_rule(pattern=["git", "push"], decision="prompt")
prefix_rule(
  pattern=["rm", "-rf"],
  decision="forbidden",
  justification="Use git clean instead"
)
```

---

## Section E: OpenCode Solutions

### Exercise E1: Agent Discovery

**Solution Location**: `resources/photo-gallery-fullstack-solution/.opencode/agents/`

Five agent files, Markdown with frontmatter, same five roles as every other track:

- `architecture-guardian.md` - Validates architectural decisions against `references/architecture.md`
- `api-contract-agent.md` - Ensures API backward compatibility
- `legacy-modernizer.md` - Guides refactoring
- `test-strategist.md` - Plans test strategies from `references/testing-guidelines.md`
- `release-safety.md` - Validates deployment readiness

**Invocation**: `@architecture-guardian I need to add a photo filter feature...`

Identical to Claude Code. Press `Tab` to switch to Plan mode if you want the agent to plan before
touching files.

### Exercise E2: Command Exploration

**Solution Location**: `resources/photo-gallery-fullstack-solution/.opencode/command/`

> **Note the singular directory name**: `.opencode/command/`, not `commands/`. This trips people up,
> and the symptom is a silent one — the slash command simply does not appear.

Six commands: `trace-flow`, `prepare-pr`, `add-tests`, `migration-plan`, `explain-oncall`,
`code-reviewer`.

**Invocation**: `/trace-flow POST /api/photos/upload`

**Expected Outcome**: the full path from HTTP request through controller, service and repository,
with file paths and line numbers for the backend you picked.

### Exercise E3-E5: API Contract, Test Strategy, and Legacy Modernization

**Key Patterns**:

- `@api-contract-agent` reads `.opencode/references/architecture.md`. Adding an **optional** `tags`
  parameter is backward compatible — the agent should say so _and_ propose the OpenAPI schema update
- `@test-strategist` reads `.opencode/references/testing-guidelines.md`, then `/add-tests <path>`
  generates the suite. The path differs per backend; the agent does not guess it for you
- `@legacy-modernizer` applies the `incremental-refactoring` skill: one behaviour-preserving step at
  a time, suite green between each. Use Plan mode (`Tab`) first on the refactoring exercise

### Exercise E6: Skills Application

**Solution Location**: `resources/photo-gallery-fullstack-solution/.opencode/skills/`

Five skills in the cross-platform `SKILL.md` format: `topology-awareness`,
`change-impact-analysis`, `incremental-refactoring`, `framework-conventions`, `debug-correlation`.

> **Correction to the lab instructions**: exercise E6 tells you to review `.claude/skills/`. The
> skills are in fact shipped at `.opencode/skills/` in this project, so OpenCode finds them without
> depending on a Claude installation. Both locations work — OpenCode reads Claude-compatible skills
> — but point trainees at `.opencode/skills/`.

Asking _"If I change the PhotoRepository interface, what else will break?"_ activates
`change-impact-analysis` from context, with no explicit invocation.

### Exercise E7-E8: Release Readiness and On-Call

```
@release-safety Are we ready to deploy these changes to production?
/prepare-pr
/explain-oncall "High error rate on photo uploads"
```

**Key Patterns**:

- `release-safety` reads the staged diff, so `git add apps/` before asking — an empty stage produces
  a confidently empty assessment
- `/explain-oncall` reads `.opencode/references/oncall.md` for the escalation path and the known
  failure modes

### Exercise E9: TypeScript Plugin — Lifecycle Hook

**Solution Location**: `resources/photo-gallery-fullstack-solution/.opencode/plugins/coding-standards.ts`

This is the OpenCode-specific exercise. Where Claude Code configures hooks as JSON in
`settings.json` and Vibe uses TOML, OpenCode exports an **async plugin function returning lifecycle
handlers**:

- `tool.execute.before` — inspects the pending `edit`/`write` payload and `throw`s to block it
- `file.edited` — fires after the write, used here to log a reminder

Asking OpenCode to _"Add a temporary variable of type any to photo.service.ts"_ makes the plugin
throw before the edit lands.

**Why this matters beyond OpenCode**: the plugin reads `.opencode/references/coding-standards.md` at
load time and derives its rule from the document. The convention and its enforcement cannot drift
apart, because there is only one source. That pattern transfers to every other platform.

### Exercise E10: Session Sharing and Headless Mode

Two capabilities with no Claude Code equivalent in this form:

**Session sharing** — `/share` (or `ctrl+x s`) publishes the conversation at a public URL, so a
teammate reviews the analysis asynchronously without re-running it.

> ⚠️ **Say this out loud in the room**: `/share` makes the session **public**. Anything in the
> context window goes with it — file contents, paths, and whatever the agent read along the way. It
> is a fine tool for an open-source repo and a poor one for client code.

**Headless mode** — `opencode run "<prompt>"` returns the analysis on stdout with no TUI, which is
what makes it usable in CI:

```bash
opencode run "Check if staged files follow team coding standards and fail if violations are found"
```

Claude Code's equivalent is `claude -p`. The difference worth noting is that `opencode run` is the
documented primary path for CI rather than a print flag on an interactive tool.

## Section F: Mistral Vibe Solutions

### Exercise F1: Folder Trust & Configuration

**Solution Location**: `resources/photo-gallery-fullstack-solution/.vibe/config.toml`

TOML configuration is loaded once the folder is trusted (folder-trust prompt on first run; `vibe --setup` for interactive configuration):

```toml
[project]
trust = true

[agent]
permission_mode = "default"
agents_dir = ".vibe/agents"

[skills]
skills_dir = ".vibe/skills"
```

### Exercise F2: Agent Discovery

**Solution Location**: `resources/photo-gallery-fullstack-solution/.vibe/agents/`

Agent files (Markdown with `name`/`description`/optional `tools` frontmatter):

- `architecture-guardian.md` - Validates architectural decisions against `references/architecture.md`
- `api-contract-agent.md` - Ensures API backward compatibility
- `legacy-modernizer.md` - Guides callback-to-async refactoring
- `test-strategist.md` - Plans test strategies based on `references/testing-guidelines.md`
- `release-safety.md` - Validates deployment readiness

**Invocation**: `@architecture-guardian I need to add a photo filter feature...`

### Exercise F3: Slash Commands via the Skills System

**Solution Location**: `resources/photo-gallery-fullstack-solution/.vibe/skills/`

The unified skills system holds both reusable skills (model-invoked) and slash commands (user-invoked with `/`):

- Reusable skills: `topology-awareness`, `change-impact-analysis`, `incremental-refactoring`, `framework-conventions`, `debug-correlation`
- Slash commands: `trace-flow`, `prepare-pr`, `add-tests`, `migration-plan`, `explain-oncall`, `code-reviewer`

**Invocation**: `/trace-flow POST /api/photos/upload`

### Exercise F4-F7: API, Testing, Legacy Modernization, and Skills

**Key Patterns**:

- API Contract Agent references `.vibe/references/coding-standards.md` for validation rules
- Test Strategist uses `.vibe/references/testing-guidelines.md` for test patterns
- Legacy Modernizer applies the `incremental-refactoring` skill; use `plan` permission mode to review changes first
- Asking about interface changes auto-activates the `change-impact-analysis` skill

### Exercise F8: TOML Hooks

**Solution Location**: `resources/photo-gallery-fullstack-solution/.vibe/hooks.toml`

```toml
[[hooks.pre_tool_use]]
matcher = "shell"
command = "bash .vibe/hooks/validate-commit.sh"

[[hooks.pre_tool_use]]
matcher = "write"
command = "bash .vibe/hooks/validate-writes.sh"

[[hooks.post_tool_use]]
matcher = "write|edit"
command = "bash .vibe/hooks/validate-coding-standards.sh"
```

**Hook Scripts**: `.vibe/hooks/`

- `validate-commit.sh`
- `validate-writes.sh`
- `validate-coding-standards.sh`

A hook that exits non-zero blocks the associated action.

### Exercise F9: Reference Usage

**Solution Location**: `resources/photo-gallery-fullstack-solution/.vibe/references/`

Reference files:

- `architecture.md` - System topology
- `domain-glossary.md` - Business terms
- `testing-guidelines.md` - Test patterns
- `coding-standards.md` - Code conventions
- `oncall.md` - Incident response

### Exercise F10: ACP Mode & Session Continuation

**Solution Reference**:

- Session continuation: `vibe --continue` (resume most recent) or `vibe --resume` (pick a previous session)
- ACP mode: `vibe-acp` serves requests over the Agent Client Protocol for ACP-compatible editors/clients

---

## Cross-Platform Patterns

| Capability           | Claude Code                 | Codex CLI                     | GitHub Copilot                | Gemini CLI                  | Mistral Vibe              |
| -------------------- | --------------------------- | ----------------------------- | ----------------------------- | --------------------------- | ------------------------- |
| Agents               | `.claude/agents/*.md`       | Use skills                    | `.github/agents/*.agent.md`   | N/A (use skills)            | `.vibe/agents/*.md`       |
| Commands/Prompts     | `.claude/commands/*.md`     | `~/.codex/prompts/`           | `.github/prompts/*.prompt.md` | `.gemini/commands/*.toml`   | via skills system         |
| Skills               | `.claude/skills/*/SKILL.md` | `.codex/skills/*/SKILL.md`    | N/A (embedded)                | `.gemini/skills/*/SKILL.md` | `.vibe/skills/*/SKILL.md` |
| References           | `.claude/references/`       | In skills `references/`       | `.github/references/`         | `.gemini/references/`       | `.vibe/references/`       |
| Hooks/Rules          | `.claude/settings.json`     | `~/.codex/rules/*.rules`      | `.github/hooks/*.json`        | `.gemini/settings.json`     | `.vibe/hooks.toml`        |
| Settings             | `.claude/settings.json`     | `.codex/config.toml`          | VS Code settings              | `.gemini/settings.json`     | `.vibe/config.toml`       |
| Profiles             | N/A                         | `[profiles.*]` in config.toml | N/A                           | N/A                         | N/A                       |
| Plugins              | `.claude/plugins/`          | N/A                           | VS Code extensions            | N/A                         | N/A                       |
| Project Instructions | `CLAUDE.md`                 | `AGENTS.md` (auto-read)       | `copilot-instructions.md`     | `GEMINI.md`                 | `AGENTS.md` (auto-read)   |

## Key Takeaways

1. **Agent/Command Mastery**: Each platform has equivalent capabilities with different syntax
2. **Skill Awareness**: Skills are auto-invoked based on query context
3. **Reference Utilization**: Shared knowledge in `references/` folders guides agent behavior
4. **Platform Conventions**: File extensions and directory structures differ by platform
5. **Team Collaboration**: Configuration files are version-controlled and shareable

## Additional Resources

- [AGENTS.md](resources/photo-gallery-fullstack-solution/AGENTS.md) - Cross-platform reference + Codex project instructions
- [CLAUDE.md](resources/photo-gallery-fullstack-solution/CLAUDE.md) - Claude Code setup guide
- [GEMINI.md](resources/photo-gallery-fullstack-solution/GEMINI.md) - Gemini CLI setup guide
