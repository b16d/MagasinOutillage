const CODING_STANDARDS_REFERENCE = '.opencode/references/coding-standards.md';

export const CodingStandardsPlugin = async ({ client }) => {
  const referenceText = await Bun.file(
    new URL('../references/coding-standards.md', import.meta.url),
  ).text();

  return {
    'tool.execute.before': async (input, output) => {
      if (input.tool !== 'edit' && input.tool !== 'write') return;

      const content = `${output.args?.content ?? ''}\n${output.args?.newString ?? ''}`;
      if (referenceText.includes('### Avoid `any`') && /:\s*any\b|\bas\s+any\b/.test(content)) {
        throw new Error(
          `Coding standards violation: avoid \`any\` types. See ${CODING_STANDARDS_REFERENCE}.`,
        );
      }
    },

    'file.edited': async ({ path }) => {
      if (!path?.match(/\.(ts|tsx|js|jsx)$/)) return;

      await client.app.log({
        body: {
          service: 'coding-standards',
          level: 'info',
          message: `Review ${path} against ${CODING_STANDARDS_REFERENCE}.`,
        },
      });
    },
  };
};
