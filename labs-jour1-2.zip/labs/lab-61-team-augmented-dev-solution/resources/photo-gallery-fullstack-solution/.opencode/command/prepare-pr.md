---
description: Generate a comprehensive pull request description and checklist based on current staged changes
---

# Prepare PR

Generate a comprehensive pull request description and checklist based on current changes.

## Purpose

Automate PR documentation by analyzing staged changes and producing:
- Concise summary of changes
- Test coverage and strategy
- Deployment considerations
- Review checklist aligned with team standards

## Instructions

Analyze the staged changes to generate a PR description. Use the provided base branch if specified: $ARGUMENTS

Reference these team standards for the checklist:
@.opencode/references/coding-standards.md
@.opencode/references/testing-guidelines.md

## Output Format

The command will generate a complete PR description template:

```markdown
## Summary

[High-level description of what changed and why]

## Changes

- [Bullet point list of specific changes]
- [Include new features, refactorings, bug fixes]

## Testing Strategy

- **Unit Tests**: [Coverage for business logic changes]
- **Integration Tests**: [API or database interaction tests]
- **Manual Testing**: [Steps performed to validate]
- **Edge Cases**: [Specific scenarios tested]

## Deployment Notes

- **Database Migrations**: [Yes/No - details if applicable]
- **Configuration Changes**: [Environment variables, feature flags]
- **Dependencies**: [New packages or version bumps]
- **Rollback Plan**: [How to revert if issues arise]

## Review Checklist

- [ ] Code follows team conventions (coding-standards.md)
- [ ] Tests added/updated with adequate coverage
- [ ] API changes maintain backward compatibility
- [ ] Documentation updated (README, API docs, CHANGELOG)
- [ ] No sensitive data or secrets committed
- [ ] Performance impact considered and measured (if applicable)
- [ ] Security implications reviewed
- [ ] Breaking changes communicated to stakeholders

## Related Issues

- Closes #[issue-number]
- Related to #[issue-number]

## Screenshots / Demos

[If UI changes, add before/after screenshots or demo GIFs]
```

## Analysis Process

The command performs the following analysis:

1. **Git Diff Analysis**: Review staged changes to understand scope
2. **File Impact Assessment**: Identify which modules/layers are affected
3. **Test Coverage Check**: Determine if adequate test coverage exists
4. **Dependency Review**: Check for new dependencies or version changes
5. **Configuration Scan**: Identify environment or config file changes
6. **Breaking Change Detection**: Flag potential API contract violations

## Activation Triggers

- Reference `change-impact-analysis` skill for assessing affected components
- Consult `api-contract-agent` when API changes detected
- Reference `testing-guidelines.md` for test coverage standards
- Reference `coding-standards.md` for team conventions

## Example Scenarios

### Feature Addition
```
## Summary
Add bulk photo upload capability allowing users to upload up to 10 photos
simultaneously with client-side preview.

## Changes
- New `BulkUploadComponent` in `src/ui/components/`
- Enhanced `PhotoService.uploadMultiple()` with Promise.all
- Added unit tests for concurrent upload logic
- Updated API docs with new endpoint documentation

## Testing Strategy
- **Unit Tests**: 8 new tests for upload validation, error handling
- **Integration Tests**: 2 tests for concurrent uploads with test database
- **Manual Testing**: Verified with 1-10 photos, tested error scenarios
```

### Bug Fix
```
## Summary
Fix race condition in photo deletion that could leave orphaned S3 objects.

## Changes
- Wrapped deletion logic in transaction in `PhotoRepository.delete()`
- Added retry mechanism for S3 deletion failures
- Enhanced error logging

## Testing Strategy
- **Unit Tests**: Added test reproducing race condition
- **Integration Tests**: Verified transaction rollback on S3 failure
```

You generate actionable, complete PR descriptions that help reviewers quickly understand context and reviewers know exactly what to validate.
