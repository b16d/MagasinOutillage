# Photo Gallery - Team Augmented Development Agents

Cross-platform agent reference for Claude Code, GitHub Copilot, Gemini CLI, Codex CLI, OpenCode, and Mistral Vibe.

## Available Agents

### Architecture Guardian
**Role**: Validates design decisions against team architectural patterns
**Claude**: `@architecture-guardian` in `.claude/agents/`
**Copilot**: `@architecture-guardian` in `.github/agents/`
**Gemini**: Use `/trace-flow` command (no direct agent support)
**Codex**: Use `$topology-awareness` skill + AGENTS.md context
**OpenCode**: `@architecture-guardian` in `.opencode/agents/`
**Mistral Vibe**: `@architecture-guardian` in `.vibe/agents/`

**Use When**: Planning architectural changes, reviewing module boundaries

### API Contract Agent
**Role**: Ensures backward compatibility and proper API documentation
**Claude**: `@api-contract-agent`
**Copilot**: `@api-contract-agent`
**Codex**: Use `$change-impact-analysis` skill with API focus
**OpenCode**: `@api-contract-agent` in `.opencode/agents/`
**Mistral Vibe**: `@api-contract-agent` in `.vibe/agents/`

**Use When**: Modifying API endpoints, changing request/response schemas

### Legacy Modernizer
**Role**: Guides safe refactoring of legacy code
**Claude**: `@legacy-modernizer`
**Copilot**: `@legacy-modernizer`
**Codex**: Use `$incremental-refactoring` skill
**OpenCode**: `@legacy-modernizer` in `.opencode/agents/`
**Mistral Vibe**: `@legacy-modernizer` in `.vibe/agents/`

**Use When**: Refactoring callback-based code, modernizing patterns

### Test Strategist
**Role**: Recommends test strategies and identifies coverage gaps
**Claude**: `@test-strategist`
**Copilot**: `@test-strategist`
**Codex**: Use `--profile testing` + `$framework-conventions` skill
**OpenCode**: `@test-strategist` in `.opencode/agents/`
**Mistral Vibe**: `@test-strategist` in `.vibe/agents/`

**Use When**: Adding tests, planning test coverage, reviewing test quality

### Release Safety
**Role**: Validates release readiness and identifies deployment risks
**Claude**: `@release-safety`
**Copilot**: `@release-safety`
**Codex**: Use `/review` command + `$change-impact-analysis` skill
**OpenCode**: `@release-safety` in `.opencode/agents/`
**Mistral Vibe**: `@release-safety` in `.vibe/agents/`

**Use When**: Preparing production deployments, assessing rollback plans

## Commands & Prompts

| Command | Claude | Copilot | Gemini | Codex | OpenCode | Mistral Vibe | Purpose |
|---------|--------|---------|--------|-------|----------|--------------|---------|
| `/trace-flow` | ✅ | ✅ | ✅ | Use skill | ✅ | ✅ | Trace system flow end-to-end |
| `/prepare-pr` | ✅ | ✅ | ✅ | Use skill | ✅ | ✅ | Generate PR description & checklist |
| `/add-tests` | ✅ | ✅ | ✅ | Use skill | ✅ | ✅ | Generate comprehensive tests |
| `/migration-plan` | ✅ | ✅ | ✅ | Use skill | ✅ | ✅ | Plan incremental refactoring |
| `/explain-oncall` | ✅ | ✅ | ✅ | Use skill | ✅ | ✅ | On-call incident guidance |
| `/code-reviewer` | ✅ | ✅ | ✅ | `/review` | ✅ | ✅ | AI-assisted code review |

## Skills

Reusable capabilities shared across platforms:

- **topology-awareness**: Dependency mapping and impact analysis
- **change-impact-analysis**: Risk assessment for code changes
- **incremental-refactoring**: Safe, step-by-step refactoring plans
- **framework-conventions**: Enforce team coding patterns
- **debug-correlation**: Root cause analysis for production issues

## Platform-Specific Setup

### Claude Code
```bash
# Agents, commands, skills auto-discovered from .claude/ directory
# Invoke: @agent-name or /command-name
```

### GitHub Copilot
```bash
# Configure in .github/copilot-instructions.md
# Agents in .github/agents/*.agent.md
# Prompts in .github/prompts/*.prompt.md
```

### Gemini CLI
```bash
# Configure in .gemini/settings.json
# Commands in .gemini/commands/*.toml
# Invoke: /command-name
```

### Codex CLI
```bash
# Trust project first: codex trust .
# AGENTS.md read automatically at session start
# Skills in .agents/skills/*
# Profiles in .codex/config.toml
# Invoke: $skill-name or --profile <name>
```

### OpenCode
```bash
# Configure in opencode.json
# Agents in .opencode/agents/*.md
# Commands in .opencode/commands/*.md
# Skills in .opencode/skills/*.md
# Invoke: @agent-name or /command-name
```

### Mistral Vibe
```bash
# Trust project first: vibe (prompts to trust the folder)
# AGENTS.md read automatically for trusted folders
# Agents in .vibe/agents/
# Config in .vibe/config.toml; hooks in .vibe/hooks.toml
# Invoke: @agent-name or /command-name
```

## References

- **Architecture**: [references/architecture.md]
- **Domain Glossary**: [references/domain-glossary.md]
- **Testing Guidelines**: [references/testing-guidelines.md]
- **Coding Standards**: [references/coding-standards.md]
- **On-Call Guide**: [references/oncall.md]
