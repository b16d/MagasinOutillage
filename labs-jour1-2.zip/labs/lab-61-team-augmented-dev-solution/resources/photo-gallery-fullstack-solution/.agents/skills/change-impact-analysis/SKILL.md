---
name: change-impact-analysis
description: Assess the scope and risk of proposed code changes by analyzing affected components, blast radius, and potential side effects. Use when reviewing PRs or planning large refactorings.
---

# Change Impact Analysis

Assess the scope and risk of proposed code changes by analyzing affected components, blast radius, and potential side effects. This skill helps teams make informed decisions about change safety.

## Capabilities

### 1. Blast Radius Assessment
- Quantify how many files, modules, and services are affected
- Categorize changes by risk level (low/medium/high/critical)
- Identify cascading effects of a change

### 2. Risk Scoring
- Calculate risk based on change size, complexity, and affected components
- Flag high-risk changes requiring extra review or testing
- Recommend mitigation strategies proportional to risk

### 3. Side Effect Detection
- Identify unintended consequences of changes
- Flag performance implications
- Detect security or compliance impacts

## Usage Context

This skill activates when:
- Reviewing pull requests for approval
- Planning large refactorings or migrations
- Assessing deployment readiness
- Evaluating rollback complexity

## Risk Assessment Framework

### Risk Factors

| Factor | Weight | Criteria |
|--------|--------|----------|
| **Lines Changed** | 20% | <50 (low) / 50-200 (med) / 200-500 (high) / >500 (critical) |
| **Files Affected** | 15% | <5 (low) / 5-10 (med) / 10-20 (high) / >20 (critical) |
| **Test Coverage** | 25% | >80% (low) / 60-80% (med) / 40-60% (high) / <40% (critical) |
| **Critical Path** | 30% | Not on critical path (low) / Near critical (med) / On critical path (high) |
| **Rollback Ease** | 10% | Easy revert (low) / Config change (med) / DB migration (high) |

### Risk Categories

**LOW RISK** (Score: 0-30)
- Small, isolated changes
- High test coverage
- Easy to rollback

**MEDIUM RISK** (Score: 31-60)
- Moderate scope changes
- Adequate test coverage
- Standard rollback procedures

**HIGH RISK** (Score: 61-85)
- Large scope or critical path changes
- Test coverage gaps
- Complex rollback

**CRITICAL RISK** (Score: 86-100)
- Changes to payment, security, or data integrity systems
- Insufficient testing
- Irreversible changes

## Example Analysis

### Feature Addition (Low Risk)

**Change**: Add "favorite photos" feature

**Analysis**:
```
Scope:
  - Files: 8 (PhotoService, PhotoController, UI component, tests)
  - Lines: 230 (150 implementation + 80 tests)
  - Modules: 2 (API, UI)

Risk Factors:
  - New feature (no existing behavior modified)
  - 65% test coverage (unit + integration)
  - Not on critical path
  - Easy rollback via feature flag
  - Database migration (adds `favorites` table)

Overall Risk: LOW (Score: 28)

Recommendations:
  - Standard review process
  - Deploy with feature flag for gradual rollout
  - Monitor error rates for 24h post-deployment
```

## Integration with Other Skills

- **topology-awareness**: Identifies affected components
- **incremental-refactoring**: Plans low-risk refactoring steps
- **framework-conventions**: Ensures changes follow safe patterns

## Metrics

Success criteria for impact analysis:
- Accurately classifies 90%+ of changes by risk
- Zero high-risk changes deployed without appropriate safeguards
- Reduces production incidents by 30% through better risk assessment
