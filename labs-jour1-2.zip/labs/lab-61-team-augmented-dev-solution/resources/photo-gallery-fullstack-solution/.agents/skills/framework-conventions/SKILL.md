---
name: framework-conventions
description: Enforce team coding patterns and framework best practices. Use when writing new code, reviewing changes, or ensuring consistency across the codebase.
---

# Framework Conventions

Enforce team coding patterns and framework best practices. This skill ensures consistency across the codebase by providing convention guidance for Angular, NestJS, and TypeORM.

## Capabilities

### 1. Pattern Enforcement
- Suggest correct patterns for common tasks
- Flag anti-patterns and explain alternatives
- Ensure consistency with existing codebase

### 2. Framework-Specific Guidance
- Angular: Components, services, signals, routing
- NestJS: Controllers, services, modules, guards
- TypeORM: Entities, repositories, migrations

### 3. Code Style Verification
- Naming conventions (files, classes, methods)
- Directory structure compliance
- Import organization

## Convention Reference

### NestJS Backend Conventions

#### Controller Pattern
```typescript
@Controller('photos')
export class PhotosController {
  constructor(private readonly photoService: PhotoService) {}

  @Get(':id')
  async findOne(@Param('id') id: string): Promise<PhotoDto> {
    return this.photoService.findById(id);
  }

  @Post('upload')
  @UseInterceptors(FileInterceptor('file'))
  async upload(
    @UploadedFile() file: Express.Multer.File,
    @Body() body: UploadPhotoDto,
  ): Promise<PhotoDto> {
    return this.photoService.create(file, body);
  }
}
```

#### Service Pattern
```typescript
@Injectable()
export class PhotoService {
  constructor(
    @Inject(PHOTO_REPOSITORY)
    private readonly photoRepository: PhotoRepository,
  ) {}

  async findById(id: string): Promise<Photo> {
    const photo = await this.photoRepository.findById(id);
    if (!photo) {
      throw new NotFoundException(`Photo ${id} not found`);
    }
    return photo;
  }
}
```

#### Repository Pattern (Domain Layer)
```typescript
// Interface in domain layer
export interface PhotoRepository {
  findById(id: string): Promise<Photo | null>;
  save(photo: Photo): Promise<Photo>;
  delete(id: string): Promise<void>;
}

// Implementation in infrastructure layer
@Injectable()
export class TypeOrmPhotoRepository implements PhotoRepository {
  constructor(
    @InjectRepository(PhotoEntity)
    private readonly repo: Repository<PhotoEntity>,
  ) {}
}
```

### Angular Frontend Conventions

#### Component Pattern (Signals)
```typescript
@Component({
  selector: 'app-photo-gallery',
  standalone: true,
  imports: [CommonModule],
  template: `
    @for (photo of photos(); track photo.id) {
      <app-photo-card [photo]="photo" />
    }
  `,
})
export class PhotoGalleryComponent {
  private readonly photoService = inject(PhotoService);

  photos = signal<Photo[]>([]);
  loading = signal(false);

  async loadPhotos(): Promise<void> {
    this.loading.set(true);
    try {
      const photos = await this.photoService.getAll();
      this.photos.set(photos);
    } finally {
      this.loading.set(false);
    }
  }
}
```

#### Service Pattern
```typescript
@Injectable({ providedIn: 'root' })
export class PhotoService {
  private readonly http = inject(HttpClient);
  private readonly apiUrl = '/api/photos';

  getAll(): Observable<Photo[]> {
    return this.http.get<Photo[]>(this.apiUrl);
  }

  upload(file: File, metadata: PhotoMetadata): Observable<Photo> {
    const formData = new FormData();
    formData.append('file', file);
    formData.append('metadata', JSON.stringify(metadata));
    return this.http.post<Photo>(`${this.apiUrl}/upload`, formData);
  }
}
```

### File Naming Conventions

| Type | Pattern | Example |
|------|---------|---------|
| Component | `*.component.ts` | `photo-gallery.component.ts` |
| Service | `*.service.ts` | `photo.service.ts` |
| Controller | `*.controller.ts` | `photos.controller.ts` |
| Repository | `*.repository.ts` | `photo.repository.ts` |
| Entity | `*.entity.ts` | `photo.entity.ts` |
| DTO | `*.dto.ts` | `upload-photo.dto.ts` |
| Interface | `*.interface.ts` | `photo.repository.interface.ts` |
| Test | `*.spec.ts` | `photo.service.spec.ts` |

### Directory Structure

```
apps/backend-nestjs/src/
  api/                    # HTTP layer (controllers, DTOs)
    photos/
      photos.controller.ts
      dto/
        upload-photo.dto.ts
  domain/                 # Business logic
    services/
      photo.service.ts
    repositories/
      photo.repository.interface.ts
  infrastructure/         # Data access, external services
    repositories/
      typeorm-photo.repository.ts
    storage/
      legacy-storage.service.ts
```

## Common Anti-Patterns to Avoid

- **Fat Controllers**: Move business logic to services
- **Anemic Services**: Services should contain business logic, not just delegate
- **Direct Repository Access**: Use dependency injection via interfaces
- **Callback Patterns**: Prefer async/await over callbacks

## Integration with Other Skills

- **topology-awareness**: Ensures conventions apply across modules
- **change-impact-analysis**: Validates convention compliance in changes
- **incremental-refactoring**: Uses conventions as migration target

## Metrics

Success criteria:
- 95%+ of new code follows conventions
- Convention violations caught in code review
- Consistent patterns across all modules
