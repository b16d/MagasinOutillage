---
description: Analyze git diff for code changes and provide detailed summary of modifications
tools: ['search/codebase']
---

# /analyze-diff

Command for analyze-diff operations in the photo gallery project.

Refer to coding standards and architecture guidelines.

