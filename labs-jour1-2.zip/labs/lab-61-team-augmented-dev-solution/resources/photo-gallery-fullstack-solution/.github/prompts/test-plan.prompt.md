---
description: Create a comprehensive test plan including unit, integration, and E2E test strategies
tools: ['search/codebase']
---

# /test-plan

Command for test-plan operations in the photo gallery project.

Refer to coding standards and architecture guidelines.

