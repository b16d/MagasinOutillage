---
description: Guide safe incremental refactoring with backward compatibility preservation
tools: ['search/codebase']
---

# /safe-refactor

Command for safe-refactor operations in the photo gallery project.

Refer to coding standards and architecture guidelines.

