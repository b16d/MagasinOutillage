---
applyTo: '**/test_*.py,**/*_test.py'
---

# Testing Guidelines Instructions

Follow guidelines from references/testing-guidelines.md when writing test files.

## Key Points for Test Files

- **Test Runner**: pytest
- **Testing Pyramid**: 70% unit, 20% integration, 10% E2E
- **Coverage Target**: 80%+ for business logic

## Test Structure (AAA Pattern)

```python
def test_rejects_files_larger_than_5mb():
    # Arrange
    file = make_test_upload(size=6 * 1024 * 1024)

    # Act
    result = validate_photo_file(file)

    # Assert
    assert result.valid is False
    assert "5MB" in result.error
```

## File Size Validation Example

```python
def test_rejects_files_larger_than_5mb():
    file = make_test_upload(size=6 * 1024 * 1024, content_type="image/jpeg")

    result = validate_photo_file(file)

    assert result.valid is False
    assert "File size exceeds 5MB" in result.error
```

## FastAPI Router Testing

```python
def test_get_photos_returns_service_result(client: TestClient, mock_photo_service):
    mock_photo_service.get_photos.return_value = []

    response = client.get("/api/photos")

    assert response.status_code == 200
    assert response.json() == []
```

See [references/testing-guidelines.md](../references/testing-guidelines.md) for complete testing documentation.
