---
applyTo: '**'
---

# On-Call Instructions

Follow guidelines from references/oncall.md for incident response.

## Quick Reference

### Severity Levels

| Level | Response Time | Example |
|-------|--------------|---------|
| P0 - Critical | Immediate | Service outage |
| P1 - High | 15 minutes | Photo uploads failing |
| P2 - Medium | 1 hour | Slow performance |
| P3 - Low | Next day | Minor bugs |

## Common Photo Upload Issues

### High Error Rate on Uploads

**Quick Checks**:
1. Check file storage availability (`./dist/uploads/` for NestJS, `./uploads/` for the other stacks)
2. Check SQLite database connection
3. Check disk space on server
4. Review backend logs for errors

**Common Causes**:
- File size > 5MB (validation error)
- Invalid file type (not JPEG/PNG/GIF/WebP)
- Disk full
- Database locked

### Database Issues (SQLite)

**Symptoms**: "SQLITE_BUSY" or connection errors

**Resolution** — use the block matching the backend you're running:

<details>
<summary><strong>NestJS</strong></summary>

```bash
ls -la ./dist/db/photogallery.db
ls -la ./dist/db/*.lock
nx serve backend-nestjs
```

</details>

<details>
<summary><strong>Spring Boot</strong></summary>

```bash
ls -la ./data/photogallery.db
npm run serve:backend-spring
```

</details>

<details>
<summary><strong>FastAPI</strong></summary>

```bash
ls -la ./data/photogallery.db
npm run serve:backend-fastapi
```

</details>

<details>
<summary><strong>.NET</strong></summary>

```bash
ls -la ./data/photogallery.db
npm run serve:backend-dotnet
```

</details>

<details>
<summary><strong>Gin</strong></summary>

```bash
ls -la ./data/photogallery.db
npm run serve:backend-gin
```

</details>

### Frontend Loading Issues

**Quick Checks**:
1. Check API proxy configuration (`proxy.conf.json`)
2. Verify a backend is running on port 42621 (any of the 5 stacks — check which one via `nx graph` or the terminal that started it)
3. Check browser console for errors

See [references/oncall.md](../references/oncall.md) for complete on-call procedures.
