---
applyTo: '**'
---

# Coding Standards Instructions

Follow guidelines from references/coding-standards.md for consistent code style.

## Key Points

### TypeScript Naming

- **PascalCase**: Classes, interfaces, types, enums
- **camelCase**: Variables, functions, methods, properties
- **UPPER_SNAKE_CASE**: Constants
- **kebab-case**: File names, CSS classes

```typescript
const MAX_FILE_SIZE = 5 * 1024 * 1024; // 5MB
```

### Angular (Frontend)

- Use standalone components (no NgModules)
- Use Angular signals for state (`signal()`, `computed()`)
- Use `inject()` function for dependency injection

```typescript
@Component({
  standalone: true,
  imports: [CommonModule]
})
export class PhotoListComponent {
  private readonly photoService = inject(PhotoService);
  readonly selectedTags = signal<string[]>([]);
}
```

### Backend

Use the block that matches the backend running in this workspace:

<details>
<summary><strong>NestJS</strong></summary>

- Use decorators: `@Controller`, `@Get`, `@Post`, `@Injectable`
- Use TypeORM for database access
- Use DTOs with class-validator

```typescript
@Controller('api/photos')
export class PhotosController {
  constructor(private readonly photoService: PhotoService) {}

  @Get()
  async getPhotos(): Promise<Photo[]> {
    return this.photoService.getPhotos();
  }
}
```

</details>

<details>
<summary><strong>Spring Boot</strong></summary>

- Use `@RestController` with constructor injection (no field `@Autowired`)
- Use Spring Data JPA repositories for database access
- Use DTOs with Bean Validation (`@NotBlank`, `@Valid`)

```java
@RestController
@RequestMapping("/api/photos")
public class PhotosController {
    private final PhotoService photoService;

    public PhotosController(PhotoService photoService) {
        this.photoService = photoService;
    }

    @GetMapping
    public List<PhotoResponse> getPhotos() {
        return photoService.getPhotos();
    }
}
```

</details>

<details>
<summary><strong>FastAPI</strong></summary>

- Use `APIRouter` with `Depends()` for dependency injection
- Use SQLModel for database access via an injected `Session`
- Use Pydantic models with `alias_generator=to_camel` for camelCase JSON

```python
router = APIRouter(prefix="/api/photos")

@router.get("", response_model=list[Photo])
def get_photos(service: PhotoService = Depends(get_photo_service)) -> list[Photo]:
    return service.get_photos()
```

</details>

<details>
<summary><strong>.NET</strong></summary>

- Use `[ApiController]` with constructor-injected interfaces
- Use Entity Framework Core for database access via the repository pattern
- Use DTOs relying on `System.Text.Json`'s default camelCase policy

```csharp
[ApiController]
[Route("api/photos")]
public class PhotosController : ControllerBase
{
    private readonly IPhotoService _photoService;

    public PhotosController(IPhotoService photoService) => _photoService = photoService;

    [HttpGet]
    public async Task<IEnumerable<PhotoResponse>> GetPhotos() => await _photoService.GetPhotosAsync();
}
```

</details>

<details>
<summary><strong>Gin</strong></summary>

- Use `Handler` struct methods registered on the Gin router
- Use GORM for database access
- Use DTOs with explicit `json:` tags for camelCase JSON

```go
func (h *Handler) GetPhotos(c *gin.Context) {
	photos, err := h.service.GetPhotos(c.Request.Context())
	if err != nil {
		c.JSON(http.StatusInternalServerError, ErrorResponse{Message: err.Error()})
		return
	}
	c.JSON(http.StatusOK, ToResponseList(photos))
}
```

</details>

### File Organization

```
apps/
  backend-<stack>/       # backend-nestjs, backend-spring, backend-fastapi, backend-dotnet, or backend-gin
    api/...               # controllers/handlers + DTOs
    domain/...            # entities, models, services
    infrastructure/...    # storage, repository implementations
  frontend/src/app/
    components/
    services/
    models/
```

See [references/coding-standards.md](../references/coding-standards.md) for complete coding standards.
