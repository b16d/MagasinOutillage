---
applyTo: '**/*.spec.ts'
---

# Testing Guidelines Instructions

Follow guidelines from references/testing-guidelines.md when writing test files.

## Key Points for Test Files

- **Test Runner**: Vitest
- **Testing Pyramid**: 70% unit, 20% integration, 10% E2E
- **Coverage Target**: 80%+ for business logic

## Test Structure (AAA Pattern)

```typescript
it('should [expected behavior] when [condition]', () => {
  // Arrange: Set up test data
  const photo = createTestPhoto({ size: 6 * 1024 * 1024 });

  // Act: Execute the code under test
  const result = validatePhotoFile(photo);

  // Assert: Verify the outcome
  expect(result.valid).toBe(false);
  expect(result.error).toContain('5MB');
});
```

## File Size Validation Example

```typescript
describe('PhotoValidator', () => {
  it('should reject files larger than 5MB', () => {
    const file = { size: 6 * 1024 * 1024, type: 'image/jpeg' };
    const result = validatePhotoFile(file);

    expect(result.valid).toBe(false);
    expect(result.error).toContain('File size exceeds 5MB');
  });
});
```

## NestJS Controller Testing

```typescript
describe('PhotosController', () => {
  let controller: PhotosController;
  let mockPhotoService: Partial<PhotoService>;

  beforeEach(async () => {
    mockPhotoService = {
      getPhotos: vi.fn().mockResolvedValue([]),
      uploadPhoto: vi.fn(),
    };

    const module = await Test.createTestingModule({
      controllers: [PhotosController],
      providers: [
        { provide: PhotoService, useValue: mockPhotoService },
      ],
    }).compile();

    controller = module.get<PhotosController>(PhotosController);
  });
});
```

## Angular Signal Testing

```typescript
describe('PhotoListComponent', () => {
  it('should filter photos by selected tags', () => {
    const component = new PhotoListComponent();
    component.selectedTags.set(['vacation']);

    expect(component.filteredPhotos().length).toBe(1);
  });
});
```

This glob matches both NestJS backend specs and Angular frontend specs (both use Vitest + `.spec.ts`); see `testing-guidelines-<stack>.instructions.md` for the equivalent guidance if you chose a different backend.

See [references/testing-guidelines.md](../references/testing-guidelines.md) for complete testing documentation.
