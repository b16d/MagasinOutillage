# GitHub Copilot postToolUse hook: Validate file changes against coding-standards.md
# Reviews file changes and checks they follow the project's coding standards

$input = $input | ConvertFrom-Json
$filePath = $input.filePath ?? $input.file_path

if (-not $filePath -or -not (Test-Path $filePath)) {
    exit 0
}

# Only check TypeScript/JavaScript files
if ($filePath -notmatch "\.(ts|tsx|js|jsx)$") {
    exit 0
}

Write-Host "🔍 Validating against coding-standards.md..."

$content = Get-Content $filePath -Raw -ErrorAction SilentlyContinue
$violations = @()

# Check for console.log statements
if ($content -match "console\.log") {
    $violations += "- Remove console.log statements before committing"
}

# Check for any type usage
if ($content -match ": any") {
    $violations += "- Avoid using 'any' type - use proper TypeScript types"
}

# Check for TODO without ticket reference
if ($content -match "TODO[^:(]") {
    $violations += "- TODO comments should reference a ticket (e.g., TODO(TICKET-123))"
}

if ($violations.Count -gt 0) {
    Write-Host "⚠️ Coding standards suggestions:" -ForegroundColor Yellow
    $violations | ForEach-Object { Write-Host $_ -ForegroundColor Yellow }
} else {
    Write-Host "✅ File follows coding standards" -ForegroundColor Green
}

exit 0
