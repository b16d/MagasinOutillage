#!/usr/bin/env bash
# GitHub Copilot postToolUse hook: Validate file changes against coding-standards.md
# Reviews file changes and checks they follow the project's coding standards

# Read hook input from stdin
input=$(cat)

# Extract file path from tool input
file_path=$(echo "$input" | jq -r '.filePath // .file_path // ""')

# Skip if no file path
if [ -z "$file_path" ] || [ ! -f "$file_path" ]; then
  exit 0
fi

# Only check TypeScript/JavaScript files
if [[ ! "$file_path" =~ \.(ts|tsx|js|jsx)$ ]]; then
  exit 0
fi

echo "🔍 Validating against coding-standards.md..."

content=$(cat "$file_path" 2>/dev/null)
violations=""

# Check for console.log statements
if echo "$content" | grep -q "console\.log"; then
  violations="$violations\n- Remove console.log statements before committing"
fi

# Check for any type usage
if echo "$content" | grep -q ": any"; then
  violations="$violations\n- Avoid using 'any' type - use proper TypeScript types"
fi

# Check for TODO without ticket reference
if echo "$content" | grep -qE "TODO[^:(]"; then
  violations="$violations\n- TODO comments should reference a ticket (e.g., TODO(TICKET-123))"
fi

# Check for proper error handling in async functions
if echo "$content" | grep -qE "async.*\{" && ! echo "$content" | grep -qE "try\s*\{|\.catch\("; then
  violations="$violations\n- Async functions should have proper error handling (try/catch or .catch())"
fi

if [ -n "$violations" ]; then
  echo -e "⚠️ Coding standards suggestions:$violations"
else
  echo "✅ File follows coding standards"
fi

exit 0
