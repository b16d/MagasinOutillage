---
name: debug-correlation
description: Analyze error logs, stack traces, and system behavior to correlate symptoms with root causes. Use when analyzing production errors, debugging unexpected behavior, investigating performance degradation, or responding to on-call incidents.
---

# Debug Correlation Skill

## Purpose

Analyze error logs, stack traces, and system behavior to correlate symptoms with root causes. This skill helps developers and on-call engineers rapidly diagnose production issues.

## Capabilities

### 1. Error Pattern Recognition
- Identify common error signatures and their known causes
- Correlate errors across multiple log sources (application, infrastructure, database)
- Detect cascading failures originating from a single root cause

### 2. Root Cause Hypothesis
- Generate ranked hypotheses for error causes based on symptoms
- Suggest specific diagnostic commands or checks
- Reference past incidents with similar patterns

### 3. Contextual Analysis
- Cross-reference errors with recent deployments or configuration changes
- Identify environmental factors (high load, resource exhaustion)
- Correlate with known infrastructure issues

## Usage Context

This skill activates when:
- Analyzing production errors or alerts
- Debugging unexpected application behavior
- Investigating performance degradation
- Responding to on-call incidents

## Knowledge Sources

- **oncall.md**: Historical incident patterns and resolutions
- **architecture.md**: System dependencies and failure modes
- **Application logs**: Error messages, stack traces, request IDs

## Error Correlation Framework

### Severity Classification

| Severity | Impact | Example |
|----------|--------|---------|
| **P0 - Critical** | Complete service outage | "Database connection pool exhausted" |
| **P1 - High** | Major feature broken | "S3 upload failures affecting 50%+ users" |
| **P2 - Medium** | Degraded experience | "Slow query causing 2s page load" |
| **P3 - Low** | Minor issue | "Logging configuration error (non-user-facing)" |

### Correlation Patterns

#### Pattern 1: Connection Pool Exhaustion

**Symptoms**:
```
ERROR: Timeout waiting for connection from pool
at ConnectionPool.acquire (pool.ts:45)
```

**Likely Causes** (ranked by probability):
1. **Database connection leak** (70%): Connections not released after use
2. **Sudden traffic spike** (20%): Legitimate load exceeding pool capacity
3. **Database performance issue** (10%): Queries taking too long, holding connections

**Diagnostic Commands**:
```bash
# Check active connections
SELECT count(*) FROM pg_stat_activity WHERE state = 'active';

# Identify long-running queries
SELECT pid, query, state, query_start 
FROM pg_stat_activity 
WHERE state = 'active' AND query_start < now() - interval '5 minutes';

# Check application connection pool stats
curl localhost:3000/metrics | grep db_pool
```

**Resolution**:
- If connection leak: Deploy fix with proper connection release
- If traffic spike: Scale up connection pool temporarily
- If slow queries: Add indexes or optimize problematic queries

---

#### Pattern 2: Cascading Failure from External Dependency

**Symptoms**:
```
ERROR: S3 upload failed: Connection timeout
ERROR: Photo metadata save failed: Foreign key constraint
ERROR: Photo cleanup job stuck in retry loop
```

**Root Cause**: Single S3 outage causing cascading failures in dependent systems

**Correlation Analysis**:
```
Timeline:
14:23:15 - S3 upload timeout (root cause)
14:23:18 - Database insert fails (photo record expects S3 URL)
14:23:25 - Cleanup job fails (missing S3 object)
14:24:00 - Error rate reaches 85% (cascade complete)
```

**Mitigation**:
```typescript
// Add circuit breaker to prevent cascading failures
const circuitBreaker = new CircuitBreaker(s3Upload, {
  timeout: 5000,
  errorThresholdPercentage: 50,
  resetTimeout: 30000
});

// Fallback: Queue for async processing
if (circuitBreaker.isOpen()) {
  await uploadQueue.enqueue(file);
  return { status: 'queued', id: generateId() };
}
```

---

#### Pattern 3: Memory Leak

**Symptoms**:
```
WARN: Heap size approaching limit (1.8GB / 2GB)
ERROR: Process killed by OOM (Out of Memory) killer
INFO: Pod restarted (exit code 137)
```

**Diagnostic Approach**:
```bash
# Capture heap snapshot before crash
kill -USR2 <node-process-pid>  # Triggers heap dump

# Analyze with Chrome DevTools
# Look for: Retained objects, detached DOM nodes, large arrays

# Check for common leak sources:
grep -r "setInterval\|setTimeout" src/  # Uncleaned timers
grep -r "addEventListener" src/         # Uncleaned listeners
grep -r "subscribe" src/                # Uncleaned subscriptions
```

**Common Leak Sources**:
```typescript
// ❌ LEAK: Event listener never removed
componentDidMount() {
  window.addEventListener('resize', this.handleResize);
}

// ✅ FIX: Cleanup in unmount
componentWillUnmount() {
  window.removeEventListener('resize', this.handleResize);
}

// ❌ LEAK: Subscription never unsubscribed
this.photoService.updates$.subscribe(data => {
  this.setState({ photos: data });
});

// ✅ FIX: Store subscription and clean up
this.subscription = this.photoService.updates$.subscribe(...);
// Later: this.subscription.unsubscribe();
```

---

#### Pattern 4: Race Condition

**Symptoms**:
```
ERROR: Photo already exists (duplicate key)
ERROR: Photo not found (tried to delete before insert completed)
Intermittent failures that resolve on retry
```

**Correlation**:
```
Request A: Upload photo (14:23:15.234)
Request B: Upload same photo (14:23:15.298) ← 64ms overlap

Result: Both reach database insert → duplicate key error
```

**Resolution**:
```typescript
// Add idempotency key
async uploadPhoto(file: File, idempotencyKey: string) {
  // Check if already processed
  const existing = await this.cache.get(idempotencyKey);
  if (existing) return existing;
  
  // Acquire distributed lock
  const lock = await this.redisLock.acquire(`upload:${idempotencyKey}`);
  try {
    const result = await this.processUpload(file);
    await this.cache.set(idempotencyKey, result, 3600);
    return result;
  } finally {
    await lock.release();
  }
}
```

---

## Cross-Service Correlation

### Example: Distributed Tracing

**Scenario**: User reports "Photo upload stuck at 50%"

**Trace Analysis**:
```
Trace ID: 7f3a9c2d-1b4e-4f89-8a2c-9e7b3c6d5a1f

[Frontend] POST /api/photos/upload → 200 OK (350ms)
  [API Gateway] Auth check → 200 OK (12ms)
  [Photo Service] Process upload → 200 OK (325ms)
    [Image Processor] Resize → 200 OK (180ms)
    [S3 Client] Upload → TIMEOUT (5000ms) ← ROOT CAUSE
    [Fallback] Retry #1 → TIMEOUT (5000ms)
    [Fallback] Retry #2 → SUCCESS (280ms)
  [Database] Insert metadata → 200 OK (8ms)

Total: 10,618ms (user sees 50% stuck during S3 retries)
```

**Diagnosis**: S3 intermittent connectivity issues with auto-retry success

**Resolution**: Tune retry strategy and add client-side progress feedback during retries

---

## Integration with Other Skills

- **topology-awareness**: Uses dependency map to identify cascading failure points
- **change-impact-analysis**: Correlates errors with recent deployments
- **framework-conventions**: Recognizes framework-specific error patterns

## Activation Examples

```bash
# When on-call engineer pastes error:
ERROR: ECONNREFUSED redis://cache-primary:6379

# Skill activates and provides:
# "🔍 Root Cause Analysis:
#  Primary Hypothesis: Redis service down or network partition
#  
#  Diagnostic Steps:
#  1. Check Redis pod status: kubectl get pods -l app=redis
#  2. Check Redis logs: kubectl logs redis-primary
#  3. Test connectivity: kubectl exec api-pod -- redis-cli -h cache-primary PING
#  
#  Known Issues:
#  - Similar incident on 2025-12-15 (Redis OOM, resolved by increasing memory limit)
#  
#  Escalation: If Redis cluster down, page Platform Team (@platform-oncall)"
```

## Metrics

Success criteria for debug correlation:
- ✅ Mean-time-to-diagnosis (MTTD) reduced by 50%
- ✅ 80%+ of incidents resolved without escalation
- ✅ Root cause identified within 15 minutes for 90% of P1 incidents
