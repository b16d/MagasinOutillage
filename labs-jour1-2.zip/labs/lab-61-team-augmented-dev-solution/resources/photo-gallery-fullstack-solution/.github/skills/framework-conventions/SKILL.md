---
name: framework-conventions
description: Ensure consistent application of framework-specific patterns, idioms, and best practices. Use when creating new components, reviewing code for convention adherence, refactoring to adopt newer patterns, or onboarding new developers.
---

# Framework Conventions Skill

## Purpose

Ensure consistent application of framework-specific patterns, idioms, and best practices across the codebase. This skill acts as a living style guide that catches deviations from team conventions.

## Capabilities

### 1. Pattern Recognition
- Identify framework-specific patterns (dependency injection, lifecycle hooks, state management)
- Detect anti-patterns and code smells
- Suggest idiomatic alternatives

### 2. Convention Enforcement
- Validate naming conventions (components, services, utilities)
- Check file organization and module structure
- Ensure consistent use of framework APIs

### 3. Best Practice Guidance
- Recommend framework-specific optimizations
- Suggest appropriate hooks, decorators, or annotations
- Guide proper error handling and state management

## Usage Context

This skill activates when:
- Creating new components, services, or modules
- Reviewing code for convention adherence
- Refactoring to adopt newer framework patterns
- Onboarding new developers to team conventions

## Knowledge Sources

- **coding-standards.md**: Team-specific framework conventions
- **architecture.md**: Preferred architectural patterns
- **Framework documentation**: Official best practices

## Supported Frameworks

### Angular Conventions

#### Component Structure
```typescript
// ✅ CORRECT: Follows Angular component pattern
@Component({
  selector: 'app-photo-card',
  templateUrl: './photo-card.component.html',
  styleUrls: ['./photo-card.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush // Performance best practice
})
export class PhotoCardComponent implements OnInit, OnDestroy {
  @Input() photo!: Photo;
  @Output() photoClick = new EventEmitter<string>();
  
  constructor(
    private photoService: PhotoService,
    private cdr: ChangeDetectorRef
  ) {}
  
  ngOnInit(): void {
    // Initialization logic
  }
  
  ngOnDestroy(): void {
    // Cleanup logic (unsubscribe, etc.)
  }
}

// ❌ INCORRECT: Missing lifecycle cleanup
export class PhotoCardComponent {
  constructor(private photoService: PhotoService) {
    this.photoService.updates$.subscribe(data => {
      // Memory leak: no unsubscribe
    });
  }
}
```

#### Service Pattern
```typescript
// ✅ CORRECT: Injectable service with single responsibility
@Injectable({ providedIn: 'root' })
export class PhotoApiService {
  private readonly apiUrl = '/api/photos';
  
  constructor(private http: HttpClient) {}
  
  getPhoto(id: string): Observable<Photo> {
    return this.http.get<Photo>(`${this.apiUrl}/${id}`);
  }
  
  uploadPhoto(file: File): Observable<UploadResult> {
    const formData = new FormData();
    formData.append('file', file);
    return this.http.post<UploadResult>(this.apiUrl, formData);
  }
}

// ❌ INCORRECT: Missing providedIn (not tree-shakeable)
@Injectable()
export class PhotoApiService { }
```

---

### React Conventions (Hooks)

#### Functional Component Pattern
```typescript
// ✅ CORRECT: Hooks pattern with proper dependencies
export function PhotoCard({ photo }: Props) {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<Error | null>(null);
  
  // Memoize expensive computation
  const thumbnailUrl = useMemo(
    () => generateThumbnail(photo.url),
    [photo.url]
  );
  
  // Effect with cleanup
  useEffect(() => {
    const subscription = photoService.subscribe(photo.id);
    return () => subscription.unsubscribe();
  }, [photo.id]);
  
  const handleClick = useCallback(() => {
    setLoading(true);
    // Handle click
  }, []);
  
  return <div onClick={handleClick}>{/* ... */}</div>;
}

// ❌ INCORRECT: Missing dependency array (infinite loop risk)
useEffect(() => {
  fetchPhotos();
}); // Missing dependency array

// ❌ INCORRECT: Expensive computation on every render
const thumbnailUrl = generateThumbnail(photo.url); // Should use useMemo
```

#### Custom Hook Pattern
```typescript
// ✅ CORRECT: Reusable hook with clear naming
export function usePhotoUpload() {
  const [progress, setProgress] = useState(0);
  const [error, setError] = useState<Error | null>(null);
  
  const upload = useCallback(async (file: File) => {
    try {
      setProgress(0);
      const result = await photoService.upload(file, {
        onProgress: (p) => setProgress(p)
      });
      return result;
    } catch (err) {
      setError(err as Error);
      throw err;
    }
  }, []);
  
  return { upload, progress, error };
}

// Usage:
const { upload, progress } = usePhotoUpload();
```

---

### Node.js/Express Conventions

#### Controller Pattern
```typescript
// ✅ CORRECT: Async controller with error handling
export class PhotoController {
  constructor(private photoService: PhotoService) {}
  
  @Get('/:id')
  async getPhoto(req: Request, res: Response, next: NextFunction) {
    try {
      const photo = await this.photoService.findById(req.params.id);
      if (!photo) {
        return res.status(404).json({ error: 'Photo not found' });
      }
      return res.json(photo);
    } catch (error) {
      next(error); // Pass to error middleware
    }
  }
}

// ❌ INCORRECT: No error handling
async getPhoto(req: Request, res: Response) {
  const photo = await this.photoService.findById(req.params.id);
  res.json(photo); // Crashes on error
}
```

#### Middleware Pattern
```typescript
// ✅ CORRECT: Middleware with next() call
export function authMiddleware(
  req: Request,
  res: Response,
  next: NextFunction
) {
  const token = req.headers.authorization;
  
  if (!token) {
    return res.status(401).json({ error: 'Unauthorized' });
  }
  
  try {
    req.user = verifyToken(token);
    next(); // Continue to next middleware
  } catch (error) {
    return res.status(401).json({ error: 'Invalid token' });
  }
}

// ❌ INCORRECT: Missing next() call
export function authMiddleware(req: Request, res: Response) {
  if (!req.headers.authorization) {
    return res.status(401).json({ error: 'Unauthorized' });
  }
  // Missing next() - request hangs
}
```

---

## Naming Conventions

### Files and Directories

```
✅ CORRECT:
src/
  components/
    photo-card/
      photo-card.component.ts
      photo-card.component.spec.ts
      photo-card.component.html
  services/
    photo-api.service.ts
    photo-api.service.spec.ts
  models/
    photo.model.ts
    user.model.ts

❌ INCORRECT:
src/
  PhotoCard.tsx              // Wrong: PascalCase for file names
  photo-api-service.ts       // Wrong: Extra hyphen
  Services/                  // Wrong: PascalCase for directories
  photo.ts                   // Wrong: Missing type suffix (.model/.service)
```

### Classes and Functions

```typescript
// ✅ CORRECT: PascalCase for classes, camelCase for functions
export class PhotoService { }
export function validatePhoto(photo: Photo): boolean { }

// ❌ INCORRECT:
export class photoService { }        // Wrong: Should be PascalCase
export function ValidatePhoto() { }  // Wrong: Should be camelCase
```

### Constants and Enums

```typescript
// ✅ CORRECT: UPPER_SNAKE_CASE for constants
export const MAX_FILE_SIZE = 10 * 1024 * 1024;
export const API_BASE_URL = '/api/v1';

export enum PhotoStatus {
  PENDING = 'pending',
  APPROVED = 'approved',
  REJECTED = 'rejected'
}

// ❌ INCORRECT:
const maxFileSize = 10485760;        // Wrong: Should be UPPER_SNAKE_CASE
enum photoStatus { }                  // Wrong: Should be PascalCase
```

---

## Common Anti-Patterns

### 1. God Class/Component

```typescript
// ❌ ANTI-PATTERN: Component does too much
@Component({ /* ... */ })
export class PhotoGalleryComponent {
  // 500+ lines
  // Handles: fetching, filtering, sorting, upload, delete, export, sharing
}

// ✅ BETTER: Single Responsibility
@Component({ /* ... */ })
export class PhotoGalleryComponent {
  constructor(
    private photoService: PhotoService,      // Fetching
    private filterService: FilterService,    // Filtering
    private uploadService: UploadService     // Upload
  ) {}
}
```

### 2. Prop Drilling (React)

```typescript
// ❌ ANTI-PATTERN: Props passed through many levels
<App>
  <Layout user={user}>
    <Header user={user}>
      <UserMenu user={user} />
    </Header>
  </Layout>
</App>

// ✅ BETTER: Use Context or state management
const UserContext = createContext<User | null>(null);

<UserContext.Provider value={user}>
  <App>
    <Layout>
      <Header>
        <UserMenu /> {/* Uses useContext(UserContext) */}
      </Header>
    </Layout>
  </App>
</UserContext.Provider>
```

### 3. Callback Hell (Node.js)

```typescript
// ❌ ANTI-PATTERN: Nested callbacks
function uploadPhoto(file, callback) {
  validateFile(file, (err, valid) => {
    if (err) return callback(err);
    processImage(file, (err, processed) => {
      if (err) return callback(err);
      uploadToS3(processed, (err, url) => {
        if (err) return callback(err);
        saveMetadata(url, callback);
      });
    });
  });
}

// ✅ BETTER: Async/await
async function uploadPhoto(file: File): Promise<UploadResult> {
  await validateFile(file);
  const processed = await processImage(file);
  const url = await uploadToS3(processed);
  return saveMetadata(url);
}
```

---

## Integration with Other Skills

- **topology-awareness**: Applies conventions consistently across module boundaries
- **incremental-refactoring**: Guides refactoring toward conventional patterns
- **change-impact-analysis**: Flags convention violations in high-risk areas

## Activation Examples

```typescript
// When developer writes:
@Component({
  selector: 'photoCard', // Missing 'app-' prefix
  template: '<div>...</div>',
  changeDetection: ChangeDetectionStrategy.Default // Should use OnPush
})

// Skill activates and suggests:
// "⚠️ Convention Violation:
//  - Selector should be 'app-photo-card' (team prefix required)
//  - Consider ChangeDetectionStrategy.OnPush for performance
//  Reference: coding-standards.md § Angular Components"
```

## Metrics

Success criteria for framework conventions:
- ✅ 95%+ of code follows team conventions
- ✅ Convention violations caught in review before merge
- ✅ New developers productive within 1 week (conventions are clear and enforced)
