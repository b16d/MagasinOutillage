# /migration-plan

Generate a detailed, step-by-step plan for migrating legacy code or systems to modern patterns.

## Purpose

Assist developers in planning safe, incremental migrations by:
- Analyzing current state and identifying technical debt
- Proposing target architecture aligned with team standards
- Breaking migration into safe, testable increments
- Identifying risks and mitigation strategies

## Usage

Invoke this command with the code, module, or system to migrate:

```
/migration-plan src/legacy/photo-storage.service.ts
```

Or specify the migration type:

```
/migration-plan callback-to-async src/api/
/migration-plan class-based-to-functional src/ui/components/
```

## Output Format

The command will generate:

1. **Current State Analysis**: What exists today and why it needs migration
2. **Target Architecture**: What the modernized version should look like
3. **Migration Strategy**: Incremental steps with risk assessment
4. **Testing Approach**: How to validate each step
5. **Rollback Plan**: How to safely revert if issues arise

## Example Output

```markdown
# Migration Plan: Photo Storage Service (Callback → Async/Await)

## Current State Analysis

**File**: `src/legacy/photo-storage.service.ts` (287 lines)

### Issues Identified:
- Uses nested callbacks ("callback hell") making code hard to follow
- No error handling consistency across callbacks
- Difficult to test due to callback timing dependencies
- Violates team coding standards (async/await required)

### Dependencies:
- Called by: `PhotoController`, `BulkUploadService`, `PhotoCleanupJob`
- Depends on: `fs` (filesystem), `aws-sdk` (S3 client)

### Risk Assessment: **MEDIUM**
- Well-defined interface (existing callers won't need immediate changes)
- Adequate test coverage (67%) provides safety net
- Not on critical path (upload failures don't block other operations)

---

## Target Architecture

**Modernized**: `src/domain/services/photo-storage.service.ts`

### Design Goals:
- Use async/await throughout (no callbacks)
- Consistent error handling with custom error types
- Dependency injection for testability
- Type-safe interfaces using TypeScript

### Pattern:
```typescript
export class PhotoStorageService {
  constructor(
    private readonly s3Client: S3Client,
    private readonly fileSystem: FileSystem
  ) {}

  async upload(file: UploadFile): Promise<StorageResult> {
    try {
      const buffer = await this.fileSystem.readFile(file.path);
      const result = await this.s3Client.upload({
        Bucket: this.config.bucket,
        Key: file.key,
        Body: buffer
      });
      return { url: result.Location, key: result.Key };
    } catch (error) {
      throw new StorageUploadError(`Failed to upload ${file.key}`, error);
    }
  }
}
```

---

## Migration Strategy (6 Steps)

### Step 1: Add Characterization Tests
**Duration**: 2-3 hours  
**Risk**: LOW

1. Create `photo-storage.service.spec.ts` with tests documenting current behavior
2. Mock filesystem and S3 client
3. Test all callback paths (success, errors, edge cases)
4. Aim for 80%+ coverage before refactoring

**Validation**: All tests pass, coverage report shows 80%+

---

### Step 2: Extract Interface & Create Adapter
**Duration**: 1 hour  
**Risk**: LOW

1. Define `IPhotoStorageService` interface with async methods
2. Create `PhotoStorageAdapter` that wraps legacy callback-based service
3. Update DI container to inject adapter
4. No behavioral changes yet

```typescript
export interface IPhotoStorageService {
  upload(file: UploadFile): Promise<StorageResult>;
  download(key: string): Promise<Buffer>;
  delete(key: string): Promise<void>;
}

export class PhotoStorageAdapter implements IPhotoStorageService {
  constructor(private legacyService: LegacyPhotoStorage) {}

  async upload(file: UploadFile): Promise<StorageResult> {
    return new Promise((resolve, reject) => {
      this.legacyService.uploadCallback(file, (err, result) => {
        if (err) reject(err);
        else resolve(result);
      });
    });
  }
}
```

**Validation**: All tests still pass, runtime behavior unchanged

---

### Step 3: Implement Modern Service Alongside Legacy
**Duration**: 3-4 hours  
**Risk**: LOW (running in parallel, not replacing yet)

1. Create `PhotoStorageService` with async/await implementation
2. Add comprehensive unit tests for new service
3. Do NOT change callers yet (legacy still in use)
4. Feature flag to enable new service in staging

```typescript
export class PhotoStorageService implements IPhotoStorageService {
  // Modern async/await implementation
}
```

**Validation**: New service tests pass, no production impact

---

### Step 4: Gradual Rollout with Feature Flag
**Duration**: 1 week (monitoring period)  
**Risk**: MEDIUM (production traffic)

1. Deploy both services to production
2. Enable feature flag for 10% of requests
3. Monitor error rates, latency, logs
4. Gradually increase to 50%, then 100% over 1 week
5. Keep legacy service available for rollback

```typescript
const storageService = featureFlags.isEnabled('modern-storage')
  ? new PhotoStorageService(...)
  : new PhotoStorageAdapter(...);
```

**Validation**: Error rates unchanged, latency within SLA, no user reports

---

### Step 5: Update All Callers
**Duration**: 2-3 hours  
**Risk**: LOW (behavior already proven in production)

1. Remove feature flag logic
2. Update DI bindings to always use `PhotoStorageService`
3. Remove `PhotoStorageAdapter` wrapper
4. Deploy with standard release process

**Validation**: All integration tests pass, production metrics stable

---

### Step 6: Remove Legacy Code
**Duration**: 30 minutes  
**Risk**: LOW

1. Delete `src/legacy/photo-storage.service.ts`
2. Delete adapter and feature flag code
3. Update documentation

**Validation**: No references to legacy code remain, all tests pass

---

## Testing Approach

### Phase 1 (Characterization):
- Unit tests with mocked dependencies
- Test all code paths including error cases

### Phase 2 (Parallel Implementation):
- Unit tests for new service (80%+ coverage)
- Integration tests with real S3 and filesystem

### Phase 3 (Rollout):
- Canary deployments with monitoring
- A/B testing between old and new implementations

---

## Rollback Plan

- **Step 1-3**: No production impact, simply abandon branch
- **Step 4**: Disable feature flag to revert to legacy
- **Step 5-6**: Revert Git commit to restore legacy code

---

## Estimated Total Effort

- **Development**: 2-3 days
- **Testing & Validation**: 1 week (gradual rollout)
- **Documentation**: 2 hours

---

## Success Criteria

- ✅ All tests passing (legacy and modern)
- ✅ No increase in error rates or latency
- ✅ Code follows team standards (coding-standards.md)
- ✅ Documentation updated
- ✅ Legacy code removed
```

## Activation Triggers

- Consult `legacy-modernizer` agent for refactoring guidance
- Reference `incremental-refactoring` skill for step-by-step approach
- Reference `architecture.md` for target patterns
- Reference `testing-guidelines.md` for test coverage requirements

You break intimidating migrations into manageable, low-risk steps that teams can execute with confidence.
