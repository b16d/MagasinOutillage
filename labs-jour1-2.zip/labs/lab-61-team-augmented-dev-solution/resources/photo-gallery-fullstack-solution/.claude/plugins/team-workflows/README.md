# Team Workflows Plugin

Comprehensive team workflow automation plugin providing commands, agents, and skills for dependency analysis, changelog generation, security scanning, and performance monitoring in the Photo Gallery project.

## Features

### Commands
- `/team-workflows:analyze-dependencies` - Analyze project dependencies and identify outdated packages
- `/team-workflows:generate-changelog` - Auto-generate changelog from commit history
- `/team-workflows:security-scan` - Scan codebase for security vulnerabilities
- `/team-workflows:performance-review` - Profile application performance and identify bottlenecks

### Agents
- **Security Auditor** - Specialized agent for security analysis and vulnerability assessment
- **Performance Optimizer** - Agent focused on performance tuning and optimization recommendations
- **Dependency Tracker** - Agent managing dependency updates and compatibility checks

### Skills
- **Dependency Graph Analysis** - Visualize and analyze dependency relationships
- **Security Pattern Detection** - Identify common security anti-patterns
- **Performance Profiling** - Measure and analyze application performance metrics

### Hooks
- Pre-commit validation for security patterns
- Post-edit performance impact analysis

### MCP Servers
- **Changelog Server** - External tool integration for changelog management
- **Metrics Analyzer** - Performance metrics collection and analysis

## Installation

```bash
# Load plugin from local directory
claude --plugin-dir .claude/plugins/team-workflows
```

## Usage Examples

### Analyze Dependencies
```
/team-workflows:analyze-dependencies
```
Scans package.json and analyzes all project dependencies for updates, security issues, and compatibility.

### Generate Changelog
```
/team-workflows:generate-changelog --since v1.0.0
```
Creates structured changelog from git commit history since specified version.

### Security Scan
```
/team-workflows:security-scan --depth deep
```
Performs comprehensive security audit of codebase, checking for vulnerabilities and insecure patterns.

### Performance Review
```
/team-workflows:performance-review --component gallery
```
Profiles specified component and provides optimization recommendations.

## Configuration

Edit `.claude-plugin/plugin.json` to customize:
- `securityScanDepth`: "shallow" | "deep"
- `performanceThresholds.responseTime`: Maximum acceptable response time (ms)
- `performanceThresholds.memoryUsage`: Maximum memory usage (MB)

## Development

See individual directories for detailed documentation:
- `commands/` - Command implementations
- `agents/` - Agent definitions
- `skills/` - Reusable skill modules
- `hooks/` - Hook configurations
- `mcp-servers/` - MCP server configurations

## Sharing This Plugin

### With Your Team (Project Scope)

Add to your project's `.claude/settings.json`:
```json
{
  "enabledPlugins": [
    { "path": ".claude/plugins/team-workflows" }
  ]
}
```

Team members will be prompted to trust and enable the plugin when they open the project.

### Via Marketplace

To distribute this plugin more broadly, see [Create and distribute a plugin marketplace](https://code.claude.com/docs/en/plugin-marketplaces)
