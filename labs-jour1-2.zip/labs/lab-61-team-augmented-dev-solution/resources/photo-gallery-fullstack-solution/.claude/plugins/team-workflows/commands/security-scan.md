---
description: Perform comprehensive security audit of the codebase to identify vulnerabilities, insecure patterns, and compliance issues
allowed-tools: Bash(npm audit:*), Bash(grep:*), Read, Glob
argument-hint: [--depth shallow|deep] [--severity low|medium|high|critical]
---

# Security Scan

Perform comprehensive security audit of the codebase to identify vulnerabilities, insecure patterns, and compliance issues.

## Instructions

Run security analysis on the codebase. Parse any options from: $ARGUMENTS

Supported options:
- `--depth <value>`: "shallow" (dependencies only) or "deep" (code + dependencies) - default: "deep"
- `--scope <path>`: Limit scan to specific directory or file pattern
- `--severity <level>`: Minimum severity to report: "low", "medium", "high", "critical" - default: "medium"

## Scan Categories

### 1. Dependency Vulnerabilities
- Known CVEs in npm packages
- Outdated packages with security patches
- Malicious package detection

### 2. Code Security Patterns
- SQL injection vulnerabilities
- XSS (Cross-Site Scripting) risks
- Authentication/authorization issues
- Sensitive data exposure
- Insecure cryptography usage
- CSRF token validation

### 3. Configuration Issues
- Exposed secrets/API keys
- Insecure CORS policies
- Missing security headers
- Debug mode in production

### 4. Compliance Checks
- OWASP Top 10 coverage
- License compatibility
- Data privacy (GDPR/CCPA considerations)

## Output Format

```
Security Scan Report
====================

🔴 CRITICAL (2)
├─ [CVE-2023-12345] SQL Injection in user query
│  File: src/api/users.service.ts:45
│  Risk: User input directly interpolated in SQL query
│  Fix: Use parameterized queries
│  
└─ [SECRET-EXPOSURE] API key hardcoded in source
   File: src/config/api.config.ts:12
   Risk: Sensitive credential in version control
   Fix: Move to environment variables

🟠 HIGH (5)
├─ [XSS-001] Unescaped user input in template
│  File: src/components/UserProfile.tsx:23
│  Risk: Potential XSS via user bio field
│  Fix: Use sanitization library (DOMPurify)
│  
└─ ...

🟡 MEDIUM (12)
...

Summary:
- Critical: 2 issues (⚠️ Requires immediate action)
- High: 5 issues
- Medium: 12 issues
- Total vulnerabilities: 19

Recommendations:
1. Immediate: Fix critical issues before deployment
2. Consult security-auditor agent for remediation guidance
3. Enable pre-commit security hooks
```

## Integration with Skills

- Uses `security-pattern-detection` skill to identify anti-patterns
- Applies `dependency-graph-analysis` to trace vulnerability impact

## Integration with Agents

- Invokes `security-auditor` agent for detailed remediation strategies
- Can escalate critical findings to `release-safety` agent

## Hooks Integration

Configure pre-commit hook to run security scan automatically:
```json
{
  "pre-commit": {
    "enabled": true,
    "command": "security-scan",
    "args": ["--depth", "shallow", "--severity", "high"],
    "blockOnFailure": true
  }
}
```
