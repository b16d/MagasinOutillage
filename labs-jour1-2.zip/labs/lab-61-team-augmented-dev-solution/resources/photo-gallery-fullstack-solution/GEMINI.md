# Gemini CLI Setup Guide

## Prerequisites

- Gemini CLI installed
- Access to photo-gallery-team-augmented project

## Configuration Structure

```
.gemini/
├── settings.json           # Runtime configuration
├── commands/               # TOML command definitions
│   ├── trace-flow.toml
│   ├── prepare-pr.toml
│   ├── add-tests.toml
│   ├── migration-plan.toml
│   ├── explain-oncall.toml
│   └── code-reviewer.toml
├── hooks/                  # Shell script hooks
│   ├── validate-writes.sh  # Pre-commit validation
│   └── auto-test.sh        # Post-edit testing
├── skills/                 # Reusable capabilities
│   ├── topology-awareness/SKILL.md
│   ├── change-impact-analysis/SKILL.md
│   ├── incremental-refactoring/SKILL.md
│   ├── framework-conventions/SKILL.md
│   └── debug-correlation/SKILL.md
└── references/             # Shared knowledge
    ├── architecture.md
    ├── domain-glossary.md
    ├── testing-guidelines.md
    ├── coding-standards.md
    └── oncall.md
```

## Quick Start

1. Configure settings.json (MCP servers, tools, hooks, skills)
2. Invoke commands: `/code-reviewer`
3. Hooks execute automatically (pre-commit, post-edit)

## Example Usage

### Trace System Flow

```
/trace-flow POST /api/photos/upload
```

### Generate PR Description

```
/prepare-pr
```

### Get On-Call Guidance

```
/explain-oncall "High error rate on photo uploads"
```

## See Also

- [AGENTS.md](AGENTS.md) - Cross-platform agent reference
- [CLAUDE.md](CLAUDE.md) - Claude setup guide
