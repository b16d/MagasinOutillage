# Claude Code Setup Guide

## Prerequisites

- Claude Code CLI installed
- VS Code with Claude extension (optional)
- Access to photo-gallery-team-augmented project

## Configuration Structure

```
.claude/
├── settings.json           # Runtime configuration
├── agents/                 # Role-specific sub-agents
│   ├── architecture-guardian.md
│   ├── api-contract-agent.md
│   ├── legacy-modernizer.md
│   ├── test-strategist.md
│   └── release-safety.md
├── commands/               # Slash commands
│   ├── trace-flow.md
│   ├── prepare-pr.md
│   ├── add-tests.md
│   ├── migration-plan.md
│   ├── explain-oncall.md
│   └── code-reviewer.md
├── skills/                 # Reusable capabilities
│   ├── topology-awareness/SKILL.md
│   ├── change-impact-analysis/SKILL.md
│   ├── incremental-refactoring/SKILL.md
│   ├── framework-conventions/SKILL.md
│   └── debug-correlation/SKILL.md
├── references/             # Shared knowledge
│   ├── architecture.md
│   ├── domain-glossary.md
│   ├── testing-guidelines.md
│   ├── coding-standards.md
│   └── oncall.md
└── plugins/                # Custom plugins
    └── team-workflows/
```

## Quick Start

1. Navigate to project root
2. Configuration auto-loaded from `.claude/` directory
3. Invoke agents: `@architecture-guardian how should I structure this module?`
4. Invoke commands: `/code-reviewer` (analyzes current diff)

## Example Usage

### Consult Architecture Guardian

```
@architecture-guardian Should this feature live in the API or domain layer?
```

### Generate PR Description

```
/prepare-pr
```
(Analyzes staged changes and generates comprehensive PR template)

### Get Test Recommendations

```
@test-strategist What test strategy should I use for this service?
```

## See Also

- [AGENTS.md](AGENTS.md) - Cross-platform agent reference
- [GEMINI.md](GEMINI.md) - Gemini setup guide
