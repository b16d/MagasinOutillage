---
name: trace-flow
description: "Slash command (/trace-flow): Trace the complete execution flow for a specified API endpoint, user interaction, or system process."
---

# /trace-flow

Trace the complete execution flow for a specified API endpoint, user interaction, or system process.

## Purpose

Generate a comprehensive narrative explanation of how a request flows through the system, including:
- Entry point and routing
- Data transformations at each layer
- File storage operations
- Database interactions
- Response construction

## Usage

Invoke this command with a specific endpoint, feature, or flow identifier:

```
/trace-flow POST /api/photos/upload
```

## Output Format

The command will produce:

1. **High-Level Overview**: Summary of the complete flow in 2-3 sentences
2. **Detailed Step-by-Step Trace**: Chronological execution path with file references
3. **Data Transformations**: Key data shape changes at each layer
4. **Dependencies**: External services, databases, or storage involved
5. **ASCII Diagram**: Visual representation of the flow (when helpful for complex paths)

## Example Output

```
### Flow: POST /api/photos/upload

#### Overview
User uploads a photo via multipart form data. The system validates the file,
stores it to local disk, creates a database record in SQLite, and returns
the photo metadata. Every backend (NestJS/Spring/FastAPI/Gin) implements
this same flow behind the same OpenAPI contract.

#### Detailed Trace (backend-specific file paths shown for NestJS;
#### see "Key File Paths" below for Spring / FastAPI / Gin equivalents)

1. **HTTP Request** → controller/handler entry (e.g. NestJS
   `apps/backend-nestjs/src/api/photos/photos.controller.ts:uploadPhoto()`)
   - Framework multipart middleware processes form data
   - File validated: type (image/*), size (<5MB)
   - File saved to `./uploads/` with unique filename

2. **Service Layer** → domain service (`PhotoService.uploadPhoto`)
   - Creates a photo entity/record with metadata
   - Generates URL path `/uploads/<storedFilename>` for the uploaded file

3. **Persistence Layer** → ORM (TypeORM / Hibernate / SQLModel / GORM)
   - Inserts record into `photos` table in SQLite
   - Returns entity with generated ID

4. **Response** → `Photo` JSON (id as string, camelCase keys, ISO-8601 createdAt)

#### Dependencies
- Framework multipart parser (Multer / Spring MVC / Starlette / Gin)
- SQLite (metadata) via the backend's ORM
- Local disk (`./uploads/` — or `./dist/uploads/` for NestJS)

#### Diagram
Client → HTTP POST → Controller/Handler → Service
                          ↓                    ↓
                    Multipart parser      Repository
                          ↓                    ↓
                    ./uploads/            SQLite DB
                          ↓                    ↓
                          +--------------------+
                                   ↓
                            Photo Response (JSON)
```

## Activation Triggers

- Reference `topology-awareness` skill for dependency mapping
- Reference `architecture.md` for layer boundaries
- Cite actual file paths and line numbers when available
- Match file paths to the trainee's chosen backend

## Key File Paths

Frontend (always the same):

- **Service**: `apps/frontend/src/app/services/photo.service.ts`
- **API Service**: `apps/frontend/src/app/services/photo-api.service.ts`

Backend — depends on chosen stack:

<details>
<summary><strong>NestJS</strong></summary>

- **Controller**: `apps/backend-nestjs/src/api/photos/photos.controller.ts`
- **Service**: `apps/backend-nestjs/src/domain/services/photo.service.ts`
- **Entity**: `apps/backend-nestjs/src/domain/entities/photo.entity.ts`
- **Repository**: `apps/backend-nestjs/src/infrastructure/repositories/typeorm-photo.repository.ts`
- **Storage**: `apps/backend-nestjs/src/infrastructure/storage/legacy-storage.service.ts`

</details>

<details>
<summary><strong>Spring Boot</strong></summary>

- **Controller**: `apps/backend-spring/src/main/java/com/photogallery/backend/api/photos/PhotosController.java`
- **Service**: `apps/backend-spring/src/main/java/com/photogallery/backend/domain/service/PhotoService.java`
- **Entity**: `apps/backend-spring/src/main/java/com/photogallery/backend/infrastructure/entity/PhotoEntity.java`
- **Repository**: `apps/backend-spring/src/main/java/com/photogallery/backend/domain/repository/PhotoRepository.java`

</details>

<details>
<summary><strong>FastAPI</strong></summary>

- **Router**: `apps/backend-fastapi/app/api/photos.py`
- **Service**: `apps/backend-fastapi/app/domain/services.py`
- **Entity**: `apps/backend-fastapi/app/infrastructure/entities.py`
- **Storage**: `apps/backend-fastapi/app/infrastructure/storage.py`

</details>

<details>
<summary><strong>.NET (C#)</strong></summary>

- **Controller**: `apps/backend-dotnet/Api/Photos/PhotosController.cs`
- **Service**: `apps/backend-dotnet/Domain/Services/PhotoService.cs`
- **Entity**: `apps/backend-dotnet/Infrastructure/Entities/PhotoEntity.cs`
- **Repository**: `apps/backend-dotnet/Infrastructure/Repositories/EfPhotoRepository.cs`
- **Storage**: `apps/backend-dotnet/Infrastructure/Storage/DiskStorage.cs`

</details>

<details>
<summary><strong>Gin</strong></summary>

- **Handler**: `apps/backend-gin/internal/api/photos/handler.go`
- **Service**: `apps/backend-gin/internal/domain/service.go`
- **Entity**: `apps/backend-gin/internal/infrastructure/entity.go`
- **Repository**: `apps/backend-gin/internal/infrastructure/repository.go`

</details>
