# Module 6 : Développement augmenté en équipe

**Durée** : 155-165 minutes de lab pratique

## Vue d'ensemble

Ce lab montre comment passer à l'échelle le développement assisté par IA sur toute une équipe grâce à des configurations spécifiques à chaque plateforme. Vous travaillerez sur une application réaliste **photo-gallery-fullstack** (un workspace Nx contenant à la fois un projet frontend et un projet API) préconfigurée avec des agents, des commandes, des skills et des références pour six plateformes : Claude Code, GitHub Copilot, Gemini CLI, Codex CLI, OpenCode et Mistral Vibe.

Le backend est **au choix du stagiaire** : prenez NestJS (TypeScript — référence), Spring Boot (Java 17), FastAPI (Python 3.12), .NET (C# 12 / ASP.NET Core 8) ou Gin (Go 1.23). Les cinq implémentent le même contrat OpenAPI dans `docs/openapi.yaml` et sont interchangeables derrière le frontend Angular.

**Objectifs pédagogiques clés** :

- Appliquer des agents IA à l'échelle de l'équipe pour la validation d'architecture, les contrats d'API et la sûreté des releases
- Exploiter des skills réutilisables entre plusieurs développeurs et plateformes
- Mettre en place des conventions spécifiques à chaque plateforme (agents, prompts, hooks)
- Gérer la connaissance partagée via des références et des glossaires métier

## Structure du lab

Ce lab est organisé en six sections spécifiques à chaque plateforme. **Choisissez UNE plateforme** selon votre environnement :

- **Section A** : exercices Claude Code
- **Section B** : exercices GitHub Copilot
- **Section C** : exercices Gemini CLI
- **Section D** : exercices Codex CLI
- **Section E** : exercices OpenCode
- **Section F** : exercices Mistral Vibe

Chaque section contient 10 exercices progressifs qui couvrent les mêmes capacités avec la syntaxe propre à la plateforme.

## Instructions d'installation

### Prérequis

- Un accès à l'un de : Claude Code, GitHub Copilot, Gemini CLI, Codex CLI, OpenCode ou Mistral Vibe
- Node.js 22+ et npm (toujours requis — le frontend est en Angular)
- Git
- Outillage supplémentaire selon le backend choisi (voir **Options d'implémentation du backend** ci-dessous) :
  - **NestJS** — juste Node.js, aucun outillage supplémentaire
  - **Spring Boot** — JDK 17+ (Maven arrive via le wrapper)
  - **FastAPI** — Python 3.12+ et `uv` (ou `pip`)
  - **.NET** — SDK .NET 8
  - **Gin** — Go 1.23+

### Installation initiale

1. Placez-vous dans le répertoire du lab ou ouvrez-le dans votre IDE :

```bash
cd labs/lab-61-team-augmented-dev/photo-gallery-fullstack
```

2. Initialisez un dépôt Git dans ce répertoire :

```bash
git init
git add .
git commit -m "chore: initial commit"
```

3. Installez les dépendances :

```bash
npm ci
```

4. Parcourez la structure du projet :

   - `apps/frontend/` — application frontend Angular
   - `apps/backend-nestjs/` — backend NestJS (TypeScript, implémentation de référence)
   - `apps/backend-spring/` — backend Spring Boot (Java 17)
   - `apps/backend-fastapi/` — backend FastAPI (Python 3.12)
   - `apps/backend-dotnet/` — backend ASP.NET Core 8 (C# 12)
   - `apps/backend-gin/` — backend Gin (Go 1.23)
   - `docs/openapi.yaml` — contrat d'API HTTP canonique partagé par tous les backends

5. Choisissez un backend (voir **Options d'implémentation du backend** ci-dessous) et démarrez-le sur le port 42621. Le proxy du frontend cible ce port inconditionnellement, donc le frontend fonctionne avec n'importe lequel d'entre eux.

6. Parcourez la configuration de la plateforme :

   - **Utilisateurs Claude** : explorez le répertoire `.claude/`
   - **Utilisateurs Copilot** : explorez le répertoire `.github/`
   - **Utilisateurs Gemini** : explorez le répertoire `.gemini/`
   - **Utilisateurs Codex** : explorez le répertoire `.codex/` et `AGENTS.md`
   - **Utilisateurs OpenCode** : explorez le répertoire `.opencode/` et `AGENTS.md`
   - **Utilisateurs Mistral Vibe** : explorez le répertoire `.vibe/` et `AGENTS.md`

7. Parcourez la connaissance partagée :
   - [AGENTS.md](photo-gallery-fullstack/AGENTS.md) — référence d'agents multi-plateformes
   - [references/architecture.md](photo-gallery-fullstack/.claude/references/architecture.md)
   - [references/domain-glossary.md](photo-gallery-fullstack/.claude/references/domain-glossary.md)
   - [docs/openapi.yaml](photo-gallery-fullstack/docs/openapi.yaml) — contrat d'API que chaque backend doit respecter

---

## Options d'implémentation du backend

Choisissez **un** backend sur lequel travailler. Les cinq implémentent le même contrat OpenAPI et écoutent le port 42621. Les fichiers agent/skill/référence spécifiques à une stack dans `.claude/`, `.github/`, `.gemini/`, `.codex/`, `.opencode/` et `.vibe/` contiennent des sous-blocs par backend — ouvrez celui qui correspond à votre choix.

<details>
<summary><strong>Backend NestJS (TypeScript) — implémentation de référence</strong></summary>

**Lancer :**

```bash
cd labs/lab-61-team-augmented-dev/photo-gallery-fullstack
npm run serve:backend-nestjs
```

Swagger UI sur http://localhost:42621/api/docs. Voir [`docs/backends/nestjs.md`](photo-gallery-fullstack/docs/backends/nestjs.md).

</details>

<details>
<summary><strong>Backend Spring Boot (Java)</strong></summary>

**Lancer :**

```bash
cd labs/lab-61-team-augmented-dev/photo-gallery-fullstack/apps/backend-spring
./mvnw spring-boot:run
```

Swagger UI sur http://localhost:42621/api/docs. Voir [`docs/backends/spring.md`](photo-gallery-fullstack/docs/backends/spring.md).

</details>

<details>
<summary><strong>Backend FastAPI (Python)</strong></summary>

**Lancer :**

```bash
cd labs/lab-61-team-augmented-dev/photo-gallery-fullstack
npm run serve:backend-fastapi
```

Swagger UI sur http://localhost:42621/api/docs. Voir [`docs/backends/fastapi.md`](photo-gallery-fullstack/docs/backends/fastapi.md).

</details>

<details>
<summary><strong>Backend .NET (C#)</strong></summary>

**Lancer :**

```bash
cd labs/lab-61-team-augmented-dev/photo-gallery-fullstack
npm run serve:backend-dotnet
# or directly:
cd apps/backend-dotnet && dotnet run
```

Swagger UI sur http://localhost:42621/api/docs. Voir [`docs/backends/dotnet.md`](photo-gallery-fullstack/docs/backends/dotnet.md).

</details>

<details>
<summary><strong>Backend Gin (Go)</strong></summary>

**Lancer :**

```bash
cd labs/lab-61-team-augmented-dev/photo-gallery-fullstack
npm run serve:backend-gin
# or directly:
cd apps/backend-gin && go run ./cmd/server
```

Swagger UI sur http://localhost:42621/api/docs. Voir [`docs/backends/gin.md`](photo-gallery-fullstack/docs/backends/gin.md).

</details>

---

<details>
<summary><strong>Exercices Claude Code</strong></summary>

**Plateforme** : Claude Code
**Documentation** : [CLAUDE.md](photo-gallery-fullstack/CLAUDE.md)

### Exercice A1 : découverte des agents (10 min)

**Objectif** : vous familiariser avec les agents disponibles

1. Listez tous les agents configurés :

```bash
ls .claude/agents/
```

2. Lisez les définitions des agents :

   - `architecture-guardian.md` - validation de conception
   - `api-contract-agent.md` - compatibilité d'API
   - `legacy-modernizer.md` - guidage de refactoring
   - `test-strategist.md` - planification des tests
   - `release-safety.md` - aptitude au déploiement

3. **Examinez le frontmatter de l'agent** pour comprendre la configuration du modèle et de la couleur :

Jetez un œil au fichier `.claude/agents/architecture-guardian.md`

Remarquez le champ `model` (`opus`, `sonnet` ou `haiku`) qui détermine quel palier de modèle Claude traite les requêtes de l'agent, et le champ `color` qui fournit un identifiant visuel dans l'UI de Claude Code.

4. **Tâche** : interrogez l'Architecture Guardian sur l'ajout d'une nouvelle fonctionnalité :

```
@architecture-guardian I need to add a photo filter feature. Should this be in the API layer or domain layer?
```

**Résultat attendu** : l'agent analyse architecture.md et propose une recommandation de couche

### Exercice A2 : exploration des commandes (15 min)

**Objectif** : comprendre les commandes disponibles

1. Parcourez les définitions de commandes dans `.claude/commands/` :

   - `/trace-flow` - traçage de flux de bout en bout
   - `/prepare-pr` - génération de description de PR
   - `/add-tests` - génération de tests
   - `/migration-plan` - planification de refactoring
   - `/explain-oncall` - réponse à incident
   - `/code-reviewer` - analyse de diff

2. **Tâche** : tracez le flux d'upload de photo :

```
/trace-flow POST /api/photos/upload
```

**Résultat attendu** : flux complet de la requête HTTP → contrôleur → service → repository avec chemins de fichiers et numéros de ligne

### Exercice A3 : validation du contrat d'API (20 min)

**Objectif** : utiliser l'API Contract Agent pour garantir la rétrocompatibilité

1. Ouvrez le fichier du backend que vous avez choisi et modifiez l'endpoint `uploadPhoto` pour ajouter un nouveau paramètre optionnel `tags` :

<details>
<summary><strong>Backend NestJS (TypeScript)</strong> — <code>apps/backend-nestjs/src/api/photos/photos.controller.ts</code></summary>

```typescript
async uploadPhoto(
  @UploadedFile(
    new ParseFilePipe({
      validators: [
        new MaxFileSizeValidator({ maxSize: 5 * 1024 * 1024 }), // 5MB
        new FileTypeValidator({
          fileType: /image\/(jpeg|png|gif|webp)/,
          fallbackToMimetype: true,
        }),
      ],
    }),
  )
  file: Express.Multer.File,
  @Body('tags') tags?: string,  // NEW: optional tags to add
): Promise<Photo> {
  const tagsList = tags ? tags.split(',').map(t => t.trim()).filter(Boolean) : [];
  // pass along the parsed tags to the service layer (instead of `[]`)
  return this.photoService.uploadPhoto(file, tagsList);
}
```

</details>

<details>
<summary><strong>Backend Spring Boot (Java)</strong> — <code>apps/backend-spring/src/main/java/com/photogallery/backend/api/photos/PhotosController.java</code></summary>

```java
@PostMapping(path = "/upload", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
@ResponseStatus(HttpStatus.CREATED)
public PhotoResponse uploadPhoto(
    @RequestParam("file") MultipartFile file,
    @RequestParam(value = "tags", required = false) String tags  // NEW: optional tags to add
) {
  List<String> tagsList = parseTags(tags);
  // pass along the parsed tags to the service layer (instead of `List.of()`)
  Photo photo = photoService.uploadPhoto(file, tagsList);
}
```

</details>

<details>
<summary><strong>Backend FastAPI (Python)</strong> — <code>apps/backend-fastapi/app/api/photos.py</code></summary>

```python
async def upload_photo(
    service: ServiceDep,
    file: Annotated[UploadFile, File(description="Image file (JPEG/PNG/GIF/WebP), max 5MB")],
    tags: Annotated[str | None, Form(description="Comma-separated tag list")] = None,  # NEW
) -> Photo:
  tagsList = _parse_tags(tags) if tags else []
  # pass along the parsed tags to the service layer (instead of `[]`)
  return service.upload_photo(
    original_filename=file.filename or "upload",
    data=data,
    tags=tagsList,
  )
```

</details>

<details>
<summary><strong>Backend .NET (C#)</strong> — <code>apps/backend-dotnet/Api/Photos/PhotosController.cs</code></summary>

```csharp
/// <summary>
/// Upload a new photo.
/// </summary>
[HttpPost("upload")]
[Consumes("multipart/form-data")]
[RequestSizeLimit(MaxUploadBytes)]
[ProducesResponseType(typeof(PhotoResponse), StatusCodes.Status201Created)]
[ProducesResponseType(typeof(ErrorEnvelope), StatusCodes.Status400BadRequest)]
public async Task<ActionResult<PhotoResponse>> UploadPhoto(
    [FromForm] UploadPhotoDto dto,
    CancellationToken cancellationToken)
{
   // ... existing validation ...
  var tagsList = ParseTags(dto.Tags);
  // pass along the parsed tags to the service layer (instead of ` new List<string>()`)
  var photo = await _photoService.UploadPhotoAsync(uploaded, tagsList, cancellationToken);
  // ...
}
```

</details>

<details>
<summary><strong>Backend Gin (Go)</strong> — <code>apps/backend-gin/internal/api/photos/handler.go</code></summary>

```go
func (h *Handler) Upload(c *gin.Context) {
    fileHeader, err := c.FormFile("file")

    // ... existing validation ...
    tagsList := parseTags(c.PostForm("tags"))  // NEW: optional tags to add
    // pass along the parsed tags to the service layer (instead of `[]string{}`)
    photo, err := h.service.UploadPhoto(c.Request.Context(), domain.UploadedFile{
      OriginalName:   fileHeader.Filename,
      StoredFilename: storedFilename,
      Size:           fileHeader.Size,
    }, tagsList)
}
```

</details>

2. **Tâche** : consultez l'API Contract Agent :

```
@api-contract-agent I've added an optional 'tags' query parameter to POST /api/photos/upload. Is this backward compatible?
```

3. Générez la mise à jour de la documentation OpenAPI :

```
/code-reviewer
```

**Résultat attendu** : l'agent valide la rétrocompatibilité et suggère des mises à jour du schéma OpenAPI

### Exercice A4 : consultation de la stratégie de test (20 min)

**Objectif** : exploiter le Test Strategist pour planifier les tests

1. Ouvrez le PhotoService de votre backend :

<details>
<summary><strong>NestJS (TypeScript)</strong></summary>

`apps/backend-nestjs/src/domain/services/photo.service.ts`

</details>
<details>
<summary><strong>Spring Boot (Java)</strong></summary>

`apps/backend-spring/src/main/java/com/photogallery/backend/domain/service/PhotoService.java`

</details>
<details>
<summary><strong>FastAPI (Python)</strong></summary>

`apps/backend-fastapi/app/domain/services.py`

</details>
<details>
<summary><strong>.NET (C#)</strong></summary>

`apps/backend-dotnet/Domain/Services/PhotoService.cs`

</details>
<details>
<summary><strong>Gin (Go)</strong></summary>

`apps/backend-gin/internal/domain/service.go`

</details>

2. **Tâche** : interrogez le Test Strategist sur le test d'une nouvelle méthode :

```
@test-strategist I'm adding a generateThumbnail method to PhotoService. What test strategy should I use?
```

3. Générez les tests avec la commande :

<details>
<summary><strong>NestJS (TypeScript)</strong></summary>

```
/add-tests apps/backend-nestjs/src/domain/services/photo.service.ts
```

</details>
<details>
<summary><strong>Spring Boot (Java)</strong></summary>

```
/add-tests apps/backend-spring/src/main/java/com/photogallery/backend/domain/service/PhotoService.java
```

</details>
<details>
<summary><strong>FastAPI (Python)</strong></summary>

```
/add-tests apps/backend-fastapi/app/domain/services.py
```

</details>
<details>
<summary><strong>.NET (C#)</strong></summary>

```
/add-tests apps/backend-dotnet/Domain/Services/PhotoService.cs
```

</details>
<details>
<summary><strong>Gin (Go)</strong></summary>

```
/add-tests apps/backend-gin/internal/domain/service.go
```

</details>

**Résultat attendu** : recommandation de stratégie de test (unitaire + intégration), fichier de test généré avec une couverture complète

### Exercice A5 : modernisation du legacy (25 min)

**Objectif** : refactorer sans risque du code legacy à base de callbacks

1. Localisez le code de stockage/legacy de votre backend :

<details>
<summary><strong>NestJS (TypeScript) — code legacy à base de callbacks</strong></summary>

`apps/backend-nestjs/src/infrastructure/storage/legacy-storage.service.ts`

</details>
<details>
<summary><strong>Spring Boot (Java)</strong></summary>

`apps/backend-spring/src/main/java/com/photogallery/backend/domain/service/PhotoService.java` — cherchez les patterns synchrones bloquants à moderniser

</details>
<details>
<summary><strong>FastAPI (Python)</strong></summary>

`apps/backend-fastapi/app/infrastructure/storage.py` — cherchez les I/O synchrones à convertir en async

</details>
<details>
<summary><strong>.NET (C#)</strong></summary>

`apps/backend-dotnet/Infrastructure/Storage/DiskStorage.cs`

</details>
<details>
<summary><strong>Gin (Go)</strong></summary>

`apps/backend-gin/internal/infrastructure/storage.go`

</details>

2. **Tâche** : demandez un plan de migration :

```
@legacy-modernizer I need to modernize legacy-storage.service.ts from callbacks to async/await. What's the safest approach?
```

3. Exécutez le plan :

<details>
<summary><strong>NestJS (TypeScript)</strong></summary>

```
/migration-plan apps/backend-nestjs/src/infrastructure/storage/legacy-storage.service.ts
```

</details>
<details>
<summary><strong>Spring Boot (Java)</strong></summary>

```
/migration-plan apps/backend-spring/src/main/java/com/photogallery/backend/domain/service/PhotoService.java
```

</details>
<details>
<summary><strong>FastAPI (Python)</strong></summary>

```
/migration-plan apps/backend-fastapi/app/infrastructure/storage.py
```

</details>
<details>
<summary><strong>.NET (C#)</strong></summary>

```
/migration-plan apps/backend-dotnet/Infrastructure/Storage/DiskStorage.cs
```

</details>
<details>
<summary><strong>Gin (Go)</strong></summary>

```
/migration-plan apps/backend-gin/internal/infrastructure/storage.go
```

</details>

**Résultat attendu** : plan de refactoring incrémental étape par étape avec évaluation des risques et stratégie de rollback

### Exercice A6 : Application des skills (15 min)

**Objectif** : Comprendre les skills réutilisables

1. Examiner les définitions de skills dans `.claude/skills/` :

   - `topology-awareness` - Cartographie des dépendances
   - `change-impact-analysis` - Évaluation des risques
   - `incremental-refactoring` - Refactoring sûr
   - `framework-conventions` - Application des patterns
   - `debug-correlation` - Analyse de cause racine

2. **Tâche** : Appliquer l'analyse d'impact de changement à un changement hypothétique :

```
"If I change the PhotoRepository interface, what else will break?"
```

(L'agent doit invoquer automatiquement le skill `change-impact-analysis`)

**Résultat attendu** : Liste des fichiers, classes et tests impactés

### Exercice A7 : Contrôle de préparation à la release (20 min)

**Objectif** : Valider la préparation au déploiement avec l'agent Release Safety

1. Indexer les modifications pour une release hypothétique :

```bash
git add apps/
```

2. **Tâche** : Consulter l'agent Release Safety :

```
@release-safety Are we ready to deploy these changes to production?
```

3. Générer la checklist de release :

```
/prepare-pr
```

**Résultat attendu** : Évaluation de la préparation à la release avec risques de déploiement, plan de rollback, recommandations de monitoring

### Exercice A8 : Scénario d'astreinte (15 min)

**Objectif** : S'entraîner à la réponse à incident avec l'assistance de l'IA

**Scénario** : Alerte en production - « Taux d'erreur élevé sur les uploads de photos »

1. **Tâche** : Obtenir des conseils d'astreinte :

```
/explain-oncall "High error rate on photo uploads"
```

2. Utiliser le skill de corrélation de debug :

```
"What are the most common causes of upload failures based on the architecture?"
```

**Résultat attendu** : Checklist de diagnostic, causes racines courantes issues de oncall.md, étapes d'investigation suggérées

### Exercice A9 : Hook de pre-commit (10 min)

**Objectif** : Configurer la validation automatisée

1. Examiner la configuration des hooks de `.claude/settings.json` :

```json
"hooks": {
  "PreToolUse": [
    {
      "matcher": "Bash",
      "hooks": [
        {
          "type": "prompt",
          "prompt": "Run code-reviewer on staged files. Check if this Bash command is a git commit. If so, verify the staged files follow coding standards before allowing the commit. Input: $ARGUMENTS"
        }
      ]
    }
  ],
  "PostToolUse": [
    {
      "matcher": "Write|Edit",
      "hooks": [
        {
          "type": "prompt",
          "prompt": "Validate against coding-standards.md. Review the file changes and check they follow the project's coding standards. Input: $ARGUMENTS"
        }
      ]
    }
  ]
}
```

2. **Tâche** : Faire une modification de code qui viole les standards de code et observer le comportement du hook

**Résultat attendu** : Le hook post-édition valide les modifications au regard des standards de code ; le hook de pre-commit relit les fichiers indexés avant les commits git

### Exercice A10 : Utilisation des plugins d'équipe (15 min)

**Objectif** : Installer, charger et utiliser des plugins de workflow d'équipe personnalisés

#### Partie 1 : Charger un plugin local (5 min)

1. **Démarrer Claude Code avec le plugin chargé** :

   ```bash
   cd photo-gallery-fullstack
   claude --plugin-dir .claude/plugins/team-workflows
   ```

2. **Vérifier que le plugin est chargé** - Lancer `/help` et chercher les commandes préfixées par `team-workflows:`

3. **Lancer une commande du plugin** (noter le séparateur de namespace `:`) :
   ```
   /team-workflows:analyze-dependencies
   ```
   **Attendu** : Analyse des dépendances du projet avec recommandations

#### Partie 2 : Explorer les composants du plugin (5 min)

4. **Examiner la structure du plugin** dans `.claude/plugins/team-workflows/` :

   - `.claude-plugin/plugin.json` - Manifeste du plugin (nom, version, description)
   - `commands/` - Commandes slash (analyze-dependencies, generate-changelog, etc.)
   - `agents/` - Sous-agents (security-auditor, performance-optimizer)
   - `skills/` - Capacités réutilisables avec fichiers SKILL.md
   - `hooks/` - Gestionnaires d'événements (hooks.json)

5. **Essayer d'autres commandes du plugin** :
   ```
   /team-workflows:security-scan
   /team-workflows:performance-review
   ```

#### Partie 3 : Découvrir les plugins de la marketplace (5 min)

6. **Ouvrir le gestionnaire de plugins** : `/plugin`

   - Naviguer entre les onglets avec Tab/Shift+Tab : Discover | Installed | Marketplaces | Errors

7. **Parcourir la marketplace officielle** (onglet Discover) :

   - Intelligence de code : typescript-lsp, pyright-lsp, rust-analyzer-lsp
   - Intégrations : github, slack, notion, linear
   - Workflows : commit-commands, pr-review-toolkit

8. **(Optionnel) Installer un plugin de la marketplace** :
   ```
   /plugin install commit-commands@claude-plugins-official
   ```

**Points clés** :

- Plugins locaux : `claude --plugin-dir <path>`
- Namespace de commande : `/plugin-name:command-name`
- Marketplaces : `/plugin` pour parcourir et installer
- Portées de plugin : user (défaut), project (partagé), local (gitignoré)

</details>

---

<details>
<summary><strong>Exercices GitHub Copilot</strong></summary>

**Plateforme** : GitHub Copilot  
**Documentation** : [AGENTS.md](photo-gallery-fullstack/AGENTS.md)

### Exercice B1 : Découverte des agents (10 min)

**Objectif** : Se familiariser avec les agents Copilot

1. Examiner les définitions d'agents dans `.github/agents/` :

   - `architecture-guardian.agent.md`
   - `api-contract-agent.agent.md`
   - `legacy-modernizer.agent.md`
   - `test-strategist.agent.md`
   - `release-safety.agent.md`

2. **Tâche** : Interroger l'Architecture Guardian :

```
@architecture-guardian I need to add a photo filter feature. Should this be in the API layer or domain layer?
```

**Résultat attendu** : L'agent référence `.github/instructions/architecture.instructions.md` et fournit une recommandation

### Exercice B2 : Exploration des prompts (15 min)

**Objectif** : Comprendre les prompts disponibles

1. Examiner les définitions de prompts dans `.github/prompts/` :

   - `trace-flow.prompt.md`
   - `prepare-pr.prompt.md`
   - `add-tests.prompt.md`
   - `migration-plan.prompt.md`
   - `explain-oncall.prompt.md`
   - `code-reviewer.prompt.md`
   - `analyze-diff.prompt.md`
   - `safe-refactor.prompt.md`
   - `test-plan.prompt.md`
   - `release-checklist.prompt.md`

2. **Tâche** : Invoquer le prompt trace-flow :

```
#trace-flow POST /api/photos/upload
```

**Résultat attendu** : Diagramme de flux de bout en bout avec chemins de fichiers

### Exercice B3 : Validation du contrat d'API (20 min)

**Objectif** : Utiliser Copilot pour garantir la compatibilité de l'API

1. Ouvrir le fichier du backend choisi et modifier l'endpoint `uploadPhoto` pour ajouter un nouveau paramètre optionnel `tags` :

<details>
<summary><strong>NestJS (TypeScript)</strong> — <code>apps/backend-nestjs/src/api/photos/photos.controller.ts</code></summary>

```typescript
async uploadPhoto(
  @UploadedFile(
    new ParseFilePipe({
      validators: [
        new MaxFileSizeValidator({ maxSize: 5 * 1024 * 1024 }), // 5MB
        new FileTypeValidator({
          fileType: /image\/(jpeg|png|gif|webp)/,
          fallbackToMimetype: true,
        }),
      ],
    }),
  )
  file: Express.Multer.File,
  @Body('tags') tags?: string,  // NEW: optional tags to add
): Promise<Photo> {
  const tagsList = tags ? tags.split(',').map(t => t.trim()).filter(Boolean) : [];
  // pass along the parsed tags to the service layer (instead of `[]`)
  return this.photoService.uploadPhoto(file, tagsList);
}
```

</details>

<details>
<summary><strong>Spring Boot (Java)</strong> — <code>apps/backend-spring/src/main/java/com/photogallery/backend/api/photos/PhotosController.java</code></summary>

```java
@PostMapping(path = "/upload", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
@ResponseStatus(HttpStatus.CREATED)
public PhotoResponse uploadPhoto(
    @RequestParam("file") MultipartFile file,
    @RequestParam(value = "tags", required = false) String tags  // NEW: optional tags to add
) {
  List<String> tagsList = parseTags(tags);
  // pass along the parsed tags to the service layer (instead of `List.of()`)
  Photo photo = photoService.uploadPhoto(file, tagsList);
}
```

</details>

<details>
<summary><strong>FastAPI (Python)</strong> — <code>apps/backend-fastapi/app/api/photos.py</code></summary>

```python
async def upload_photo(
    service: ServiceDep,
    file: Annotated[UploadFile, File(description="Image file (JPEG/PNG/GIF/WebP), max 5MB")],
    tags: Annotated[str | None, Form(description="Comma-separated tag list")] = None,  # NEW
) -> Photo:
  tagsList = _parse_tags(tags) if tags else []
  # pass along the parsed tags to the service layer (instead of `[]`)
  return service.upload_photo(
    original_filename=file.filename or "upload",
    data=data,
    tags=tagsList,
  )
```

</details>

<details>
<summary><strong>.NET (C#)</strong> — <code>apps/backend-dotnet/Api/Photos/PhotosController.cs</code></summary>

```csharp
/// <summary>
/// Upload a new photo.
/// </summary>
[HttpPost("upload")]
[Consumes("multipart/form-data")]
[RequestSizeLimit(MaxUploadBytes)]
[ProducesResponseType(typeof(PhotoResponse), StatusCodes.Status201Created)]
[ProducesResponseType(typeof(ErrorEnvelope), StatusCodes.Status400BadRequest)]
public async Task<ActionResult<PhotoResponse>> UploadPhoto(
    [FromForm] UploadPhotoDto dto,
    CancellationToken cancellationToken)
{
   // ... existing validation ...
  var tagsList = ParseTags(dto.Tags);
  // pass along the parsed tags to the service layer (instead of ` new List<string>()`)
  var photo = await _photoService.UploadPhotoAsync(uploaded, tagsList, cancellationToken);
  // ...
}
```

</details>

<details>
<summary><strong>Gin (Go)</strong> — <code>apps/backend-gin/internal/api/photos/handler.go</code></summary>

```go
func (h *Handler) Upload(c *gin.Context) {
    fileHeader, err := c.FormFile("file")

    // ... existing validation ...
    tagsList := parseTags(c.PostForm("tags"))  // NEW: optional tags to add
    // pass along the parsed tags to the service layer (instead of `[]string{}`)
    photo, err := h.service.UploadPhoto(c.Request.Context(), domain.UploadedFile{
      OriginalName:   fileHeader.Filename,
      StoredFilename: storedFilename,
      Size:           fileHeader.Size,
    }, tagsList)
}
```

</details>

2. **Tâche** : Consulter l'API Contract Agent :

```
@api-contract-agent I've added an optional 'tags' query parameter to POST /api/photos/upload. Is this backward compatible?
```

3. Générer la mise à jour de la documentation OpenAPI :

```
#analyze-diff
```

**Résultat attendu** : L'agent valide la rétrocompatibilité, suggère des mises à jour du schéma OpenAPI

### Exercice B4 : Génération de tests (20 min)

**Objectif** : Générer des tests avec les prompts Copilot

1. Ouvrir le PhotoService de votre backend :

<details>
<summary><strong>NestJS (TypeScript)</strong></summary>

`apps/backend-nestjs/src/domain/services/photo.service.ts`

</details>
<details>
<summary><strong>Spring Boot (Java)</strong></summary>

`apps/backend-spring/src/main/java/com/photogallery/backend/domain/service/PhotoService.java`

</details>
<details>
<summary><strong>FastAPI (Python)</strong></summary>

`apps/backend-fastapi/app/domain/services.py`

</details>
<details>
<summary><strong>.NET (C#)</strong></summary>

`apps/backend-dotnet/Domain/Services/PhotoService.cs`

</details>
<details>
<summary><strong>Gin (Go)</strong></summary>

`apps/backend-gin/internal/domain/service.go`

</details>

2. **Tâche** : Générer le plan de test :

<details>
<summary><strong>NestJS (TypeScript)</strong></summary>

```
#test-plan apps/backend-nestjs/src/domain/services/photo.service.ts
```

</details>
<details>
<summary><strong>Spring Boot (Java)</strong></summary>

```
#test-plan apps/backend-spring/src/main/java/com/photogallery/backend/domain/service/PhotoService.java
```

</details>
<details>
<summary><strong>FastAPI (Python)</strong></summary>

```
#test-plan apps/backend-fastapi/app/domain/services.py
```

</details>
<details>
<summary><strong>.NET (C#)</strong></summary>

```
#test-plan apps/backend-dotnet/Domain/Services/PhotoService.cs
```

</details>
<details>
<summary><strong>Gin (Go)</strong></summary>

```
#test-plan apps/backend-gin/internal/domain/service.go
```

</details>

3. Générer les tests réels :

<details>
<summary><strong>NestJS (TypeScript)</strong></summary>

```
#add-tests apps/backend-nestjs/src/domain/services/photo.service.ts
```

</details>
<details>
<summary><strong>Spring Boot (Java)</strong></summary>

```
#add-tests apps/backend-spring/src/main/java/com/photogallery/backend/domain/service/PhotoService.java
```

</details>
<details>
<summary><strong>FastAPI (Python)</strong></summary>

```
#add-tests apps/backend-fastapi/app/domain/services.py
```

</details>
<details>
<summary><strong>.NET (C#)</strong></summary>

```
#add-tests apps/backend-dotnet/Domain/Services/PhotoService.cs
```

</details>
<details>
<summary><strong>Gin (Go)</strong></summary>

```
#add-tests apps/backend-gin/internal/domain/service.go
```

</details>

**Résultat attendu** : Suite de tests complète avec tests unitaires et d'intégration

### Exercice B5 : Refactoring sûr (25 min)

**Objectif** : Refactorer du code legacy en toute sécurité

1. Ouvrir le code de stockage/legacy de votre backend :

<details>
<summary><strong>NestJS (TypeScript) — code legacy à base de callbacks</strong></summary>

`apps/backend-nestjs/src/infrastructure/storage/legacy-storage.service.ts`

</details>
<details>
<summary><strong>Spring Boot (Java)</strong></summary>

`apps/backend-spring/src/main/java/com/photogallery/backend/domain/service/PhotoService.java` — repérer les patterns bloquants synchrones à moderniser

</details>
<details>
<summary><strong>FastAPI (Python)</strong></summary>

`apps/backend-fastapi/app/infrastructure/storage.py` — repérer les I/O synchrones à convertir en async

</details>
<details>
<summary><strong>.NET (C#)</strong></summary>

`apps/backend-dotnet/Infrastructure/Storage/DiskStorage.cs`

</details>
<details>
<summary><strong>Gin (Go)</strong></summary>

`apps/backend-gin/internal/infrastructure/storage.go`

</details>

2. **Tâche** : Demander un refactoring sûr :

```
@legacy-modernizer Modernize this file from callbacks to async/await
```

3. Utiliser le prompt safe-refactor :

<details>
<summary><strong>NestJS (TypeScript)</strong></summary>

```
#safe-refactor apps/backend-nestjs/src/infrastructure/storage/legacy-storage.service.ts
```

</details>
<details>
<summary><strong>Spring Boot (Java)</strong></summary>

```
#safe-refactor apps/backend-spring/src/main/java/com/photogallery/backend/domain/service/PhotoService.java
```

</details>
<details>
<summary><strong>FastAPI (Python)</strong></summary>

```
#safe-refactor apps/backend-fastapi/app/infrastructure/storage.py
```

</details>
<details>
<summary><strong>.NET (C#)</strong></summary>

```
#safe-refactor apps/backend-dotnet/Infrastructure/Storage/DiskStorage.cs
```

</details>
<details>
<summary><strong>Gin (Go)</strong></summary>

```
#safe-refactor apps/backend-gin/internal/infrastructure/storage.go
```

</details>

**Résultat attendu** : Étapes de refactoring incrémentales avec tests à chaque étape

### Exercice B6 : Instructions ciblées par chemin (15 min)

**Objectif** : Comprendre le ciblage des instructions

1. Passer en revue les fichiers `.github/instructions/` avec le frontmatter `applyTo` :

   - `architecture.instructions.md` (applyTo : toutes les couches domaine du backend — `apps/backend-nestjs/src/domain/**`, `apps/backend-spring/.../domain/**`, `apps/backend-fastapi/app/domain/**`, `apps/backend-dotnet/Domain/**`, `apps/backend-gin/internal/domain/**`)
   - `testing-guidelines.instructions.md` (applyTo : `**/*.spec.ts`)

2. **Tâche** : Modifier un fichier du domaine et observer comment les suggestions Copilot suivent les patterns propres au domaine

**Résultat attendu** : Les suggestions Copilot respectent les conventions ciblées par chemin

### Exercice B7 : Exécution des hooks (15 min)

**Objectif** : Comprendre les hooks pre/post

1. Passer en revue les configurations de hooks dans `.github/hooks/` :

   - `code-reviewer.json` - Hook pre-tool pour la validation des commits git
   - `coding-standards.json` - Hook post-tool pour la validation des standards de code

2. Passer en revue les scripts de hooks dans `.github/hooks/scripts/` :

   - `validate-commit.sh` / `.ps1` - Lance code-reviewer sur les fichiers indexés lors des commits git
   - `validate-coding-standards.sh` / `.ps1` - Valide contre coding-standards.md après édition

3. Exemple de configuration de hook (`code-reviewer.json`) :

```json
{
  "version": 1,
  "hooks": {
    "preToolUse": [
      {
        "type": "command",
        "bash": ".github/hooks/scripts/validate-commit.sh",
        "powershell": ".github/hooks/scripts/validate-commit.ps1"
      }
    ]
  }
}
```

4. **Tâche** : Faire une modification de code qui viole les standards et observer le comportement du hook

**Résultat attendu** : Le hook post-édition valide les changements contre les standards de code ; le hook pre-commit relit les fichiers indexés avant les commits git

### Exercice B8 : Intégration du workflow CI (15 min)

**Objectif** : Comprendre l'intégration CI/CD

1. Passer en revue `.github/workflows/` :

   - `ci.yml` - Lint, test, build
   - `pr-review.yml` - Revue de PR assistée par IA
   - `deploy.yml` - Déploiement en production

2. **Tâche** : Déclencher le workflow de revue de PR :

```bash
git checkout -b feature/test-workflow
git add .
git commit -m "test: trigger PR review"
# (In real scenario, open PR to trigger workflow)
```

**Résultat attendu** : Compréhension de la revue IA automatisée dans le pipeline CI

### Exercice B9 : Checklist de release (15 min)

**Objectif** : Générer la documentation de release

1. Indexer les changements :

```bash
git add apps/
```

2. **Tâche** : Générer la checklist de release :

```
#release-checklist
```

**Résultat attendu** : Checklist de release complète avec étapes de déploiement, plan de rollback, monitoring

### Exercice B10 : Guidage on-call (15 min)

**Objectif** : S'entraîner à la réponse à incident

**Scénario** : « Taux d'erreur élevé sur les uploads de photos »

1. **Tâche** : Obtenir un guidage de dépannage :

```
#explain-oncall "High error rate on photo uploads"
```

**Résultat attendu** : Étapes de réponse à incident issues de `.github/references/oncall.md`

</details>

---

<details>
<summary><strong>Exercices Gemini CLI</strong></summary>

**Plateforme** : Gemini CLI  
**Documentation** : [GEMINI.md](photo-gallery-fullstack/GEMINI.md)

### Exercice C1 : Revue de la configuration (10 min)

**Objectif** : Comprendre la configuration Gemini

1. Passer en revue `.gemini/settings.json` :

   - Configuration des serveurs MCP
   - Configuration des tools
   - Hooks (beforeTool, afterTool)
   - Tableau skills
   - Tableau commands

2. **Tâche** : Vérifier que la configuration se charge correctement :

```bash
cat .gemini/settings.json | jq .
```

**Résultat attendu** : Configuration JSON valide avec toutes les sections

### Exercice C2 : Découverte des commandes (15 min)

**Objectif** : Explorer les commandes TOML

1. Passer en revue `.gemini/commands/` :

   - `trace-flow.toml`
   - `prepare-pr.toml`
   - `add-tests.toml`
   - `migration-plan.toml`
   - `explain-oncall.toml`
   - `code-reviewer.toml`

2. **Tâche** : Lire une définition de commande :

```bash
cat .gemini/commands/trace-flow.toml
```

3. Invoquer la commande :

```
/trace-flow POST /api/photos/upload
```

**Résultat attendu** : Trace du flux de bout en bout avec chemins de fichiers et numéros de ligne

### Exercice C3 : Exécution des hooks (20 min)

**Objectif** : Comprendre les hooks pre/post

1. Passer en revue les hooks dans `.gemini/settings.json` :

```json
"hooks": {
  "BeforeTool": [
    {
      "matcher": "terminal|shell|bash",
      "hooks": [{ "command": ".gemini/hooks/validate-commit.sh" }]
    },
    {
      "matcher": "write_file|replace",
      "hooks": [{ "command": ".gemini/hooks/validate-writes.sh" }]
    }
  ],
  "AfterTool": [
    {
      "matcher": "write_file|replace",
      "hooks": [{ "command": ".gemini/hooks/validate-coding-standards.sh" }]
    }
  ]
}
```

2. Passer en revue les scripts de hooks dans `.gemini/hooks/` :

   - `validate-commit.sh` - Lance code-reviewer sur les fichiers indexés lors des commits git
   - `validate-writes.sh` - Validation de sécurité avant écriture de fichier
   - `validate-coding-standards.sh` - Valide contre coding-standards.md après édition

3. **Tâche** : Faire une modification de code qui viole les standards et observer le comportement du hook

**Résultat attendu** : Le hook post-édition valide les changements contre les standards de code ; le hook pre-commit relit les fichiers indexés avant les commits git

### Exercice C4 : Vérification du contrat d'API (20 min)

**Objectif** : Valider les changements d'API

1. Ouvrir le fichier du backend choisi et modifier l'endpoint `uploadPhoto` pour ajouter un nouveau paramètre optionnel `tags` :

<details>
<summary><strong>NestJS (TypeScript)</strong> — <code>apps/backend-nestjs/src/api/photos/photos.controller.ts</code></summary>

```typescript
async uploadPhoto(
  @UploadedFile(
    new ParseFilePipe({
      validators: [
        new MaxFileSizeValidator({ maxSize: 5 * 1024 * 1024 }), // 5MB
        new FileTypeValidator({
          fileType: /image\/(jpeg|png|gif|webp)/,
          fallbackToMimetype: true,
        }),
      ],
    }),
  )
  file: Express.Multer.File,
  @Body('tags') tags?: string,  // NEW: optional tags to add
): Promise<Photo> {
  const tagsList = tags ? tags.split(',').map(t => t.trim()).filter(Boolean) : [];
  // pass along the parsed tags to the service layer (instead of `[]`)
  return this.photoService.uploadPhoto(file, tagsList);
}
```

</details>

<details>
<summary><strong>Spring Boot (Java)</strong> — <code>apps/backend-spring/src/main/java/com/photogallery/backend/api/photos/PhotosController.java</code></summary>

```java
@PostMapping(path = "/upload", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
@ResponseStatus(HttpStatus.CREATED)
public PhotoResponse uploadPhoto(
    @RequestParam("file") MultipartFile file,
    @RequestParam(value = "tags", required = false) String tags  // NEW: optional tags to add
) {
  List<String> tagsList = parseTags(tags);
  // pass along the parsed tags to the service layer (instead of `List.of()`)
  Photo photo = photoService.uploadPhoto(file, tagsList);
}
```

</details>

<details>
<summary><strong>FastAPI (Python)</strong> — <code>apps/backend-fastapi/app/api/photos.py</code></summary>

```python
async def upload_photo(
    service: ServiceDep,
    file: Annotated[UploadFile, File(description="Image file (JPEG/PNG/GIF/WebP), max 5MB")],
    tags: Annotated[str | None, Form(description="Comma-separated tag list")] = None,  # NEW
) -> Photo:
  tagsList = _parse_tags(tags) if tags else []
  # pass along the parsed tags to the service layer (instead of `[]`)
  return service.upload_photo(
    original_filename=file.filename or "upload",
    data=data,
    tags=tagsList,
  )
```

</details>

<details>
<summary><strong>.NET (C#)</strong> — <code>apps/backend-dotnet/Api/Photos/PhotosController.cs</code></summary>

```csharp
/// <summary>
/// Upload a new photo.
/// </summary>
[HttpPost("upload")]
[Consumes("multipart/form-data")]
[RequestSizeLimit(MaxUploadBytes)]
[ProducesResponseType(typeof(PhotoResponse), StatusCodes.Status201Created)]
[ProducesResponseType(typeof(ErrorEnvelope), StatusCodes.Status400BadRequest)]
public async Task<ActionResult<PhotoResponse>> UploadPhoto(
    [FromForm] UploadPhotoDto dto,
    CancellationToken cancellationToken)
{
   // ... existing validation ...
  var tagsList = ParseTags(dto.Tags);
  // pass along the parsed tags to the service layer (instead of ` new List<string>()`)
  var photo = await _photoService.UploadPhotoAsync(uploaded, tagsList, cancellationToken);
  // ...
}
```

</details>

<details>
<summary><strong>Gin (Go)</strong> — <code>apps/backend-gin/internal/api/photos/handler.go</code></summary>

```go
func (h *Handler) Upload(c *gin.Context) {
    fileHeader, err := c.FormFile("file")

    // ... existing validation ...
    tagsList := parseTags(c.PostForm("tags"))  // NEW: optional tags to add
    // pass along the parsed tags to the service layer (instead of `[]string{}`)
    photo, err := h.service.UploadPhoto(c.Request.Context(), domain.UploadedFile{
      OriginalName:   fileHeader.Filename,
      StoredFilename: storedFilename,
      Size:           fileHeader.Size,
    }, tagsList)
}
```

</details>

2. **Tâche** : Consulter l'API Contract Agent :

```
"I've added an optional 'tags' form parameter to POST /api/photos/upload. Is this backward compatible?"
```

3. Générer la mise à jour de la documentation OpenAPI :

```
/code-reviewer
```

**Résultat attendu** : L'agent valide la rétrocompatibilité et suggère les mises à jour du schéma OpenAPI

### Exercice C5 : Génération de tests (20 min)

**Objectif** : Générer des tests complets

1. Ouvrir le PhotoService de votre backend :

<details>
<summary><strong>NestJS (TypeScript)</strong></summary>

`apps/backend-nestjs/src/domain/services/photo.service.ts`

</details>
<details>
<summary><strong>Spring Boot (Java)</strong></summary>

`apps/backend-spring/src/main/java/com/photogallery/backend/domain/service/PhotoService.java`

</details>
<details>
<summary><strong>FastAPI (Python)</strong></summary>

`apps/backend-fastapi/app/domain/services.py`

</details>
<details>
<summary><strong>.NET (C#)</strong></summary>

`apps/backend-dotnet/Domain/Services/PhotoService.cs`

</details>
<details>
<summary><strong>Gin (Go)</strong></summary>

`apps/backend-gin/internal/domain/service.go`

</details>

2. **Tâche** : Générer les tests :

<details>
<summary><strong>NestJS (TypeScript)</strong></summary>

```
/add-tests apps/backend-nestjs/src/domain/services/photo.service.ts
```

</details>
<details>
<summary><strong>Spring Boot (Java)</strong></summary>

```
/add-tests apps/backend-spring/src/main/java/com/photogallery/backend/domain/service/PhotoService.java
```

</details>
<details>
<summary><strong>FastAPI (Python)</strong></summary>

```
/add-tests apps/backend-fastapi/app/domain/services.py
```

</details>
<details>
<summary><strong>.NET (C#)</strong></summary>

```
/add-tests apps/backend-dotnet/Domain/Services/PhotoService.cs
```

</details>
<details>
<summary><strong>Gin (Go)</strong></summary>

```
/add-tests apps/backend-gin/internal/domain/service.go
```

</details>

**Résultat attendu** : Suite de tests avec tests unitaires et d'intégration, suivant testing-guidelines.md

### Exercice C6 : Planification de migration (25 min)

**Objectif** : Planifier la modernisation du code legacy

1. Ouvrir le code de stockage/legacy de votre backend :

<details>
<summary><strong>NestJS (TypeScript) — code legacy à base de callbacks</strong></summary>

`apps/backend-nestjs/src/infrastructure/storage/legacy-storage.service.ts`

</details>
<details>
<summary><strong>Spring Boot (Java)</strong></summary>

`apps/backend-spring/src/main/java/com/photogallery/backend/domain/service/PhotoService.java` — chercher les patterns synchrones bloquants à moderniser

</details>
<details>
<summary><strong>FastAPI (Python)</strong></summary>

`apps/backend-fastapi/app/infrastructure/storage.py` — chercher les I/O synchrones à convertir en async

</details>
<details>
<summary><strong>.NET (C#)</strong></summary>

`apps/backend-dotnet/Infrastructure/Storage/DiskStorage.cs`

</details>
<details>
<summary><strong>Gin (Go)</strong></summary>

`apps/backend-gin/internal/infrastructure/storage.go`

</details>

2. **Tâche** : Demander un plan de migration :

<details>
<summary><strong>NestJS (TypeScript)</strong></summary>

```
/migration-plan apps/backend-nestjs/src/infrastructure/storage/legacy-storage.service.ts
```

</details>
<details>
<summary><strong>Spring Boot (Java)</strong></summary>

```
/migration-plan apps/backend-spring/src/main/java/com/photogallery/backend/domain/service/PhotoService.java
```

</details>
<details>
<summary><strong>FastAPI (Python)</strong></summary>

```
/migration-plan apps/backend-fastapi/app/infrastructure/storage.py
```

</details>
<details>
<summary><strong>.NET (C#)</strong></summary>

```
/migration-plan apps/backend-dotnet/Infrastructure/Storage/DiskStorage.cs
```

</details>
<details>
<summary><strong>Gin (Go)</strong></summary>

```
/migration-plan apps/backend-gin/internal/infrastructure/storage.go
```

</details>

**Résultat attendu** : Plan de refactoring étape par étape avec évaluation des risques

### Exercice C7 : Invocation de skills (15 min)

**Objectif** : Comprendre l'usage des skills

1. Passer en revue la structure du répertoire `.gemini/skills/` (identique à Claude)

2. **Tâche** : Poser une question qui déclenche la skill change-impact-analysis :

```
"If I change the PhotoRepository interface, what files will be affected?"
```

**Résultat attendu** : Analyse de dépendances via les skills topology-awareness et change-impact-analysis

### Exercice C8 : Scénario on-call (15 min)

**Objectif** : S'entraîner à la réponse à incident

**Scénario** : « Taux d'erreur élevé sur les uploads de photos »

1. **Tâche** : Obtenir un guidage on-call :

```
/explain-oncall "High error rate on photo uploads"
```

**Résultat attendu** : Étapes de dépannage issues de references/oncall.md

### Exercice C9 : Préparation de PR (15 min)

**Objectif** : Générer la documentation de PR

1. Indexer les changements :

```bash
git add apps/
```

2. **Tâche** : Générer la description de PR :

```
/prepare-pr
```

**Résultat attendu** : Titre de PR, description, checklist, notes de test

### Exercice C10 : Usage des références (10 min)

**Objectif** : Exploiter la connaissance partagée

1. Passer en revue `.gemini/references/` :

   - `architecture.md` - Topologie du système
   - `domain-glossary.md` - Termes métier
   - `testing-guidelines.md` - Patterns de test
   - `coding-standards.md` - Conventions de code
   - `oncall.md` - Réponse à incident

2. **Tâche** : Poser une question qui s'appuie sur le glossaire du domaine :

```
"What's the difference between a PhotoAlbum and a PhotoCollection in our domain model?"
```

**Résultat attendu** : Réponse dérivée de domain-glossary.md

</details>

---

<details>
<summary><strong>Exercices Codex CLI</strong></summary>

**Plateforme** : OpenAI Codex CLI
**Documentation** : [AGENTS.md](photo-gallery-fullstack/AGENTS.md) (lu automatiquement par Codex)

### Exercice D1 : Confiance projet et configuration (10 min)

**Objectif** : Configurer Codex CLI avec la configuration du projet

1. Naviguer vers le projet et lui accorder la confiance :

```bash
cd photo-gallery-fullstack
codex trust .
```

2. Examiner la configuration du projet :

```bash
cat .codex/config.toml
```

3. **Tâche** : Démarrer Codex et vérifier que la configuration se charge :

```bash
codex
```

Puis utiliser `/status` pour voir les réglages actuels.

**Résultat attendu** : Codex se charge avec le modèle `gpt-5-codex` et la politique d'approbation `on-request`

### Exercice D2 : Découverte d'AGENTS.md (15 min)

**Objectif** : Comprendre comment AGENTS.md fournit le contexte projet

1. Examiner `AGENTS.md` à la racine du projet — ce fichier est lu automatiquement par Codex

2. **Tâche** : Interroger Codex sur l'architecture du projet :

```
"Describe the architecture of this photo gallery application"
```

3. Vérifier que Codex reprend des informations issues d'AGENTS.md

**Résultat attendu** : La réponse mentionne le frontend Angular, le backend que vous avez choisi et les détails d'architecture en couches issus d'AGENTS.md

### Exercice D3 : Exploration des skills (15 min)

**Objectif** : Découvrir et utiliser les skills disponibles

1. Lister les skills disponibles :

```
/skills
```

2. Examiner les définitions de skills dans `.codex/skills/` :

   - `topology-awareness` - Cartographie des dépendances
   - `change-impact-analysis` - Évaluation des risques
   - `incremental-refactoring` - Refactoring sûr
   - `framework-conventions` - Application des patterns
   - `debug-correlation` - Analyse de cause racine

3. **Tâche** : Invoquer explicitement un skill :

```
$topology-awareness "What are the dependencies of PhotoService?"
```

**Résultat attendu** : Le skill s'active et fournit une analyse des dépendances

### Exercice D4 : Changement de profil (15 min)

**Objectif** : Utiliser les profils pour différents contextes de travail

1. Examiner les profils disponibles dans `.codex/config.toml` :

   - `deep-review` - Raisonnement élevé, analyse approfondie
   - `lightweight` - Itération rapide
   - `architecture` - Validation de conception
   - `testing` - Génération de tests
   - `code-review` - Revue équilibrée

2. **Tâche** : Démarrer Codex avec le profil deep-review :

```bash
codex --profile deep-review
```

3. Demander une validation d'architecture :

```
"I need to add a photo filter feature. Should this be in the API layer or domain layer?"
```

4. Comparer avec le profil lightweight :

```bash
codex --profile lightweight
```

**Résultat attendu** : deep-review fournit une analyse approfondie avec un raisonnement élevé ; lightweight donne des réponses plus rapides et plus concises

### Exercice D5 : Analyse de changement d'API (20 min)

**Objectif** : Utiliser les skills pour la compatibilité ascendante d'API

1. Démarrer Codex avec le profil code-review :

```bash
codex --profile code-review
```

2. Ouvrir le fichier du backend choisi et modifier l'endpoint `uploadPhoto` pour ajouter un nouveau paramètre optionnel `tags` :

<details>
<summary><strong>NestJS (TypeScript)</strong> — <code>apps/backend-nestjs/src/api/photos/photos.controller.ts</code></summary>

```typescript
async uploadPhoto(
  @UploadedFile(
    new ParseFilePipe({
      validators: [
        new MaxFileSizeValidator({ maxSize: 5 * 1024 * 1024 }), // 5MB
        new FileTypeValidator({
          fileType: /image\/(jpeg|png|gif|webp)/,
          fallbackToMimetype: true,
        }),
      ],
    }),
  )
  file: Express.Multer.File,
  @Body('tags') tags?: string,  // NEW: optional tags to add
): Promise<Photo> {
  const tagsList = tags ? tags.split(',').map(t => t.trim()).filter(Boolean) : [];
  // pass along the parsed tags to the service layer (instead of `[]`)
  return this.photoService.uploadPhoto(file, tagsList);
}
```

</details>

<details>
<summary><strong>Spring Boot (Java)</strong> — <code>apps/backend-spring/src/main/java/com/photogallery/backend/api/photos/PhotosController.java</code></summary>

```java
@PostMapping(path = "/upload", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
@ResponseStatus(HttpStatus.CREATED)
public PhotoResponse uploadPhoto(
    @RequestParam("file") MultipartFile file,
    @RequestParam(value = "tags", required = false) String tags  // NEW: optional tags to add
) {
  List<String> tagsList = parseTags(tags);
  // pass along the parsed tags to the service layer (instead of `List.of()`)
  Photo photo = photoService.uploadPhoto(file, tagsList);
}
```

</details>

<details>
<summary><strong>FastAPI (Python)</strong> — <code>apps/backend-fastapi/app/api/photos.py</code></summary>

```python
async def upload_photo(
    service: ServiceDep,
    file: Annotated[UploadFile, File(description="Image file (JPEG/PNG/GIF/WebP), max 5MB")],
    tags: Annotated[str | None, Form(description="Comma-separated tag list")] = None,  # NEW
) -> Photo:
  tagsList = _parse_tags(tags) if tags else []
  # pass along the parsed tags to the service layer (instead of `[]`)
  return service.upload_photo(
    original_filename=file.filename or "upload",
    data=data,
    tags=tagsList,
  )
```

</details>

<details>
<summary><strong>.NET (C#)</strong> — <code>apps/backend-dotnet/Api/Photos/PhotosController.cs</code></summary>

```csharp
/// <summary>
/// Upload a new photo.
/// </summary>
[HttpPost("upload")]
[Consumes("multipart/form-data")]
[RequestSizeLimit(MaxUploadBytes)]
[ProducesResponseType(typeof(PhotoResponse), StatusCodes.Status201Created)]
[ProducesResponseType(typeof(ErrorEnvelope), StatusCodes.Status400BadRequest)]
public async Task<ActionResult<PhotoResponse>> UploadPhoto(
    [FromForm] UploadPhotoDto dto,
    CancellationToken cancellationToken)
{
   // ... existing validation ...
  var tagsList = ParseTags(dto.Tags);
  // pass along the parsed tags to the service layer (instead of ` new List<string>()`)
  var photo = await _photoService.UploadPhotoAsync(uploaded, tagsList, cancellationToken);
  // ...
}
```

</details>

<details>
<summary><strong>Gin (Go)</strong> — <code>apps/backend-gin/internal/api/photos/handler.go</code></summary>

```go
func (h *Handler) Upload(c *gin.Context) {
    fileHeader, err := c.FormFile("file")

    // ... existing validation ...
    tagsList := parseTags(c.PostForm("tags"))  // NEW: optional tags to add
    // pass along the parsed tags to the service layer (instead of `[]string{}`)
    photo, err := h.service.UploadPhoto(c.Request.Context(), domain.UploadedFile{
      OriginalName:   fileHeader.Filename,
      StoredFilename: storedFilename,
      Size:           fileHeader.Size,
    }, tagsList)
}
```

</details>

3. **Tâche** : Poser la question de la compatibilité ascendante :

```
"I've added an optional 'tags' form parameter to POST /api/photos/upload. Is this backward compatible?"
```

4. Générer la mise à jour de la documentation OpenAPI :

```
$change-impact-analysis "Adding tags parameter to upload endpoint"
```

**Résultat attendu** : L'agent valide la compatibilité ascendante et propose les mises à jour du schéma OpenAPI

### Exercice D6 : Modernisation du legacy (25 min)

**Objectif** : Planifier un refactoring sûr avec les skills

1. Ouvrir le code de stockage/legacy de votre backend :

<details>
<summary><strong>NestJS (TypeScript) — code legacy à base de callbacks</strong></summary>

`apps/backend-nestjs/src/infrastructure/storage/legacy-storage.service.ts`

</details>
<details>
<summary><strong>Spring Boot (Java)</strong></summary>

`apps/backend-spring/src/main/java/com/photogallery/backend/domain/service/PhotoService.java` — repérer les patterns bloquants synchrones à moderniser

</details>
<details>
<summary><strong>FastAPI (Python)</strong></summary>

`apps/backend-fastapi/app/infrastructure/storage.py` — repérer les I/O synchrones à convertir en async

</details>
<details>
<summary><strong>.NET (C#)</strong></summary>

`apps/backend-dotnet/Infrastructure/Storage/DiskStorage.cs`

</details>
<details>
<summary><strong>Gin (Go)</strong></summary>

`apps/backend-gin/internal/infrastructure/storage.go`

</details>

2. **Tâche** : Demander des conseils de refactoring :

```
$incremental-refactoring "Modernize legacy-storage.service.ts from callbacks to async/await"
```

3. Suivre le plan étape par étape fourni

**Résultat attendu** : Un plan de migration détaillé avec :

- Étape 1 : Ajouter des méthodes wrapper async
- Étape 2 : Migrer les consommateurs un par un
- Étape 3 : Remplacer l'implémentation
- Étape 4 : Supprimer le code legacy
- Des points de contrôle et stratégies de rollback à chaque étape

### Exercice D7 : Stratégie de test (20 min)

**Objectif** : Utiliser le profil testing pour planifier les tests

1. Démarrer avec le profil testing :

```bash
codex --profile testing
```

2. Ouvrir le PhotoService de votre backend :

<details>
<summary><strong>NestJS (TypeScript)</strong></summary>

`apps/backend-nestjs/src/domain/services/photo.service.ts`

</details>
<details>
<summary><strong>Spring Boot (Java)</strong></summary>

`apps/backend-spring/src/main/java/com/photogallery/backend/domain/service/PhotoService.java`

</details>
<details>
<summary><strong>FastAPI (Python)</strong></summary>

`apps/backend-fastapi/app/domain/services.py`

</details>
<details>
<summary><strong>.NET (C#)</strong></summary>

`apps/backend-dotnet/Domain/Services/PhotoService.cs`

</details>
<details>
<summary><strong>Gin (Go)</strong></summary>

`apps/backend-gin/internal/domain/service.go`

</details>

3. **Tâche** : Demander une stratégie de test :

```
"I'm adding a generateThumbnail method to PhotoService. What test strategy should I use?"
```

4. Utiliser le skill framework-conventions :

```
$framework-conventions "Show me the test patterns for the backend service layer"
```

**Résultat attendu** : Une stratégie de test couvrant tests unitaires, tests d'intégration et patterns de test conformes aux conventions du framework

### Exercice D8 : Revue de code intégrée (15 min)

**Objectif** : Utiliser la commande de revue intégrée de Codex

1. Faire un changement de code (ou stager des changements existants) :

```bash
git add apps/
```

2. **Tâche** : Utiliser la commande de revue intégrée :

```
/review
```

3. Autre possibilité, demander directement :

```
"Review the changes in my working tree"
```

**Résultat attendu** : Revue assistée par IA des changements stagés, avec évaluation des risques et recommandations

### Exercice D9 : Débogage d'astreinte (15 min)

**Objectif** : Utiliser le skill debug-correlation pour la réponse à incident

**Scénario** : « Taux d'erreur élevé sur les uploads de photos »

1. **Tâche** : Invoquer le skill de débogage :

```
$debug-correlation "High error rate on photo uploads - help me investigate"
```

2. Suivre le workflow de corrélation :
   - Vérifier les logs frontend
   - Vérifier les logs controller/service du backend
   - Vérifier les opérations de stockage
   - Vérifier les opérations base de données

**Résultat attendu** : Une approche de débogage systématique avec :

- Des points de corrélation à travers toute la stack
- Les causes courantes (taille de fichier, espace disque, verrous SQLite)
- Les étapes de résolution

### Exercice D10 : Règles personnalisées (15 min)

**Objectif** : Comprendre les règles d'exécution pour contrôler les commandes

1. Examiner le fonctionnement des règles (configurées dans `~/.codex/rules/default.rules`)

2. **Tâche** : Utiliser la commande execpolicy check :

```bash
codex execpolicy check -- npm run test
```

3. Comprendre les décisions de règle :

   - `allow` - Exécuter sans demander
   - `prompt` - Demander avant d'exécuter
   - `forbidden` - Bloquer l'exécution

4. Exemple de structure de règle (pour référence) :

```starlark
# Allow npm commands
prefix_rule(pattern=["npm", "run"], decision="allow")

# Prompt for git push
prefix_rule(pattern=["git", "push"], decision="prompt")
```

**Résultat attendu** : Compréhension de la façon dont les règles contrôlent l'exécution des commandes dans le sandbox Codex

</details>

---

<details>
<summary><strong>Exercices OpenCode CLI</strong></summary>

**Plateforme** : OpenCode CLI
**Documentation** : [AGENTS.md](photo-gallery-fullstack/AGENTS.md)

> **Note** : OpenCode lit automatiquement `AGENTS.md` et `CLAUDE.md` (fallback). Le répertoire `.opencode/agents/` contient les définitions d'agents personnalisés propres au projet. Utiliser `Tab` pour basculer entre les modes Build et Plan ; `ctrl+x` est la touche leader pour la navigation TUI.

### Exercice E1 : Découverte des agents (10 min)

**Objectif** : Se familiariser avec les agents disponibles

1. Lister tous les agents configurés :

```bash
ls photo-gallery-fullstack/.opencode/agents/
```

2. Lire les définitions d'agents :

   - `architecture-guardian.md` - Validation de conception
   - `api-contract-agent.md` - Compatibilité d'API
   - `legacy-modernizer.md` - Conseils de refactoring
   - `test-strategist.md` - Planification de tests
   - `release-safety.md` - Aptitude au déploiement

3. Démarrer OpenCode dans le projet :

```bash
cd photo-gallery-fullstack && opencode
```

4. **Tâche** : Interroger l'Architecture Guardian sur l'ajout d'une nouvelle fonctionnalité via la syntaxe `@mention` :

```
@architecture-guardian I need to add a photo filter feature. Should this be in the API layer or domain layer?
```

**Résultat attendu** : L'agent analyse AGENTS.md et le contexte d'architecture, puis recommande une couche

**Note** : OpenCode utilise la syntaxe `@mention` pour les agents, identique à Claude Code. Appuyer sur `Tab` pour passer en mode Plan si vous voulez que l'agent planifie avant d'exécuter les changements.

### Exercice E2 : Exploration des commandes (15 min)

**Objectif** : Comprendre les commandes disponibles

1. Examiner les définitions de commandes dans `.opencode/command/` (à noter : répertoire au singulier) :

   - `/trace-flow` - Traçage de flux de bout en bout
   - `/prepare-pr` - Génération de description de PR
   - `/add-tests` - Génération de tests
   - `/migration-plan` - Planification de refactoring
   - `/explain-oncall` - Réponse à incident
   - `/code-reviewer` - Analyse de diff

2. **Tâche** : Tracer le flux d'upload de photo :

```
/trace-flow POST /api/photos/upload
```

**Résultat attendu** : Le flux complet depuis la requête HTTP → controller → service → repository avec chemins de fichiers et numéros de ligne

**Note** : L'invocation de commande OpenCode (`/command-name`) est identique à Claude Code. La différence est que les commandes sont stockées dans `.opencode/command/` (singulier) plutôt que dans `.claude/commands/`.

### Exercice E3 : Validation de contrat d'API (20 min)

**Objectif** : Utiliser l'API Contract Agent pour garantir la compatibilité ascendante

1. Ouvrir le fichier du backend choisi et modifier l'endpoint `uploadPhoto` pour ajouter un nouveau paramètre optionnel `tags` :

<details>
<summary><strong>NestJS (TypeScript)</strong> — <code>apps/backend-nestjs/src/api/photos/photos.controller.ts</code></summary>

```typescript
async uploadPhoto(
  @UploadedFile(
    new ParseFilePipe({
      validators: [
        new MaxFileSizeValidator({ maxSize: 5 * 1024 * 1024 }), // 5MB
        new FileTypeValidator({
          fileType: /image\/(jpeg|png|gif|webp)/,
          fallbackToMimetype: true,
        }),
      ],
    }),
  )
  file: Express.Multer.File,
  @Body('tags') tags?: string,  // NEW: optional tags to add
): Promise<Photo> {
  const tagsList = tags ? tags.split(',').map(t => t.trim()).filter(Boolean) : [];
  // pass along the parsed tags to the service layer (instead of `[]`)
  return this.photoService.uploadPhoto(file, tagsList);
}
```

</details>

<details>
<summary><strong>Spring Boot (Java)</strong> — <code>apps/backend-spring/src/main/java/com/photogallery/backend/api/photos/PhotosController.java</code></summary>

```java
@PostMapping(path = "/upload", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
@ResponseStatus(HttpStatus.CREATED)
public PhotoResponse uploadPhoto(
    @RequestParam("file") MultipartFile file,
    @RequestParam(value = "tags", required = false) String tags  // NEW: optional tags to add
) {
  List<String> tagsList = parseTags(tags);
  // pass along the parsed tags to the service layer (instead of `List.of()`)
  Photo photo = photoService.uploadPhoto(file, tagsList);
}
```

</details>

<details>
<summary><strong>FastAPI (Python)</strong> — <code>apps/backend-fastapi/app/api/photos.py</code></summary>

```python
async def upload_photo(
    service: ServiceDep,
    file: Annotated[UploadFile, File(description="Image file (JPEG/PNG/GIF/WebP), max 5MB")],
    tags: Annotated[str | None, Form(description="Comma-separated tag list")] = None,  # NEW
) -> Photo:
  tagsList = _parse_tags(tags) if tags else []
  # pass along the parsed tags to the service layer (instead of `[]`)
  return service.upload_photo(
    original_filename=file.filename or "upload",
    data=data,
    tags=tagsList,
  )
```

</details>

<details>
<summary><strong>.NET (C#)</strong> — <code>apps/backend-dotnet/Api/Photos/PhotosController.cs</code></summary>

```csharp
/// <summary>
/// Upload a new photo.
/// </summary>
[HttpPost("upload")]
[Consumes("multipart/form-data")]
[RequestSizeLimit(MaxUploadBytes)]
[ProducesResponseType(typeof(PhotoResponse), StatusCodes.Status201Created)]
[ProducesResponseType(typeof(ErrorEnvelope), StatusCodes.Status400BadRequest)]
public async Task<ActionResult<PhotoResponse>> UploadPhoto(
    [FromForm] UploadPhotoDto dto,
    CancellationToken cancellationToken)
{
   // ... existing validation ...
  var tagsList = ParseTags(dto.Tags);
  // pass along the parsed tags to the service layer (instead of ` new List<string>()`)
  var photo = await _photoService.UploadPhotoAsync(uploaded, tagsList, cancellationToken);
  // ...
}
```

</details>

<details>
<summary><strong>Gin (Go)</strong> — <code>apps/backend-gin/internal/api/photos/handler.go</code></summary>

```go
func (h *Handler) Upload(c *gin.Context) {
    fileHeader, err := c.FormFile("file")

    // ... existing validation ...
    tagsList := parseTags(c.PostForm("tags"))  // NEW: optional tags to add
    // pass along the parsed tags to the service layer (instead of `[]string{}`)
    photo, err := h.service.UploadPhoto(c.Request.Context(), domain.UploadedFile{
      OriginalName:   fileHeader.Filename,
      StoredFilename: storedFilename,
      Size:           fileHeader.Size,
    }, tagsList)
}
```

</details>

2. **Tâche** : Consulter l'API Contract Agent :

```
@api-contract-agent I've added an optional 'tags' query parameter to POST /api/photos/upload. Is this backward compatible?
```

3. Générer la mise à jour de la documentation OpenAPI :

```
/code-reviewer
```

**Résultat attendu** : L'agent valide la compatibilité ascendante et propose les mises à jour du schéma OpenAPI

### Exercice E4 : Consultation de stratégie de test (20 min)

**Objectif** : Exploiter le Test Strategist pour la planification des tests

1. Ouvrez le PhotoService de votre backend :

<details>
<summary><strong>NestJS (TypeScript)</strong></summary>

`apps/backend-nestjs/src/domain/services/photo.service.ts`

</details>
<details>
<summary><strong>Spring Boot (Java)</strong></summary>

`apps/backend-spring/src/main/java/com/photogallery/backend/domain/service/PhotoService.java`

</details>
<details>
<summary><strong>FastAPI (Python)</strong></summary>

`apps/backend-fastapi/app/domain/services.py`

</details>
<details>
<summary><strong>.NET (C#)</strong></summary>

`apps/backend-dotnet/Domain/Services/PhotoService.cs`

</details>
<details>
<summary><strong>Gin (Go)</strong></summary>

`apps/backend-gin/internal/domain/service.go`

</details>

2. **Tâche** : Interrogez le Test Strategist sur le test d'une nouvelle méthode :

```
@test-strategist I'm adding a generateThumbnail method to PhotoService. What test strategy should I use?
```

3. Générez les tests avec la commande :

<details>
<summary><strong>NestJS (TypeScript)</strong></summary>

```
/add-tests apps/backend-nestjs/src/domain/services/photo.service.ts
```

</details>
<details>
<summary><strong>Spring Boot (Java)</strong></summary>

```
/add-tests apps/backend-spring/src/main/java/com/photogallery/backend/domain/service/PhotoService.java
```

</details>
<details>
<summary><strong>FastAPI (Python)</strong></summary>

```
/add-tests apps/backend-fastapi/app/domain/services.py
```

</details>
<details>
<summary><strong>.NET (C#)</strong></summary>

```
/add-tests apps/backend-dotnet/Domain/Services/PhotoService.cs
```

</details>
<details>
<summary><strong>Gin (Go)</strong></summary>

```
/add-tests apps/backend-gin/internal/domain/service.go
```

</details>

**Résultat attendu** : Recommandation de stratégie de test (unitaire + intégration), fichier de tests généré avec une couverture complète

### Exercice E5 : Modernisation du legacy (25 min)

**Objectif** : Refactorer sans risque du code legacy à base de callbacks

1. Localisez le code de stockage/legacy de votre backend :

<details>
<summary><strong>NestJS (TypeScript) — code legacy à base de callbacks</strong></summary>

`apps/backend-nestjs/src/infrastructure/storage/legacy-storage.service.ts`

</details>
<details>
<summary><strong>Spring Boot (Java)</strong></summary>

`apps/backend-spring/src/main/java/com/photogallery/backend/domain/service/PhotoService.java` — cherchez les motifs synchrones bloquants à moderniser

</details>
<details>
<summary><strong>FastAPI (Python)</strong></summary>

`apps/backend-fastapi/app/infrastructure/storage.py` — cherchez les I/O synchrones à convertir en async

</details>
<details>
<summary><strong>.NET (C#)</strong></summary>

`apps/backend-dotnet/Infrastructure/Storage/DiskStorage.cs`

</details>
<details>
<summary><strong>Gin (Go)</strong></summary>

`apps/backend-gin/internal/infrastructure/storage.go`

</details>

2. **Tâche** : Demandez un plan de migration en mode Plan — appuyez sur `Tab` pour entrer en mode Plan, puis envoyez :

```
@legacy-modernizer I need to modernize legacy-storage.service.ts from callbacks to async/await. What's the safest approach?
```

3. Exécutez le plan :

<details>
<summary><strong>NestJS (TypeScript)</strong></summary>

```
/migration-plan apps/backend-nestjs/src/infrastructure/storage/legacy-storage.service.ts
```

</details>
<details>
<summary><strong>Spring Boot (Java)</strong></summary>

```
/migration-plan apps/backend-spring/src/main/java/com/photogallery/backend/domain/service/PhotoService.java
```

</details>
<details>
<summary><strong>FastAPI (Python)</strong></summary>

```
/migration-plan apps/backend-fastapi/app/infrastructure/storage.py
```

</details>
<details>
<summary><strong>.NET (C#)</strong></summary>

```
/migration-plan apps/backend-dotnet/Infrastructure/Storage/DiskStorage.cs
```

</details>
<details>
<summary><strong>Gin (Go)</strong></summary>

```
/migration-plan apps/backend-gin/internal/infrastructure/storage.go
```

</details>

**Résultat attendu** : Plan de refactoring incrémental étape par étape, avec analyse de risque et stratégie de rollback

**Note** : Le mode Plan d'OpenCode (activé avec `Tab`) garantit que l'agent planifie toutes les modifications et les présente pour relecture avant exécution — équivalent au mode Plan de Claude Code (`Shift+Tab`).

### Exercice E6 : Application des skills (15 min)

**Objectif** : Comprendre les skills réutilisables (format SKILL.md multiplateforme)

1. Passez en revue les définitions de skills dans `.claude/skills/` (OpenCode lit les skills compatibles Claude) :

   - `topology-awareness` - Cartographie des dépendances
   - `change-impact-analysis` - Analyse de risque
   - `incremental-refactoring` - Refactoring sans risque
   - `framework-conventions` - Application des patterns
   - `debug-correlation` - Analyse de cause racine

2. **Tâche** : Appliquez l'analyse d'impact à un changement hypothétique :

```
"If I change the PhotoRepository interface, what else will break?"
```

(L'agent invoque automatiquement le skill `change-impact-analysis` depuis le contexte)

**Résultat attendu** : Liste des fichiers, classes et tests impactés

**Note** : OpenCode est compatible avec les skills stockés dans `~/.claude/skills/` au format SKILL.md — le standard multiplateforme des agent skills.

### Exercice E7 : Vérification de préparation à la release (20 min)

**Objectif** : Valider la préparation au déploiement avec l'agent Release Safety

1. Stagez les modifications pour une release hypothétique :

```bash
git add apps/
```

2. **Tâche** : Consultez l'agent Release Safety :

```
@release-safety Are we ready to deploy these changes to production?
```

3. Générez la checklist de release :

```
/prepare-pr
```

**Résultat attendu** : Évaluation de préparation à la release avec risques de déploiement, plan de rollback, recommandations de monitoring

### Exercice E8 : Scénario d'astreinte (15 min)

**Objectif** : Pratiquer la réponse à incident avec l'assistance de l'IA

**Scénario** : Alerte en production - « Taux d'erreur élevé sur les uploads de photos »

1. **Tâche** : Obtenez des consignes d'astreinte :

```
/explain-oncall "High error rate on photo uploads"
```

2. Utilisez le skill de corrélation de debug :

```
"What are the most common causes of upload failures based on the architecture?"
```

**Résultat attendu** : Checklist de dépannage, causes racines fréquentes issues d'oncall.md, pistes d'investigation suggérées

### Exercice E9 : Plugin TypeScript — Hook de cycle de vie (10 min)

**Objectif** : Explorer le système de plugins TypeScript d'OpenCode (équivalent aux hooks settings.json de Claude Code, mais en TypeScript)

1. Passez en revue le plugin de standards de code dans `.opencode/plugins/coding-standards.ts` :

```typescript
const CODING_STANDARDS_REFERENCE = '.opencode/references/coding-standards.md';

export const CodingStandardsPlugin = async ({ client }) => {
  const referenceText = await Bun.file(new URL('../references/coding-standards.md', import.meta.url)).text();

  return {
    'tool.execute.before': async (input, output) => {
      if (input.tool !== 'edit' && input.tool !== 'write') return;

      const content = `${output.args?.content ?? ''}\n${output.args?.newString ?? ''}`;
      if (referenceText.includes('### Avoid `any`') && /:\s*any\b|\bas\s+any\b/.test(content)) {
        throw new Error(`Coding standards violation: avoid \`any\` types. See ${CODING_STANDARDS_REFERENCE}.`);
      }
    },

    'file.edited': async ({ path }) => {
      if (!path?.match(/\.(ts|tsx|js|jsx)$/)) return;

      await client.app.log({
        body: {
          service: 'coding-standards',
          level: 'info',
          message: `Review ${path} against ${CODING_STANDARDS_REFERENCE}.`,
        },
      });
    },
  };
};
```

2. **Tâche** : Demandez à OpenCode d'ajouter une variable de type `any` et observez le plugin l'intercepter :

```
Add a temporary variable of type any to photo.service.ts
```

3. Comparez avec l'approche par hooks `settings.json` de Claude Code :
   - Claude Code : config JSON dans `settings.json` avec script shell + hooks `type: "prompt"`
   - OpenCode : fonction de plugin JavaScript/TypeScript exportée qui retourne des hooks de cycle de vie tels que `tool.execute.before` et `file.edited`

**Résultat attendu** : Le plugin intercepte la demande d'édition, lève une erreur bloquante et journalise un rappel de relire `.opencode/references/coding-standards.md` après l'édition de fichiers TypeScript

**Différence clé** : Les plugins OpenCode sont des modules TypeScript/JavaScript qui exportent des fonctions de plugin asynchrones. Ils peuvent réutiliser directement les références du projet et les API Bun, donc l'exemple reste multiplateforme sans dépendre de scripts `.opencode/hooks/*.sh`.

### Exercice E10 : Partage de session et mode headless (15 min)

**Objectif** : Explorer les fonctionnalités propres à OpenCode : partage public de session et mode headless/CI

#### Partie 1 : Partage de session (5 min)

1. Démarrez une session de debug dans OpenCode :

```
Analyze the photo upload flow and identify potential performance bottlenecks
```

2. Partagez la session publiquement :

```
/share
```

Ou appuyez sur `ctrl+x s`

3. OpenCode génère une URL publique — partagez-la avec un collègue pour une relecture asynchrone

**Résultat attendu** : Une URL de conversation partageable est générée, permettant aux collègues de relire l'analyse de l'IA sans rejouer la session

#### Partie 2 : Mode headless/CI (10 min)

4. Lancez OpenCode en mode non interactif (headless) :

Utilisez `opencode run` avec le chemin du PhotoService de votre backend :

<details>
<summary><strong>NestJS (TypeScript)</strong></summary>

```bash
opencode run "Review apps/backend-nestjs/src/domain/services/photo.service.ts for architectural compliance"
```

</details>
<details>
<summary><strong>Spring Boot (Java)</strong></summary>

```bash
opencode run "Review apps/backend-spring/src/main/java/com/photogallery/backend/domain/service/PhotoService.java for architectural compliance"
```

</details>
<details>
<summary><strong>FastAPI (Python)</strong></summary>

```bash
opencode run "Review apps/backend-fastapi/app/domain/services.py for architectural compliance"
```

</details>
<details>
<summary><strong>.NET (C#)</strong></summary>

```bash
opencode run "Review apps/backend-dotnet/Domain/Services/PhotoService.cs for architectural compliance"
```

</details>
<details>
<summary><strong>Gin (Go)</strong></summary>

```bash
opencode run "Review apps/backend-gin/internal/domain/service.go for architectural compliance"
```

</details>

5. Utilisez-le dans un script CI :

```bash
# Pre-commit check (add to .husky/pre-commit)
opencode run "Check if staged files follow team coding standards and fail if violations are found"
```

**Résultat attendu** : OpenCode renvoie l'analyse sur stdout sans ouvrir la TUI interactive — adapté aux pipelines CI/CD

**Différence clé avec Claude Code** : `opencode run` d'OpenCode permet un usage CI réellement non interactif. Claude Code utilise `claude -p` (mode print) dans le même but.

</details>

---

<details>
<summary><strong>Exercices Mistral Vibe</strong></summary>

**Plateforme** : Mistral Vibe
**Documentation** : [AGENTS.md](photo-gallery-fullstack/AGENTS.md) (lu automatiquement par Mistral Vibe au démarrage de la session)

> **Note** : Mistral Vibe s'installe avec `curl -LsSf https://mistral.ai/vibe/install.sh | bash` (ou `uv tool install mistral-vibe`). Lancez la session interactive avec `vibe` ; lancez l'intégration ACP avec `vibe-acp`. Tous les paramètres du projet sont en TOML sous `.vibe/` (`config.toml`, `hooks.toml`). Mistral Vibe unifie les skills réutilisables et les slash commands invocables par l'utilisateur dans un **système de skills** unique, sous `.vibe/skills/`. Utilisez `@` pour mentionner agents/fichiers, `/` pour lancer les skill-commands, et `!` pour lancer des commandes shell.

### Exercice F1 : Confiance du dossier et configuration (10 min)

**Objectif** : Mettre en place Mistral Vibe avec la configuration du projet

1. Placez-vous dans le projet et démarrez Mistral Vibe :

```bash
cd photo-gallery-fullstack
vibe
```

Au premier lancement, Mistral Vibe affiche une **invite de confiance du dossier** — approuvez-la pour que la configuration `.vibe/` du projet soit chargée.

2. (Optionnel) Lancez la configuration interactive :

```bash
vibe --setup
```

3. Passez en revue la configuration TOML :

```bash
cat .vibe/config.toml
```

**Résultat attendu** : Mistral Vibe se charge avec le projet approuvé, le mode de permission `default`, et les répertoires `.vibe/agents` et `.vibe/skills` enregistrés.

### Exercice F2 : Découverte des agents (10 min)

**Objectif** : Vous familiariser avec les agents disponibles

1. Listez tous les agents configurés :

```bash
ls .vibe/agents/
```

2. Lisez les définitions d'agents :

   - `architecture-guardian.md` - Validation de conception
   - `api-contract-agent.md` - Compatibilité d'API
   - `legacy-modernizer.md` - Accompagnement du refactoring
   - `test-strategist.md` - Planification des tests
   - `release-safety.md` - Préparation au déploiement

3. **Tâche** : Interrogez l'Architecture Guardian sur l'ajout d'une nouvelle fonctionnalité avec la syntaxe `@mention` :

```
@architecture-guardian I need to add a photo filter feature. Should this be in the API layer or domain layer?
```

**Résultat attendu** : L'agent analyse `AGENTS.md` et les références d'architecture, puis recommande une couche.

### Exercice F3 : Slash commands via le système de skills (15 min)

**Objectif** : Comprendre comment Mistral Vibe expose des workflows répétables

1. Passez en revue le système de skills dans `.vibe/skills/`. Il contient deux types d'entrées :

   - **Skills réutilisables** (invoqués par le modèle) : `topology-awareness`, `change-impact-analysis`, `incremental-refactoring`, `framework-conventions`, `debug-correlation`
   - **Slash commands** (invoqués par l'utilisateur avec `/`) : `trace-flow`, `prepare-pr`, `add-tests`, `migration-plan`, `explain-oncall`, `code-reviewer`

2. **Tâche** : Tracez le flux d'upload de photo :

```
/trace-flow POST /api/photos/upload
```

**Résultat attendu** : Flux complet de la requête HTTP → controller → service → repository, avec chemins de fichiers et numéros de ligne.

**Note** : Dans Mistral Vibe il n'y a qu'un seul système de skills. Chaque `SKILL.md` sous `.vibe/skills/` est soit activé automatiquement depuis le contexte (skills réutilisables), soit invoqué explicitement avec un `/` initial (slash commands).

### Exercice F4 : Validation du contrat d'API (20 min)

**Objectif** : Utiliser l'API Contract Agent pour garantir la rétrocompatibilité

1. Ouvrez le fichier du backend choisi et modifiez l'endpoint `uploadPhoto` pour ajouter un nouveau paramètre optionnel `tags` :

<details>
<summary><strong>NestJS (TypeScript)</strong> — <code>apps/backend-nestjs/src/api/photos/photos.controller.ts</code></summary>

```typescript
async uploadPhoto(
  @UploadedFile(
    new ParseFilePipe({
      validators: [
        new MaxFileSizeValidator({ maxSize: 5 * 1024 * 1024 }), // 5MB
        new FileTypeValidator({
          fileType: /image\/(jpeg|png|gif|webp)/,
          fallbackToMimetype: true,
        }),
      ],
    }),
  )
  file: Express.Multer.File,
  @Body('tags') tags?: string,  // NEW: optional tags to add
): Promise<Photo> {
  const tagsList = tags ? tags.split(',').map(t => t.trim()).filter(Boolean) : [];
  // pass along the parsed tags to the service layer (instead of `[]`)
  return this.photoService.uploadPhoto(file, tagsList);
}
```

</details>

<details>
<summary><strong>Spring Boot (Java)</strong> — <code>apps/backend-spring/src/main/java/com/photogallery/backend/api/photos/PhotosController.java</code></summary>

```java
@PostMapping(path = "/upload", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
@ResponseStatus(HttpStatus.CREATED)
public PhotoResponse uploadPhoto(
    @RequestParam("file") MultipartFile file,
    @RequestParam(value = "tags", required = false) String tags  // NEW: optional tags to add
) {
  List<String> tagsList = parseTags(tags);
  // pass along the parsed tags to the service layer (instead of `List.of()`)
  Photo photo = photoService.uploadPhoto(file, tagsList);
}
```

</details>

<details>
<summary><strong>FastAPI (Python)</strong> — <code>apps/backend-fastapi/app/api/photos.py</code></summary>

```python
async def upload_photo(
    service: ServiceDep,
    file: Annotated[UploadFile, File(description="Image file (JPEG/PNG/GIF/WebP), max 5MB")],
    tags: Annotated[str | None, Form(description="Comma-separated tag list")] = None,  # NEW
) -> Photo:
  tagsList = _parse_tags(tags) if tags else []
  # pass along the parsed tags to the service layer (instead of `[]`)
  return service.upload_photo(
    original_filename=file.filename or "upload",
    data=data,
    tags=tagsList,
  )
```

</details>

<details>
<summary><strong>.NET (C#)</strong> — <code>apps/backend-dotnet/Api/Photos/PhotosController.cs</code></summary>

```csharp
/// <summary>
/// Upload a new photo.
/// </summary>
[HttpPost("upload")]
[Consumes("multipart/form-data")]
[RequestSizeLimit(MaxUploadBytes)]
[ProducesResponseType(typeof(PhotoResponse), StatusCodes.Status201Created)]
[ProducesResponseType(typeof(ErrorEnvelope), StatusCodes.Status400BadRequest)]
public async Task<ActionResult<PhotoResponse>> UploadPhoto(
    [FromForm] UploadPhotoDto dto,
    CancellationToken cancellationToken)
{
   // ... existing validation ...
  var tagsList = ParseTags(dto.Tags);
  // pass along the parsed tags to the service layer (instead of ` new List<string>()`)
  var photo = await _photoService.UploadPhotoAsync(uploaded, tagsList, cancellationToken);
  // ...
}
```

</details>

<details>
<summary><strong>Gin (Go)</strong> — <code>apps/backend-gin/internal/api/photos/handler.go</code></summary>

```go
func (h *Handler) Upload(c *gin.Context) {
    fileHeader, err := c.FormFile("file")

    // ... existing validation ...
    tagsList := parseTags(c.PostForm("tags"))  // NEW: optional tags to add
    // pass along the parsed tags to the service layer (instead of `[]string{}`)
    photo, err := h.service.UploadPhoto(c.Request.Context(), domain.UploadedFile{
      OriginalName:   fileHeader.Filename,
      StoredFilename: storedFilename,
      Size:           fileHeader.Size,
    }, tagsList)
}
```

</details>

2. **Tâche** : Consultez l'API Contract Agent :

```
@api-contract-agent I've added an optional 'tags' query parameter to POST /api/photos/upload. Is this backward compatible?
```

3. Générez la mise à jour de la documentation OpenAPI :

```
/code-reviewer
```

**Résultat attendu** : L'agent valide la rétrocompatibilité et propose des mises à jour du schéma OpenAPI.

### Exercice F5 : Consultation de la stratégie de test (20 min)

**Objectif** : Exploiter le Test Strategist pour la planification des tests

1. Ouvrez le PhotoService correspondant à votre backend :

<details>
<summary><strong>NestJS (TypeScript)</strong></summary>

`apps/backend-nestjs/src/domain/services/photo.service.ts`

</details>
<details>
<summary><strong>Spring Boot (Java)</strong></summary>

`apps/backend-spring/src/main/java/com/photogallery/backend/domain/service/PhotoService.java`

</details>
<details>
<summary><strong>FastAPI (Python)</strong></summary>

`apps/backend-fastapi/app/domain/services.py`

</details>
<details>
<summary><strong>.NET (C#)</strong></summary>

`apps/backend-dotnet/Domain/Services/PhotoService.cs`

</details>
<details>
<summary><strong>Gin (Go)</strong></summary>

`apps/backend-gin/internal/domain/service.go`

</details>

2. **Tâche** : Interrogez le Test Strategist sur le test d'une nouvelle méthode :

```
@test-strategist I'm adding a generateThumbnail method to PhotoService. What test strategy should I use?
```

3. Générez les tests avec la commande slash (adaptez le chemin à votre backend) :

```
/add-tests apps/backend-nestjs/src/domain/services/photo.service.ts
```

**Résultat attendu** : Recommandation de stratégie de test (unitaire + intégration), fichier de test généré avec une couverture complète.

### Exercice F6 : Modernisation du legacy (25 min)

**Objectif** : Refactoriser du code legacy à base de callbacks en toute sécurité

1. Localisez le code de stockage/legacy correspondant à votre backend :

<details>
<summary><strong>NestJS (TypeScript) — code legacy à base de callbacks</strong></summary>

`apps/backend-nestjs/src/infrastructure/storage/legacy-storage.service.ts`

</details>
<details>
<summary><strong>Spring Boot (Java)</strong></summary>

`apps/backend-spring/src/main/java/com/photogallery/backend/domain/service/PhotoService.java` — cherchez les patterns synchrones bloquants à moderniser

</details>
<details>
<summary><strong>FastAPI (Python)</strong></summary>

`apps/backend-fastapi/app/infrastructure/storage.py` — cherchez les I/O synchrones à convertir en async

</details>
<details>
<summary><strong>.NET (C#)</strong></summary>

`apps/backend-dotnet/Infrastructure/Storage/DiskStorage.cs`

</details>
<details>
<summary><strong>Gin (Go)</strong></summary>

`apps/backend-gin/internal/infrastructure/storage.go`

</details>

2. **Tâche** : Passez en mode de permission `plan`, puis demandez un plan de migration :

```
@legacy-modernizer I need to modernize legacy-storage.service.ts from callbacks to async/await. What's the safest approach?
```

3. Exécutez le plan (adaptez le chemin à votre backend) :

```
/migration-plan apps/backend-nestjs/src/infrastructure/storage/legacy-storage.service.ts
```

**Résultat attendu** : Plan de refactoring incrémental étape par étape, avec analyse des risques et stratégie de rollback.

**Note** : Mistral Vibe propose plusieurs modes de permission — `default`, `plan`, `accept-edits` et `auto-approve`. Utilisez `plan` lorsque vous voulez que l'agent propose toutes les modifications pour relecture avant de toucher aux fichiers.

### Exercice F7 : Application des skills (15 min)

**Objectif** : Comprendre les skills réutilisables

1. Passez en revue les skills réutilisables dans `.vibe/skills/` :

   - `topology-awareness` - Cartographie des dépendances
   - `change-impact-analysis` - Analyse des risques
   - `incremental-refactoring` - Refactoring sûr
   - `framework-conventions` - Application des patterns
   - `debug-correlation` - Analyse de cause racine

2. **Tâche** : Appliquez l'analyse d'impact des changements à une modification hypothétique :

```
"If I change the PhotoRepository interface, what else will break?"
```

(Le skill `change-impact-analysis` s'active automatiquement selon le contexte.)

**Résultat attendu** : Liste des fichiers, classes et tests impactés.

### Exercice F8 : Hooks TOML (15 min)

**Objectif** : Configurer une validation automatisée avec des hooks TOML

1. Passez en revue les hooks déclarés dans `.vibe/hooks.toml` :

```toml
[[hooks.pre_tool_use]]
matcher = "shell"
command = "bash .vibe/hooks/validate-commit.sh"
description = "Block git commits when staged files contain secrets, denied files, or non-conventional subjects."

[[hooks.pre_tool_use]]
matcher = "write"
command = "bash .vibe/hooks/validate-writes.sh"
description = "Scan files for secrets and disallowed filenames before they are written."

[[hooks.post_tool_use]]
matcher = "write|edit"
command = "bash .vibe/hooks/validate-coding-standards.sh"
description = "Warn on coding-standards violations after edits."
```

2. Passez en revue les scripts de hooks dans `.vibe/hooks/` :

   - `validate-commit.sh` - Valide les fichiers stagés avant les commits git
   - `validate-writes.sh` - Validation de sécurité avant l'écriture des fichiers
   - `validate-coding-standards.sh` - Valide par rapport à coding-standards.md après les modifications

3. **Tâche** : Faites une modification de code qui viole les standards de codage et observez le comportement du hook.

**Résultat attendu** : Le hook post-édition alerte sur les violations des standards de codage ; le hook de pre-commit bloque le commit sur un code de sortie non nul.

**Note** : Mistral Vibe sépare la configuration (`config.toml`) et les hooks (`hooks.toml`) dans deux fichiers TOML distincts. Un hook qui se termine avec un code non nul bloque l'action associée.

### Exercice F9 : Utilisation des références (10 min)

**Objectif** : Exploiter la connaissance partagée

1. Passez en revue `.vibe/references/` :

   - `architecture.md` - Topologie du système
   - `domain-glossary.md` - Termes métier
   - `testing-guidelines.md` - Patterns de test
   - `coding-standards.md` - Conventions de code
   - `oncall.md` - Réponse aux incidents

2. **Tâche** : Obtenez des consignes d'astreinte pour une alerte en production :

```
/explain-oncall "High error rate on photo uploads"
```

3. Posez une question qui s'appuie sur le glossaire métier :

```
"What's the difference between a PhotoAlbum and a PhotoCollection in our domain model?"
```

**Résultat attendu** : Étapes de résolution issues de `oncall.md` et réponse dérivée de `domain-glossary.md`.

### Exercice F10 : Mode ACP & reprise de session (15 min)

**Objectif** : Explorer les fonctionnalités propres à Mistral Vibe : le mode ACP et les sessions reprenables

#### Partie 1 : Reprise de session (7 min)

1. Démarrez une session de débogage :

```
Analyze the photo upload flow and identify potential performance bottlenecks
```

2. Quittez Mistral Vibe, puis reprenez la conversation plus tard :

```bash
vibe --continue   # resume the most recent session
# or
vibe --resume     # pick a previous session to resume
```

**Résultat attendu** : Le contexte de la conversation précédente est restauré, vous permettant de reprendre là où vous vous étiez arrêté.

#### Partie 2 : Mode ACP (8 min)

3. Lancez Mistral Vibe en mode ACP (Agent Client Protocol) pour l'intégrer à un éditeur ou un client compatible ACP :

```bash
vibe-acp
```

4. Connectez votre éditeur compatible ACP au processus `vibe-acp` en cours d'exécution et envoyez une requête telle que :

```
Review apps/backend-nestjs/src/domain/services/photo.service.ts for architectural compliance
```

**Résultat attendu** : Mistral Vibe traite les requêtes via ACP, ce qui permet à un client externe de piloter les mêmes agents et skills que dans le TUI interactif.

</details>

---

## Évaluation

Après avoir terminé les exercices de votre plateforme, évaluez votre compréhension :

1. **Maîtrise des agents/commandes** : Savez-vous invoquer le bon agent/la bonne commande pour chaque scénario ?
2. **Connaissance des skills** : Comprenez-vous quand les skills sont invoqués automatiquement ?
3. **Utilisation des références** : Savez-vous naviguer efficacement dans la connaissance partagée ?
4. **Conventions des plateformes** : Comprenez-vous les différences de syntaxe propres à chaque plateforme ?
5. **Collaboration en équipe** : Sauriez-vous embarquer un coéquipier sur cette configuration ?

## Prochaines étapes

- Explorez les sections des deux autres plateformes pour comprendre les patterns multi-plateformes
- Consultez [AGENTS.md](photo-gallery-fullstack/AGENTS.md) pour la comparaison des plateformes
- Adaptez les configurations aux projets de votre propre équipe
- Envisagez des approches hybrides (par ex. Claude + Copilot sur la même base de code)

## Dépannage

- **Commandes non reconnues** : Vérifiez l'installation du CLI de la plateforme et les chemins des fichiers de configuration
- **Hooks non exécutés** : Vérifiez les permissions des fichiers (`chmod +x .gemini/hooks/*.sh`)
- **Références non chargées** : Assurez-vous que les chemins relatifs sont corrects dans les fichiers de settings
- **Skills non invoqués** : Vérifiez la configuration du tableau skills dans settings.json
- **Config Codex non chargée** : Lancez `codex trust .` pour faire confiance au projet
- **Skills Codex non activés** : Vérifiez que les descriptions des skills correspondent à votre tâche ; essayez une invocation explicite `$skill-name`

## Ressources

- [Slides du module 6](../../docs/markdown/60_module_6_team_augmented/)
- [AGENTS.md - Référence multi-plateformes](photo-gallery-fullstack/AGENTS.md) (également instructions projet pour Codex)
- [Guide de configuration Claude](photo-gallery-fullstack/CLAUDE.md)
- [Guide de configuration Gemini](photo-gallery-fullstack/GEMINI.md)
