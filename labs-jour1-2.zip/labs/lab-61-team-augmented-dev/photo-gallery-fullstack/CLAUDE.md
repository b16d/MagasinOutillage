# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project

Fullstack photo gallery: Angular 20 frontend + a trainee-choosable backend (NestJS 11, Spring Boot, FastAPI, ASP.NET Core, or Gin — all backed by SQLite behind the same OpenAPI contract), in an Nx monorepo. Used as the lab project for the "Team-Augmented Development" module — much of the `.claude/`, `.gemini/`, `.github/`, `.codex/`, and `.opencode/` scaffolding exists to demonstrate cross-tool agent/skill setups.

## Common Commands

All commands run from the project root.

```sh
npm ci                     # install
npm run start              # alias for `nx serve frontend` (proxies /api → backend)
npm run serve              # same as start
npm run build              # nx run-many -t build --all
npm run lint               # nx run-many -t lint --all
npm run test               # nx run-many -t test --all (Vitest)
```

Per-project (preferred when iterating):

```sh
nx serve backend-nestjs    # NestJS on port from NESTJS_BACKEND_PORT (default 42621) — or `npm run serve:backend-<stack>` for another stack, see below
nx serve frontend          # Angular dev server, proxies /api/* via apps/frontend/proxy.conf.json
nx test backend-nestjs     # Vitest for the NestJS backend only
nx test frontend           # Vitest for frontend only
nx lint <project>          # ESLint for one project
nx e2e frontend-e2e        # Playwright e2e
```

Single test file / pattern (Vitest passthrough, NestJS backend):

```sh
nx test backend-nestjs -- path/to/file.spec.ts
nx test frontend -- -t "name pattern"
```

The frontend dev server proxies `/api/*` and `/uploads/*` to `http://localhost:42621` — whichever backend you start (`npm run serve:backend-<stack>`) must be running on that port for API calls to work. See `.claude/references/architecture.md` for the per-stack serve commands.

## Architecture

Strict layered architecture. Read `.claude/references/architecture.md` for the full reference (data-flow diagrams, schema, conventions); the rules below are the load-bearing constraints.

### Layers

- `apps/frontend/src/app/components/` — Angular **standalone** components (no NgModules). State via `signal()` / `computed()`, DI via `inject()`.
- `apps/frontend/src/app/services/` — `PhotoService` (state) wraps `PhotoApiService` (HTTP). All HTTP goes through services, never components.
- `apps/backend-<stack>/.../api/` — controllers/handlers + DTOs. 5MB upload limit, MIME whitelist (jpeg/png/gif/webp).
- `apps/backend-<stack>/.../domain/` — entities, domain models, business services. **Pure domain logic — no infrastructure imports.**
- `apps/backend-<stack>/.../infrastructure/` — storage and repository implementations. Implements domain interfaces.

<details>
<summary><strong>NestJS</strong> — <code>apps/backend-nestjs/src/</code></summary>

- `api/photos/` — NestJS controllers + DTOs. Multer disk storage to `./dist/uploads/`.
- `domain/` — Entities (TypeORM), domain models, business services.
- `infrastructure/` — `TypeOrmPhotoRepository` and storage implementations.

</details>

<details>
<summary><strong>Spring Boot</strong> — <code>apps/backend-spring/src/main/java/com/photogallery/backend/</code></summary>

- `api/photos/` — `@RestController` + request/response DTOs.
- `domain/` — plain-record `Photo`, domain services.
- `infrastructure/` — JPA `PhotoEntity` + `PhotoRepository extends JpaRepository`.

</details>

<details>
<summary><strong>FastAPI</strong> — <code>apps/backend-fastapi/app/</code></summary>

- `api/` — `APIRouter`-based routes, injected via `Depends()`.
- `domain/` — Pydantic `Photo` model, domain services.
- `infrastructure/` — SQLModel `PhotoEntity`, `database.py`, `storage.py`.

</details>

<details>
<summary><strong>.NET</strong> — <code>apps/backend-dotnet/</code></summary>

- `Api/Photos/` — `[ApiController]` classes + DTOs.
- `Domain/` — plain `Photo` class, domain services.
- `Infrastructure/` — EF Core `PhotoEntity`, `EfPhotoRepository`.

</details>

<details>
<summary><strong>Gin</strong> — <code>apps/backend-gin/internal/</code></summary>

- `api/photos/` — Gin handlers + DTOs.
- `domain/` — plain `Photo` struct, domain services.
- `infrastructure/` — GORM entity, repository implementation.

</details>

### Dependency Rules (do not violate)

- Domain Layer must NOT import from Infrastructure Layer.
- API Layer depends only on Domain services.
- UI Layer must NOT call backend modules directly — only via HTTP through `PhotoApiService`.

When in doubt about where a piece of logic belongs, consult `@architecture-guardian` before writing it.

### Persistence

All backends persist to SQLite behind the same schema.

- SQLite database file: `./dist/db/photogallery.db` (NestJS, relative to dist output) or `./data/photogallery.db` (Spring/FastAPI/.NET/Gin), auto-created on first run.
- Schema is derived/synced from entities on startup (NestJS TypeORM `synchronize: true`, Spring/​.NET run auto-DDL, FastAPI/Gin create tables on boot) — do not write migrations.
- Uploaded files served statically at `/uploads/*` from `./uploads/` (or `./dist/uploads/` for NestJS).

See `.claude/references/architecture.md` for exact per-stack paths and commands.

### Deliberately legacy code

`apps/backend-nestjs/src/infrastructure/storage/legacy-storage.service.ts` uses a callback-based API on purpose — it exists as the subject of the `@legacy-modernizer` / `/migration-plan` refactoring exercises and only exists in the NestJS reference implementation. Don't "fix" it unless the task is explicitly about modernizing it.

## Hooks (settings.json)

`.claude/settings.json` wires three prompt-type hooks to scripts in `.claude/hooks/`:

- `PreToolUse` on `Bash` → `validate-commit.sh` (run before `git commit`). Blocks commits that stage secrets/denied files or use a non-conventional commit subject.
- `PreToolUse` on `Write` → `validate-writes.sh`. Scans modified + untracked files for secret patterns (AWS/GitHub/OpenAI/Anthropic/Slack tokens, private keys) and disallowed filenames (`.env*`, `credentials.json`, `id_rsa*`).
- `PostToolUse` on `Write|Edit` → `validate-coding-standards.sh`. Advisory-only (always exit 0) scan of modified TS/JS files in `apps/` for `: any`, `console.log`, and `@NgModule`.

The scripts are intentionally conservative (high-confidence matches only) so they don't block routine work. If you change them, run all three once against a clean tree to confirm they still exit 0.

## AI Assistant Scaffolding

This repo ships with multi-tool agent configs. For Claude specifically:

- `.claude/agents/` — sub-agents (`@architecture-guardian`, `@api-contract-agent`, `@legacy-modernizer`, `@test-strategist`, `@release-safety`)
- `.claude/commands/` — slash commands (`/trace-flow`, `/prepare-pr`, `/add-tests`, `/migration-plan`, `/explain-oncall`, `/code-reviewer`)
- `.claude/skills/` — reusable skills (topology-awareness, change-impact-analysis, incremental-refactoring, framework-conventions, debug-correlation)
- `.claude/references/` — authoritative shared knowledge: `architecture.md`, `domain-glossary.md`, `coding-standards.md`, `testing-guidelines.md`, `oncall.md`. **Read these before answering domain or convention questions** rather than inferring from code.

Cross-tool equivalents live in `AGENTS.md` (Codex/OpenCode), `GEMINI.md`, and `.github/` (Copilot) — keep them in sync when changing agent definitions.
