---
name: incremental-refactoring
description: Guide developers through safe, testable refactoring by breaking large changes into small, low-risk increments. Use when planning large refactorings (>200 lines), migrating between frameworks or patterns, modernizing legacy code, or replacing deprecated libraries.
allowed-tools: Read, Grep, Glob, Edit
---

# Incremental Refactoring Skill

## Purpose

Guide developers through safe, testable refactoring by breaking large changes into small, low-risk increments. This skill prevents "big bang" refactorings that destabilize systems.

## Capabilities

### 1. Refactoring Step Decomposition
- Break large refactorings into 5-10 independent steps
- Each step is independently verifiable and deployable
- Preserve system behavior at every checkpoint

### 2. Risk Minimization Strategies
- Introduce abstractions before implementation changes
- Use adapter/facade patterns for gradual migration
- Recommend feature flags for parallel implementations

### 3. Rollback Safety
- Ensure each step can be safely reverted
- Identify checkpoints where rollback is simple
- Flag irreversible steps requiring extra validation

## Usage Context

This skill activates when:
- Planning large code refactorings (>200 lines changed)
- Migrating between frameworks or architectural patterns
- Modernizing legacy code
- Replacing deprecated libraries

## Knowledge Sources

- **architecture.md**: Target patterns and conventions
- **coding-standards.md**: Team refactoring practices
- **testing-guidelines.md**: Test coverage requirements for refactoring

## Refactoring Principles

### The Strangler Fig Pattern

Replace old systems incrementally by:
1. Identify functionality to migrate
2. Implement new version alongside old
3. Route traffic to new version gradually
4. Remove old version once new is proven

### Parallel Run Strategy

For high-risk migrations:
1. Deploy both old and new implementations
2. Run both in parallel (with feature flag)
3. Compare outputs to verify correctness
4. Switch traffic once confidence is high
5. Remove old implementation

### Characterization Testing

Before refactoring untested code:
1. Write tests that document current behavior
2. Run tests to establish baseline
3. Refactor while keeping tests green
4. Add proper unit tests after refactoring

## Example Refactoring Plans

### Example 1: Callback → Async/Await

**Goal**: Modernize callback-based photo storage to async/await

**Incremental Steps**:

#### Step 1: Add Tests (2 hours, LOW RISK)
```typescript
// Before any changes, characterize existing behavior
describe('PhotoStorage (Legacy)', () => {
  it('should upload file via callback', (done) => {
    storage.upload(file, (err, result) => {
      expect(err).toBeNull();
      expect(result.url).toBeDefined();
      done();
    });
  });
});
```

#### Step 2: Extract Interface (1 hour, LOW RISK)
```typescript
export interface IPhotoStorage {
  upload(file: File): Promise<StorageResult>;
  delete(key: string): Promise<void>;
}
```

#### Step 3: Create Adapter (2 hours, LOW RISK)
```typescript
export class CallbackPhotoStorageAdapter implements IPhotoStorage {
  constructor(private legacy: LegacyPhotoStorage) {}
  
  async upload(file: File): Promise<StorageResult> {
    return new Promise((resolve, reject) => {
      this.legacy.uploadCallback(file, (err, res) => {
        if (err) reject(err);
        else resolve(res);
      });
    });
  }
}
```

#### Step 4: Implement Modern Version (4 hours, LOW RISK - runs in parallel)
```typescript
export class ModernPhotoStorage implements IPhotoStorage {
  async upload(file: File): Promise<StorageResult> {
    try {
      const buffer = await fs.promises.readFile(file.path);
      const result = await this.s3.upload({ Body: buffer });
      return { url: result.Location, key: result.Key };
    } catch (error) {
      throw new StorageUploadError('Upload failed', error);
    }
  }
}
```

#### Step 5: Feature Flag Rollout (1 week, MEDIUM RISK - production traffic)
```typescript
const storage = featureFlags.isEnabled('modern-storage')
  ? new ModernPhotoStorage(s3, config)
  : new CallbackPhotoStorageAdapter(legacyStorage);
  
// Deploy with flag OFF → ON for 10% → 50% → 100%
```

#### Step 6: Switch Default (1 day, LOW RISK - already proven)
```typescript
// Remove feature flag, use modern by default
const storage = new ModernPhotoStorage(s3, config);
```

#### Step 7: Remove Legacy Code (1 hour, LOW RISK)
```typescript
// Delete: LegacyPhotoStorage, CallbackPhotoStorageAdapter
// Keep: ModernPhotoStorage, IPhotoStorage interface
```

**Total Time**: 2 weeks (including monitoring period)  
**Max Risk at Any Step**: MEDIUM  
**Rollback Strategy**: Disable feature flag or Git revert at each step

---

### Example 2: Class-Based → Functional Components (React/Angular)

**Goal**: Migrate UI components from class-based to functional (with hooks)

**Incremental Steps**:

#### Step 1: Identify Component Tree (1 hour, NO RISK)
```
PhotoGalleryApp (class, 150 lines)
  ├─ PhotoGrid (class, 80 lines)
  │   └─ PhotoCard (class, 45 lines) ← Start here (leaf node)
  ├─ UploadButton (functional, 20 lines) ← Already done
  └─ FilterBar (class, 60 lines)
```

**Strategy**: Migrate bottom-up (leaf nodes first, parents last)

#### Step 2: Migrate PhotoCard (2 hours, LOW RISK - isolated component)
```typescript
// Before:
class PhotoCard extends Component {
  state = { hovered: false };
  handleMouseEnter = () => this.setState({ hovered: true });
  render() { /* ... */ }
}

// After:
function PhotoCard({ photo }: Props) {
  const [hovered, setHovered] = useState(false);
  return (
    <div onMouseEnter={() => setHovered(true)}>
      {/* ... */}
    </div>
  );
}
```

#### Step 3: Test Migration (1 hour, LOW RISK)
```typescript
// Ensure tests still pass with functional component
expect(screen.getByRole('img')).toBeInTheDocument();
```

#### Step 4: Migrate PhotoGrid (3 hours, LOW RISK - parent component)
```typescript
// PhotoCard is now functional, PhotoGrid can safely migrate
function PhotoGrid({ photos }: Props) {
  return (
    <div className="grid">
      {photos.map(p => <PhotoCard key={p.id} photo={p} />)}
    </div>
  );
}
```

#### Steps 5-7: Repeat for remaining components (staggered over 2 weeks)

**Total Time**: 3 weeks (one component per week with testing)  
**Max Risk**: LOW (each component independent)  
**Rollback**: Git revert individual component changes

---

### Example 3: REST API → GraphQL

**Goal**: Migrate from REST endpoints to GraphQL while maintaining backward compatibility

**Incremental Steps**:

#### Step 1: Add GraphQL Server Alongside REST (1 week, LOW RISK)
```typescript
// Both run in parallel:
app.use('/api', restRouter);      // Existing
app.use('/graphql', graphqlRouter); // New
```

#### Step 2: Implement Core Queries (1 week, LOW RISK - new code path)
```graphql
type Query {
  photo(id: ID!): Photo
  photos(limit: Int): [Photo!]!
}
```

#### Step 3: Migrate Mobile App (2 weeks, MEDIUM RISK - production traffic)
```typescript
// Update mobile app to use GraphQL
// Keep REST as fallback
const useGraphQL = featureFlags.isEnabled('graphql-mobile');
```

#### Step 4: Migrate Web App (2 weeks, MEDIUM RISK)
```typescript
// Gradual rollout: 10% → 50% → 100%
```

#### Step 5: Deprecate REST Endpoints (6 months, LOW RISK - gradual sunset)
```typescript
// Add deprecation warnings to REST responses
res.setHeader('X-API-Deprecated', 'Use GraphQL endpoint');
```

#### Step 6: Remove REST (after 6 months monitoring)

**Total Time**: 7 months (includes 6-month deprecation period)  
**Max Risk**: MEDIUM  
**Rollback**: Both systems run in parallel for 6+ months

---

## Integration with Other Skills

- **topology-awareness**: Identifies dependencies for safe refactoring order
- **change-impact-analysis**: Assesses risk at each refactoring step
- **framework-conventions**: Ensures refactored code follows team patterns

## Activation Examples

```typescript
// When developer asks:
// "How should I refactor this 500-line controller to follow clean architecture?"

// Skill activates and provides:
// "Incremental Refactoring Plan (7 steps over 3 weeks):
//  Step 1: Extract business logic into service layer (LOW RISK, 1 day)
//  Step 2: Add unit tests for extracted service (LOW RISK, 1 day)
//  ..."
```

## Metrics

Success criteria for incremental refactoring:
- ✅ Zero "big bang" refactorings (all changes <200 lines per PR)
- ✅ Refactoring-related production incidents reduced by 60%
- ✅ Average refactoring PR time-to-merge decreased by 40%
