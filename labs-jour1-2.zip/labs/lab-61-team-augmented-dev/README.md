# Module 6: Team-Augmented Development

**Duration**: 155-165 minutes hands-on lab

## Overview

This lab demonstrates how to scale AI-assisted development across an entire team using platform-specific configurations. You'll work with a realistic **photo-gallery-fullstack** application (an Nx workspace containing both frontend and API projects) that has been pre-configured with agents, commands, skills, and references for six platforms: Claude Code, GitHub Copilot, Gemini CLI, Codex CLI, OpenCode, and Mistral Vibe.

The backend is **trainee-choosable**: pick NestJS (TypeScript — reference), Spring Boot (Java 17), FastAPI (Python 3.12), .NET (C# 12 / ASP.NET Core 8), or Gin (Go 1.23). All five implement the same OpenAPI contract in `docs/openapi.yaml` and are interchangeable behind the Angular frontend.

**Key Learning Objectives**:

- Apply team-wide AI agents for architecture validation, API contracts, and release safety
- Leverage reusable skills across multiple developers and platforms
- Implement platform-specific conventions (agents, prompts, hooks)
- Manage shared knowledge through references and domain glossaries

## Lab Structure

This lab is organized into six platform-specific sections. **Choose ONE platform** based on your environment:

- **Section A**: Claude Code exercises
- **Section B**: GitHub Copilot exercises
- **Section C**: Gemini CLI exercises
- **Section D**: Codex CLI exercises
- **Section E**: OpenCode exercises
- **Section F**: Mistral Vibe exercises

Each section contains 10 progressive exercises that cover the same capabilities with platform-specific syntax.

## Setup Instructions

### Prerequisites

- One of: Claude Code, GitHub Copilot, Gemini CLI, Codex CLI, OpenCode, or Mistral Vibe access
- Node.js 22+ and npm (always required — the frontend is Angular)
- Git
- Additional toolchain depending on which backend you pick (see **Backend Implementation Options** below):
  - **NestJS** — just Node.js, no extra tooling
  - **Spring Boot** — JDK 17+ (Maven comes via the wrapper)
  - **FastAPI** — Python 3.12+ and `uv` (or `pip`)
  - **.NET** — .NET 8 SDK
  - **Gin** — Go 1.23+

### Initial Setup

1. Navigate to the lab directory or open it in your IDE:

```bash
cd labs/lab-61-team-augmented-dev/photo-gallery-fullstack
```

2. Initialize a Git repository within that directory:

```bash
git init
git add .
git commit -m "chore: initial commit"
```

3. Install dependencies:

```bash
npm ci
```

4. Review project structure:

   - `apps/frontend/` — Angular frontend application
   - `apps/backend-nestjs/` — NestJS backend (TypeScript, reference implementation)
   - `apps/backend-spring/` — Spring Boot backend (Java 17)
   - `apps/backend-fastapi/` — FastAPI backend (Python 3.12)
   - `apps/backend-dotnet/` — ASP.NET Core 8 backend (C# 12)
   - `apps/backend-gin/` — Gin backend (Go 1.23)
   - `docs/openapi.yaml` — canonical HTTP API contract shared by all backends

5. Pick a backend (see **Backend Implementation Options** below) and start it on port 42621. The frontend proxy targets that port unconditionally, so the frontend works against any one of them.

6. Review platform configuration:

   - **Claude users**: Explore `.claude/` directory
   - **Copilot users**: Explore `.github/` directory
   - **Gemini users**: Explore `.gemini/` directory
   - **Codex users**: Explore `.codex/` directory and `AGENTS.md`
   - **OpenCode users**: Explore `.opencode/` directory and `AGENTS.md`
   - **Mistral Vibe users**: Explore `.vibe/` directory and `AGENTS.md`

7. Review shared knowledge:
   - [AGENTS.md](photo-gallery-fullstack/AGENTS.md) — Cross-platform agent reference
   - [references/architecture.md](photo-gallery-fullstack/.claude/references/architecture.md)
   - [references/domain-glossary.md](photo-gallery-fullstack/.claude/references/domain-glossary.md)
   - [docs/openapi.yaml](photo-gallery-fullstack/docs/openapi.yaml) — API contract every backend must honor

---

## Backend Implementation Options

Pick **one** backend to work with. All five implement the same OpenAPI contract and bind port 42621. The stack-specific agent/skill/reference files inside `.claude/`, `.github/`, `.gemini/`, `.codex/`, `.opencode/`, and `.vibe/` contain per-backend sub-blocks — open whichever matches your choice.

<details>
<summary><strong>Backend NestJS (TypeScript) — reference implementation</strong></summary>

**Run:**

```bash
cd labs/lab-61-team-augmented-dev/photo-gallery-fullstack
npm run serve:backend-nestjs
```

Swagger UI at http://localhost:42621/api/docs. See [`docs/backends/nestjs.md`](photo-gallery-fullstack/docs/backends/nestjs.md).

</details>

<details>
<summary><strong>Backend Spring Boot (Java)</strong></summary>

**Run:**

```bash
cd labs/lab-61-team-augmented-dev/photo-gallery-fullstack/apps/backend-spring
./mvnw spring-boot:run
```

Swagger UI at http://localhost:42621/api/docs. See [`docs/backends/spring.md`](photo-gallery-fullstack/docs/backends/spring.md).

</details>

<details>
<summary><strong>Backend FastAPI (Python)</strong></summary>

**Run:**

```bash
cd labs/lab-61-team-augmented-dev/photo-gallery-fullstack
npm run serve:backend-fastapi
```

Swagger UI at http://localhost:42621/api/docs. See [`docs/backends/fastapi.md`](photo-gallery-fullstack/docs/backends/fastapi.md).

</details>

<details>
<summary><strong>Backend .NET (C#)</strong></summary>

**Run:**

```bash
cd labs/lab-61-team-augmented-dev/photo-gallery-fullstack
npm run serve:backend-dotnet
# or directly:
cd apps/backend-dotnet && dotnet run
```

Swagger UI at http://localhost:42621/api/docs. See [`docs/backends/dotnet.md`](photo-gallery-fullstack/docs/backends/dotnet.md).

</details>

<details>
<summary><strong>Backend Gin (Go)</strong></summary>

**Run:**

```bash
cd labs/lab-61-team-augmented-dev/photo-gallery-fullstack
npm run serve:backend-gin
# or directly:
cd apps/backend-gin && go run ./cmd/server
```

Swagger UI at http://localhost:42621/api/docs. See [`docs/backends/gin.md`](photo-gallery-fullstack/docs/backends/gin.md).

</details>

---

<details>
<summary><strong>Claude Code Exercises</strong></summary>

**Platform**: Claude Code
**Documentation**: [CLAUDE.md](photo-gallery-fullstack/CLAUDE.md)

### Exercise A1: Agent Discovery (10 min)

**Objective**: Familiarize yourself with available agents

1. List all configured agents:

```bash
ls .claude/agents/
```

2. Read agent definitions:

   - `architecture-guardian.md` - Design validation
   - `api-contract-agent.md` - API compatibility
   - `legacy-modernizer.md` - Refactoring guidance
   - `test-strategist.md` - Test planning
   - `release-safety.md` - Deployment readiness

3. **Examine agent frontmatter** to understand model and color configuration:

Have a look at `.claude/agents/architecture-guardian.md` file

Notice the `model` field (`opus`, `sonnet`, or `haiku`) which controls which Claude model tier handles the agent's requests, and the `color` field which provides a visual identifier in the Claude Code UI.

4. **Task**: Ask the Architecture Guardian about adding a new feature:

```
@architecture-guardian I need to add a photo filter feature. Should this be in the API layer or domain layer?
```

**Expected Outcome**: Agent analyzes architecture.md and provides layer recommendation

### Exercise A2: Command Exploration (15 min)

**Objective**: Understand available commands

1. Review command definitions in `.claude/commands/`:

   - `/trace-flow` - End-to-end flow tracing
   - `/prepare-pr` - PR description generation
   - `/add-tests` - Test generation
   - `/migration-plan` - Refactoring planning
   - `/explain-oncall` - Incident response
   - `/code-reviewer` - Diff analysis

2. **Task**: Trace the photo upload flow:

```
/trace-flow POST /api/photos/upload
```

**Expected Outcome**: Complete flow from HTTP request → controller → service → repository with file paths and line numbers

### Exercise A3: API Contract Validation (20 min)

**Objective**: Use the API Contract Agent to ensure backward compatibility

1. Open the file for your chosen backend and modify the `uploadPhoto` endpoint to add a new optional `tags` parameter:

<details>
<summary><strong>Backend NestJS (TypeScript)</strong> — <code>apps/backend-nestjs/src/api/photos/photos.controller.ts</code></summary>

```typescript
async uploadPhoto(
  @UploadedFile(
    new ParseFilePipe({
      validators: [
        new MaxFileSizeValidator({ maxSize: 5 * 1024 * 1024 }), // 5MB
        new FileTypeValidator({
          fileType: /image\/(jpeg|png|gif|webp)/,
          fallbackToMimetype: true,
        }),
      ],
    }),
  )
  file: Express.Multer.File,
  @Body('tags') tags?: string,  // NEW: optional tags to add
): Promise<Photo> {
  const tagsList = tags ? tags.split(',').map(t => t.trim()).filter(Boolean) : [];
  // pass along the parsed tags to the service layer (instead of `[]`)
  return this.photoService.uploadPhoto(file, tagsList);
}
```

</details>

<details>
<summary><strong>Backend Spring Boot (Java)</strong> — <code>apps/backend-spring/src/main/java/com/photogallery/backend/api/photos/PhotosController.java</code></summary>

```java
@PostMapping(path = "/upload", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
@ResponseStatus(HttpStatus.CREATED)
public PhotoResponse uploadPhoto(
    @RequestParam("file") MultipartFile file,
    @RequestParam(value = "tags", required = false) String tags  // NEW: optional tags to add
) {
  List<String> tagsList = parseTags(tags);
  // pass along the parsed tags to the service layer (instead of `List.of()`)
  Photo photo = photoService.uploadPhoto(file, tagsList);
}
```

</details>

<details>
<summary><strong>Backend FastAPI (Python)</strong> — <code>apps/backend-fastapi/app/api/photos.py</code></summary>

```python
async def upload_photo(
    service: ServiceDep,
    file: Annotated[UploadFile, File(description="Image file (JPEG/PNG/GIF/WebP), max 5MB")],
    tags: Annotated[str | None, Form(description="Comma-separated tag list")] = None,  # NEW
) -> Photo:
  tagsList = _parse_tags(tags) if tags else []
  # pass along the parsed tags to the service layer (instead of `[]`)
  return service.upload_photo(
    original_filename=file.filename or "upload",
    data=data,
    tags=tagsList,
  )
```

</details>

<details>
<summary><strong>Backend .NET (C#)</strong> — <code>apps/backend-dotnet/Api/Photos/PhotosController.cs</code></summary>

```csharp
/// <summary>
/// Upload a new photo.
/// </summary>
[HttpPost("upload")]
[Consumes("multipart/form-data")]
[RequestSizeLimit(MaxUploadBytes)]
[ProducesResponseType(typeof(PhotoResponse), StatusCodes.Status201Created)]
[ProducesResponseType(typeof(ErrorEnvelope), StatusCodes.Status400BadRequest)]
public async Task<ActionResult<PhotoResponse>> UploadPhoto(
    [FromForm] UploadPhotoDto dto,
    CancellationToken cancellationToken)
{
   // ... existing validation ...
  var tagsList = ParseTags(dto.Tags);
  // pass along the parsed tags to the service layer (instead of ` new List<string>()`)
  var photo = await _photoService.UploadPhotoAsync(uploaded, tagsList, cancellationToken);
  // ...
}
```

</details>

<details>
<summary><strong>Backend Gin (Go)</strong> — <code>apps/backend-gin/internal/api/photos/handler.go</code></summary>

```go
func (h *Handler) Upload(c *gin.Context) {
    fileHeader, err := c.FormFile("file")

    // ... existing validation ...
    tagsList := parseTags(c.PostForm("tags"))  // NEW: optional tags to add
    // pass along the parsed tags to the service layer (instead of `[]string{}`)
    photo, err := h.service.UploadPhoto(c.Request.Context(), domain.UploadedFile{
      OriginalName:   fileHeader.Filename,
      StoredFilename: storedFilename,
      Size:           fileHeader.Size,
    }, tagsList)
}
```

</details>

2. **Task**: Consult the API Contract Agent:

```
@api-contract-agent I've added an optional 'tags' query parameter to POST /api/photos/upload. Is this backward compatible?
```

3. Generate OpenAPI documentation update:

```
/code-reviewer
```

**Expected Outcome**: Agent validates backward compatibility, suggests OpenAPI schema updates

### Exercise A4: Test Strategy Consultation (20 min)

**Objective**: Leverage the Test Strategist for test planning

1. Open the PhotoService for your backend:

<details>
<summary><strong>NestJS (TypeScript)</strong></summary>

`apps/backend-nestjs/src/domain/services/photo.service.ts`

</details>
<details>
<summary><strong>Spring Boot (Java)</strong></summary>

`apps/backend-spring/src/main/java/com/photogallery/backend/domain/service/PhotoService.java`

</details>
<details>
<summary><strong>FastAPI (Python)</strong></summary>

`apps/backend-fastapi/app/domain/services.py`

</details>
<details>
<summary><strong>.NET (C#)</strong></summary>

`apps/backend-dotnet/Domain/Services/PhotoService.cs`

</details>
<details>
<summary><strong>Gin (Go)</strong></summary>

`apps/backend-gin/internal/domain/service.go`

</details>

2. **Task**: Ask the Test Strategist about testing a new method:

```
@test-strategist I'm adding a generateThumbnail method to PhotoService. What test strategy should I use?
```

3. Generate tests using the command:

<details>
<summary><strong>NestJS (TypeScript)</strong></summary>

```
/add-tests apps/backend-nestjs/src/domain/services/photo.service.ts
```

</details>
<details>
<summary><strong>Spring Boot (Java)</strong></summary>

```
/add-tests apps/backend-spring/src/main/java/com/photogallery/backend/domain/service/PhotoService.java
```

</details>
<details>
<summary><strong>FastAPI (Python)</strong></summary>

```
/add-tests apps/backend-fastapi/app/domain/services.py
```

</details>
<details>
<summary><strong>.NET (C#)</strong></summary>

```
/add-tests apps/backend-dotnet/Domain/Services/PhotoService.cs
```

</details>
<details>
<summary><strong>Gin (Go)</strong></summary>

```
/add-tests apps/backend-gin/internal/domain/service.go
```

</details>

**Expected Outcome**: Test strategy recommendation (unit + integration), generated test file with comprehensive coverage

### Exercise A5: Legacy Modernization (25 min)

**Objective**: Safely refactor legacy callback code

1. Locate the storage/legacy code for your backend:

<details>
<summary><strong>NestJS (TypeScript) — callback-based legacy code</strong></summary>

`apps/backend-nestjs/src/infrastructure/storage/legacy-storage.service.ts`

</details>
<details>
<summary><strong>Spring Boot (Java)</strong></summary>

`apps/backend-spring/src/main/java/com/photogallery/backend/domain/service/PhotoService.java` — look for synchronous blocking patterns to modernize

</details>
<details>
<summary><strong>FastAPI (Python)</strong></summary>

`apps/backend-fastapi/app/infrastructure/storage.py` — look for synchronous I/O to convert to async

</details>
<details>
<summary><strong>.NET (C#)</strong></summary>

`apps/backend-dotnet/Infrastructure/Storage/DiskStorage.cs`

</details>
<details>
<summary><strong>Gin (Go)</strong></summary>

`apps/backend-gin/internal/infrastructure/storage.go`

</details>

2. **Task**: Request a migration plan:

```
@legacy-modernizer I need to modernize legacy-storage.service.ts from callbacks to async/await. What's the safest approach?
```

3. Execute the plan:

<details>
<summary><strong>NestJS (TypeScript)</strong></summary>

```
/migration-plan apps/backend-nestjs/src/infrastructure/storage/legacy-storage.service.ts
```

</details>
<details>
<summary><strong>Spring Boot (Java)</strong></summary>

```
/migration-plan apps/backend-spring/src/main/java/com/photogallery/backend/domain/service/PhotoService.java
```

</details>
<details>
<summary><strong>FastAPI (Python)</strong></summary>

```
/migration-plan apps/backend-fastapi/app/infrastructure/storage.py
```

</details>
<details>
<summary><strong>.NET (C#)</strong></summary>

```
/migration-plan apps/backend-dotnet/Infrastructure/Storage/DiskStorage.cs
```

</details>
<details>
<summary><strong>Gin (Go)</strong></summary>

```
/migration-plan apps/backend-gin/internal/infrastructure/storage.go
```

</details>

**Expected Outcome**: Step-by-step incremental refactoring plan with risk assessment and rollback strategy

### Exercise A6: Skills Application (15 min)

**Objective**: Understand reusable skills

1. Review skill definitions in `.claude/skills/`:

   - `topology-awareness` - Dependency mapping
   - `change-impact-analysis` - Risk assessment
   - `incremental-refactoring` - Safe refactoring
   - `framework-conventions` - Pattern enforcement
   - `debug-correlation` - Root cause analysis

2. **Task**: Apply change impact analysis to a hypothetical change:

```
"If I change the PhotoRepository interface, what else will break?"
```

(Agent should invoke `change-impact-analysis` skill automatically)

**Expected Outcome**: List of affected files, classes, and tests

### Exercise A7: Release Readiness Check (20 min)

**Objective**: Validate deployment readiness with Release Safety agent

1. Stage changes for a hypothetical release:

```bash
git add apps/
```

2. **Task**: Consult Release Safety agent:

```
@release-safety Are we ready to deploy these changes to production?
```

3. Generate release checklist:

```
/prepare-pr
```

**Expected Outcome**: Release readiness assessment with deployment risks, rollback plan, monitoring recommendations

### Exercise A8: On-Call Scenario (15 min)

**Objective**: Practice incident response with AI assistance

**Scenario**: Production alert - "High error rate on photo uploads"

1. **Task**: Get on-call guidance:

```
/explain-oncall "High error rate on photo uploads"
```

2. Use debug correlation skill:

```
"What are the most common causes of upload failures based on the architecture?"
```

**Expected Outcome**: Troubleshooting checklist, common root causes from oncall.md, suggested investigation steps

### Exercise A9: Pre-Commit Hook (10 min)

**Objective**: Configure automated validation

1. Review `.claude/settings.json` hooks configuration:

```json
"hooks": {
  "PreToolUse": [
    {
      "matcher": "Bash",
      "hooks": [
        {
          "type": "prompt",
          "prompt": "Run code-reviewer on staged files. Check if this Bash command is a git commit. If so, verify the staged files follow coding standards before allowing the commit. Input: $ARGUMENTS"
        }
      ]
    }
  ],
  "PostToolUse": [
    {
      "matcher": "Write|Edit",
      "hooks": [
        {
          "type": "prompt",
          "prompt": "Validate against coding-standards.md. Review the file changes and check they follow the project's coding standards. Input: $ARGUMENTS"
        }
      ]
    }
  ]
}
```

2. **Task**: Make a code change that violates coding standards and observe hook behavior

**Expected Outcome**: Post-edit hook validates changes against coding standards; pre-commit hook reviews staged files before git commits

### Exercise A10: Team Plugin Usage (15 min)

**Objective**: Install, load, and use custom team workflow plugins

#### Part 1: Load Local Plugin (5 min)

1. **Start Claude Code with the plugin loaded**:

   ```bash
   cd photo-gallery-fullstack
   claude --plugin-dir .claude/plugins/team-workflows
   ```

2. **Verify plugin is loaded** - Run `/help` and look for commands prefixed with `team-workflows:`

3. **Run a plugin command** (note the `:` namespace separator):
   ```
   /team-workflows:analyze-dependencies
   ```
   **Expected**: Analysis of project dependencies with recommendations

#### Part 2: Explore Plugin Components (5 min)

4. **Review plugin structure** in `.claude/plugins/team-workflows/`:

   - `.claude-plugin/plugin.json` - Plugin manifest (name, version, description)
   - `commands/` - Slash commands (analyze-dependencies, generate-changelog, etc.)
   - `agents/` - Sub-agents (security-auditor, performance-optimizer)
   - `skills/` - Reusable capabilities with SKILL.md files
   - `hooks/` - Event handlers (hooks.json)

5. **Try other plugin commands**:
   ```
   /team-workflows:security-scan
   /team-workflows:performance-review
   ```

#### Part 3: Discover Marketplace Plugins (5 min)

6. **Open plugin manager**: `/plugin`

   - Navigate tabs with Tab/Shift+Tab: Discover | Installed | Marketplaces | Errors

7. **Browse official marketplace** (Discover tab):

   - Code intelligence: typescript-lsp, pyright-lsp, rust-analyzer-lsp
   - Integrations: github, slack, notion, linear
   - Workflows: commit-commands, pr-review-toolkit

8. **(Optional) Install a marketplace plugin**:
   ```
   /plugin install commit-commands@claude-plugins-official
   ```

**Key Learnings**:

- Local plugins: `claude --plugin-dir <path>`
- Command namespace: `/plugin-name:command-name`
- Marketplaces: `/plugin` to browse and install
- Plugin scopes: user (default), project (shared), local (gitignored)

</details>

---

<details>
<summary><strong>GitHub Copilot Exercises</strong></summary>

**Platform**: GitHub Copilot  
**Documentation**: [AGENTS.md](photo-gallery-fullstack/AGENTS.md)

### Exercise B1: Agent Discovery (10 min)

**Objective**: Familiarize yourself with Copilot agents

1. Review agent definitions in `.github/agents/`:

   - `architecture-guardian.agent.md`
   - `api-contract-agent.agent.md`
   - `legacy-modernizer.agent.md`
   - `test-strategist.agent.md`
   - `release-safety.agent.md`

2. **Task**: Ask the Architecture Guardian:

```
@architecture-guardian I need to add a photo filter feature. Should this be in the API layer or domain layer?
```

**Expected Outcome**: Agent references `.github/instructions/architecture.instructions.md` and provides recommendation

### Exercise B2: Prompt Exploration (15 min)

**Objective**: Understand available prompts

1. Review prompt definitions in `.github/prompts/`:

   - `trace-flow.prompt.md`
   - `prepare-pr.prompt.md`
   - `add-tests.prompt.md`
   - `migration-plan.prompt.md`
   - `explain-oncall.prompt.md`
   - `code-reviewer.prompt.md`
   - `analyze-diff.prompt.md`
   - `safe-refactor.prompt.md`
   - `test-plan.prompt.md`
   - `release-checklist.prompt.md`

2. **Task**: Invoke trace-flow prompt:

```
#trace-flow POST /api/photos/upload
```

**Expected Outcome**: End-to-end flow diagram with file paths

### Exercise B3: API Contract Validation (20 min)

**Objective**: Use Copilot to ensure API compatibility

1. Open the file for your chosen backend and modify the `uploadPhoto` endpoint to add a new optional `tags` parameter:

<details>
<summary><strong>NestJS (TypeScript)</strong> — <code>apps/backend-nestjs/src/api/photos/photos.controller.ts</code></summary>

```typescript
async uploadPhoto(
  @UploadedFile(
    new ParseFilePipe({
      validators: [
        new MaxFileSizeValidator({ maxSize: 5 * 1024 * 1024 }), // 5MB
        new FileTypeValidator({
          fileType: /image\/(jpeg|png|gif|webp)/,
          fallbackToMimetype: true,
        }),
      ],
    }),
  )
  file: Express.Multer.File,
  @Body('tags') tags?: string,  // NEW: optional tags to add
): Promise<Photo> {
  const tagsList = tags ? tags.split(',').map(t => t.trim()).filter(Boolean) : [];
  // pass along the parsed tags to the service layer (instead of `[]`)
  return this.photoService.uploadPhoto(file, tagsList);
}
```

</details>

<details>
<summary><strong>Spring Boot (Java)</strong> — <code>apps/backend-spring/src/main/java/com/photogallery/backend/api/photos/PhotosController.java</code></summary>

```java
@PostMapping(path = "/upload", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
@ResponseStatus(HttpStatus.CREATED)
public PhotoResponse uploadPhoto(
    @RequestParam("file") MultipartFile file,
    @RequestParam(value = "tags", required = false) String tags  // NEW: optional tags to add
) {
  List<String> tagsList = parseTags(tags);
  // pass along the parsed tags to the service layer (instead of `List.of()`)
  Photo photo = photoService.uploadPhoto(file, tagsList);
}
```

</details>

<details>
<summary><strong>FastAPI (Python)</strong> — <code>apps/backend-fastapi/app/api/photos.py</code></summary>

```python
async def upload_photo(
    service: ServiceDep,
    file: Annotated[UploadFile, File(description="Image file (JPEG/PNG/GIF/WebP), max 5MB")],
    tags: Annotated[str | None, Form(description="Comma-separated tag list")] = None,  # NEW
) -> Photo:
  tagsList = _parse_tags(tags) if tags else []
  # pass along the parsed tags to the service layer (instead of `[]`)
  return service.upload_photo(
    original_filename=file.filename or "upload",
    data=data,
    tags=tagsList,
  )
```

</details>

<details>
<summary><strong>.NET (C#)</strong> — <code>apps/backend-dotnet/Api/Photos/PhotosController.cs</code></summary>

```csharp
/// <summary>
/// Upload a new photo.
/// </summary>
[HttpPost("upload")]
[Consumes("multipart/form-data")]
[RequestSizeLimit(MaxUploadBytes)]
[ProducesResponseType(typeof(PhotoResponse), StatusCodes.Status201Created)]
[ProducesResponseType(typeof(ErrorEnvelope), StatusCodes.Status400BadRequest)]
public async Task<ActionResult<PhotoResponse>> UploadPhoto(
    [FromForm] UploadPhotoDto dto,
    CancellationToken cancellationToken)
{
   // ... existing validation ...
  var tagsList = ParseTags(dto.Tags);
  // pass along the parsed tags to the service layer (instead of ` new List<string>()`)
  var photo = await _photoService.UploadPhotoAsync(uploaded, tagsList, cancellationToken);
  // ...
}
```

</details>

<details>
<summary><strong>Gin (Go)</strong> — <code>apps/backend-gin/internal/api/photos/handler.go</code></summary>

```go
func (h *Handler) Upload(c *gin.Context) {
    fileHeader, err := c.FormFile("file")

    // ... existing validation ...
    tagsList := parseTags(c.PostForm("tags"))  // NEW: optional tags to add
    // pass along the parsed tags to the service layer (instead of `[]string{}`)
    photo, err := h.service.UploadPhoto(c.Request.Context(), domain.UploadedFile{
      OriginalName:   fileHeader.Filename,
      StoredFilename: storedFilename,
      Size:           fileHeader.Size,
    }, tagsList)
}
```

</details>

2. **Task**: Consult API Contract Agent:

```
@api-contract-agent I've added an optional 'tags' query parameter to POST /api/photos/upload. Is this backward compatible?
```

3. Generate OpenAPI documentation update:

```
#analyze-diff
```

**Expected Outcome**: Agent validates backward compatibility, suggests OpenAPI schema updates

### Exercise B4: Test Generation (20 min)

**Objective**: Generate tests using Copilot prompts

1. Open the PhotoService for your backend:

<details>
<summary><strong>NestJS (TypeScript)</strong></summary>

`apps/backend-nestjs/src/domain/services/photo.service.ts`

</details>
<details>
<summary><strong>Spring Boot (Java)</strong></summary>

`apps/backend-spring/src/main/java/com/photogallery/backend/domain/service/PhotoService.java`

</details>
<details>
<summary><strong>FastAPI (Python)</strong></summary>

`apps/backend-fastapi/app/domain/services.py`

</details>
<details>
<summary><strong>.NET (C#)</strong></summary>

`apps/backend-dotnet/Domain/Services/PhotoService.cs`

</details>
<details>
<summary><strong>Gin (Go)</strong></summary>

`apps/backend-gin/internal/domain/service.go`

</details>

2. **Task**: Generate test plan:

<details>
<summary><strong>NestJS (TypeScript)</strong></summary>

```
#test-plan apps/backend-nestjs/src/domain/services/photo.service.ts
```

</details>
<details>
<summary><strong>Spring Boot (Java)</strong></summary>

```
#test-plan apps/backend-spring/src/main/java/com/photogallery/backend/domain/service/PhotoService.java
```

</details>
<details>
<summary><strong>FastAPI (Python)</strong></summary>

```
#test-plan apps/backend-fastapi/app/domain/services.py
```

</details>
<details>
<summary><strong>.NET (C#)</strong></summary>

```
#test-plan apps/backend-dotnet/Domain/Services/PhotoService.cs
```

</details>
<details>
<summary><strong>Gin (Go)</strong></summary>

```
#test-plan apps/backend-gin/internal/domain/service.go
```

</details>

3. Generate actual tests:

<details>
<summary><strong>NestJS (TypeScript)</strong></summary>

```
#add-tests apps/backend-nestjs/src/domain/services/photo.service.ts
```

</details>
<details>
<summary><strong>Spring Boot (Java)</strong></summary>

```
#add-tests apps/backend-spring/src/main/java/com/photogallery/backend/domain/service/PhotoService.java
```

</details>
<details>
<summary><strong>FastAPI (Python)</strong></summary>

```
#add-tests apps/backend-fastapi/app/domain/services.py
```

</details>
<details>
<summary><strong>.NET (C#)</strong></summary>

```
#add-tests apps/backend-dotnet/Domain/Services/PhotoService.cs
```

</details>
<details>
<summary><strong>Gin (Go)</strong></summary>

```
#add-tests apps/backend-gin/internal/domain/service.go
```

</details>

**Expected Outcome**: Comprehensive test suite with unit and integration tests

### Exercise B5: Safe Refactoring (25 min)

**Objective**: Refactor legacy code safely

1. Open the storage/legacy code for your backend:

<details>
<summary><strong>NestJS (TypeScript) — callback-based legacy code</strong></summary>

`apps/backend-nestjs/src/infrastructure/storage/legacy-storage.service.ts`

</details>
<details>
<summary><strong>Spring Boot (Java)</strong></summary>

`apps/backend-spring/src/main/java/com/photogallery/backend/domain/service/PhotoService.java` — look for synchronous blocking patterns to modernize

</details>
<details>
<summary><strong>FastAPI (Python)</strong></summary>

`apps/backend-fastapi/app/infrastructure/storage.py` — look for synchronous I/O to convert to async

</details>
<details>
<summary><strong>.NET (C#)</strong></summary>

`apps/backend-dotnet/Infrastructure/Storage/DiskStorage.cs`

</details>
<details>
<summary><strong>Gin (Go)</strong></summary>

`apps/backend-gin/internal/infrastructure/storage.go`

</details>

2. **Task**: Request safe refactoring:

```
@legacy-modernizer Modernize this file from callbacks to async/await
```

3. Use safe-refactor prompt:

<details>
<summary><strong>NestJS (TypeScript)</strong></summary>

```
#safe-refactor apps/backend-nestjs/src/infrastructure/storage/legacy-storage.service.ts
```

</details>
<details>
<summary><strong>Spring Boot (Java)</strong></summary>

```
#safe-refactor apps/backend-spring/src/main/java/com/photogallery/backend/domain/service/PhotoService.java
```

</details>
<details>
<summary><strong>FastAPI (Python)</strong></summary>

```
#safe-refactor apps/backend-fastapi/app/infrastructure/storage.py
```

</details>
<details>
<summary><strong>.NET (C#)</strong></summary>

```
#safe-refactor apps/backend-dotnet/Infrastructure/Storage/DiskStorage.cs
```

</details>
<details>
<summary><strong>Gin (Go)</strong></summary>

```
#safe-refactor apps/backend-gin/internal/infrastructure/storage.go
```

</details>

**Expected Outcome**: Incremental refactoring steps with tests at each stage

### Exercise B6: Path-Specific Instructions (15 min)

**Objective**: Understand instruction scoping

1. Review `.github/instructions/` files with `applyTo` frontmatter:

   - `architecture.instructions.md` (applyTo: all backend domain layers — `apps/backend-nestjs/src/domain/**`, `apps/backend-spring/.../domain/**`, `apps/backend-fastapi/app/domain/**`, `apps/backend-dotnet/Domain/**`, `apps/backend-gin/internal/domain/**`)
   - `testing-guidelines.instructions.md` (applyTo: `**/*.spec.ts`)

2. **Task**: Edit a domain file and observe how Copilot suggestions follow domain-specific patterns

**Expected Outcome**: Copilot suggestions respect path-specific conventions

### Exercise B7: Hook Execution (15 min)

**Objective**: Understand pre/post hooks

1. Review hook configurations in `.github/hooks/`:

   - `code-reviewer.json` - Pre-tool hook for git commit validation
   - `coding-standards.json` - Post-tool hook for coding standards validation

2. Review hook scripts in `.github/hooks/scripts/`:

   - `validate-commit.sh` / `.ps1` - Run code-reviewer on staged files for git commits
   - `validate-coding-standards.sh` / `.ps1` - Validate against coding-standards.md after edits

3. Example hook configuration (`code-reviewer.json`):

```json
{
  "version": 1,
  "hooks": {
    "preToolUse": [
      {
        "type": "command",
        "bash": ".github/hooks/scripts/validate-commit.sh",
        "powershell": ".github/hooks/scripts/validate-commit.ps1"
      }
    ]
  }
}
```

4. **Task**: Make a code change that violates coding standards and observe hook behavior

**Expected Outcome**: Post-edit hook validates changes against coding standards; pre-commit hook reviews staged files before git commits

### Exercise B8: CI Workflow Integration (15 min)

**Objective**: Understand CI/CD integration

1. Review `.github/workflows/`:

   - `ci.yml` - Lint, test, build
   - `pr-review.yml` - AI-assisted PR review
   - `deploy.yml` - Production deployment

2. **Task**: Trigger PR review workflow:

```bash
git checkout -b feature/test-workflow
git add .
git commit -m "test: trigger PR review"
# (In real scenario, open PR to trigger workflow)
```

**Expected Outcome**: Understanding of automated AI review in CI pipeline

### Exercise B9: Release Checklist (15 min)

**Objective**: Generate release documentation

1. Stage changes:

```bash
git add apps/
```

2. **Task**: Generate release checklist:

```
#release-checklist
```

**Expected Outcome**: Comprehensive release checklist with deployment steps, rollback plan, monitoring

### Exercise B10: On-Call Guidance (15 min)

**Objective**: Practice incident response

**Scenario**: "High error rate on photo uploads"

1. **Task**: Get troubleshooting guidance:

```
#explain-oncall "High error rate on photo uploads"
```

**Expected Outcome**: Incident response steps from `.github/references/oncall.md`

</details>

---

<details>
<summary><strong>Gemini CLI Exercises</strong></summary>

**Platform**: Gemini CLI  
**Documentation**: [GEMINI.md](photo-gallery-fullstack/GEMINI.md)

### Exercise C1: Configuration Review (10 min)

**Objective**: Understand Gemini configuration

1. Review `.gemini/settings.json`:

   - MCP servers configuration
   - Tools configuration
   - Hooks (beforeTool, afterTool)
   - Skills array
   - Commands array

2. **Task**: Verify configuration loads correctly:

```bash
cat .gemini/settings.json | jq .
```

**Expected Outcome**: Valid JSON configuration with all sections

### Exercise C2: Command Discovery (15 min)

**Objective**: Explore TOML commands

1. Review `.gemini/commands/`:

   - `trace-flow.toml`
   - `prepare-pr.toml`
   - `add-tests.toml`
   - `migration-plan.toml`
   - `explain-oncall.toml`
   - `code-reviewer.toml`

2. **Task**: Read a command definition:

```bash
cat .gemini/commands/trace-flow.toml
```

3. Invoke command:

```
/trace-flow POST /api/photos/upload
```

**Expected Outcome**: End-to-end flow trace with file paths and line numbers

### Exercise C3: Hook Execution (20 min)

**Objective**: Understand pre/post hooks

1. Review hooks in `.gemini/settings.json`:

```json
"hooks": {
  "BeforeTool": [
    {
      "matcher": "terminal|shell|bash",
      "hooks": [{ "command": ".gemini/hooks/validate-commit.sh" }]
    },
    {
      "matcher": "write_file|replace",
      "hooks": [{ "command": ".gemini/hooks/validate-writes.sh" }]
    }
  ],
  "AfterTool": [
    {
      "matcher": "write_file|replace",
      "hooks": [{ "command": ".gemini/hooks/validate-coding-standards.sh" }]
    }
  ]
}
```

2. Review hook scripts in `.gemini/hooks/`:

   - `validate-commit.sh` - Run code-reviewer on staged files for git commits
   - `validate-writes.sh` - Security validation before file writes
   - `validate-coding-standards.sh` - Validate against coding-standards.md after edits

3. **Task**: Make a code change that violates coding standards and observe hook behavior

**Expected Outcome**: Post-edit hook validates changes against coding standards; pre-commit hook reviews staged files before git commits

### Exercise C4: API Contract Check (20 min)

**Objective**: Validate API changes

1. Open the file for your chosen backend and modify the `uploadPhoto` endpoint to add a new optional `tags` parameter:

<details>
<summary><strong>NestJS (TypeScript)</strong> — <code>apps/backend-nestjs/src/api/photos/photos.controller.ts</code></summary>

```typescript
async uploadPhoto(
  @UploadedFile(
    new ParseFilePipe({
      validators: [
        new MaxFileSizeValidator({ maxSize: 5 * 1024 * 1024 }), // 5MB
        new FileTypeValidator({
          fileType: /image\/(jpeg|png|gif|webp)/,
          fallbackToMimetype: true,
        }),
      ],
    }),
  )
  file: Express.Multer.File,
  @Body('tags') tags?: string,  // NEW: optional tags to add
): Promise<Photo> {
  const tagsList = tags ? tags.split(',').map(t => t.trim()).filter(Boolean) : [];
  // pass along the parsed tags to the service layer (instead of `[]`)
  return this.photoService.uploadPhoto(file, tagsList);
}
```

</details>

<details>
<summary><strong>Spring Boot (Java)</strong> — <code>apps/backend-spring/src/main/java/com/photogallery/backend/api/photos/PhotosController.java</code></summary>

```java
@PostMapping(path = "/upload", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
@ResponseStatus(HttpStatus.CREATED)
public PhotoResponse uploadPhoto(
    @RequestParam("file") MultipartFile file,
    @RequestParam(value = "tags", required = false) String tags  // NEW: optional tags to add
) {
  List<String> tagsList = parseTags(tags);
  // pass along the parsed tags to the service layer (instead of `List.of()`)
  Photo photo = photoService.uploadPhoto(file, tagsList);
}
```

</details>

<details>
<summary><strong>FastAPI (Python)</strong> — <code>apps/backend-fastapi/app/api/photos.py</code></summary>

```python
async def upload_photo(
    service: ServiceDep,
    file: Annotated[UploadFile, File(description="Image file (JPEG/PNG/GIF/WebP), max 5MB")],
    tags: Annotated[str | None, Form(description="Comma-separated tag list")] = None,  # NEW
) -> Photo:
  tagsList = _parse_tags(tags) if tags else []
  # pass along the parsed tags to the service layer (instead of `[]`)
  return service.upload_photo(
    original_filename=file.filename or "upload",
    data=data,
    tags=tagsList,
  )
```

</details>

<details>
<summary><strong>.NET (C#)</strong> — <code>apps/backend-dotnet/Api/Photos/PhotosController.cs</code></summary>

```csharp
/// <summary>
/// Upload a new photo.
/// </summary>
[HttpPost("upload")]
[Consumes("multipart/form-data")]
[RequestSizeLimit(MaxUploadBytes)]
[ProducesResponseType(typeof(PhotoResponse), StatusCodes.Status201Created)]
[ProducesResponseType(typeof(ErrorEnvelope), StatusCodes.Status400BadRequest)]
public async Task<ActionResult<PhotoResponse>> UploadPhoto(
    [FromForm] UploadPhotoDto dto,
    CancellationToken cancellationToken)
{
   // ... existing validation ...
  var tagsList = ParseTags(dto.Tags);
  // pass along the parsed tags to the service layer (instead of ` new List<string>()`)
  var photo = await _photoService.UploadPhotoAsync(uploaded, tagsList, cancellationToken);
  // ...
}
```

</details>

<details>
<summary><strong>Gin (Go)</strong> — <code>apps/backend-gin/internal/api/photos/handler.go</code></summary>

```go
func (h *Handler) Upload(c *gin.Context) {
    fileHeader, err := c.FormFile("file")

    // ... existing validation ...
    tagsList := parseTags(c.PostForm("tags"))  // NEW: optional tags to add
    // pass along the parsed tags to the service layer (instead of `[]string{}`)
    photo, err := h.service.UploadPhoto(c.Request.Context(), domain.UploadedFile{
      OriginalName:   fileHeader.Filename,
      StoredFilename: storedFilename,
      Size:           fileHeader.Size,
    }, tagsList)
}
```

</details>

2. **Task**: Consult the API Contract Agent:

```
"I've added an optional 'tags' form parameter to POST /api/photos/upload. Is this backward compatible?"
```

3. Generate OpenAPI documentation update:

```
/code-reviewer
```

**Expected Outcome**: Agent validates backward compatibility, suggests OpenAPI schema updates

### Exercise C5: Test Generation (20 min)

**Objective**: Generate comprehensive tests

1. Open the PhotoService for your backend:

<details>
<summary><strong>NestJS (TypeScript)</strong></summary>

`apps/backend-nestjs/src/domain/services/photo.service.ts`

</details>
<details>
<summary><strong>Spring Boot (Java)</strong></summary>

`apps/backend-spring/src/main/java/com/photogallery/backend/domain/service/PhotoService.java`

</details>
<details>
<summary><strong>FastAPI (Python)</strong></summary>

`apps/backend-fastapi/app/domain/services.py`

</details>
<details>
<summary><strong>.NET (C#)</strong></summary>

`apps/backend-dotnet/Domain/Services/PhotoService.cs`

</details>
<details>
<summary><strong>Gin (Go)</strong></summary>

`apps/backend-gin/internal/domain/service.go`

</details>

2. **Task**: Generate tests:

<details>
<summary><strong>NestJS (TypeScript)</strong></summary>

```
/add-tests apps/backend-nestjs/src/domain/services/photo.service.ts
```

</details>
<details>
<summary><strong>Spring Boot (Java)</strong></summary>

```
/add-tests apps/backend-spring/src/main/java/com/photogallery/backend/domain/service/PhotoService.java
```

</details>
<details>
<summary><strong>FastAPI (Python)</strong></summary>

```
/add-tests apps/backend-fastapi/app/domain/services.py
```

</details>
<details>
<summary><strong>.NET (C#)</strong></summary>

```
/add-tests apps/backend-dotnet/Domain/Services/PhotoService.cs
```

</details>
<details>
<summary><strong>Gin (Go)</strong></summary>

```
/add-tests apps/backend-gin/internal/domain/service.go
```

</details>

**Expected Outcome**: Test suite with unit and integration tests, following testing-guidelines.md

### Exercise C6: Migration Planning (25 min)

**Objective**: Plan legacy code modernization

1. Open the storage/legacy code for your backend:

<details>
<summary><strong>NestJS (TypeScript) — callback-based legacy code</strong></summary>

`apps/backend-nestjs/src/infrastructure/storage/legacy-storage.service.ts`

</details>
<details>
<summary><strong>Spring Boot (Java)</strong></summary>

`apps/backend-spring/src/main/java/com/photogallery/backend/domain/service/PhotoService.java` — look for synchronous blocking patterns to modernize

</details>
<details>
<summary><strong>FastAPI (Python)</strong></summary>

`apps/backend-fastapi/app/infrastructure/storage.py` — look for synchronous I/O to convert to async

</details>
<details>
<summary><strong>.NET (C#)</strong></summary>

`apps/backend-dotnet/Infrastructure/Storage/DiskStorage.cs`

</details>
<details>
<summary><strong>Gin (Go)</strong></summary>

`apps/backend-gin/internal/infrastructure/storage.go`

</details>

2. **Task**: Request migration plan:

<details>
<summary><strong>NestJS (TypeScript)</strong></summary>

```
/migration-plan apps/backend-nestjs/src/infrastructure/storage/legacy-storage.service.ts
```

</details>
<details>
<summary><strong>Spring Boot (Java)</strong></summary>

```
/migration-plan apps/backend-spring/src/main/java/com/photogallery/backend/domain/service/PhotoService.java
```

</details>
<details>
<summary><strong>FastAPI (Python)</strong></summary>

```
/migration-plan apps/backend-fastapi/app/infrastructure/storage.py
```

</details>
<details>
<summary><strong>.NET (C#)</strong></summary>

```
/migration-plan apps/backend-dotnet/Infrastructure/Storage/DiskStorage.cs
```

</details>
<details>
<summary><strong>Gin (Go)</strong></summary>

```
/migration-plan apps/backend-gin/internal/infrastructure/storage.go
```

</details>

**Expected Outcome**: Step-by-step refactoring plan with risk assessment

### Exercise C7: Skills Invocation (15 min)

**Objective**: Understand skill usage

1. Review `.gemini/skills/` directory structure (same as Claude)

2. **Task**: Ask a question that triggers change-impact-analysis skill:

```
"If I change the PhotoRepository interface, what files will be affected?"
```

**Expected Outcome**: Dependency analysis using topology-awareness and change-impact-analysis skills

### Exercise C8: On-Call Scenario (15 min)

**Objective**: Practice incident response

**Scenario**: "High error rate on photo uploads"

1. **Task**: Get on-call guidance:

```
/explain-oncall "High error rate on photo uploads"
```

**Expected Outcome**: Troubleshooting steps from references/oncall.md

### Exercise C9: PR Preparation (15 min)

**Objective**: Generate PR documentation

1. Stage changes:

```bash
git add apps/
```

2. **Task**: Generate PR description:

```
/prepare-pr
```

**Expected Outcome**: PR title, description, checklist, testing notes

### Exercise C10: Reference Usage (10 min)

**Objective**: Leverage shared knowledge

1. Review `.gemini/references/`:

   - `architecture.md` - System topology
   - `domain-glossary.md` - Business terms
   - `testing-guidelines.md` - Test patterns
   - `coding-standards.md` - Code conventions
   - `oncall.md` - Incident response

2. **Task**: Ask a question that references domain glossary:

```
"What's the difference between a PhotoAlbum and a PhotoCollection in our domain model?"
```

**Expected Outcome**: Answer derived from domain-glossary.md

</details>

---

<details>
<summary><strong>Codex CLI Exercises</strong></summary>

**Platform**: OpenAI Codex CLI
**Documentation**: [AGENTS.md](photo-gallery-fullstack/AGENTS.md) (auto-read by Codex)

### Exercise D1: Project Trust & Configuration (10 min)

**Objective**: Set up Codex CLI with project configuration

1. Navigate to the project and trust it:

```bash
cd photo-gallery-fullstack
codex trust .
```

2. Review project configuration:

```bash
cat .codex/config.toml
```

3. **Task**: Start Codex and verify configuration loads:

```bash
codex
```

Then use `/status` to see current settings.

**Expected Outcome**: Codex loads with `gpt-5-codex` model, `on-request` approval policy

### Exercise D2: AGENTS.md Discovery (15 min)

**Objective**: Understand how AGENTS.md provides project context

1. Review `AGENTS.md` at project root - this file is automatically read by Codex

2. **Task**: Ask Codex about the project architecture:

```
"Describe the architecture of this photo gallery application"
```

3. Verify Codex references information from AGENTS.md

**Expected Outcome**: Response includes Angular frontend, your chosen backend, layered architecture details from AGENTS.md

### Exercise D3: Skills Exploration (15 min)

**Objective**: Discover and use available skills

1. List available skills:

```
/skills
```

2. Review skill definitions in `.codex/skills/`:

   - `topology-awareness` - Dependency mapping
   - `change-impact-analysis` - Risk assessment
   - `incremental-refactoring` - Safe refactoring
   - `framework-conventions` - Pattern enforcement
   - `debug-correlation` - Root cause analysis

3. **Task**: Explicitly invoke a skill:

```
$topology-awareness "What are the dependencies of PhotoService?"
```

**Expected Outcome**: Skill activates and provides dependency analysis

### Exercise D4: Profile Switching (15 min)

**Objective**: Use profiles for different workflow contexts

1. Review available profiles in `.codex/config.toml`:

   - `deep-review` - High reasoning, thorough analysis
   - `lightweight` - Fast iteration
   - `architecture` - Design validation
   - `testing` - Test generation
   - `code-review` - Balanced review

2. **Task**: Start Codex with the deep-review profile:

```bash
codex --profile deep-review
```

3. Ask for architecture validation:

```
"I need to add a photo filter feature. Should this be in the API layer or domain layer?"
```

4. Compare with lightweight profile:

```bash
codex --profile lightweight
```

**Expected Outcome**: Deep-review provides thorough analysis with high reasoning; lightweight gives faster, more concise responses

### Exercise D5: API Change Analysis (20 min)

**Objective**: Use skills for API backward compatibility

1. Start Codex with code-review profile:

```bash
codex --profile code-review
```

2. Open the file for your chosen backend and modify the `uploadPhoto` endpoint to add a new optional `tags` parameter:

<details>
<summary><strong>NestJS (TypeScript)</strong> — <code>apps/backend-nestjs/src/api/photos/photos.controller.ts</code></summary>

```typescript
async uploadPhoto(
  @UploadedFile(
    new ParseFilePipe({
      validators: [
        new MaxFileSizeValidator({ maxSize: 5 * 1024 * 1024 }), // 5MB
        new FileTypeValidator({
          fileType: /image\/(jpeg|png|gif|webp)/,
          fallbackToMimetype: true,
        }),
      ],
    }),
  )
  file: Express.Multer.File,
  @Body('tags') tags?: string,  // NEW: optional tags to add
): Promise<Photo> {
  const tagsList = tags ? tags.split(',').map(t => t.trim()).filter(Boolean) : [];
  // pass along the parsed tags to the service layer (instead of `[]`)
  return this.photoService.uploadPhoto(file, tagsList);
}
```

</details>

<details>
<summary><strong>Spring Boot (Java)</strong> — <code>apps/backend-spring/src/main/java/com/photogallery/backend/api/photos/PhotosController.java</code></summary>

```java
@PostMapping(path = "/upload", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
@ResponseStatus(HttpStatus.CREATED)
public PhotoResponse uploadPhoto(
    @RequestParam("file") MultipartFile file,
    @RequestParam(value = "tags", required = false) String tags  // NEW: optional tags to add
) {
  List<String> tagsList = parseTags(tags);
  // pass along the parsed tags to the service layer (instead of `List.of()`)
  Photo photo = photoService.uploadPhoto(file, tagsList);
}
```

</details>

<details>
<summary><strong>FastAPI (Python)</strong> — <code>apps/backend-fastapi/app/api/photos.py</code></summary>

```python
async def upload_photo(
    service: ServiceDep,
    file: Annotated[UploadFile, File(description="Image file (JPEG/PNG/GIF/WebP), max 5MB")],
    tags: Annotated[str | None, Form(description="Comma-separated tag list")] = None,  # NEW
) -> Photo:
  tagsList = _parse_tags(tags) if tags else []
  # pass along the parsed tags to the service layer (instead of `[]`)
  return service.upload_photo(
    original_filename=file.filename or "upload",
    data=data,
    tags=tagsList,
  )
```

</details>

<details>
<summary><strong>.NET (C#)</strong> — <code>apps/backend-dotnet/Api/Photos/PhotosController.cs</code></summary>

```csharp
/// <summary>
/// Upload a new photo.
/// </summary>
[HttpPost("upload")]
[Consumes("multipart/form-data")]
[RequestSizeLimit(MaxUploadBytes)]
[ProducesResponseType(typeof(PhotoResponse), StatusCodes.Status201Created)]
[ProducesResponseType(typeof(ErrorEnvelope), StatusCodes.Status400BadRequest)]
public async Task<ActionResult<PhotoResponse>> UploadPhoto(
    [FromForm] UploadPhotoDto dto,
    CancellationToken cancellationToken)
{
   // ... existing validation ...
  var tagsList = ParseTags(dto.Tags);
  // pass along the parsed tags to the service layer (instead of ` new List<string>()`)
  var photo = await _photoService.UploadPhotoAsync(uploaded, tagsList, cancellationToken);
  // ...
}
```

</details>

<details>
<summary><strong>Gin (Go)</strong> — <code>apps/backend-gin/internal/api/photos/handler.go</code></summary>

```go
func (h *Handler) Upload(c *gin.Context) {
    fileHeader, err := c.FormFile("file")

    // ... existing validation ...
    tagsList := parseTags(c.PostForm("tags"))  // NEW: optional tags to add
    // pass along the parsed tags to the service layer (instead of `[]string{}`)
    photo, err := h.service.UploadPhoto(c.Request.Context(), domain.UploadedFile{
      OriginalName:   fileHeader.Filename,
      StoredFilename: storedFilename,
      Size:           fileHeader.Size,
    }, tagsList)
}
```

</details>

3. **Task**: Ask about backward compatibility:

```
"I've added an optional 'tags' form parameter to POST /api/photos/upload. Is this backward compatible?"
```

4. Generate OpenAPI documentation update:

```
$change-impact-analysis "Adding tags parameter to upload endpoint"
```

**Expected Outcome**: Agent validates backward compatibility, suggests OpenAPI schema updates

### Exercise D6: Legacy Modernization (25 min)

**Objective**: Plan safe refactoring with skills

1. Open the storage/legacy code for your backend:

<details>
<summary><strong>NestJS (TypeScript) — callback-based legacy code</strong></summary>

`apps/backend-nestjs/src/infrastructure/storage/legacy-storage.service.ts`

</details>
<details>
<summary><strong>Spring Boot (Java)</strong></summary>

`apps/backend-spring/src/main/java/com/photogallery/backend/domain/service/PhotoService.java` — look for synchronous blocking patterns to modernize

</details>
<details>
<summary><strong>FastAPI (Python)</strong></summary>

`apps/backend-fastapi/app/infrastructure/storage.py` — look for synchronous I/O to convert to async

</details>
<details>
<summary><strong>.NET (C#)</strong></summary>

`apps/backend-dotnet/Infrastructure/Storage/DiskStorage.cs`

</details>
<details>
<summary><strong>Gin (Go)</strong></summary>

`apps/backend-gin/internal/infrastructure/storage.go`

</details>

2. **Task**: Request refactoring guidance:

```
$incremental-refactoring "Modernize legacy-storage.service.ts from callbacks to async/await"
```

3. Follow the step-by-step plan provided

**Expected Outcome**: Detailed migration plan with:

- Step 1: Add async wrapper methods
- Step 2: Migrate consumers one-by-one
- Step 3: Replace implementation
- Step 4: Remove legacy code
- Checkpoints and rollback strategies at each step

### Exercise D7: Test Strategy (20 min)

**Objective**: Use testing profile for test planning

1. Start with testing profile:

```bash
codex --profile testing
```

2. Open the PhotoService for your backend:

<details>
<summary><strong>NestJS (TypeScript)</strong></summary>

`apps/backend-nestjs/src/domain/services/photo.service.ts`

</details>
<details>
<summary><strong>Spring Boot (Java)</strong></summary>

`apps/backend-spring/src/main/java/com/photogallery/backend/domain/service/PhotoService.java`

</details>
<details>
<summary><strong>FastAPI (Python)</strong></summary>

`apps/backend-fastapi/app/domain/services.py`

</details>
<details>
<summary><strong>.NET (C#)</strong></summary>

`apps/backend-dotnet/Domain/Services/PhotoService.cs`

</details>
<details>
<summary><strong>Gin (Go)</strong></summary>

`apps/backend-gin/internal/domain/service.go`

</details>

3. **Task**: Ask for test strategy:

```
"I'm adding a generateThumbnail method to PhotoService. What test strategy should I use?"
```

4. Use framework-conventions skill:

```
$framework-conventions "Show me the test patterns for the backend service layer"
```

**Expected Outcome**: Test strategy covering unit tests, integration tests, and test patterns following framework conventions

### Exercise D8: Built-in Code Review (15 min)

**Objective**: Use Codex's built-in review command

1. Make a code change (or stage existing changes):

```bash
git add apps/
```

2. **Task**: Use the built-in review command:

```
/review
```

3. Alternatively, ask directly:

```
"Review the changes in my working tree"
```

**Expected Outcome**: AI-assisted review of staged changes with risk assessment and recommendations

### Exercise D9: On-Call Debugging (15 min)

**Objective**: Use debug-correlation skill for incident response

**Scenario**: "High error rate on photo uploads"

1. **Task**: Invoke debug skill:

```
$debug-correlation "High error rate on photo uploads - help me investigate"
```

2. Follow the correlation workflow:
   - Check frontend logs
   - Check backend controller/service logs
   - Check storage operations
   - Check database operations

**Expected Outcome**: Systematic debugging approach with:

- Correlation points across the stack
- Common causes (file size, disk space, SQLite locks)
- Resolution steps

### Exercise D10: Custom Rules (15 min)

**Objective**: Understand execution rules for command control

1. Review how rules work (configured in `~/.codex/rules/default.rules`)

2. **Task**: Use the execpolicy check command:

```bash
codex execpolicy check -- npm run test
```

3. Understand rule decisions:

   - `allow` - Execute without prompting
   - `prompt` - Ask before executing
   - `forbidden` - Block execution

4. Example rule structure (for reference):

```starlark
# Allow npm commands
prefix_rule(pattern=["npm", "run"], decision="allow")

# Prompt for git push
prefix_rule(pattern=["git", "push"], decision="prompt")
```

**Expected Outcome**: Understanding of how rules control command execution in Codex sandbox

</details>

---

<details>
<summary><strong>OpenCode CLI Exercises</strong></summary>

**Platform**: OpenCode CLI
**Documentation**: [AGENTS.md](photo-gallery-fullstack/AGENTS.md)

> **Note**: OpenCode automatically reads both `AGENTS.md` and `CLAUDE.md` (fallback). The `.opencode/agents/` directory contains project-specific custom agent definitions. Use `Tab` to toggle between Build and Plan modes; `ctrl+x` is the leader key for TUI navigation.

### Exercise E1: Agent Discovery (10 min)

**Objective**: Familiarize yourself with available agents

1. List all configured agents:

```bash
ls photo-gallery-fullstack/.opencode/agents/
```

2. Read agent definitions:

   - `architecture-guardian.md` - Design validation
   - `api-contract-agent.md` - API compatibility
   - `legacy-modernizer.md` - Refactoring guidance
   - `test-strategist.md` - Test planning
   - `release-safety.md` - Deployment readiness

3. Start OpenCode in the project:

```bash
cd photo-gallery-fullstack && opencode
```

4. **Task**: Ask the Architecture Guardian about adding a new feature using `@mention` syntax:

```
@architecture-guardian I need to add a photo filter feature. Should this be in the API layer or domain layer?
```

**Expected Outcome**: Agent analyzes AGENTS.md and architecture context, provides layer recommendation

**Note**: OpenCode uses `@mention` syntax for agents, identical to Claude Code. Press `Tab` to switch to Plan mode if you want the agent to plan before executing changes.

### Exercise E2: Command Exploration (15 min)

**Objective**: Understand available commands

1. Review command definitions in `.opencode/command/` (note: singular directory):

   - `/trace-flow` - End-to-end flow tracing
   - `/prepare-pr` - PR description generation
   - `/add-tests` - Test generation
   - `/migration-plan` - Refactoring planning
   - `/explain-oncall` - Incident response
   - `/code-reviewer` - Diff analysis

2. **Task**: Trace the photo upload flow:

```
/trace-flow POST /api/photos/upload
```

**Expected Outcome**: Complete flow from HTTP request → controller → service → repository with file paths and line numbers

**Note**: OpenCode command invocation (`/command-name`) is identical to Claude Code. The difference is that commands are stored in `.opencode/command/` (singular) rather than `.claude/commands/`.

### Exercise E3: API Contract Validation (20 min)

**Objective**: Use the API Contract Agent to ensure backward compatibility

1. Open the file for your chosen backend and modify the `uploadPhoto` endpoint to add a new optional `tags` parameter:

<details>
<summary><strong>NestJS (TypeScript)</strong> — <code>apps/backend-nestjs/src/api/photos/photos.controller.ts</code></summary>

```typescript
async uploadPhoto(
  @UploadedFile(
    new ParseFilePipe({
      validators: [
        new MaxFileSizeValidator({ maxSize: 5 * 1024 * 1024 }), // 5MB
        new FileTypeValidator({
          fileType: /image\/(jpeg|png|gif|webp)/,
          fallbackToMimetype: true,
        }),
      ],
    }),
  )
  file: Express.Multer.File,
  @Body('tags') tags?: string,  // NEW: optional tags to add
): Promise<Photo> {
  const tagsList = tags ? tags.split(',').map(t => t.trim()).filter(Boolean) : [];
  // pass along the parsed tags to the service layer (instead of `[]`)
  return this.photoService.uploadPhoto(file, tagsList);
}
```

</details>

<details>
<summary><strong>Spring Boot (Java)</strong> — <code>apps/backend-spring/src/main/java/com/photogallery/backend/api/photos/PhotosController.java</code></summary>

```java
@PostMapping(path = "/upload", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
@ResponseStatus(HttpStatus.CREATED)
public PhotoResponse uploadPhoto(
    @RequestParam("file") MultipartFile file,
    @RequestParam(value = "tags", required = false) String tags  // NEW: optional tags to add
) {
  List<String> tagsList = parseTags(tags);
  // pass along the parsed tags to the service layer (instead of `List.of()`)
  Photo photo = photoService.uploadPhoto(file, tagsList);
}
```

</details>

<details>
<summary><strong>FastAPI (Python)</strong> — <code>apps/backend-fastapi/app/api/photos.py</code></summary>

```python
async def upload_photo(
    service: ServiceDep,
    file: Annotated[UploadFile, File(description="Image file (JPEG/PNG/GIF/WebP), max 5MB")],
    tags: Annotated[str | None, Form(description="Comma-separated tag list")] = None,  # NEW
) -> Photo:
  tagsList = _parse_tags(tags) if tags else []
  # pass along the parsed tags to the service layer (instead of `[]`)
  return service.upload_photo(
    original_filename=file.filename or "upload",
    data=data,
    tags=tagsList,
  )
```

</details>

<details>
<summary><strong>.NET (C#)</strong> — <code>apps/backend-dotnet/Api/Photos/PhotosController.cs</code></summary>

```csharp
/// <summary>
/// Upload a new photo.
/// </summary>
[HttpPost("upload")]
[Consumes("multipart/form-data")]
[RequestSizeLimit(MaxUploadBytes)]
[ProducesResponseType(typeof(PhotoResponse), StatusCodes.Status201Created)]
[ProducesResponseType(typeof(ErrorEnvelope), StatusCodes.Status400BadRequest)]
public async Task<ActionResult<PhotoResponse>> UploadPhoto(
    [FromForm] UploadPhotoDto dto,
    CancellationToken cancellationToken)
{
   // ... existing validation ...
  var tagsList = ParseTags(dto.Tags);
  // pass along the parsed tags to the service layer (instead of ` new List<string>()`)
  var photo = await _photoService.UploadPhotoAsync(uploaded, tagsList, cancellationToken);
  // ...
}
```

</details>

<details>
<summary><strong>Gin (Go)</strong> — <code>apps/backend-gin/internal/api/photos/handler.go</code></summary>

```go
func (h *Handler) Upload(c *gin.Context) {
    fileHeader, err := c.FormFile("file")

    // ... existing validation ...
    tagsList := parseTags(c.PostForm("tags"))  // NEW: optional tags to add
    // pass along the parsed tags to the service layer (instead of `[]string{}`)
    photo, err := h.service.UploadPhoto(c.Request.Context(), domain.UploadedFile{
      OriginalName:   fileHeader.Filename,
      StoredFilename: storedFilename,
      Size:           fileHeader.Size,
    }, tagsList)
}
```

</details>

2. **Task**: Consult the API Contract Agent:

```
@api-contract-agent I've added an optional 'tags' query parameter to POST /api/photos/upload. Is this backward compatible?
```

3. Generate OpenAPI documentation update:

```
/code-reviewer
```

**Expected Outcome**: Agent validates backward compatibility, suggests OpenAPI schema updates

### Exercise E4: Test Strategy Consultation (20 min)

**Objective**: Leverage the Test Strategist for test planning

1. Open the PhotoService for your backend:

<details>
<summary><strong>NestJS (TypeScript)</strong></summary>

`apps/backend-nestjs/src/domain/services/photo.service.ts`

</details>
<details>
<summary><strong>Spring Boot (Java)</strong></summary>

`apps/backend-spring/src/main/java/com/photogallery/backend/domain/service/PhotoService.java`

</details>
<details>
<summary><strong>FastAPI (Python)</strong></summary>

`apps/backend-fastapi/app/domain/services.py`

</details>
<details>
<summary><strong>.NET (C#)</strong></summary>

`apps/backend-dotnet/Domain/Services/PhotoService.cs`

</details>
<details>
<summary><strong>Gin (Go)</strong></summary>

`apps/backend-gin/internal/domain/service.go`

</details>

2. **Task**: Ask the Test Strategist about testing a new method:

```
@test-strategist I'm adding a generateThumbnail method to PhotoService. What test strategy should I use?
```

3. Generate tests using the command:

<details>
<summary><strong>NestJS (TypeScript)</strong></summary>

```
/add-tests apps/backend-nestjs/src/domain/services/photo.service.ts
```

</details>
<details>
<summary><strong>Spring Boot (Java)</strong></summary>

```
/add-tests apps/backend-spring/src/main/java/com/photogallery/backend/domain/service/PhotoService.java
```

</details>
<details>
<summary><strong>FastAPI (Python)</strong></summary>

```
/add-tests apps/backend-fastapi/app/domain/services.py
```

</details>
<details>
<summary><strong>.NET (C#)</strong></summary>

```
/add-tests apps/backend-dotnet/Domain/Services/PhotoService.cs
```

</details>
<details>
<summary><strong>Gin (Go)</strong></summary>

```
/add-tests apps/backend-gin/internal/domain/service.go
```

</details>

**Expected Outcome**: Test strategy recommendation (unit + integration), generated test file with comprehensive coverage

### Exercise E5: Legacy Modernization (25 min)

**Objective**: Safely refactor legacy callback code

1. Locate the storage/legacy code for your backend:

<details>
<summary><strong>NestJS (TypeScript) — callback-based legacy code</strong></summary>

`apps/backend-nestjs/src/infrastructure/storage/legacy-storage.service.ts`

</details>
<details>
<summary><strong>Spring Boot (Java)</strong></summary>

`apps/backend-spring/src/main/java/com/photogallery/backend/domain/service/PhotoService.java` — look for synchronous blocking patterns to modernize

</details>
<details>
<summary><strong>FastAPI (Python)</strong></summary>

`apps/backend-fastapi/app/infrastructure/storage.py` — look for synchronous I/O to convert to async

</details>
<details>
<summary><strong>.NET (C#)</strong></summary>

`apps/backend-dotnet/Infrastructure/Storage/DiskStorage.cs`

</details>
<details>
<summary><strong>Gin (Go)</strong></summary>

`apps/backend-gin/internal/infrastructure/storage.go`

</details>

2. **Task**: Request a migration plan using Plan mode — press `Tab` to enter Plan mode, then send:

```
@legacy-modernizer I need to modernize legacy-storage.service.ts from callbacks to async/await. What's the safest approach?
```

3. Execute the plan:

<details>
<summary><strong>NestJS (TypeScript)</strong></summary>

```
/migration-plan apps/backend-nestjs/src/infrastructure/storage/legacy-storage.service.ts
```

</details>
<details>
<summary><strong>Spring Boot (Java)</strong></summary>

```
/migration-plan apps/backend-spring/src/main/java/com/photogallery/backend/domain/service/PhotoService.java
```

</details>
<details>
<summary><strong>FastAPI (Python)</strong></summary>

```
/migration-plan apps/backend-fastapi/app/infrastructure/storage.py
```

</details>
<details>
<summary><strong>.NET (C#)</strong></summary>

```
/migration-plan apps/backend-dotnet/Infrastructure/Storage/DiskStorage.cs
```

</details>
<details>
<summary><strong>Gin (Go)</strong></summary>

```
/migration-plan apps/backend-gin/internal/infrastructure/storage.go
```

</details>

**Expected Outcome**: Step-by-step incremental refactoring plan with risk assessment and rollback strategy

**Note**: OpenCode's Plan mode (toggled with `Tab`) ensures the agent plans all changes and shows them for review before executing — equivalent to Claude Code's Plan mode (`Shift+Tab`).

### Exercise E6: Skills Application (15 min)

**Objective**: Understand reusable skills (cross-platform SKILL.md format)

1. Review skill definitions in `.claude/skills/` (OpenCode reads Claude-compatible skills):

   - `topology-awareness` - Dependency mapping
   - `change-impact-analysis` - Risk assessment
   - `incremental-refactoring` - Safe refactoring
   - `framework-conventions` - Pattern enforcement
   - `debug-correlation` - Root cause analysis

2. **Task**: Apply change impact analysis to a hypothetical change:

```
"If I change the PhotoRepository interface, what else will break?"
```

(Agent invokes `change-impact-analysis` skill automatically from context)

**Expected Outcome**: List of affected files, classes, and tests

**Note**: OpenCode is compatible with skills stored in `~/.claude/skills/` following the SKILL.md format — the cross-platform agent skills standard.

### Exercise E7: Release Readiness Check (20 min)

**Objective**: Validate deployment readiness with Release Safety agent

1. Stage changes for a hypothetical release:

```bash
git add apps/
```

2. **Task**: Consult Release Safety agent:

```
@release-safety Are we ready to deploy these changes to production?
```

3. Generate release checklist:

```
/prepare-pr
```

**Expected Outcome**: Release readiness assessment with deployment risks, rollback plan, monitoring recommendations

### Exercise E8: On-Call Scenario (15 min)

**Objective**: Practice incident response with AI assistance

**Scenario**: Production alert - "High error rate on photo uploads"

1. **Task**: Get on-call guidance:

```
/explain-oncall "High error rate on photo uploads"
```

2. Use debug correlation skill:

```
"What are the most common causes of upload failures based on the architecture?"
```

**Expected Outcome**: Troubleshooting checklist, common root causes from oncall.md, suggested investigation steps

### Exercise E9: TypeScript Plugin — Lifecycle Hook (10 min)

**Objective**: Explore OpenCode's TypeScript plugin system (equivalent to Claude Code's settings.json hooks, but TypeScript-based)

1. Review the coding standards plugin in `.opencode/plugins/coding-standards.ts`:

```typescript
const CODING_STANDARDS_REFERENCE = '.opencode/references/coding-standards.md';

export const CodingStandardsPlugin = async ({ client }) => {
  const referenceText = await Bun.file(new URL('../references/coding-standards.md', import.meta.url)).text();

  return {
    'tool.execute.before': async (input, output) => {
      if (input.tool !== 'edit' && input.tool !== 'write') return;

      const content = `${output.args?.content ?? ''}\n${output.args?.newString ?? ''}`;
      if (referenceText.includes('### Avoid `any`') && /:\s*any\b|\bas\s+any\b/.test(content)) {
        throw new Error(`Coding standards violation: avoid \`any\` types. See ${CODING_STANDARDS_REFERENCE}.`);
      }
    },

    'file.edited': async ({ path }) => {
      if (!path?.match(/\.(ts|tsx|js|jsx)$/)) return;

      await client.app.log({
        body: {
          service: 'coding-standards',
          level: 'info',
          message: `Review ${path} against ${CODING_STANDARDS_REFERENCE}.`,
        },
      });
    },
  };
};
```

2. **Task**: Ask OpenCode to add a variable with `any` type and observe the plugin intercepting it:

```
Add a temporary variable of type any to photo.service.ts
```

3. Compare with Claude Code's `settings.json` hook approach:
   - Claude Code: JSON config in `settings.json` with shell script + `type: "prompt"` hooks
   - OpenCode: exported JavaScript/TypeScript plugin function returning lifecycle hooks such as `tool.execute.before` and `file.edited`

**Expected Outcome**: Plugin intercepts the edit request, throws a blocking error, and logs a reminder to review `.opencode/references/coding-standards.md` after TypeScript files are edited

**Key Difference**: OpenCode plugins are TypeScript/JavaScript modules that export async plugin functions. They can reuse project references and Bun APIs directly, so the example stays cross-platform without depending on `.opencode/hooks/*.sh` scripts.

### Exercise E10: Session Sharing & Headless Mode (15 min)

**Objective**: Explore OpenCode-unique features: public session sharing and headless/CI mode

#### Part 1: Session Sharing (5 min)

1. Start a debugging session in OpenCode:

```
Analyze the photo upload flow and identify potential performance bottlenecks
```

2. Share the session publicly:

```
/share
```

Or press `ctrl+x s`

3. OpenCode generates a public URL — share it with a teammate for async review

**Expected Outcome**: A shareable conversation URL is generated, allowing teammates to review the AI analysis without re-running the session

#### Part 2: Headless/CI Mode (10 min)

4. Run OpenCode in non-interactive (headless) mode:

Use `opencode run` with your backend's PhotoService path:

<details>
<summary><strong>NestJS (TypeScript)</strong></summary>

```bash
opencode run "Review apps/backend-nestjs/src/domain/services/photo.service.ts for architectural compliance"
```

</details>
<details>
<summary><strong>Spring Boot (Java)</strong></summary>

```bash
opencode run "Review apps/backend-spring/src/main/java/com/photogallery/backend/domain/service/PhotoService.java for architectural compliance"
```

</details>
<details>
<summary><strong>FastAPI (Python)</strong></summary>

```bash
opencode run "Review apps/backend-fastapi/app/domain/services.py for architectural compliance"
```

</details>
<details>
<summary><strong>.NET (C#)</strong></summary>

```bash
opencode run "Review apps/backend-dotnet/Domain/Services/PhotoService.cs for architectural compliance"
```

</details>
<details>
<summary><strong>Gin (Go)</strong></summary>

```bash
opencode run "Review apps/backend-gin/internal/domain/service.go for architectural compliance"
```

</details>

5. Use it in a CI script:

```bash
# Pre-commit check (add to .husky/pre-commit)
opencode run "Check if staged files follow team coding standards and fail if violations are found"
```

**Expected Outcome**: OpenCode returns analysis to stdout without opening the interactive TUI — suitable for CI/CD pipelines

**Key Difference from Claude Code**: OpenCode's `opencode run` enables true non-interactive CI use. Claude Code uses `claude -p` (print mode) for the same purpose.

</details>

---

<details>
<summary><strong>Mistral Vibe Exercises</strong></summary>

**Platform**: Mistral Vibe
**Documentation**: [AGENTS.md](photo-gallery-fullstack/AGENTS.md) (auto-read by Mistral Vibe at session start)

> **Note**: Mistral Vibe is installed with `curl -LsSf https://mistral.ai/vibe/install.sh | bash` (or `uv tool install mistral-vibe`). Launch the interactive session with `vibe`; run the ACP integration with `vibe-acp`. All project settings live in TOML under `.vibe/` (`config.toml`, `hooks.toml`). Mistral Vibe unifies reusable skills and user-invocable slash commands under a single **skills system** in `.vibe/skills/`. Use `@` to mention agents/files, `/` to run skill-commands, and `!` to run shell commands.

### Exercise F1: Folder Trust & Configuration (10 min)

**Objective**: Set up Mistral Vibe with the project configuration

1. Navigate to the project and start Mistral Vibe:

```bash
cd photo-gallery-fullstack
vibe
```

On first run, Mistral Vibe shows a **folder-trust prompt** — approve it so the project's `.vibe/` configuration is loaded.

2. (Optional) Run interactive configuration:

```bash
vibe --setup
```

3. Review the TOML configuration:

```bash
cat .vibe/config.toml
```

**Expected Outcome**: Mistral Vibe loads with the project trusted, the `default` permission mode, and the `.vibe/agents` and `.vibe/skills` directories registered.

### Exercise F2: Agent Discovery (10 min)

**Objective**: Familiarize yourself with available agents

1. List all configured agents:

```bash
ls .vibe/agents/
```

2. Read agent definitions:

   - `architecture-guardian.md` - Design validation
   - `api-contract-agent.md` - API compatibility
   - `legacy-modernizer.md` - Refactoring guidance
   - `test-strategist.md` - Test planning
   - `release-safety.md` - Deployment readiness

3. **Task**: Ask the Architecture Guardian about adding a new feature using `@mention` syntax:

```
@architecture-guardian I need to add a photo filter feature. Should this be in the API layer or domain layer?
```

**Expected Outcome**: Agent analyzes `AGENTS.md` and the architecture references, then provides a layer recommendation.

### Exercise F3: Slash Commands via the Skills System (15 min)

**Objective**: Understand how Mistral Vibe exposes repeatable workflows

1. Review the skills system in `.vibe/skills/`. It holds two kinds of entries:

   - **Reusable skills** (model-invoked): `topology-awareness`, `change-impact-analysis`, `incremental-refactoring`, `framework-conventions`, `debug-correlation`
   - **Slash commands** (user-invoked with `/`): `trace-flow`, `prepare-pr`, `add-tests`, `migration-plan`, `explain-oncall`, `code-reviewer`

2. **Task**: Trace the photo upload flow:

```
/trace-flow POST /api/photos/upload
```

**Expected Outcome**: Complete flow from HTTP request → controller → service → repository with file paths and line numbers.

**Note**: In Mistral Vibe there is one skills system. Each `SKILL.md` under `.vibe/skills/` is either activated automatically from context (reusable skills) or invoked explicitly with a leading `/` (slash commands).

### Exercise F4: API Contract Validation (20 min)

**Objective**: Use the API Contract Agent to ensure backward compatibility

1. Open the file for your chosen backend and modify the `uploadPhoto` endpoint to add a new optional `tags` parameter:

<details>
<summary><strong>NestJS (TypeScript)</strong> — <code>apps/backend-nestjs/src/api/photos/photos.controller.ts</code></summary>

```typescript
async uploadPhoto(
  @UploadedFile(
    new ParseFilePipe({
      validators: [
        new MaxFileSizeValidator({ maxSize: 5 * 1024 * 1024 }), // 5MB
        new FileTypeValidator({
          fileType: /image\/(jpeg|png|gif|webp)/,
          fallbackToMimetype: true,
        }),
      ],
    }),
  )
  file: Express.Multer.File,
  @Body('tags') tags?: string,  // NEW: optional tags to add
): Promise<Photo> {
  const tagsList = tags ? tags.split(',').map(t => t.trim()).filter(Boolean) : [];
  // pass along the parsed tags to the service layer (instead of `[]`)
  return this.photoService.uploadPhoto(file, tagsList);
}
```

</details>

<details>
<summary><strong>Spring Boot (Java)</strong> — <code>apps/backend-spring/src/main/java/com/photogallery/backend/api/photos/PhotosController.java</code></summary>

```java
@PostMapping(path = "/upload", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
@ResponseStatus(HttpStatus.CREATED)
public PhotoResponse uploadPhoto(
    @RequestParam("file") MultipartFile file,
    @RequestParam(value = "tags", required = false) String tags  // NEW: optional tags to add
) {
  List<String> tagsList = parseTags(tags);
  // pass along the parsed tags to the service layer (instead of `List.of()`)
  Photo photo = photoService.uploadPhoto(file, tagsList);
}
```

</details>

<details>
<summary><strong>FastAPI (Python)</strong> — <code>apps/backend-fastapi/app/api/photos.py</code></summary>

```python
async def upload_photo(
    service: ServiceDep,
    file: Annotated[UploadFile, File(description="Image file (JPEG/PNG/GIF/WebP), max 5MB")],
    tags: Annotated[str | None, Form(description="Comma-separated tag list")] = None,  # NEW
) -> Photo:
  tagsList = _parse_tags(tags) if tags else []
  # pass along the parsed tags to the service layer (instead of `[]`)
  return service.upload_photo(
    original_filename=file.filename or "upload",
    data=data,
    tags=tagsList,
  )
```

</details>

<details>
<summary><strong>.NET (C#)</strong> — <code>apps/backend-dotnet/Api/Photos/PhotosController.cs</code></summary>

```csharp
/// <summary>
/// Upload a new photo.
/// </summary>
[HttpPost("upload")]
[Consumes("multipart/form-data")]
[RequestSizeLimit(MaxUploadBytes)]
[ProducesResponseType(typeof(PhotoResponse), StatusCodes.Status201Created)]
[ProducesResponseType(typeof(ErrorEnvelope), StatusCodes.Status400BadRequest)]
public async Task<ActionResult<PhotoResponse>> UploadPhoto(
    [FromForm] UploadPhotoDto dto,
    CancellationToken cancellationToken)
{
   // ... existing validation ...
  var tagsList = ParseTags(dto.Tags);
  // pass along the parsed tags to the service layer (instead of ` new List<string>()`)
  var photo = await _photoService.UploadPhotoAsync(uploaded, tagsList, cancellationToken);
  // ...
}
```

</details>

<details>
<summary><strong>Gin (Go)</strong> — <code>apps/backend-gin/internal/api/photos/handler.go</code></summary>

```go
func (h *Handler) Upload(c *gin.Context) {
    fileHeader, err := c.FormFile("file")

    // ... existing validation ...
    tagsList := parseTags(c.PostForm("tags"))  // NEW: optional tags to add
    // pass along the parsed tags to the service layer (instead of `[]string{}`)
    photo, err := h.service.UploadPhoto(c.Request.Context(), domain.UploadedFile{
      OriginalName:   fileHeader.Filename,
      StoredFilename: storedFilename,
      Size:           fileHeader.Size,
    }, tagsList)
}
```

</details>

2. **Task**: Consult the API Contract Agent:

```
@api-contract-agent I've added an optional 'tags' query parameter to POST /api/photos/upload. Is this backward compatible?
```

3. Generate OpenAPI documentation update:

```
/code-reviewer
```

**Expected Outcome**: Agent validates backward compatibility, suggests OpenAPI schema updates.

### Exercise F5: Test Strategy Consultation (20 min)

**Objective**: Leverage the Test Strategist for test planning

1. Open the PhotoService for your backend:

<details>
<summary><strong>NestJS (TypeScript)</strong></summary>

`apps/backend-nestjs/src/domain/services/photo.service.ts`

</details>
<details>
<summary><strong>Spring Boot (Java)</strong></summary>

`apps/backend-spring/src/main/java/com/photogallery/backend/domain/service/PhotoService.java`

</details>
<details>
<summary><strong>FastAPI (Python)</strong></summary>

`apps/backend-fastapi/app/domain/services.py`

</details>
<details>
<summary><strong>.NET (C#)</strong></summary>

`apps/backend-dotnet/Domain/Services/PhotoService.cs`

</details>
<details>
<summary><strong>Gin (Go)</strong></summary>

`apps/backend-gin/internal/domain/service.go`

</details>

2. **Task**: Ask the Test Strategist about testing a new method:

```
@test-strategist I'm adding a generateThumbnail method to PhotoService. What test strategy should I use?
```

3. Generate tests using the slash command (adjust the path to your backend):

```
/add-tests apps/backend-nestjs/src/domain/services/photo.service.ts
```

**Expected Outcome**: Test strategy recommendation (unit + integration), generated test file with comprehensive coverage.

### Exercise F6: Legacy Modernization (25 min)

**Objective**: Safely refactor legacy callback code

1. Locate the storage/legacy code for your backend:

<details>
<summary><strong>NestJS (TypeScript) — callback-based legacy code</strong></summary>

`apps/backend-nestjs/src/infrastructure/storage/legacy-storage.service.ts`

</details>
<details>
<summary><strong>Spring Boot (Java)</strong></summary>

`apps/backend-spring/src/main/java/com/photogallery/backend/domain/service/PhotoService.java` — look for synchronous blocking patterns to modernize

</details>
<details>
<summary><strong>FastAPI (Python)</strong></summary>

`apps/backend-fastapi/app/infrastructure/storage.py` — look for synchronous I/O to convert to async

</details>
<details>
<summary><strong>.NET (C#)</strong></summary>

`apps/backend-dotnet/Infrastructure/Storage/DiskStorage.cs`

</details>
<details>
<summary><strong>Gin (Go)</strong></summary>

`apps/backend-gin/internal/infrastructure/storage.go`

</details>

2. **Task**: Switch to `plan` permission mode, then request a migration plan:

```
@legacy-modernizer I need to modernize legacy-storage.service.ts from callbacks to async/await. What's the safest approach?
```

3. Execute the plan (adjust the path to your backend):

```
/migration-plan apps/backend-nestjs/src/infrastructure/storage/legacy-storage.service.ts
```

**Expected Outcome**: Step-by-step incremental refactoring plan with risk assessment and rollback strategy.

**Note**: Mistral Vibe supports several permission modes — `default`, `plan`, `accept-edits`, and `auto-approve`. Use `plan` when you want the agent to propose all changes for review before touching files.

### Exercise F7: Skills Application (15 min)

**Objective**: Understand reusable skills

1. Review the reusable skills in `.vibe/skills/`:

   - `topology-awareness` - Dependency mapping
   - `change-impact-analysis` - Risk assessment
   - `incremental-refactoring` - Safe refactoring
   - `framework-conventions` - Pattern enforcement
   - `debug-correlation` - Root cause analysis

2. **Task**: Apply change impact analysis to a hypothetical change:

```
"If I change the PhotoRepository interface, what else will break?"
```

(The `change-impact-analysis` skill activates automatically from context.)

**Expected Outcome**: List of affected files, classes, and tests.

### Exercise F8: TOML Hooks (15 min)

**Objective**: Configure automated validation with TOML hooks

1. Review the hooks declared in `.vibe/hooks.toml`:

```toml
[[hooks.pre_tool_use]]
matcher = "shell"
command = "bash .vibe/hooks/validate-commit.sh"
description = "Block git commits when staged files contain secrets, denied files, or non-conventional subjects."

[[hooks.pre_tool_use]]
matcher = "write"
command = "bash .vibe/hooks/validate-writes.sh"
description = "Scan files for secrets and disallowed filenames before they are written."

[[hooks.post_tool_use]]
matcher = "write|edit"
command = "bash .vibe/hooks/validate-coding-standards.sh"
description = "Warn on coding-standards violations after edits."
```

2. Review the hook scripts in `.vibe/hooks/`:

   - `validate-commit.sh` - Validates staged files before git commits
   - `validate-writes.sh` - Security validation before file writes
   - `validate-coding-standards.sh` - Validates against coding-standards.md after edits

3. **Task**: Make a code change that violates coding standards and observe the hook behavior.

**Expected Outcome**: The post-edit hook warns about coding-standards violations; the pre-commit hook blocks the commit on a non-zero exit code.

**Note**: Mistral Vibe keeps configuration (`config.toml`) and hooks (`hooks.toml`) in separate TOML files. A hook that exits non-zero blocks the associated action.

### Exercise F9: Reference Usage (10 min)

**Objective**: Leverage shared knowledge

1. Review `.vibe/references/`:

   - `architecture.md` - System topology
   - `domain-glossary.md` - Business terms
   - `testing-guidelines.md` - Test patterns
   - `coding-standards.md` - Code conventions
   - `oncall.md` - Incident response

2. **Task**: Get on-call guidance for a production alert:

```
/explain-oncall "High error rate on photo uploads"
```

3. Ask a question that references the domain glossary:

```
"What's the difference between a PhotoAlbum and a PhotoCollection in our domain model?"
```

**Expected Outcome**: Troubleshooting steps from `oncall.md` and an answer derived from `domain-glossary.md`.

### Exercise F10: ACP Mode & Session Continuation (15 min)

**Objective**: Explore Mistral Vibe-unique features: ACP mode and resumable sessions

#### Part 1: Session Continuation (7 min)

1. Start a debugging session:

```
Analyze the photo upload flow and identify potential performance bottlenecks
```

2. Exit Mistral Vibe, then resume the conversation later:

```bash
vibe --continue   # resume the most recent session
# or
vibe --resume     # pick a previous session to resume
```

**Expected Outcome**: The prior conversation context is restored so you can continue where you left off.

#### Part 2: ACP Mode (8 min)

3. Launch Mistral Vibe in ACP (Agent Client Protocol) mode to integrate it with an ACP-compatible editor or client:

```bash
vibe-acp
```

4. Connect your ACP-capable editor to the running `vibe-acp` process and issue a request such as:

```
Review apps/backend-nestjs/src/domain/services/photo.service.ts for architectural compliance
```

**Expected Outcome**: Mistral Vibe serves requests over ACP, letting an external client drive the same agents and skills available in the interactive TUI.

</details>

---

## Assessment

After completing your platform's exercises, evaluate your understanding:

1. **Agent/Command Mastery**: Can you invoke the right agent/command for each scenario?
2. **Skill Awareness**: Do you understand when skills are automatically invoked?
3. **Reference Utilization**: Can you navigate shared knowledge effectively?
4. **Platform Conventions**: Do you understand platform-specific syntax differences?
5. **Team Collaboration**: Could you onboard a teammate to this setup?

## Next Steps

- Explore the other two platform sections to understand cross-platform patterns
- Review [AGENTS.md](photo-gallery-fullstack/AGENTS.md) for platform comparison
- Adapt configurations for your own team's projects
- Consider hybrid approaches (e.g., Claude + Copilot on same codebase)

## Troubleshooting

- **Commands not recognized**: Verify platform CLI installation and configuration file paths
- **Hooks not executing**: Check file permissions (`chmod +x .gemini/hooks/*.sh`)
- **References not loading**: Ensure relative paths are correct in settings files
- **Skills not invoked**: Check skills array configuration in settings.json
- **Codex config not loading**: Run `codex trust .` to trust the project
- **Codex skills not activating**: Check skill descriptions match your task; try explicit `$skill-name` invocation

## Resources

- [Module 6 Slides](../../docs/markdown/60_module_6_team_augmented/)
- [AGENTS.md - Cross-Platform Reference](photo-gallery-fullstack/AGENTS.md) (also Codex project instructions)
- [Claude Setup Guide](photo-gallery-fullstack/CLAUDE.md)
- [Gemini Setup Guide](photo-gallery-fullstack/GEMINI.md)
