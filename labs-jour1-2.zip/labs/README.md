# Labs Overview

This folder contains all hands-on exercises for the SFEIR Institute "GenAI Augmented Developer" training. Each lab is designed to reinforce the concepts learned in the corresponding module and provide practical experience with AI coding tools and techniques.

## Module 12 — MCP Server Creation

| Lab                                                       | Track      | Duration | Description                                                 |
| --------------------------------------------------------- | ---------- | -------- | ----------------------------------------------------------- |
| [lab-121-mcp-typescript-sdk](lab-121-mcp-typescript-sdk/) | TypeScript | ~65 min  | Build a Photo Metadata Extractor MCP server with the TS SDK |
| [lab-122-mcp-java-sdk](lab-122-mcp-java-sdk/)             | Java       | ~65 min  | Build a Photo Metadata Extractor MCP server with Spring AI  |

> **Note**: Labs 121 and 122 are **mutually exclusive** — deliver only one per session based on the audience's primary language.
