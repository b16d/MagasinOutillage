# Lab 41 Solution: Agentic Tools Deep Dive

> **Audience: trainees.** Read this after attempting the lab. It walks through the expected
> result and the reasoning behind it.

## Solution Reference

The complete solutions for all lab exercises are the pre-built configuration files in the **photo-gallery-fullstack** project:

```
labs/lab-41-agentic-tools-deep-dive-solution/resources/photo-gallery-fullstack-solution/
```

### Platform-Specific Solution Locations

| Platform           | Config Directory | Key Files                                                                                                            |
| ------------------ | ---------------- | -------------------------------------------------------------------------------------------------------------------- |
| **Claude Code**    | `.claude/`       | `agents/`, `commands/`, `skills/`, `plugins/`, `rules/`, `settings.json`                                             |
| **GitHub Copilot** | `.github/`       | `agents/`, `prompts/`, `instructions/`, `skills/`, `hooks/`, `copilot-instructions.md`, plugins via `copilot plugin` |
| **Gemini CLI**     | `.gemini/`       | `agents/` (exp.), `commands/`, `skills/`, `hooks/`, `settings.json`, extensions via `gemini extensions`              |
| **Codex CLI**      | `.codex/`        | `agents/*.toml`, `skills/`, `rules/`, `references/`, `config.toml` + root `AGENTS.md`                                |
| **OpenCode**       | `.opencode/`     | `agents/*.md`, `commands/*.md`, `skills/`, `plugins/` + root `AGENTS.md` + `opencode.json`                           |
| **Mistral Vibe**   | `.vibe/`         | `agents/*.md`, `skills/` (slash commands), `references/`, `hooks.toml`, `config.toml` + root `AGENTS.md`             |

### Cross-Platform Feature Reference

All platforms share the same agent skill (SKILL.md format):

- `change-impact-analysis` - Risk assessment and blast radius

All platforms share the same 5 reference documents:

- `architecture.md` - System topology and layering
- `coding-standards.md` - TypeScript/Angular/NestJS conventions
- `domain-glossary.md` - Business terminology
- `testing-guidelines.md` - Testing strategies and patterns
- `oncall.md` - Incident escalation procedures

---

## Walkthrough by Section

Every exercise below maps to a file in
`resources/photo-gallery-fullstack-solution/`. Two exercises produce no committed artifact and say so.

Three things recur across all six platforms, and they are the point of the lab:

1. **Context file first.** Every track opens by writing the tool's root instruction file. Everything
   afterwards references it. A trainee who rushes this ends up with agents that re-explain the
   project in every prompt.
2. **The five `references/` files are the payload.** Agents, commands and skills are thin wrappers;
   the knowledge lives in `architecture.md`, `coding-standards.md`, `domain-glossary.md`,
   `testing-guidelines.md` and `oncall.md`. They are pre-seeded so trainees configure rather than write prose.
3. **The same `SKILL.md` works everywhere.** `change-impact-analysis` is byte-identical across the
   six platforms. That is the single most transferable thing in this lab.

---

### Section A: Claude Code

| Exercise                            | Solution artifact                                                                         | Watch for                                                                                                                                      |
| ----------------------------------- | ----------------------------------------------------------------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------- |
| A1 Initialize CLAUDE.md             | `CLAUDE.md` (root)                                                                        | `/init` generates a draft; it must then be _edited_. The generated version describes the tree, not the conventions                             |
| A2 Create Claude Rules              | `.claude/rules/backend-{nestjs,spring,fastapi,dotnet,gin}-rules.md` + `frontend-rules.md` | Six files, one per stack. Trainees write only the one matching their backend                                                                   |
| A3 Create a Custom Agent            | `.claude/agents/architecture-guardian.md`                                                 | YAML frontmatter with `name` and `description`. A missing `description` means the agent never auto-activates                                   |
| A4 Create an Agent Team             | _no artifact_ — `CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS=1` in `.claude/settings.json`       | Experimental, and token-hungry. Teammates talk to each other, unlike subagents which only report back                                          |
| A5 Create a Custom Command          | `.claude/commands/code-reviewer.md`                                                       | Invoked as `/code-reviewer`. The filename _is_ the command name                                                                                |
| A6 Create an Agent Skill            | `.claude/skills/change-impact-analysis/SKILL.md`                                          | Directory name = skill name; the file must be exactly `SKILL.md`                                                                               |
| A7 Install a Skill from Registry    | _no artifact_ — installed from a public registry at runtime                               | Nothing to commit. The exercise is about provenance: read a third-party skill before trusting it                                               |
| A8 Evaluate an Agent Skill          | _no artifact_ — `npx --yes tessl review run …`                                            | Output is a review score, not a file                                                                                                           |
| A9 Configure Hooks                  | `.claude/settings.json` (`hooks` block)                                                   | Three hooks configured. A hook that exits non-zero blocks the tool call                                                                        |
| A10 Create a Plugin                 | `.claude/plugins/team-workflows/` + `.claude/marketplaces/sfeir-marketplace/`             | The richest artifact in the lab: 4 agents, 4 commands, 4 skills, `hooks/hooks.json` and 2 MCP server definitions, all behind one `plugin.json` |
| A11 Configure Settings _(optional)_ | `.claude/settings.json`, `settings.local.json`                                            | `settings.local.json` is per-developer and git-ignored; `settings.json` is the team's                                                          |

**The lesson in A10**: a plugin is how one person's configuration becomes the team's. Everything from
A3 to A9 was local; the plugin packages it for distribution through a marketplace.

---

### Section B: GitHub Copilot

| Exercise                       | Solution artifact                                                                      | Watch for                                                                                                                               |
| ------------------------------ | -------------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------- |
| B1-B2 copilot-instructions.md  | `.github/copilot-instructions.md`                                                      | B1 is the minimal version, B2 the full one. Compare them: B2 is what actually changes Copilot's output                                  |
| B3 Create an Instruction       | `.github/instructions/architecture-{nestjs,spring,fastapi,dotnet,gin}.instructions.md` | The `applyTo` frontmatter glob is what scopes an instruction to a path. Omit it and it applies everywhere                               |
| B4 Create a Prompt             | `.github/prompts/code-reviewer.prompt.md`                                              | Prompts are user-invoked; instructions are automatic. That distinction has no equivalent in Claude Code                                 |
| B5 Create a Custom Agent       | `.github/agents/architecture-guardian.agent.md`                                        | Note the double extension `.agent.md`                                                                                                   |
| B6 Use /delegate               | _no artifact_ — runtime feature                                                        | Background agents run detached; this is Copilot's answer to Claude's agent teams                                                        |
| B7-B9 Skill, install, evaluate | `.github/skills/change-impact-analysis/SKILL.md`                                       | Same `SKILL.md` as every other platform                                                                                                 |
| B10 Configure Hooks            | `.github/hooks/code-reviewer.json` + `hooks/scripts/validate-commit.{sh,ps1}`          | **Two scripts, one per OS.** Copilot is the only track that ships both a shell and a PowerShell variant — worth showing a mixed-OS room |
| B11 Create a Plugin            | `.github/plugins/team-workflows/`                                                      | Thinner than Claude's: `plugin.json`, one agent, one prompt                                                                             |

---

### Section C: Gemini CLI

| Exercise                       | Solution artifact                                                                      | Watch for                                                                                           |
| ------------------------------ | -------------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------------- |
| C1 Initialize GEMINI.md        | `GEMINI.md` (root)                                                                     | Gemini does not read `AGENTS.md`; it needs its own file                                             |
| C2 Create a Custom Agent       | `.gemini/agents/architecture-guardian.md`                                              | Agent support is **experimental** — behaviour changes between releases                              |
| C3 Create a Custom Command     | `.gemini/commands/code-reviewer.toml`                                                  | **TOML, not Markdown.** The prompt lives in a `prompt` key. This trips up anyone coming from Claude |
| C4-C6 Skill, install, evaluate | `.gemini/skills/change-impact-analysis/SKILL.md`                                       | Standard                                                                                            |
| C7 Configure Hooks             | `.gemini/hooks/validate-{coding-standards,commit,writes}.sh` + `.gemini/settings.json` | Three hooks, wired in `settings.json`. Shell only                                                   |
| C8 Explore Extensions          | _no artifact_ — `gemini extensions`                                                    | Runtime exploration                                                                                 |
| C9 Configure Settings          | `.gemini/settings.json`                                                                | One file carries hooks _and_ settings, unlike the other platforms                                   |

---

### Section D: Codex CLI

| Exercise                       | Solution artifact                                  | Watch for                                                                                                                                                                                            |
| ------------------------------ | -------------------------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| D1 Initialize AGENTS.md        | `AGENTS.md` (root)                                 | Codex reads the cross-platform `AGENTS.md` standard directly                                                                                                                                         |
| D2 Create a Custom Agent       | `.codex/agents/architecture-guardian.toml`         | **TOML**, and it must be declared in the `[agents]` section of `config.toml` or it is silently ignored                                                                                               |
| D3-D5 Skill, install, evaluate | `.codex/skills/change-impact-analysis/SKILL.md`    | Standard                                                                                                                                                                                             |
| D6 Configure Codex Rules       | `.codex/rules/project.rules`                       | **Starlark**, a Python-like language. This is Codex's replacement for hooks: a static policy evaluated at command-invocation time, with no shell script involved. Test with `codex execpolicy check` |
| D7 Sandbox and Approvals       | `.codex/config.toml` (`[sandbox_workspace_write]`) | `writable_roots` plus `network_access = false`. The strictest sandbox of the six platforms                                                                                                           |
| D8 Configure Profiles          | `.codex/config.toml` (`[profiles.*]`)              | Named profiles switch model and approval policy together                                                                                                                                             |

**Why this track is shorter**: no slash-command system, and Rules replace hooks — one exercise where
the other platforms need two. Eight exercises, ~95 minutes. Trainees finish early; send them to
compare another section rather than inventing work.

---

### Section E: OpenCode

| Exercise                       | Solution artifact                                               | Watch for                                                                                                                                        |
| ------------------------------ | --------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------ |
| E1 Initialize AGENTS.md        | `AGENTS.md` (root) + `opencode.json`                            | Reads the `AGENTS.md` standard, like Codex and Vibe                                                                                              |
| E2 Explore Built-in Modes      | _no artifact_                                                   | Build / Plan modes, switched with `Tab`                                                                                                          |
| E3 Create a Custom Agent       | `.opencode/agents/architecture-guardian.md`                     | Markdown with frontmatter, like Claude                                                                                                           |
| E4 Create a Custom Command     | `.opencode/commands/code-reviewer.md`                           | ⚠️ In **lab 61** the directory is `.opencode/command/` (singular). Check which the tool version expects — a wrong name fails silently            |
| E5-E7 Skill, install, evaluate | `.opencode/skills/change-impact-analysis/SKILL.md`              | Standard                                                                                                                                         |
| E8 Create a Plugin             | `.opencode/plugins/coding-standards.ts` and `env-protection.js` | **TypeScript/JavaScript modules**, not config. They export an async function returning lifecycle handlers (`tool.execute.before`, `file.edited`) |
| E9 Configure OpenCode          | `opencode.json`                                                 | Root-level, not inside `.opencode/`                                                                                                              |

**The lesson in E8**: `coding-standards.ts` reads `references/coding-standards.md` at load time and
derives its rule from that document. The convention and its enforcement cannot drift apart, because
there is only one source. That pattern transfers to every other platform.

---

### Section F: Mistral Vibe

| Exercise                      | Solution artifact                              | Watch for                                                                                                                                                                       |
| ----------------------------- | ---------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| F1 Initialize AGENTS.md       | `AGENTS.md` (root)                             | Auto-read at session start, once the folder is trusted                                                                                                                          |
| F2 Explore Built-in Agents    | _no artifact_                                  | Runtime exploration                                                                                                                                                             |
| F3 Create a Custom Agent      | `.vibe/agents/architecture-guardian.md`        | Markdown with frontmatter                                                                                                                                                       |
| F4 Create a Custom Command    | `.vibe/skills/code-reviewer/SKILL.md`          | **Vibe unifies skills and slash commands into one system.** A "command" is a skill invoked with `/`                                                                             |
| F5-F6 Skill and install       | `.vibe/skills/change-impact-analysis/SKILL.md` | Same file, different invocation path                                                                                                                                            |
| F7 Configure Hooks            | `.vibe/hooks.toml`                             | **TOML, and no script at all.** Both hooks are `type = "prompt"`: the gate is a natural-language instruction the model evaluates, not an exit code. Unique among the six tracks |
| F8 Session Continuation & ACP | _no artifact_ — `vibe --continue`, `vibe-acp`  | ACP lets Vibe drive an external editor                                                                                                                                          |
| F9 Configure Vibe             | `.vibe/config.toml`                            | Folder trust is set here; without it the project config is not loaded at all                                                                                                    |

---

## Cross-Platform Comparison

The same five capabilities, six different shapes. This table is the summary worth putting on screen
at the end of the lab:

| Capability   | Claude Code          | Copilot                   | Gemini CLI   | Codex CLI          | OpenCode       | Mistral Vibe           |
| ------------ | -------------------- | ------------------------- | ------------ | ------------------ | -------------- | ---------------------- |
| Context file | `CLAUDE.md`          | `copilot-instructions.md` | `GEMINI.md`  | `AGENTS.md`        | `AGENTS.md`    | `AGENTS.md`            |
| Agents       | `.md` + frontmatter  | `.agent.md`               | `.md` (exp.) | `.toml`            | `.md`          | `.md`                  |
| Commands     | `.md`                | `.prompt.md`              | `.toml`      | **none**           | `.md`          | skill invoked with `/` |
| Skills       | `SKILL.md`           | `SKILL.md`                | `SKILL.md`   | `SKILL.md`         | `SKILL.md`     | `SKILL.md`             |
| Enforcement  | JSON hooks           | JSON + sh/ps1             | sh hooks     | **Starlark rules** | **TS plugins** | TOML + Python          |
| Packaging    | plugin + marketplace | plugin                    | extensions   | profiles           | plugins        | skills                 |

**Read the rows, not the columns.** Skills are identical everywhere — write one, use it on six tools.
Enforcement is different everywhere — and a team that standardises on one tool's hook format has
bought a migration cost it has not priced.

---

## Common Failure Modes

What actually goes wrong in the room, in rough order of frequency:

1. **Frontmatter typo → agent never activates.** No error message; the agent simply is not offered.
   Have the trainee list the agents before debugging the prompt.
2. **Wrong directory name.** `commands/` vs `command/`, `.agent.md` vs `.md`, `skills/` vs `skill/`.
   All fail silently.
3. **Skill directory does not match the skill name.** The folder name is the identifier; `SKILL.md`
   is the fixed filename. Swapping the two is a common first attempt.
4. **Codex agent not declared in `config.toml`.** The `.toml` file exists and is ignored.
5. **Hook not executable.** On Unix, a `.sh` without `+x` fails in a way the tool reports as a
   generic hook error.
6. **Editing the solution instead of the exercise project.** Check the path before debugging anything.

### Evaluation Criteria

Your lab exercises are successful if:

1. **Files are correctly structured**: YAML frontmatter is valid, file suffixes match platform conventions
2. **Features are functional**: Agents respond when invoked, commands execute, hooks trigger
3. **Content is relevant**: Agents reference appropriate context files, commands produce useful output
4. **Configuration is secure**: Hooks validate quality, settings restrict dangerous operations
