/**
 * Photo Gallery
 * Grid of picsum.photos images with an accessible lightbox:
 * prev/next navigation, keyboard (←, →, Esc, Home, End), swipe, loading states.
 */
(() => {
  'use strict';

  const CONFIG = {
    photoCount: 24,
    listEndpoint: 'https://picsum.photos/v2/list?page=3&limit=24',
    thumbSize: { width: 600, height: 450 },
    fullSize: { width: 1600, height: 1200 },
    listTimeoutMs: 4000,
    closeTransitionMs: 300,
    swipeThresholdPx: 50,
  };

  const els = {
    gallery: document.getElementById('gallery'),
    status: document.getElementById('gallery-status'),
    lightbox: document.getElementById('lightbox'),
    image: document.getElementById('lightbox-image'),
    spinner: document.getElementById('lightbox-spinner'),
    title: document.getElementById('lightbox-title'),
    counter: document.getElementById('lightbox-counter'),
    closeBtn: document.getElementById('lightbox-close'),
    prevBtn: document.getElementById('lightbox-prev'),
    nextBtn: document.getElementById('lightbox-next'),
  };

  const state = {
    photos: [],
    currentIndex: -1,
    isOpen: false,
    lastFocused: null,
    loadToken: 0,
    closeTimer: null,
    touchStartX: 0,
    touchStartY: 0,
  };

  // ===== Data =====

  const picsumUrl = (photo, { width, height }) =>
    photo.id != null
      ? `https://picsum.photos/id/${photo.id}/${width}/${height}`
      : `https://picsum.photos/seed/${encodeURIComponent(photo.seed)}/${width}/${height}`;

  /** Fetch real photo metadata (author names); fall back to seeded images if offline/slow. */
  async function loadPhotos() {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), CONFIG.listTimeoutMs);
    try {
      const res = await fetch(CONFIG.listEndpoint, { signal: controller.signal });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const list = await res.json();
      return list.slice(0, CONFIG.photoCount).map((item) => ({
        id: item.id,
        title: `Photo by ${item.author}`,
      }));
    } catch {
      return Array.from({ length: CONFIG.photoCount }, (_, i) => ({
        seed: `gallery-${i + 1}`,
        title: `Photo ${i + 1}`,
      }));
    } finally {
      clearTimeout(timeout);
    }
  }

  // ===== Gallery =====

  /** Placeholder tiles shown while photo metadata is being fetched. */
  function renderSkeletons() {
    const items = Array.from({ length: CONFIG.photoCount }, (_, index) => {
      const li = document.createElement('li');
      li.className = 'gallery-item';
      li.style.setProperty('--i', index);
      li.setAttribute('aria-hidden', 'true');
      const tile = document.createElement('div');
      tile.className = 'gallery-button';
      li.append(tile);
      return li;
    });
    els.gallery.replaceChildren(...items);
  }

  function renderGallery() {
    const fragment = document.createDocumentFragment();

    state.photos.forEach((photo, index) => {
      const li = document.createElement('li');
      li.className = 'gallery-item';
      li.style.setProperty('--i', index);

      const button = document.createElement('button');
      button.type = 'button';
      button.className = 'gallery-button';
      button.dataset.index = index;
      button.setAttribute('aria-label', `Open ${photo.title} (${index + 1} of ${state.photos.length})`);

      const img = document.createElement('img');
      img.alt = photo.title;
      img.loading = 'lazy';
      img.decoding = 'async';
      img.width = CONFIG.thumbSize.width;
      img.height = CONFIG.thumbSize.height;
      img.addEventListener('load', () => button.classList.add('is-loaded'), { once: true });
      img.addEventListener('error', () => {
        button.classList.add('is-error');
        button.disabled = true;
      }, { once: true });
      img.src = picsumUrl(photo, CONFIG.thumbSize);

      const label = document.createElement('span');
      label.className = 'gallery-label';
      label.textContent = photo.title;
      label.setAttribute('aria-hidden', 'true');

      button.append(img, label);
      li.append(button);
      fragment.append(li);
    });

    els.gallery.replaceChildren(fragment);
    els.status.textContent = `${state.photos.length} photos`;
  }

  // ===== Lightbox =====

  function openLightbox(index) {
    clearTimeout(state.closeTimer);
    state.lastFocused = document.activeElement;
    state.isOpen = true;

    els.lightbox.hidden = false;
    els.lightbox.setAttribute('aria-hidden', 'false');
    // Force reflow so the opacity transition runs after un-hiding.
    void els.lightbox.offsetWidth;
    els.lightbox.classList.add('is-open');
    document.body.classList.add('no-scroll');

    const hasMany = state.photos.length > 1;
    els.prevBtn.hidden = !hasMany;
    els.nextBtn.hidden = !hasMany;

    showPhoto(index, 0);
    els.closeBtn.focus({ preventScroll: true });
  }

  function closeLightbox() {
    if (!state.isOpen) return;
    state.isOpen = false;
    state.loadToken++; // cancel any in-flight load

    els.lightbox.classList.remove('is-open');
    els.lightbox.setAttribute('aria-hidden', 'true');
    document.body.classList.remove('no-scroll');

    state.closeTimer = setTimeout(() => {
      els.lightbox.hidden = true;
      els.image.removeAttribute('src');
      els.image.classList.remove('is-visible');
    }, CONFIG.closeTransitionMs);

    if (state.lastFocused instanceof HTMLElement) {
      state.lastFocused.focus({ preventScroll: true });
    }
  }

  /**
   * Display the photo at `index`. `direction` (-1, 0, 1) controls the slide-in animation.
   * A token guards against out-of-order loads when the user navigates quickly.
   */
  function showPhoto(index, direction) {
    const count = state.photos.length;
    state.currentIndex = (index + count) % count;
    const photo = state.photos[state.currentIndex];
    const token = ++state.loadToken;

    els.title.textContent = photo.title;
    els.counter.textContent = `${state.currentIndex + 1} / ${count}`;
    els.image.alt = photo.title;
    els.image.classList.remove('is-visible', 'slide-from-left', 'slide-from-right');
    if (direction > 0) els.image.classList.add('slide-from-right');
    if (direction < 0) els.image.classList.add('slide-from-left');
    els.spinner.classList.add('is-active');

    const loader = new Image();
    loader.decoding = 'async';
    loader.onload = () => {
      if (token !== state.loadToken) return;
      els.image.src = loader.src;
      els.spinner.classList.remove('is-active');
      requestAnimationFrame(() => {
        els.image.classList.remove('slide-from-left', 'slide-from-right');
        els.image.classList.add('is-visible');
      });
      preloadNeighbors();
    };
    loader.onerror = () => {
      if (token !== state.loadToken) return;
      els.spinner.classList.remove('is-active');
      els.title.textContent = `${photo.title} — failed to load`;
    };
    loader.src = picsumUrl(photo, CONFIG.fullSize);
  }

  function preloadNeighbors() {
    const count = state.photos.length;
    [1, -1].forEach((offset) => {
      const photo = state.photos[(state.currentIndex + offset + count) % count];
      new Image().src = picsumUrl(photo, CONFIG.fullSize);
    });
  }

  const showNext = () => showPhoto(state.currentIndex + 1, 1);
  const showPrev = () => showPhoto(state.currentIndex - 1, -1);

  // ===== Events =====

  function onKeydown(event) {
    if (!state.isOpen) return;

    switch (event.key) {
      case 'Escape':
        event.preventDefault();
        closeLightbox();
        break;
      case 'ArrowRight':
        event.preventDefault();
        showNext();
        break;
      case 'ArrowLeft':
        event.preventDefault();
        showPrev();
        break;
      case 'Home':
        event.preventDefault();
        showPhoto(0, -1);
        break;
      case 'End':
        event.preventDefault();
        showPhoto(state.photos.length - 1, 1);
        break;
      case 'Tab':
        trapFocus(event);
        break;
      default:
        break;
    }
  }

  /** Keep keyboard focus inside the lightbox while it is open. */
  function trapFocus(event) {
    const focusable = [els.closeBtn, els.prevBtn, els.nextBtn].filter((el) => !el.hidden);
    const first = focusable[0];
    const last = focusable[focusable.length - 1];

    if (event.shiftKey && document.activeElement === first) {
      event.preventDefault();
      last.focus();
    } else if (!event.shiftKey && document.activeElement === last) {
      event.preventDefault();
      first.focus();
    } else if (!focusable.includes(document.activeElement)) {
      event.preventDefault();
      first.focus();
    }
  }

  function onTouchStart(event) {
    const touch = event.changedTouches[0];
    state.touchStartX = touch.clientX;
    state.touchStartY = touch.clientY;
  }

  function onTouchEnd(event) {
    const touch = event.changedTouches[0];
    const dx = touch.clientX - state.touchStartX;
    const dy = touch.clientY - state.touchStartY;
    // Horizontal swipe only; ignore mostly-vertical gestures.
    if (Math.abs(dx) < CONFIG.swipeThresholdPx || Math.abs(dx) < Math.abs(dy)) return;
    if (dx < 0) showNext();
    else showPrev();
  }

  function bindEvents() {
    els.gallery.addEventListener('click', (event) => {
      const button = event.target.closest('.gallery-button');
      if (button && !button.disabled) openLightbox(Number(button.dataset.index));
    });

    els.lightbox.addEventListener('click', (event) => {
      if (event.target.closest('[data-close]')) closeLightbox();
    });

    els.prevBtn.addEventListener('click', showPrev);
    els.nextBtn.addEventListener('click', showNext);

    els.lightbox.addEventListener('touchstart', onTouchStart, { passive: true });
    els.lightbox.addEventListener('touchend', onTouchEnd, { passive: true });

    document.addEventListener('keydown', onKeydown);
  }

  // ===== Init =====

  async function init() {
    bindEvents();
    renderSkeletons();
    state.photos = await loadPhotos();
    renderGallery();
  }

  init();
})();
