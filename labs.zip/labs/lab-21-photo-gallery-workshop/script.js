/**
 * Photo Gallery Application
 * Modern, responsive photo gallery with modal lightbox
 */

// ===== Configuration =====
const CONFIG = {
    imageCount: 12,
    imageWidth: 500,
    imageHeight: 500,
    baseUrl: 'https://picsum.photos',
    seedPrefix: 'gallery-',
    loadingDelay: 1000, // Minimum loading time for UX
};

// ===== State =====
const state = {
    photos: [],
    currentIndex: -1,
    isModalOpen: false,
    isLoading: true,
};

// ===== DOM Elements =====
const elements = {
    gallery: document.getElementById('gallery'),
    modal: document.getElementById('modal'),
    modalImage: document.getElementById('modalImage'),
    caption: document.getElementById('caption'),
    closeModal: document.getElementById('closeModal'),
    prevBtn: document.getElementById('prevBtn'),
    nextBtn: document.getElementById('nextBtn'),
    loading: document.getElementById('loading'),
};

// ===== Utility Functions =====
function generateRandomSeed(index) {
    return `${CONFIG.seedPrefix}${index}`;
}

function getImageUrl(index, width = CONFIG.imageWidth, height = CONFIG.imageHeight) {
    const seed = generateRandomSeed(index);
    return `${CONFIG.baseUrl}/seed/${seed}/${width}/${height}`;
}

function generateCaption(index) {
    const captions = [
        'Sunset over the mountains',
        'Autumn forest path',
        'Ocean waves at dusk',
        'City lights at night',
        'Tropical beach paradise',
        'Mountain peak view',
        'Serene lake reflection',
        'Urban architecture',
        'Wildflower meadow',
        'Desert sand dunes',
        'Snow covered landscape',
        'Tropical waterfall',
        'Ancient temple ruins',
        'Colorful hot air balloons',
        'Vibrant street market',
        'Peaceful river journey',
    ];
    return captions[index % captions.length] || `Photo ${index + 1}`;
}

// ===== Gallery Initialization =====
async function initGallery() {
    state.isLoading = true;
    elements.loading.classList.remove('hidden');
    
    // Simulate minimum loading time for better UX
    const loadStart = Date.now();
    
    try {
        // Create photo data
        state.photos = Array.from({ length: CONFIG.imageCount }, (_, index) => ({
            id: index,
            url: getImageUrl(index),
            thumbnailUrl: getImageUrl(index, 300, 300),
            caption: generateCaption(index),
            loaded: false,
        }));
        
        // Wait for minimum loading time
        const elapsed = Date.now() - loadStart;
        if (elapsed < CONFIG.loadingDelay) {
            await new Promise(resolve => setTimeout(resolve, CONFIG.loadingDelay - elapsed));
        }
        
        renderGallery();
        
    } catch (error) {
        console.error('Error initializing gallery:', error);
        // Fallback with static images
        state.photos = Array.from({ length: CONFIG.imageCount }, (_, index) => ({
            id: index,
            url: `https://picsum.photos/500/500?random=${index}`,
            thumbnailUrl: `https://picsum.photos/300/300?random=${index}`,
            caption: `Photo ${index + 1}`,
            loaded: false,
        }));
        renderGallery();
    } finally {
        state.isLoading = false;
        elements.loading.classList.add('hidden');
    }
}

function renderGallery() {
    elements.gallery.innerHTML = '';
    
    state.photos.forEach((photo, index) => {
        const galleryItem = document.createElement('div');
        galleryItem.className = 'gallery-item';
        galleryItem.dataset.index = index;
        galleryItem.setAttribute('role', 'button');
        galleryItem.setAttribute('aria-label', `View photo: ${photo.caption}`);
        galleryItem.tabIndex = 0;
        
        const img = document.createElement('img');
        img.src = photo.thumbnailUrl;
        img.alt = photo.caption;
        img.loading = 'lazy';
        img.decoding = 'async';
        
        // Add loading state for individual images
        img.addEventListener('load', () => {
            photo.loaded = true;
            galleryItem.classList.add('loaded');
        });
        
        img.addEventListener('error', () => {
            console.warn(`Failed to load image: ${photo.url}`);
            // Fallback image
            img.src = `https://via.placeholder.com/${CONFIG.imageWidth}x${CONFIG.imageHeight}?text=Photo+${index + 1}`;
        });
        
        galleryItem.appendChild(img);
        galleryItem.addEventListener('click', () => openModal(index));
        galleryItem.addEventListener('keydown', (e) => {
            if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                openModal(index);
            }
        });
        
        elements.gallery.appendChild(galleryItem);
    });
}

// ===== Modal Functions =====
function openModal(index) {
    state.currentIndex = index;
    state.isModalOpen = true;
    updateModalContent();
    elements.modal.classList.add('active');
    document.body.style.overflow = 'hidden';
    
    // Focus on modal for keyboard navigation
    elements.modal.focus();
    
    // Update button states
    updateNavButtonStates();
}

function closeModal() {
    state.isModalOpen = false;
    elements.modal.classList.remove('active');
    document.body.style.overflow = '';
    
    // Return focus to the clicked gallery item
    const galleryItems = document.querySelectorAll('.gallery-item');
    if (state.currentIndex >= 0 && galleryItems[state.currentIndex]) {
        galleryItems[state.currentIndex].focus();
    }
}

function updateModalContent() {
    const photo = state.photos[state.currentIndex];
    if (!photo) return;
    
    // Use high-res image for modal
    elements.modalImage.src = photo.url;
    elements.modalImage.alt = photo.caption;
    elements.caption.textContent = photo.caption;
}

function navigate(direction) {
    const newIndex = state.currentIndex + direction;
    
    if (newIndex >= 0 && newIndex < state.photos.length) {
        state.currentIndex = newIndex;
        updateModalContent();
        updateNavButtonStates();
    }
}

function updateNavButtonStates() {
    elements.prevBtn.disabled = state.currentIndex === 0;
    elements.nextBtn.disabled = state.currentIndex === state.photos.length - 1;
}

// ===== Event Listeners =====
function setupEventListeners() {
    // Close modal on button click
    elements.closeModal.addEventListener('click', closeModal);
    
    // Navigation buttons
    elements.prevBtn.addEventListener('click', () => navigate(-1));
    elements.nextBtn.addEventListener('click', () => navigate(1));
    
    // Close modal on background click
    elements.modal.addEventListener('click', (e) => {
        if (e.target === elements.modal) {
            closeModal();
        }
    });
    
    // Keyboard navigation
    document.addEventListener('keydown', (e) => {
        if (!state.isModalOpen) return;
        
        switch (e.key) {
            case 'Escape':
                closeModal();
                break;
            case 'ArrowLeft':
                navigate(-1);
                break;
            case 'ArrowRight':
                navigate(1);
                break;
            case 'Home':
                state.currentIndex = 0;
                updateModalContent();
                updateNavButtonStates();
                break;
            case 'End':
                state.currentIndex = state.photos.length - 1;
                updateModalContent();
                updateNavButtonStates();
                break;
        }
    });
    
    // Handle window resize for responsive adjustments
    window.addEventListener('resize', () => {
        if (state.isModalOpen) {
            // Recalculate max image size on resize
            updateModalContent();
        }
    });
    
    // Prevent body scroll when modal is open
    elements.modal.addEventListener('wheel', (e) => {
        if (state.isModalOpen) {
            e.preventDefault();
        }
    });
}

// ===== Image Preloading =====
function preloadImages() {
    state.photos.forEach(photo => {
        const img = new Image();
        img.src = photo.url;
        img.loading = 'lazy';
    });
}

// ===== Image Loading Tracking =====
function setupImageLoadingTracker() {
    let loadedCount = 0;
    const totalImages = state.photos.length;
    
    state.photos.forEach((photo, index) => {
        const img = new Image();
        img.src = photo.thumbnailUrl;
        img.onload = () => {
            loadedCount++;
            state.photos[index].loaded = true;
            
            // Update progress if still loading
            if (state.isLoading) {
                const progress = Math.round((loadedCount / totalImages) * 100);
                const loadingText = elements.loading.querySelector('p');
                if (loadingText) {
                    loadingText.textContent = `Loading gallery... ${progress}%`;
                }
            }
            
            // All images loaded
            if (loadedCount === totalImages && state.isLoading) {
                const elapsed = Date.now() - loadStart;
                if (elapsed >= CONFIG.loadingDelay) {
                    state.isLoading = false;
                    elements.loading.classList.add('hidden');
                }
            }
        };
    });
}

// ===== Initialize Application =====
let loadStart = Date.now();

// Start the application
async function init() {
    setupEventListeners();
    await initGallery();
    preloadImages();
    setupImageLoadingTracker();
}

// Run initialization
init();

// ===== Graceful Degradation =====
// Handle cases where JavaScript is disabled or fails
window.addEventListener('error', (e) => {
    console.error('Gallery error:', e.message);
    // Show error message to user
    const errorMessage = document.createElement('div');
    errorMessage.style.cssText = `
        position: fixed;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        background: white;
        padding: 20px;
        border-radius: 8px;
        box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        z-index: 2000;
    `;
    errorMessage.innerHTML = `
        <h3>Gallery Error</h3>
        <p>Sorry, there was an error loading the gallery. Please refresh the page.</p>
    `;
    document.body.appendChild(errorMessage);
});
